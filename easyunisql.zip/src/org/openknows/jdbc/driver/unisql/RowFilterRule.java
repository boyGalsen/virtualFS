package org.openknows.jdbc.driver.unisql;

public interface RowFilterRule {
  
  public static RowFilterRule referenceTrue = new RowFilterRule() {
    
    public boolean check(final Row row) { 
      
      return true; 
    }};
  public static RowFilterRule referenceFalse = new RowFilterRule() {
    
    public boolean check(final Row row) { 
      return false; 
    }
  };

  public boolean check(final Row row);
}

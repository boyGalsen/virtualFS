package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.*;

import java.util.*;

public interface DatabaseValue {

  public Object getOriginalValue();
  public boolean isNull(); 
  public boolean isDoubleAvailable();
  public double getdoubleValue();
  public Double getDoubleValue();
  public boolean isIntAvailable();
  public long getintValue();
  public Long getIntegerValue();
  public String getStringValue();
  public boolean isBooleanAvailable();
  public boolean getbooleanValue();
  public Boolean getBooleanValue();
  public Date getDateValue();
  public boolean isDateAvailable();
  
  public boolean isIgnored();
  
  public DatabaseValue getSubValue(String key);
  public EzArray<String> getSubValueKeys();
}

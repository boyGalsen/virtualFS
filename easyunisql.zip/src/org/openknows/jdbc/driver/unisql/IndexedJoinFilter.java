package org.openknows.jdbc.driver.unisql;

import org.openknows.jdbc.driver.unisql.memory.MemoryIndexedTable;

public class IndexedJoinFilter implements Table {
  
  public IndexedJoinFilter init(final String name, final String tableAName, final TableAccessor accessorA, final IndexRule indexRuleA, final String tableBName, final TableAccessor accessorB, final IndexRule indexRuleB, final JoinFilterRule filter) throws DatabaseException {
    this.name = name;
    this.metaData = new TableMetaData();
    final MetaData metaDataA = accessorA.getMetaData();
    final IndexFilter indexFilterA = new IndexFilter().init(indexRuleA, metaDataA);
    
    for (int i = 1, n = metaDataA.getColumnCount(); i <= n ; i++) {
      final Column column = metaDataA.getColumn(i);
      this.metaData.add(Column.getAndInit(tableAName+column.getName(), column.getDescription(), column.getType()));
    }
    final MetaData metaDataB = accessorB.getMetaData();
    for (int i = 1, n = metaDataB.getColumnCount(); i <= n ; i++) {
      final Column column = metaDataB.getColumn(i);
      this.metaData.add(Column.getAndInit(tableBName+column.getName(), column.getDescription(), column.getType()));
    }
    tableB = new MemoryIndexedTable().init(tableBName, indexRuleB, metaDataB);
    tableB.insert(accessorB);
    this.accessor = new TableAccessor() {

      public void init() throws DatabaseException {
        findNext();
      }

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return hasNext;
      }

      public Row getNext() throws DatabaseException {
        if (!hasNext) throw new IndexOutOfBoundsException();
        final Row result = nextRow;
        findNext();
        return result;
      }
      
      private void findNext() throws DatabaseException {
        do {
          if (otherAccessor == null) {
            if (!accessorA.hasNext()) return;
            tableARow = accessorA.getNext();
            otherAccessor = tableB.getAccessor(indexFilterA.getKey(tableARow));
            hasNext = otherAccessor.hasNext();
            if (!hasNext) {
              otherAccessor = null;
            }
            else {
              final Row tableBRow = otherAccessor.getNext();
              hasNext = filter.check(tableARow, tableBRow);
              if (hasNext) nextRow = new JoinDatabaseRow().init(metaData, tableARow, tableBRow);
            }
          }
          else {
            hasNext = otherAccessor.hasNext();
            if (!hasNext) {
              otherAccessor = null;
            }
            else {
              final Row tableBRow = otherAccessor.getNext();
              hasNext = filter.check(tableARow, tableBRow);
              if (hasNext) nextRow = new JoinDatabaseRow().init(metaData, tableARow, tableBRow);
            }
          }
        } while (!hasNext);
      }

      public void close() throws DatabaseException {}
      
      private boolean hasNext;
      private Row tableARow;
      private TableAccessor otherAccessor = null;
      private Row nextRow;
    };
    this.accessor.init();
    return this;
  }

  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getType() {
    return Table.MEMORY;
  }
  
  public String getDescription() {
    return null;
  }

  public TableAccessor getAccessor() throws DatabaseException {
    return accessor;
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }
  
  private TableMetaData metaData;
  private String name;
  private MemoryIndexedTable tableB;   
  private TableAccessor accessor;
}

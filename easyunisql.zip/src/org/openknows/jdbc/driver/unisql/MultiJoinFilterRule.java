package org.openknows.jdbc.driver.unisql;

public abstract class MultiJoinFilterRule {
  
  public static MultiJoinFilterRule referenceTrue = new MultiJoinFilterRule() { 
    @Override
    public boolean check(Row[] rows) { return true; } 
  };
  public static MultiJoinFilterRule referenceFalse = new MultiJoinFilterRule() { 
    @Override
    public boolean check(Row[] rows) { return false; } 
  };

  public abstract boolean check(final Row[] rows);
}

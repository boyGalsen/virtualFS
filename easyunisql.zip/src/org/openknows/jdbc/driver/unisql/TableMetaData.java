package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.*;

import java.util.*;


public class TableMetaData implements MetaData {
	
	public void add(final Column column) {
		final String name = column.getName().toUpperCase();
		if (this.columnByName.containsKey(name)) throw new IllegalArgumentException(name+" allready column exist");
		this.columns.add(column);
		this.columnByName.put(name, column);
    final Integer index = IntegerCache.get(this.columns.size());
		this.indexByName.put(name, index);
    final int pointIndex = name.indexOf(".");
    if (pointIndex > 0) {
      final String subName = name.substring(pointIndex+1);
      if (!indexByNameWithoutTable.containsKey(subName)) {
        this.indexByNameWithoutTable.put(subName, index);
      }
      else {
        this.indexByNameWithoutTable.put(subName, null);
      }
    }
    else {
      final String subName = name;
      if (!indexByNameWithoutTable.containsKey(subName)) {
        this.indexByNameWithoutTable.put(subName, index);
      }
      else {
        this.indexByNameWithoutTable.put(subName, null);
      }
    }
	}

	public int getColumnCount() {
	  return columns.size();
	}
 
	public Column getColumn(int i) {
	  return columns.get(i-1);
	}
 
	public Column findColumnByName(final String columnName) {
   final String name = columnName.toUpperCase();
   final int pointIndex = name.indexOf(".");
   if (columnByName.containsKey(name)) return columnByName.get(name);
   return columnByName.get(pointIndex > 0 ? name.substring(pointIndex+1) : name);
	}
	
	public int getColumnIndex(final Column column) {
		return columns.indexOf(column)+1;
	}
	
	public int getColumnIndex(final String columnName) {
    final String name = columnName.toUpperCase();
    if (indexByName.containsKey(name)) return indexByName.get(name).intValue();
    final int pointIndex = name.indexOf(".");
		return indexByName.get(pointIndex > 0 ? name.substring(pointIndex+1) : name).intValue();
	}
  
  public int getColumnIndex(final String columnName, final String alternativeColumnName) {
    final String name = (columnName == null) ? null : columnName.toUpperCase();
    final String alternativeName = (alternativeColumnName == null) ? null : alternativeColumnName.toUpperCase();
    final Integer nameIndexMain = indexByName.get(name);
    if (nameIndexMain != null) {
      return nameIndexMain.intValue();
    }
    final Integer altNameIndexMain = indexByName.get(alternativeName);
    if (altNameIndexMain != null) {
      return altNameIndexMain.intValue();
    }
    final int pointIndex = (name == null) ? -1 : name.indexOf(".");
    final Integer nameIndex = indexByNameWithoutTable.get((name != null && pointIndex > 0) ? name.substring(pointIndex+1) : name);
    if (nameIndex != null) {
      return nameIndex.intValue();
    }
    final int altPointIndex = (alternativeName == null) ? -1 : alternativeName.indexOf(".");
    final Integer altNameIndex = indexByNameWithoutTable.get((alternativeName != null && altPointIndex > 0) ? alternativeName.substring(altPointIndex+1) : alternativeName);
    if (altNameIndex != null) {
      return altNameIndex.intValue();
    }
    throw new IllegalArgumentException();
  }
	
	private final ArrayList<Column> columns = new ArrayList<Column>();
	private final HashMap<String, Column> columnByName = new HashMap<String, Column>();
	private final HashMap<String, Integer> indexByName = new HashMap<String, Integer>();
  private final HashMap<String, Integer> indexByNameWithoutTable = new HashMap<String, Integer>();
}
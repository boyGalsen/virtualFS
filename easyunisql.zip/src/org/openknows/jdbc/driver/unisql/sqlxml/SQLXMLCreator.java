package org.openknows.jdbc.driver.unisql.sqlxml;

import com.easyrms.builder.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import java.io.*;
import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;


public class SQLXMLCreator {

  public SQLXMLCreator() { 
  }
  
  public void create(final ValidatedFile file, final MetaData metaData, final Parameters parameters) throws DatabaseException {
  	try {
	  	if (file.isExists()) {
	  	  StreamUtils.delete(file);
	  	}
	  	try (final FileWriter out = StreamUtils.newFileWriter(file)) {
		  	//final int n = metaData.getColumnCount();
		  	//final String[] columNames = new String[n];
        final long date = StampUtil.getStampValue();
        final int columnCount = metaData.getColumnCount();
        //for (int i = 1 ; i <= n; i++) columNames[i-1] = metaData.getColumn(i).getName();
        out.write("<SQLRESPONSE ID=\"\" WITHERROR=\"NO\" STARTTIME=\"");
        out.write(dateFormat.format(new java.util.Date(date)));
        out.write("\" EXECUTIONDURATION=\"");
        out.write(""+(StampUtil.getStampValue() - date));
        out.write("\" COLCOUNT=\"");
        out.write(columnCount);
        out.write("\" ROWCOUNT=\"0\">\n");
        out.write("<SQLREQUEST><REQUEST><![CDATA[]]></REQUEST></SQLREQUEST>");
        out.write("<RSET>\n<METADATA>\n");
        for (int i = 1; i <= columnCount; i++) {
          final Column column = metaData.getColumn(i);
          out.write("<COL TYPE=\""); 
          out.write(getColumnType(column));
          out.write("\" PRECISION=\""); 
          out.write(getColumnPrecision(column));
          out.write("\" SCALE=\""); 
          out.write(getColumnScale(column));
          out.write("\" NAME=\""); 
          out.write(getColumnName(column));
          out.write("\" DISPLAYSIZE=\""); 
          out.write(getColumnDisplaySize(column));
          out.write("\"/>");
        }
        out.write("</METADATA>\n<DATA>\n</DATA>\n</RSET>\n</SQLRESPONSE>");
	  	}
  	}
  	catch (Throwable e) {
  		throw new DatabaseException(e);
  	}
  }
  
  static final String getColumnName(Column column) {
    return column.getDescription();
  }

  static final int getColumnType(Column column) {
    switch (column.getType()) {
      case DOUBLE : return Types.NUMERIC; 
      case LONG : return Types.NUMERIC; 
      case BOOLEAN : return Types.VARCHAR; 
      case STRING : return Types.VARCHAR;
      default : throw new IllegalStateException();
    }
  }

  static final int getColumnPrecision(Column column) {
    switch (column.getType()) {
      case DOUBLE : return 12; 
      case LONG : return 9; 
      case BOOLEAN : return 1; 
      case STRING : return 4000;
      default : throw new IllegalStateException();
    }
  }

  static final int getColumnScale(Column column) {
    switch (column.getType()) {
      case DOUBLE : return 4; 
      case LONG : return 0; 
      case BOOLEAN : return 0; 
      case STRING : return 0;
      default : throw new IllegalStateException();
    }
  }
  
  static final int getColumnDisplaySize(Column column) {
    switch (column.getType()) {
      case DOUBLE : return 16; 
      case LONG : return 9; 
      case BOOLEAN : return 1; 
      case STRING : return 4000;
      default : throw new IllegalStateException();
    }
  }
  
  protected final DateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
}
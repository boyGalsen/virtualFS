package org.openknows.jdbc.driver.unisql.sqlxml;


import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import org.openknows.common.db.*;
import org.openknows.common.db.xml.*;
import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;


public class SQLXMLFileTable implements Table, AtTable {
  
  public SQLXMLFileTable init(final MemoryDatabase database, final String file, final String name) throws DatabaseException {
    return new SQLXMLFileTable().init(StreamUtils.getFile(file), name);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return this.file.getFullName();
  }
  
  public String getName() {
    return this.name;
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }

  public SQLXMLFileTable init(final ValidatedFile file, final String name) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
  	}
		catch (Throwable ignored) {
      throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
    return findAccessor();
  }

  private synchronized TableAccessor findAccessor() throws DatabaseException {
    try (final FileReader in = StreamUtils.newFileReader(file)) {
      final SimpleStatementResult xmlStatement = XMLStatementHandler.getStatement(in);
      final ResultSet rs = xmlStatement.getCurrentResultSet();
      final TableAccessor accessor = new TableAccessor() {
        private final MetaData metaData = findMetaData(rs);
        private final int columnCount = metaData.getColumnCount();
        
        public MetaData getMetaData() throws DatabaseException {
          return metaData;
        }

        public boolean hasNext() throws DatabaseException {
          return hasNext;
        }

        public Row getNext() throws DatabaseException {
          if (!hasNext) throw new DatabaseException("not valid state");
          final Row result = nextRow;
          findNext();
          return result;
        }
        
        public void init() throws DatabaseException {
          findNext();
        }
        
        private void findNext() throws DatabaseException {
          try {
            hasNext = rs.next();
            if (hasNext) {
              nextRow = new DatabaseRow();
              nextRow.init(metaData);
              for (int j = 1 ; j <= columnCount ; j++) {
                switch (metaData.getColumn(j).getType()) {
                  case LONG: {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getInteger(rs, j)));
                  } break;
                  case DOUBLE: {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(MathUtils.getDouble(SQLUtils.getDouble(rs, j))));
                  } break;
                  case BOOLEAN : {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getBoolean(rs, j)));
                  } break;
                  case STRING : {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getString(rs, j)));
                  } break;
                  default:
                    throw new DatabaseException("Unvalid type");
                }
              }
            }
          }
          catch (Throwable ignored) {
            EasyRMS.trace.log(ignored);
            throw new DatabaseException(ignored);
          }
        }

        public void close() throws DatabaseException {
          try {
            rs.close();
          }
          catch (Throwable ignored) {
            throw new DatabaseException(ignored);
          }          
        }
        private boolean hasNext;
        private DatabaseRow nextRow;
      };
      accessor.init();
      return accessor;
    }
    catch (Throwable ignored) {
      throw new DatabaseException(ignored);
    }
  }
  
  private synchronized MetaData findMetaData(ResultSet refResultSet) throws DatabaseException {
    try {
      if (this.metaData == null) {
        if (refResultSet == null) {
          final SimpleStatementResult xmlStatement = XMLStatementHandler.getStatement(StreamUtils.newFileReader(file));
          refResultSet = xmlStatement.getCurrentResultSet();
        }
        final TableMetaData tableMetaData = new TableMetaData();
        final ResultSetMetaData rsm = refResultSet.getMetaData();
        final int n = rsm.getColumnCount();
        for (int j = 1 ; j <= n ; j++) {
          final Class<?> classe = SQLUtils.getSQLClass(j, rsm);
          final String columnName = rsm.getColumnName(j);
          if (classe != null) {
            if (classe.equals(Integer.class)) {
              tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
            }
            else if (classe.equals(Long.class)) {
              tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
            }
            else if (classe.equals(Float.class)) {
              tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
            }
            else if (classe.equals(Double.class)) {
              tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
            }
            else if (classe.equals(Boolean.class)) {
              tableMetaData.add(Column.getAndInit(columnName, ColumnType.BOOLEAN));
            }
            else {
              tableMetaData.add(Column.getAndInit(columnName, ColumnType.STRING));
            }
          }
          else {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.STRING));
          }
        }
        this.metaData = tableMetaData;
      }
      return this.metaData;
    }
    catch (Throwable ignored) {
      throw new DatabaseException(ignored);
    }
  }

  private MetaData metaData;
  
  private ValidatedFile file;
  private String name;
  
  public MetaData getMetaData() throws DatabaseException {
    return findMetaData(null);
  }
}
package org.openknows.jdbc.driver.unisql.sqlxml;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;

public class SQLXMLAtManager implements AtManager {
  
  public String getPrefix() {
    return "SQL.XML";
  }

  public Table createTable(final MemoryDatabase database, String file, String name, MetaData metaData) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public void init(Parameters properties) {
  }
  
  public boolean dropTable(final MemoryDatabase database, String file, String name) throws DatabaseException {
    final ValidatedFile f = StreamUtils.getFile(file);
    if (f.isExists()) {
      return StreamUtils.delete(f);
    }
    return false;
  }

  public Table getTable(final MemoryDatabase database, String file, String name) throws DatabaseException {
    return new SQLXMLFileTable().init(database, file, name);
  }
}
package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.comparator.*;

import java.util.Comparator;

public class RowComparator implements Comparator<Row> {

  public RowComparator(final MetaData metadata, final int... columns) {
    this.columns = columns;
    this.isNumComparator = new boolean[columns.length];
    for (int i = 0, n = columns.length; i < n ; i++) {
      final ColumnType type = metadata.getColumn(Math.abs(columns[i])).getType();
      this.isNumComparator[i] = (type == ColumnType.DOUBLE || type == ColumnType.LONG);  
    }
  }
  
  private final int[] columns;
  private final boolean[] isNumComparator; 

  public int compare(Row o1, Row o2) {
    for (int i = 0, n = columns.length; i < n ; i++) {
      final int I = Math.abs(columns[i]);
      if (o1.isNull(I) && o2.isNull(I)) continue;
      if (o1.isNull(I)) return 1;
      if (o2.isNull(I)) return -1;
      final boolean isDesc = columns[i] < 0; 
      if (isNumComparator[i]) {
        final double v1 = o1.getAsDouble(I).doubleValue();
        final double v2 = o2.getAsDouble(I).doubleValue();
        if (v1 == v2) continue;
        if (v1 > v2) return isDesc ? -1 : 1;
        return isDesc ? 1 : -1;
      }
      final int c = StringComparator.compare(o1.getAsString(I), o2.getAsString(I));
      if (c == 0) continue;
      return isDesc ? -c : c;
    }
    return StringComparator.compare(o1.toString(), o2.toString());
  }
  
}
package org.openknows.jdbc.driver.unisql;


public interface MetaData {

	public int getColumnCount();
 	public Column getColumn(int i);
 	public Column findColumnByName(final String name);
	public int getColumnIndex(final Column column);
	public int getColumnIndex(final String columnName);
  public int getColumnIndex(final String columnName, final String alternativeColumnName);

}

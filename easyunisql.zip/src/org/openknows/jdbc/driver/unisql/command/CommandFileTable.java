package org.openknows.jdbc.driver.unisql.command;


import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;


public class CommandFileTable implements Table, AtTable {
  
  public CommandFileTable init(final MemoryDatabase database, final String command, final String name) throws DatabaseException {
    return new CommandFileTable().init(database, command, command, name, true);
  }
  
	public CommandFileTable init(final MemoryDatabase database, final String command) throws DatabaseException {
		return this.init(database, command, command, command, true);
	}
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return this.command;
  }
  
  public String getName() {
    return this.name;
  }

  public CommandFileTable init(final MemoryDatabase database, final Table table, final String command, final String name) throws DatabaseException {
    this.command = command;
    this.name = name;
    this.table = table;
    final TableMetaData metaData = new TableMetaData();
    metaData.add(Column.getAndInit("RESPONSE", ColumnType.STRING));
    this.metaData = metaData;
    return this;
  }
  
  public CommandFileTable init(final MemoryDatabase database, final String originalName, final String command, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	this.command = command;
    this.name = name;
    final TableMetaData metaData = new TableMetaData();
    metaData.add(Column.getAndInit("CMDROW", ColumnType.LONG));
    metaData.add(Column.getAndInit("CMDRESPONSE", ColumnType.STRING));
    this.metaData = metaData;
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
      if (table != null) return table.getAccessor();
      final MemoryTable memoryTable = new MemoryTable("commandResult", metaData, null);
      try {
        final InsertTableAccessor is = memoryTable.getInsertAccessor();
        try {
          try {
              command = command.replace("#", " ");
              final Process process = Runtime.getRuntime().exec(command);
              final BoundedBufferedReader in = new BoundedBufferedReader(new InputStreamReader(process.getInputStream()));
              String line = null;
              int rowIndex = 0;
              while((line = in.readLine()) != null) {
                final DatabaseRow row = new DatabaseRow();
                row.init(metaData);
                row.set(1, JDBCDatabaseValue.getAndInit(LongCache.get(rowIndex++)));
                row.set(2, JDBCDatabaseValue.getAndInit(StringComparator.NVL(line)));
                is.insert(row);
              }
          }
          catch (Throwable ignored) {
            final DatabaseRow row = new DatabaseRow();
            row.init(metaData);
            row.set(1, JDBCDatabaseValue.getAndInit(LongCache.get(-1)));
            row.set(2, JDBCDatabaseValue.getAndInit("Error ["+ExceptionUtils.getMessage(ignored)+"]"));
            is.insert(row);
          }
        }
        finally {
          is.close();
        }
      }
      catch (DatabaseException databaseException) {
        throw new SQLException(databaseException); 
      }
      return memoryTable.getAccessor();
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return null;
	}
  
  private String command;
  private MetaData metaData;
  private String name;
  
  private Table table;
  
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}
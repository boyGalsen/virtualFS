package org.openknows.jdbc.driver.unisql.command;

import com.easyrms.util.preferences.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;


public class CommandCreator {

  public CommandCreator() { 
  }
  
  public void create(final File file, final MetaData metaData, final Parameters parameters) throws DatabaseException {
  	throw new DatabaseException("Unsupported Operation");
  }
}

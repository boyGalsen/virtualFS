package org.openknows.jdbc.driver.unisql;

import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;

public interface AtTable extends Table {
  
  public AtTable init(MemoryDatabase database, String file, String name) throws DatabaseException;
}

package org.openknows.jdbc.driver.unisql;

import org.openknows.jdbc.driver.unisql.operation.OperationColumnFilter;

public class TableAccessorFilter implements TableAccessor {
  
  public TableAccessorFilter(final TableAccessor accessor, final OperationColumnFilter filter) {
    this.accessor = accessor;
    this.filter = filter;
  }

  public void close() throws DatabaseException {
    this.accessor.close();
  }

  public MetaData getMetaData() throws DatabaseException {
    return this.filter.getMetaData();
  }

  public Row getNext() throws DatabaseException {
    return this.filter.setRow(this.accessor.getNext());
  }

  public boolean hasNext() throws DatabaseException {
    return this.accessor.hasNext();
  }

  public void init() throws DatabaseException {
    this.accessor.init();
  }

  private final TableAccessor accessor;
  private final OperationColumnFilter filter;
}

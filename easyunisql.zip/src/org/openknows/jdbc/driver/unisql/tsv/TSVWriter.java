package org.openknows.jdbc.driver.unisql.tsv;

import com.easyrms.builder.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.preferences.*;

import java.io.*;
import java.util.*;


public class TSVWriter {
  
  public static enum TSVObjectType {
    DEFAULT_QUOTE, STRING_QUOTE, DECIMAL_QUOTE, INTEGER_QUOTE,
    DEFAULT, STRING, DECIMAL, INTEGER;
    
    TSVObjectType() {
    }

  }
  
	public TSVWriter() {
	}
  
  public void write(final Parameters parameters) throws IOException {
    if (parameters != null) {
      boolean withParameter = false;
      for (final ParametersTuple parameter : parameters) {
        this.out.write(parameter.getParameter());
        this.out.write("=");
        this.out.write(StringUtil.NVL(parameter.getParameterValue()));
        this.out.write("\r\n");
      }
      if (withParameter) {
        this.out.write(".\r\n");
      }
    }
  }
	
	public TSVWriter init(final Writer out) {
		this.out = out;
		return this;
	}

  public void write(final Object[] values) throws IOException {
    write(values, (TSVObjectType[])null, (Builder[])null);
  }

  public void write(final Object[] values, final TSVObjectType[] types, final Builder[] builders) throws IOException {
  	if (values.length > 0) {
      for (int i = 0, n = values.length; i < n; i++) {
  			if (i > 0) {
  			  out.write("\t");
  			}
        write(values[i], (types == null) ? TSVObjectType.DEFAULT_QUOTE : types[i], (builders == null) ? null : builders[i]);
      }
  		out.write("\r\n");
  		out.flush();
  	}
  }
  
  public void close() {
  	out = null;
  }
  
  private final void write(final Object value, final TSVObjectType type, final Builder builder) throws IOException {
    if (value != null) {
      out.write(toTSVValue(value, type, builder));
    }
  }
  
  private final String toTSVValue(final Object value, final TSVObjectType type, final Builder builder) {
    final Builder valueBuilder = (builder == null) ? formats.get(type) : builder;
    if (valueBuilder != null) {
      return valueBuilder.format(value);
    }
    String valueString = value.toString();
    if (StringComparator.isWithTabOrEndLine(valueString)) {
      valueString = valueString.replace("\t", " ").replace("\r\n", " ");
    }
    return valueString;
  }
  
  public void set(final TSVObjectType type, final Builder builder) {
    formats.put(type, builder);
  }
  
  private final HashMap<TSVObjectType, Builder> formats = new HashMap<TSVObjectType, Builder>(); 
  
  private Writer out;
}
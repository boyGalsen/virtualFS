package org.openknows.jdbc.driver.unisql.tsv;

import com.easyrms.util.*;

import java.io.*;
import java.util.Properties;


public class TSVParser {

  public TSVParser() {
  }
  
  public void reset() throws IOException {
    this.in.reset();
    this.state = START;
    this.currentRow = 0;
    this.hasMoreElement = false;
    this.hasMoreRow = true; 
    this.header = new Properties();
  }
    
  public TSVParser init(final Reader in) throws IOException {
    this.state = START;
    this.in = in;
    this.currentRow = 0;
    this.hasMoreElement = false;
    this.hasMoreRow = true; 
    this.header = new Properties();
    return this;
  }

  public String getNextElement() throws IOException {
    hasMoreElement = false;
    final String element = this.element;
    if (!this.hasMoreRow) {
      findNextElement();
    }
    return element;
  }
  
  public int getNextRow() throws IOException {
    hasMoreRow = false;
    final int currentRow = this.currentRow;
    findNextElement();
    return currentRow;
  }
  
  public boolean hasMoreHeader() {
    return hasMoreHeader;
  }
  
  public boolean hasMoreRow() throws IOException {
    return hasMoreRow;
  }
  
  public boolean hasMoreElement() throws IOException {
    return hasMoreElement;
  }
  
  public Properties getHeader() {
    return header;
  }
  
  private void findNextElement() throws IOException {
    state = START;
    element = null;
    hasMoreElement = false;
    hasMoreRow = false;
    final StringBuilder buffer = StreamUtils.getStringBuilder();
    try {
      while (in.read(buff) >= 0) {
        final char c = buff[0];
          switch (state) {
          case START : 
            switch (c) {
              case '\t' : {
                element = null;
                hasMoreElement = true;
                return;
              }
              case '\r' : case ' ' : case '\f' : {
                break;
              }
              case '\n' : {
                currentRow++;
                hasMoreRow = true;
                return;
              }
              default : {
                buffer.append(c);
                state = IN_DATA2;
              }
            }
            break;
          case END : 
            switch (c) {
              case ',' : case ';' : case '\t' : {
                return;
              }
              case '\r' : case ' ' : case '\f' : {
                break;
              }
              case '\n' : {
                currentRow++;
                hasMoreRow = true;
                return;
              }
              default : {
                throw new IllegalStateException();
              }
            }
            break;
          case IN_DATA2 : 
            switch (c) {
              case '\t': {
                element = buffer.toString();
                buffer.setLength(0);
                hasMoreElement = true;
                return;
              }
              case '\r' : {
                break;
              }
              case '\n' : {
                element = buffer.toString();
                buffer.setLength(0);
                currentRow++;
                hasMoreElement = true;
                hasMoreRow = true;
                return;
              }
              default : {
                buffer.append(c);
              }
            }
            break;
          default : throw new IllegalStateException();
        }
      }
      element = buffer.toString();
      buffer.setLength(0);
      hasMoreElement = (state != START);
      hasMoreRow = (state != START);
      state = START;
    }
    finally {
      StreamUtils.free(buffer);
    }
  }
  
  public void close() {
    in = null;
    element = null;
    hasMoreElement = false;
    hasMoreRow = false;
    hasMoreHeader = false;
    header = null;
  }

  private String element = null;
  private boolean hasMoreElement = false;
  private boolean hasMoreRow = false; 
  private boolean hasMoreHeader = false; 
  private int state = START;
  private Reader in = null;
  private int currentRow = 0;
  private Properties header = null;
  private final char[] buff = new char[1];
  
  private static final int START = 0;
  private static final int IN_DATA2 = 2;
  private static final int END = 4;
}
package org.openknows.jdbc.driver.unisql.tsv;

import com.easyrms.builder.*;
import com.easyrms.io.ezfs.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.tsv.TSVWriter.*;

import java.io.*;
import java.util.*;



public class TSVTableInsertAccessor extends AbstractInsertTableAccessor implements InsertTableAccessor {
	
	public TSVTableInsertAccessor init(final EzFSFileDescriptor file, final MetaData metaData) throws DatabaseException {
	  try {
  	  this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
  	  final Writer out = fsConnection.find(file).getAccess().openAppendWriter();
      this.out = new TSVWriter().init(out);
  		this.metaData = metaData;
      this.types = new TSVWriter.TSVObjectType[this.metaData.getColumnCount()];
      this.builders = new Builder[this.metaData.getColumnCount()];
      Arrays.fill(this.types, TSVWriter.TSVObjectType.DEFAULT_QUOTE);
  		this.w = out;
  		return this;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
	}
  
  public void setType(final int index, final TSVWriter.TSVObjectType type) {
    this.types[index-1] = (type == null) ? TSVWriter.TSVObjectType.DEFAULT_QUOTE : type;
  }
  
  public void set(final TSVObjectType type, final Builder builder) {
    this.out.set(type, builder);
  }
  
  public void set(final int index, final Builder builder) {
    this.builders[index - 1] = builder;
  }
	
	public MetaData getMetaData() throws DatabaseException {
		return metaData;
	}

  @Override
  protected void internalInsert(final Row row) throws DatabaseException {
    try {
      final int count = row.getElementCount();
      final Object[] values = new Object[count];
      for (int i = 1; i <= count; i++) {
        final DatabaseValue value = row.getDatabaseValue(i);
        switch (types[i-1]) {
          case DECIMAL :
          case DECIMAL_QUOTE : {
            values[i-1] = (value == null) ? null : value.isNull() ? null : value.getDoubleValue();
          } break;
          case INTEGER :
          case INTEGER_QUOTE : {
            values[i-1] = (value == null) ? null : value.isNull() ? null : value.getIntegerValue();
          } break;
          case STRING :
          case STRING_QUOTE : {
            values[i-1] = (value == null) ? null : value.isNull() ? null : value.getStringValue();
          } break;
          default : {
            values[i-1] = (value == null) ? null : value.isNull() ? null : value.getOriginalValue();
          }
        }
      }
      this.out.write(values, this.types, this.builders);
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

	public void close() throws DatabaseException {
	  try {
      try {
        if (w != null) {
          w.close();
          w = null;
        }
      }
      finally {
        if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
        }
      }
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    } 
	}

  private EzFSConnection fsConnection;
  private MetaData metaData;
  private TSVWriter.TSVObjectType[] types;
  private Builder[] builders;
  private Writer w;
  private TSVWriter out;
}

package org.openknows.jdbc.driver.unisql.tsv;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;


public class TSVTableAccessor implements TableAccessor {

  public TSVTableAccessor(EzFSFileDescriptor file, final MetaData metaData, final boolean withColumnNames, final boolean ignoreExtraData) throws DatabaseException  { 
		try {
	    this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
	    this.reader = fsConnection.find(file).getAccess().openReader();
	    this.parser = new TSVParser();
	    this.metaData = metaData;
	    this.ignoreExtraData = ignoreExtraData;
			this.parser.init(reader);
      if (!parser.hasMoreRow()) throw new DatabaseException("Not Valid File.");
      parser.getNextRow();
      while (parser.hasMoreElement()) { parser.getNextElement();} //ignored
			if (parser.hasMoreRow()) {
				parser.getNextRow();
				hasNext = parser.hasMoreElement();
			}
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}
  }
  
  public void init() throws DatabaseException {
  }

  public MetaData getMetaData()  throws DatabaseException {
    return metaData;
  }

  public boolean hasNext() throws DatabaseException {
  	return hasNext;
  }

  public Row getNext() throws DatabaseException {
		if (!hasNext) throw new DatabaseException("no more value");
		try {
      rowIndex++;
      row = new DatabaseRow();
      row.init(this.metaData);
	  	int i = 1;
	  	while (parser.hasMoreElement()) {
        if (ignoreExtraData) {
          try {
            row.set(i++, JDBCDatabaseValue.getAndInit(parser.getNextElement()));
          }
          catch (ArrayIndexOutOfBoundsException ignored) {
          }
        }
        else {
          row.set(i++, JDBCDatabaseValue.getAndInit(parser.getNextElement()));
        }
	  	}
      if (parser.hasMoreRow()) {
				parser.getNextRow();
				hasNext = parser.hasMoreElement();
	  	}
	  	else {
	  		hasNext = false;
	  	}
	    return row;
		}
		catch (Throwable e) {
      EasyRMS.trace.log(e);
			throw new DatabaseException("on row "+rowIndex+":"+ExceptionUtils.getMessage(e));
		}	  	
  }
  
  public void close() throws DatabaseException {
		try {
		  try {
  	  	hasNext = false;
  	  	row = null;
        reader.close();
  	  	parser.close();
		  }
		  finally {
		    if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
		    }
		  }
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}	  	
  }
  
  private EzFSConnection fsConnection;
  private final Reader reader;
	private final TSVParser parser;
  private final MetaData metaData;

  private int rowIndex;
  private DatabaseRow row;
  private boolean hasNext;
  
  private final boolean ignoreExtraData; 
}

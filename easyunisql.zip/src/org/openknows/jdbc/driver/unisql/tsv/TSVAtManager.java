package org.openknows.jdbc.driver.unisql.tsv;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import java.io.File;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;

public class TSVAtManager implements AtManager {
  
  public static TSVAtManager reference = new TSVAtManager();

  public String getPrefix() {
    return "TSV";
  }
  
  public void init(Parameters properties) {
  }
  
  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    final ValidatedFile f = StreamUtils.getFile(file);
    if (f.isExists()) {
      return StreamUtils.delete(f);
    }
    return false;
  }
  
  public Table createTable(MemoryDatabase database, String file, String name, MetaData metaData) throws DatabaseException {
    new TSVCreator().create(StreamUtils.getFile(file), metaData, null);
    return getTable(database, file, name);
  }

  public Table getTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    return new TSVFileTable().init(database, file, name);
  }
}

package org.openknows.jdbc.driver.unisql.csv;


import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;


public class CSVFileTable implements AtTable {
  
  public CSVFileTable init(final MemoryDatabase database, final String file, String name) throws DatabaseException {
    try {
      return this.init(EzFSUtil.findEzFsFileDescriptior(file), name);
    }
    catch (IOException ioException) {
      throw new DatabaseException(ioException);
    }
  }
	
	public CSVFileTable init(final EzFSFileDescriptor file) throws DatabaseException {
		return this.init(file, true);
	}
  
  public CSVFileTable init(final EzFSFileDescriptor file, String name) throws DatabaseException {
    return this.init(file, name, true);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return EzFSUtil.getAbsolutePath(this.file);
  }
  
  public String getName() {
    return this.name;
  }

  public CSVFileTable init(final EzFSFileDescriptor file, final boolean withColumnNameHeader) throws DatabaseException {
    return init(file, EzFSUtil.getAbsolutePath(file), withColumnNameHeader);
  }
  
  public CSVFileTable init(final EzFSFileDescriptor file, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
	  	this.withColumnNameHeader = withColumnNameHeader;
	  	final CSVParser parser = new CSVParser();
	  	final TableMetaData metaData = new TableMetaData();
	  	try (final EzFSConnection connection = EzFS.reference.get().getConnection(file.getConnectionDescriptor())) {
        try (final Reader in = connection.find(file).getAccess().openReader()) {
  		  	parser.init(in);
  				if (withColumnNameHeader) {
  					if (!parser.hasMoreRow()) throw new DatabaseException("Not Valid File.");
  					parser.getNextRow();
  					while (parser.hasMoreElement()) {
  						metaData.add(Column.getAndInit(parser.getNextElement(), ColumnType.STRING));
  					}
  				}
  				else {
  					if (!parser.hasMoreRow()) throw new DatabaseException("Not Valid File.");
  					parser.getNextRow();
  					int i = 1;
  					while(parser.hasMoreElement()) {
  						metaData.add(Column.getAndInit(IntegerCache.toString(i++), ColumnType.LONG));
  					}
  				}
        }
	  	}
	  	this.metaData = metaData;
  	}
		catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
			return new CSVTableAccessor(file, metaData, withColumnNameHeader, false);
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

  public CSVTableInsertAccessor getCSVInsertAccessor() throws DatabaseException {
    try {
      return new CSVTableInsertAccessor().init(file, metaData);
    }
    catch (Throwable ignored) {
      throw new DatabaseException(ignored);
    }
  }

	public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return getCSVInsertAccessor();
	}
  
  private EzFSFileDescriptor file;
  private boolean withColumnNameHeader;
  private MetaData metaData;
  private String name;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}

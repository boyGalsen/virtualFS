package org.openknows.jdbc.driver.unisql.csv;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import java.io.File;
import java.io.FileWriter;
import java.util.HashSet;

import org.openknows.jdbc.driver.unisql.*;


public class CSVCreator {

  public CSVCreator() { 
  }
  
  public void create(final ValidatedFile file, final MetaData metaData, final Parameters parameters) throws DatabaseException {
  	try {
	  	if (file.isExists()) {
	  	  StreamUtils.delete(file);
	  	}
      final HashSet<String> columnNames = new HashSet<String>();
	  	final FileWriter out = StreamUtils.newFileWriter(file);
	  	try {
		  	final CSVWriter w = new CSVWriter();
        w.write(parameters);
		  	w.init(out);
		  	final int n = metaData.getColumnCount();
		  	final String[] columNames = new String[n];
		  	for (int i = 1 ; i <= n; i++) {
          final String description = metaData.getColumn(i).getDescription();
          final String finalName = !columnNames.contains(description) ? description : metaData.getColumn(i).getName();
          columNames[i-1] = finalName;
          columnNames.add(finalName);
        }
		  	w.write(columNames);
	  	}
	  	finally {
	  		out.close();
	  	}
  	}
  	catch (Throwable ignored) {
  		throw new DatabaseException(ignored);
  	}
  }
}

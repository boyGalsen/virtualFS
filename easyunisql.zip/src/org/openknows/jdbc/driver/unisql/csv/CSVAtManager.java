package org.openknows.jdbc.driver.unisql.csv;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import java.io.File;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;

public class CSVAtManager implements AtManager {
  
  public static CSVAtManager reference = new CSVAtManager();

  public String getPrefix() {
    return "CSV";
  }
  
  public void init(Parameters properties) {
  }
  
  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    final ValidatedFile f = StreamUtils.getFile(file);
    if (f.isExists()) {
      return StreamUtils.delete(f);
    }
    return false;
  }
  
  public Table createTable(MemoryDatabase database, String file, String name, MetaData metaData) throws DatabaseException {
    new CSVCreator().create(StreamUtils.getFile(file), metaData, null);
    return getTable(database, file, name);
  }

  public Table getTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    return new CSVFileTable().init(database, file, name);
  }
}

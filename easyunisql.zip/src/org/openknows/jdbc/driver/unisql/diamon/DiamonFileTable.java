package org.openknows.jdbc.driver.unisql.diamon;


import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;
import org.openknows.jdbc.driver.unisql.memory.MemoryTable;
import org.openknows.jdbc.driver.unisql.sql.AT_TABLE;


public class DiamonFileTable implements Table, AtTable {
  
  public DiamonFileTable init(final MemoryDatabase database, final String file, final String name) throws DatabaseException {
    final int index = file.indexOf("#");
    if (index < 0) {
      if (file.indexOf(":") < 0) {
        if (file.indexOf(".") < 0) {
          return new DiamonFileTable().init(database, database.findTable(null, file), name);
        }
        return new DiamonFileTable().init(database, database.findTable(null, file), name);
      }
      return new DiamonFileTable().init(database, StreamUtils.getFileOrDirectory(file), null, name);
    }
    return new DiamonFileTable().init(database, file, StreamUtils.getFileOrDirectory(file.substring(0, index)), file.substring(index+1), name, true);
  }
  
	public DiamonFileTable init(final MemoryDatabase database, final ValidatedFileOrDirecotry file, final String subFile) throws DatabaseException {
		return this.init(database, file, subFile, true);
	}
  
  public DiamonFileTable init(final MemoryDatabase database, final ValidatedFileOrDirecotry file, final String subFile, String name) throws DatabaseException {
    return this.init(database, file.getFullName(), file, subFile, name, true);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return this.file.getFullName();
  }
  
  public String getName() {
    return this.name;
  }

  public DiamonFileTable init(final MemoryDatabase database, final Table table, final String name) throws DatabaseException {
    this.file = null;
    this.name = name;
    this.table = table;
    this.metaData = this.table.getMetaData();
    return this;
  }
  
  public DiamonFileTable init(final MemoryDatabase database, final ValidatedFileOrDirecotry file, final String subFile, final boolean withColumnNameHeader) throws DatabaseException {
    return init(database, file.getFullName(), file, subFile, file.getFullName(), withColumnNameHeader);
  }
  
  public DiamonFileTable init(final MemoryDatabase database, final String originalName, final ValidatedFileOrDirecotry file, final String subFile, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
	  	if (!this.file.isFile()) {
        final TableMetaData metaData = new TableMetaData();
        metaData.add(Column.getAndInit("NAME", ColumnType.STRING));
        metaData.add(Column.getAndInit("SIZE", ColumnType.LONG));
        metaData.add(Column.getAndInit("TIME", ColumnType.LONG));
        metaData.add(Column.getAndInit("ISDIRECTORY", ColumnType.STRING));
        metaData.add(Column.getAndInit("ISHIDDEN", ColumnType.STRING));
        this.metaData = metaData;
      }
      else {
        final String fileName = file.getName();
        final int extensionIndex = fileName.lastIndexOf("#");
        final String realFileName = (extensionIndex >= 0) ? fileName.substring(0, extensionIndex).toUpperCase() : fileName.toUpperCase();
        final AtManagerController atManager = database.getDriver().getAtManager();
        final String[] suffixes = atManager.getSuffixes();
        final String thisPrefix = DiamonAtManager.prefix;
        for (final String suffix : suffixes) {
          if (!thisPrefix.equals(suffix) && realFileName.endsWith(suffix)) {
            this.table = atManager.get(database, new AT_TABLE("@"+suffix+":", originalName, name));
            if (table == null) {
              throw new DatabaseException("Unsupported Extension:"+suffix);
            }
            this.metaData = table.getMetaData();
            return this;
          }
        }
        throw new DatabaseException("Unsupported Path");
      }
  	}
		catch (Throwable ignored) {
      throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
      if (table != null) return table.getAccessor();
      if (!this.file.isFile()) {
        final MemoryTable memoryTable = new MemoryTable(this.name, this.metaData, null);
        final InsertTableAccessor is = memoryTable.getInsertAccessor();
        try {
          final EzArray<? extends ValidatedFileOrDirecotry> files = this.file.asDirectory().findValidatedFileOrDirectoriess(null);
          for (int j = 0, n = files.getCount(); j < n; j++) {
            final ValidatedFileOrDirecotry file = files.get(j);
            final DatabaseRow row = new DatabaseRow();
            row.init(this.metaData);
            int i = 1;
            row.set(i++, JDBCDatabaseValue.getAndInit(file.getName()));
            row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(file.getLength())));
            row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(file.getLastModification())));
            row.set(i++, JDBCDatabaseValue.getAndInit(file.isFile() ? "N" : "Y"));
            row.set(i++, JDBCDatabaseValue.getAndInit(file.isHidden() ? "Y" : "N"));
            is.insert(row);
          }
        }
        finally {
          is.close();
        }
        return memoryTable.getAccessor();
      }
      throw new DatabaseException("Invalid Argument");
  	}
  	catch (DatabaseException forward) {
  	  throw forward;
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return null;
	}
  
  private ValidatedFileOrDirecotry file;
  private MetaData metaData;
  private String name;
  
  private Table table;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}
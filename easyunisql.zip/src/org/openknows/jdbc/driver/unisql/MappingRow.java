package org.openknows.jdbc.driver.unisql;

public class MappingRow extends DatabaseRow {

  public Row init(final MetaData metadata, final Row originalRow, final int[] columnMapping) {
    super.init(metadata);
    this.originalRow = originalRow;
    this.columnMapping = columnMapping;
    return this;
  }
  
  @Override
  public DatabaseValue getDatabaseValue(final int index) {
    return originalRow.getDatabaseValue(columnMapping[index-1]);
  }
  
  private Row originalRow;
  private int[] columnMapping;
}

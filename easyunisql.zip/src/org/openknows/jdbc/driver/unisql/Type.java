package org.openknows.jdbc.driver.unisql;


public class Type {

  public static final int DATE = 1;
  public static final int INT = 2;
  public static final int STRING = 3;
  public static final int DOUBLE = 4;
}

package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

public class IndexRule {

  public void set(int columnIndex, int indexOrder) {
    rules.put(columnIndex, IntegerCache.get(indexOrder));
  }

  public void remove(int columnIndex) {
    rules.remove(columnIndex);
  }
  
  public int get(int columnIndex) {
    final Integer indexOrder = rules.get(columnIndex);
    return indexOrder == null ? -1 : indexOrder.intValue();
  }

  public int getIndexSize() {
    return rules.getValueCount();
  }
  
  private IntObjectMap<Integer> rules = new IntObjectMap<Integer>();
}

package org.openknows.jdbc.driver.unisql;


import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;

public class T1 extends org.openknows.jdbc.driver.unisql.operation.Operation {

  public T1(String name, ColumnType type) {
    super(name, type);
  }

  @Override
  public DatabaseValue process(final Row row, final DatabaseValue previousValue) {
    return JDBCDatabaseValue.getAndInit(JDBCUtil.add((row.getAsDouble("A.2")),(1)));
  }
}


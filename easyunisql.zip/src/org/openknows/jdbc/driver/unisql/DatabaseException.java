package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.*;

public class DatabaseException extends Exception {

  public DatabaseException(final Throwable message) {
    this.message = ExceptionUtils.getMessage(message);
  }

  public DatabaseException(final String message) {
  	this.message = message;
  }
 
  @Override
  public String getLocalizedMessage() {
    return message;
  }

  @Override
  public String getMessage() {
    return message;
  }

	private final String message;
}
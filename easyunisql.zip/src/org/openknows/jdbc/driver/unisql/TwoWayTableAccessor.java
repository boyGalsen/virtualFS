package org.openknows.jdbc.driver.unisql;


public interface TwoWayTableAccessor extends TableAccessor {
	
  public boolean hasPrevious() throws DatabaseException;
  public Row getPrevious() throws DatabaseException;
  
  public Row getFirst() throws DatabaseException;
  public Row getLast() throws DatabaseException;
  
  public Row absolute(int row) throws DatabaseException;
  public Row relative(int row) throws DatabaseException;
  
  public int getRowIndex() throws DatabaseException;
  
  public void beforeFirst() throws DatabaseException;
  public void afterLast() throws DatabaseException;
}

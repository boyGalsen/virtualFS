package org.openknows.jdbc.driver.unisql.jdbcmap;


import com.easyrms.db.*;
import com.easyrms.util.*;

import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;


public class JDBCTable implements Table {
  
  public JDBCTable init(final String database, final String name, final String request, final Object[] parameters) throws DatabaseException {
    try {
      return init(SimpleConnections.getConnection(name, "databaseTable", database, true, false), database, name, request, parameters);
    }
    catch (final Throwable ignored) {
      throw new DatabaseException(ignored);
    }
  }
  
  public String getType() {
    return Table.JDBC;
  }
  
  public String getDescription() {
    return this.database;
  }
  
  public JDBCTable init(final Connection databaseConnection, final String database, final String name,  final String request, final Object[] parameters) throws DatabaseException {
    try {
      this.databaseConnection = databaseConnection;
      this.name = name;
      this.database = database;
      this.request = request;
      this.parameters = parameters.clone();
      return this;
    }
    catch (final Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
    }
  }
  
  public MetaData getMetaData() throws DatabaseException {
    return findMetaData();
  }

  public TableAccessor getAccessor() throws DatabaseException {
    return findAccessor();
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }
  
  public String getName() {
    return this.name;
  }
  
  private synchronized TableAccessor findAccessor() throws DatabaseException {
    try {
      int i = 1;
      final PreparedStatement s = databaseConnection.prepareStatement(request);
      for (final Object parameter : parameters) s.setObject(i++, parameter);
      final ResultSet rs = s.executeQuery();
      final TableAccessor accessor = new TableAccessor() {
        private final MetaData metaData = findMetaData();
        private final int columnCount = metaData.getColumnCount();
        
        public MetaData getMetaData() throws DatabaseException {
          return metaData;
        }

        public boolean hasNext() throws DatabaseException {
          return hasNext;
        }

        public Row getNext() throws DatabaseException {
          if (!hasNext) throw new DatabaseException("not valid state");
          final Row result = nextRow;
          findNext();
          return result;
        }
        
        public void init() throws DatabaseException {
          findNext();
        }
        
        private void findNext() throws DatabaseException {
          try {
            hasNext = rs.next();
            if (hasNext) {
              nextRow = new DatabaseRow();
              nextRow.init(metaData);
              for (int j = 1 ; j <= columnCount ; j++) {
                switch (metaData.getColumn(j).getType()) {
                  case LONG: {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getInteger(rs, j)));
                  } break;
                  case DOUBLE: {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getDOUBLE(rs, j)));
                  } break;
                  case BOOLEAN : {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getBoolean(rs, j)));
                  } break;
                  case STRING : {
                    nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getString(rs, j)));
                  } break;
                  default:
                    throw new DatabaseException("Unvalid type");
                }
              }
            }
          }
          catch (Throwable ignored) {
            EasyRMS.trace.log(ignored);
            throw new DatabaseException(ignored);
          }
        }

        public void close() throws DatabaseException {
          try {
            rs.close();
          }
          catch (Throwable ignored) {
            EasyRMS.trace.log(ignored);
            throw new DatabaseException(ignored);
          }          
        }
        private boolean hasNext;
        private DatabaseRow nextRow;
      };
      accessor.init();
      return accessor;
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
    }
  }

  private synchronized MetaData findMetaData() throws DatabaseException {
    try {
      if (this.metaData == null) {
        final PreparedStatement s = databaseConnection.prepareStatement(request);
        final TableMetaData tableMetaData = new TableMetaData();
        final ResultSetMetaData rsm = s.getMetaData();
        final int n = rsm.getColumnCount();
        for (int j = 1 ; j <= n ; j++) {
          final Class<?> classe = SQLUtils.getSQLClass(j, rsm);
          final String columnName = rsm.getColumnName(j);
          if (classe.equals(Integer.class)) {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
          }
          else if (classe.equals(Long.class)) {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
          }
          else if (classe.equals(Float.class)) {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
          }
          else if (classe.equals(Double.class)) {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
          }
          else if (classe.equals(Boolean.class)) {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.BOOLEAN));
          }
          else {
            tableMetaData.add(Column.getAndInit(columnName, ColumnType.STRING));
          }
        }
        this.metaData = tableMetaData;
      }
      return this.metaData;
    }
    catch (Throwable ignored) {
      try {
        if (this.metaData == null) {
          final PreparedStatement s = databaseConnection.prepareStatement(request);
          try {
            s.setMaxRows(1);
            s.execute();
            final TableMetaData tableMetaData = new TableMetaData();
            final ResultSetMetaData rsm = s.getMetaData();
            final int n = rsm.getColumnCount();
            for (int j = 1 ; j <= n ; j++) {
              final Class<?> classe = SQLUtils.getSQLClass(j, rsm);
              final String columnName = rsm.getColumnName(j);
              if (classe.equals(Integer.class)) {
                tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
              }
              else if (classe.equals(Long.class)) {
                tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
              }
              else if (classe.equals(Float.class)) {
                tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
              }
              else if (classe.equals(Double.class)) {
                tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
              }
              else if (classe.equals(Boolean.class)) {
                tableMetaData.add(Column.getAndInit(columnName, ColumnType.BOOLEAN));
              }
              else {
                tableMetaData.add(Column.getAndInit(columnName, ColumnType.STRING));
              }
            }
            this.metaData = tableMetaData;
          }
          finally {
            s.close();
          }
        }
        return this.metaData;
      }
      catch (Throwable ignored2) {
        EasyRMS.trace.log(ignored2);
        throw new DatabaseException(ignored2);
      }    
    }
  }
  
  private MetaData metaData;
  private String name;
  private String database;
  private Connection databaseConnection;
  private String request;
  private Object[] parameters;
}
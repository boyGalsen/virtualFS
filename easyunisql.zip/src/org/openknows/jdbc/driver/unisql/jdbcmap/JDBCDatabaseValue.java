package org.openknows.jdbc.driver.unisql.jdbcmap;


import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import org.openknows.jdbc.driver.unisql.*;

import java.util.*;


public class JDBCDatabaseValue implements DatabaseValue {

  public static JDBCDatabaseValue getAndInitNumber(DatabaseValue value) {
    if (value == null) return NULL;
    if (value instanceof JDBCDatabaseValue) return (JDBCDatabaseValue)value;
    if (value.isIntAvailable()) return getAndInit(value.getIntegerValue());
    return getAndInit(value.getDoubleValue());
  }

  public static JDBCDatabaseValue getAndInit(Object value) {
    if (value == null) return NULL;
    if (value instanceof JDBCDatabaseValue) return (JDBCDatabaseValue)value;
    if (value instanceof Long) return new JDBCDatabaseValue((Long)value);
    if (value instanceof Integer) return new JDBCDatabaseValue(LongCache.get(((Number)value).intValue()));
    if (value instanceof Short) return new JDBCDatabaseValue(LongCache.get(((Number)value).intValue()));
    if (value instanceof Double) return new JDBCDatabaseValue((Double)value);
    if (value instanceof Float) return new JDBCDatabaseValue(MathUtils.getDouble(((Number)value).doubleValue()));
    if (value instanceof Number) return new JDBCDatabaseValue(MathUtils.getDouble(((Number)value).doubleValue()));
    if (value instanceof DateAccessor) return new JDBCDatabaseValue(((DateAccessor)value).toDate());
    if (value instanceof Date) return new JDBCDatabaseValue((Date)value);
    if (value instanceof String) return new JDBCDatabaseValue((String)value, false);
    return new JDBCDatabaseValue(value.toString(), false);
  }

  public static JDBCDatabaseValue getAndInit(Double value) {
    if (value == null) return NULL;
    return new JDBCDatabaseValue(value);
  }
  public static JDBCDatabaseValue getAndInit(Long value) {
    if (value == null) return NULL;
    return new JDBCDatabaseValue(value);
  }
  public static JDBCDatabaseValue getAndInit(Integer value) {
    if (value == null) return NULL;
    return new JDBCDatabaseValue(LongCache.get(value.intValue()));
  }
  public static JDBCDatabaseValue getAndInit(String value) {
    if (value == null) return NULL;
    return new JDBCDatabaseValue(value, false);
  }
  public static JDBCDatabaseValue getAndInit(Boolean value) {
    if (value == null) return NULL;
    return new JDBCDatabaseValue(value);
  }

  public static final JDBCDatabaseValue NULL = new JDBCDatabaseValue((String)null, false);
  public static final JDBCDatabaseValue IGNORED = new JDBCDatabaseValue("Ignored", true);
  
  public final Object getOriginalValue() { return originalValue; }
  
  public final void onPoolFinalize() { onPoolRecycle(); }
  
  @Override
  public final int hashCode() { 
    return isNull() ? 0 : getStringValue().hashCode(); 
  }

  @Override
  public final boolean equals(Object obj) {
    if (obj == null) return false;
    if (obj == this) return true;
    final DatabaseValue otherValue = (DatabaseValue)obj;
    return (otherValue.isNull() && this.isNull()) 
           || StringComparator.equals(this.getStringValue(), otherValue.getStringValue());
  }

  @Override
  public final String toString() { 
    return getStringValue(); 
  }
  public final void close() { 
    onPoolRecycle(); 
  }
  
  public JDBCDatabaseValue initSubValues(final DatabaseValue... fromValues) {
    if (!isNull() && !isIgnored()) {
      for (int i = 0, n = fromValues.length; i < n; i++) {
        final DatabaseValue value = fromValues[i];
        if (value != null) {
          final EzArray<String> subKeys = value.getSubValueKeys();
          if (subKeys != null) {
            for (int j = 0, m = subKeys.getCount(); j < m; j++) {
              final String subKey = subKeys.get(j);
              setSubValue(subKey, value.getSubValue(subKey));
            }
          }
        }
      }
    }
    return this;
  }
  
  public boolean isIgnored() {
    return isIgnored;
  }
  
  private boolean isIgnored;
  
  private JDBCDatabaseValue(final String value, boolean isIgnored) {
    this.isIgnored = isIgnored;
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.dateValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = "".equals(value) ? Boolean.TRUE : Boolean.FALSE;
      this.stringValue = value;
    }
  }
  
  private JDBCDatabaseValue(final Date value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.dateValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = "".equals(value) ? Boolean.TRUE : Boolean.FALSE;
      this.stringValue = ebXMLDateFormat.referenceFormat(value);
      this.dateValue = value;
    }
  }


  private JDBCDatabaseValue(final Long value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.dateValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = Boolean.FALSE;
      final int intValue = value.intValue();
      this.stringValue = LongCache.toString(intValue);
      this.isIntAvailable = true;
      this.intValue = value;
      this.isDoubleAvailable = true;
      this.doubleValue = MathUtils.getDouble(intValue);
      switch (intValue) {
        case 0 : this.booleanValue = Boolean.FALSE; this.isBooleanAvailable = true; break;
        case 1 : this.booleanValue = Boolean.TRUE; this.isBooleanAvailable = true; break;
      }
    }
  }
  
  private JDBCDatabaseValue(final Double value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.dateValue = null;
      this.intValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = Boolean.FALSE;
      final double doubleValue = value.doubleValue();
      this.stringValue = value.toString();
      this.isDoubleAvailable = true;
      this.doubleValue = value;
      if (doubleValue == 0.0) {
        this.booleanValue = Boolean.FALSE; this.isBooleanAvailable = true;
      }
      else if (doubleValue == 1.0) {
        this.booleanValue = Boolean.TRUE; this.isBooleanAvailable = true;
      }
    }
  }
  
  private JDBCDatabaseValue(final Boolean value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.dateValue = null;
      this.intValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = Boolean.FALSE;
      final boolean booleanValue = value.booleanValue();
      this.stringValue = value.toString();
      this.isDoubleAvailable = true;
      this.doubleValue = booleanValue ? MathUtils.getDouble(1) : MathUtils.getDouble(0);
      this.isIntAvailable = true;
      this.intValue = booleanValue ? LongCache.one : LongCache.zero;
      this.booleanValue = value; 
      this.isBooleanAvailable = true;
    }
  }
  
  public final boolean isNull() {
    return isNull.booleanValue();
  }

  public final boolean isDoubleAvailable() {
    return isDoubleAvailable;
  }

  public final double getdoubleValue() {
    checkIntegerAndDouble();
    return (doubleValue == null)
      ? 0.0
      : doubleValue.doubleValue();
  }

  public final Double getDoubleValue() {
    checkIntegerAndDouble();
    return doubleValue;
  }

  public final boolean isIntAvailable() {
    return isIntAvailable;
  }

  public final long getintValue() {
    checkIntegerAndDouble();
    return intValue == null
      ? 0
      : intValue.longValue();
  }

  public final Long getIntegerValue() {
    checkIntegerAndDouble();
    return intValue;
  }
  
  private void checkIntegerAndDouble() {
    if (!this.isDoubleAvailable && !this.isIntAvailable) {
      if (this.stringValue != null) {
        if (StringComparator.isInteger(stringValue)) {
          this.intValue = LongCache.parseLong(stringValue.trim());
          this.doubleValue = MathUtils.getDouble(this.intValue.longValue());
        }
        else if (StringComparator.isNumberExtended(stringValue)) {
          final String stringValue = this.stringValue.replace(',','.').trim();
          this.intValue = null;
          this.doubleValue = StringComparator.getDouble(stringValue, null);
        }
      }
      this.isDoubleAvailable = true;
      this.isIntAvailable = true;
    }
  }

  public final String getStringValue() {
    return stringValue;
  }

  public final boolean isBooleanAvailable() {
    return isBooleanAvailable;
  }

  public final boolean getbooleanValue() {
    return (booleanValue == null)
      ? false
      : booleanValue.booleanValue();
  }

  public final Boolean getBooleanValue() {
    return booleanValue;
  }

  public final Date getDateValue() {
    return dateValue;
  }

  public final boolean isDateAvailable() {
    return isDateAvailable;
  }

  private Object originalValue;
  private String stringValue;
  private Boolean isNull;
  private Long intValue;
  private Double doubleValue;
  private Boolean booleanValue;
  private Date dateValue;
  
  private boolean isDoubleAvailable;
  private boolean isIntAvailable;
  private boolean isBooleanAvailable;
  private boolean isDateAvailable;
  
  public EzArray<String> getSubValueKeys() {
    if (subValues == null) return null;
    return new EzArrayList<String>(subValues.keySet()); 
  }
  public DatabaseValue getSubValue(String key) {
    if (subValues == null) return null;
    return subValues.get(key);
  }
  public JDBCDatabaseValue setSubValue(String key, DatabaseValue value) {
    if (subValues == null) {
      subValues = new HashMap<String, DatabaseValue>();
    }
    subValues.put(key, value);
    return this;
  }
  public JDBCDatabaseValue setSubValue(String[] key, DatabaseValue[] value) {
    if (subValues == null) {
      subValues = new HashMap<String, DatabaseValue>();
    }
    for (int i = 0, n = value.length; i < n; i++) {
      subValues.put(key[i], value[i]);
    }
    return this;
  }
  
  private HashMap<String, DatabaseValue> subValues;

  public final void onPoolRecycle() {
    stringValue = null;
    isNull = null;
    intValue = null;
    doubleValue = null;
    booleanValue = null;
    isDoubleAvailable = false;
    isIntAvailable = false;
    isBooleanAvailable = false;
    dateValue = null;
    isDateAvailable = false;
    if (subValues != null) {
      subValues.clear();
    }
    subValues = null;
  }
}
package org.openknows.jdbc.driver.unisql.jdbcmap;


import com.easyrms.db.*;
import com.easyrms.util.*;

import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;


public class JDBCRequestTable implements Table {
  
  public JDBCRequestTable init(final String database, final String name, final String request, final Object[] parameters) throws DatabaseException {
    try {
      return init(SimpleConnections.getConnection(name, "databaseRequest", database, true, false), database, name, request, parameters);
    }
    catch (final Throwable ignored) {
      throw new DatabaseException(ignored);
    }
  }
  
  public String getType() {
    return Table.JDBC;
  }
  
  public String getDescription() {
    return this.database;
  }

  public JDBCRequestTable init(final Connection databaseConnection, final String database, final String name,  final String request, final Object[] parameters) throws DatabaseException {
    try {
      this.databaseConnection = databaseConnection;
      this.name = name;
      this.request = request;
      this.parameters = parameters.clone();
      return this;
    }
    catch (final Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
    }
  }
  
  public MetaData getMetaData() throws DatabaseException {
    return findMetaData();
  }

  public TableAccessor getAccessor() throws DatabaseException {
    return findAccessor();
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }
  
  public String getName() {
    return this.name;
  }
  
  private synchronized TableAccessor findAccessor() throws DatabaseException {
    try {
      int i = 1;
      try (final PreparedStatement s = databaseConnection.prepareStatement(request)) {
        for (int j = 0, m = parameters.length; j < m; j++) {
          final Object parameter = parameters[j];
          s.setObject(i++, parameter);
        }
        try (final ResultSet rs = s.executeQuery()) {
          return createTableAccessorFromJDBCResultSet(rs);
        }
      }
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
    }
  }
  
  public static TableAccessor createTableAccessorFromJDBCResultSet(ResultSet rs) throws SQLException, DatabaseException {
    final MetaData metaData = createMetaDataFromJDBCResultSetMetaData(rs.getMetaData());
    final int columnCount = metaData.getColumnCount();
    final TableAccessor accessor = new TableAccessor() {
      
      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return hasNext;
      }

      public Row getNext() throws DatabaseException {
        if (!hasNext) throw new DatabaseException("not valid state");
        final Row result = nextRow;
        findNext();
        return result;
      }
      
      public void init() throws DatabaseException {
        findNext();
      }
      
      private void findNext() throws DatabaseException {
        try {
          hasNext = rs.next();
          if (hasNext) {
            nextRow = new DatabaseRow();
            nextRow.init(metaData);
            for (int j = 1 ; j <= columnCount ; j++) {
              switch (metaData.getColumn(j).getType()) {
                case LONG: {
                  nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getInteger(rs, j)));
                } break;
                case DOUBLE: {
                  nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getDOUBLE(rs, j)));
                } break;
                case BOOLEAN : {
                  nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getBoolean(rs, j)));
                } break;
                case STRING : {
                  nextRow.set(j , JDBCDatabaseValue.getAndInit(SQLUtils.getString(rs, j)));
                } break;
                default:
                  throw new DatabaseException("Unvalid type");
              }
            }
          }
        }
        catch (Throwable ignored) {
          EasyRMS.trace.log(ignored);
          throw new DatabaseException(ignored);
        }
      }

      public void close() throws DatabaseException {
        try {
          rs.close();
        }
        catch (Throwable ignored) {
          EasyRMS.trace.log(ignored);
          throw new DatabaseException(ignored);
        }          
      }
      private boolean hasNext;
      private DatabaseRow nextRow;
    };
    accessor.init();
    return accessor;
  }

  private synchronized MetaData findMetaData() throws DatabaseException {
    try {
      if (this.metaData == null) {
        try (final PreparedStatement s = databaseConnection.prepareStatement(request)) {
          final ResultSetMetaData rsm = s.getMetaData();
          this.metaData = createMetaDataFromJDBCResultSetMetaData(rsm);
        }
      }
      return this.metaData;
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
    }
  }
  
  public static MetaData createMetaDataFromJDBCResultSetMetaData(ResultSetMetaData rsm) throws SQLException {
    final TableMetaData tableMetaData = new TableMetaData();
    final int n = rsm.getColumnCount();
    for (int j = 1 ; j <= n ; j++) {
      final Class<?> classe = SQLUtils.getSQLClass(j, rsm);
      final String columnName = rsm.getColumnName(j); 
      if (classe != null) {
        if (classe.equals(Integer.class)) {
          tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
        }
        else if (classe.equals(Long.class)) {
          tableMetaData.add(Column.getAndInit(columnName, ColumnType.LONG));
        }
        else if (classe.equals(Float.class)) {
          tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
        }
        else if (classe.equals(Double.class)) {
          tableMetaData.add(Column.getAndInit(columnName, ColumnType.DOUBLE));
        }
        else if (classe.equals(Boolean.class)) {
          tableMetaData.add(Column.getAndInit(columnName, ColumnType.BOOLEAN));
        }
        else {
          tableMetaData.add(Column.getAndInit(columnName, ColumnType.STRING));
        }
      }
      else {
        tableMetaData.add(Column.getAndInit(columnName, ColumnType.STRING));
      }
    }
    return tableMetaData;
  }

  private MetaData metaData;
  private String name;
  private String database;
  private Connection databaseConnection;
  private String request;
  private Object[] parameters;
}
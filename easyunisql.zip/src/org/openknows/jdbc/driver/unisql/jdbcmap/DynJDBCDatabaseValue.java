package org.openknows.jdbc.driver.unisql.jdbcmap;


import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.util.*;
import java.util.regex.*;

import org.openknows.jdbc.driver.unisql.*;

public class DynJDBCDatabaseValue implements DatabaseValue {
  
  public final Object getOriginalValue() { 
    return originalValue; 
  }
  
  @Override
  public final int hashCode() { 
    return isNull() ? 0 : getStringValue().hashCode(); 
  }
  
  public boolean isIgnored() {
    return isIgnored;
  }

  @Override
  public final boolean equals(Object obj) {
    if (obj == null) return false;
    if (obj == this) return true;
    final DatabaseValue otherValue = (DatabaseValue)obj;
    return (otherValue.isNull() && this.isNull()) 
           || StringComparator.equals(this.getStringValue(), otherValue.getStringValue());
  }

  @Override
  public final String toString() { 
    return getStringValue(); 
  }
  
  public final void close() {     
    stringValue = null;
    isNull = null;
    intValue = null;
    doubleValue = null;
    booleanValue = null;
    isDoubleAvailable = false;
    isIntAvailable = false;
    isBooleanAvailable = false;
    isCkeck = false;
    if (subValues != null) {
      subValues.clear();
    }
    subValues = null;
  }

  private void init(final String value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = "".equals(value) ? Boolean.TRUE : Boolean.FALSE;
      this.stringValue = value;
    }
  }

  private void init(final Long value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = Boolean.FALSE;
      final long longValue = value.intValue();
      this.stringValue = LongCache.toString(longValue);
      this.isIntAvailable = true;
      this.intValue = value;
      this.isDoubleAvailable = true;
      this.doubleValue = MathUtils.getDouble(longValue);
      switch ((int)longValue) {
        case 0 : this.booleanValue = Boolean.FALSE; this.isBooleanAvailable = true; break;
        case 1 : this.booleanValue = Boolean.TRUE; this.isBooleanAvailable = true; break;
      }
    }
  }

  private void init(final Double value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = Boolean.FALSE;
      final double doubleValue = value.doubleValue();
      this.stringValue = value.toString();
      this.isDoubleAvailable = true;
      this.doubleValue = value;
      if (doubleValue == 0.0) {
        this.booleanValue = Boolean.FALSE; this.isBooleanAvailable = true;
      }
      else if (doubleValue == 1.0) {
        this.booleanValue = Boolean.TRUE; this.isBooleanAvailable = true;
      }
    }
  }
  
  private void init(final Boolean value) {
    this.originalValue = value;
    if (value == null) {
      this.isNull = Boolean.TRUE;
      this.stringValue = null;
      this.intValue = null;
      this.doubleValue = null;
      this.booleanValue = null;
    }
    else {
      this.isNull = Boolean.FALSE;
      final boolean booleanValue = value.booleanValue();
      this.stringValue = value.toString();
      this.isDoubleAvailable = true;
      this.doubleValue = booleanValue ? MathUtils.getDouble(1) : MathUtils.getDouble(0);
      this.isIntAvailable = true;
      this.intValue = booleanValue ? LongCache.one : LongCache.zero;
      this.booleanValue = value; 
      this.isBooleanAvailable = true;
    }
  }

  public DynJDBCDatabaseValue() { }
  
  protected Object buildOriginalValue() {
    return originalValue;
  }
  
  public final String getStringValue() { 
    check();  
    return stringValue; 
  }
  public final boolean isBooleanAvailable() { 
    check();  
    return isBooleanAvailable; 
  }
  public final boolean getbooleanValue() { 
    check();  
    return booleanValue == null ? false : booleanValue.booleanValue(); 
  }
  public final Boolean getBooleanValue() { 
    check();  
    return booleanValue; 
  }
  public final Date getDateValue() { 
    check();  
    return null; 
  }
  public final boolean isDateAvailable() { 
    check();  
    return false; 
  }
  public final boolean isNull() { 
    check();  
    return isNull.booleanValue(); 
  }
  public final boolean isDoubleAvailable() { 
    check();  
    return isDoubleAvailable; 
  }
  public final double getdoubleValue() { 
    check(); 
    return (doubleValue == null) ? 0.0 : doubleValue.doubleValue(); 
  }
  public final Double getDoubleValue() { 
    check(); return doubleValue; 
  }
  public final boolean isIntAvailable() { 
    check();  
    return isIntAvailable; 
  }
  public final long getintValue() { 
    check(); 
    return (intValue == null) ? 0 : intValue.longValue(); 
  }
  public final Long getIntegerValue() { 
    check();  
    return intValue; 
  }
  
  private void check() {
    if (!isCkeck) { 
      final Object originalValue = buildOriginalValue();
      if (originalValue instanceof Double) {
        init((Double)originalValue);
      }
      else if (originalValue instanceof Long) {
        init((Long)originalValue);
      }
      else if (originalValue instanceof Boolean) {
        init((Boolean)originalValue);
      }
      else {
        init((String)originalValue == null ? null : originalValue.toString());
      }
      if (!this.isDoubleAvailable && !this.isIntAvailable) {
        if (this.stringValue != null) {
          if (intPattern.matcher(stringValue).matches()) {
            this.intValue = LongCache.parseLong(stringValue.trim());
            this.doubleValue = MathUtils.getDouble(this.intValue.intValue());
          }
          else if (doublePattern.matcher(stringValue).matches()) {
            final String stringValue = this.stringValue.replace(',','.').trim();
            this.intValue = null;
            this.doubleValue = MathUtils.getDouble(Double.parseDouble(stringValue));
          }
        }
        this.isDoubleAvailable = true;
        this.isIntAvailable = true;
      }
      isCkeck = true;
    }
  }
  
  private static final Pattern intPattern = Pattern.compile("[ \t]*-?[0-9]+[ \t]*");
  private static final Pattern doublePattern = Pattern.compile("[ \t]*-?[0-9]+[\\.,][0-9]*[ \t]*");
  
  
  private Object originalValue;
  private String stringValue;
  private Boolean isNull;
  private Long intValue;
  private Double doubleValue;
  private Boolean booleanValue;
  private boolean isCkeck;
  
  private boolean isIgnored;
  
  private boolean isDoubleAvailable;
  private boolean isIntAvailable;
  private boolean isBooleanAvailable;
  
  public EzArray<DatabaseValue> getSubValues() {
    if (subValues == null) return null;
    issubValuesRead = true;
    return subValues; 
  }

  public DynJDBCDatabaseValue addSubValue(DatabaseValue value) {
    if (subValues == null) {
      subValues = new EzArrayList<DatabaseValue>();
    }
    else if (issubValuesRead) {
      final EzArrayList<DatabaseValue> previousSubValues = subValues;
      subValues = new EzArrayList<DatabaseValue>((ArrayList<DatabaseValue>)previousSubValues);
    }
    subValues.add(value);
    isIgnored = isIgnored || value.isIgnored();
    isCkeck = false;
    stringValue = null;
    isNull = null;
    intValue = null;
    doubleValue = null;
    booleanValue = null;
    isDoubleAvailable = false;
    isIntAvailable = false;
    isBooleanAvailable = false;
    return this;
  }
  
  public EzArray<String> getSubValueKeys() {
    return (stdSubValues != null) ? new EzArrayList<String>(stdSubValues.keySet()) : null; 
  }
  public DatabaseValue getSubValue(String key) {
    if (stdSubValues == null) {
      return null;
    }
    return stdSubValues.get(key);
  }
  public DynJDBCDatabaseValue setSubValue(String key, DatabaseValue value) {
    if (stdSubValues == null) {
      stdSubValues = new HashMap<String, DatabaseValue>();
    }
    stdSubValues.put(key, value);
    return this;
  }
  public DynJDBCDatabaseValue setSubValue(String[] key, DatabaseValue[] value) {
    if (stdSubValues == null) {
      stdSubValues = new HashMap<String, DatabaseValue>();
    }
    for (int i = 0, n = value.length; i < n; i++) {
      stdSubValues.put(key[i], value[i]);
    }
    return this;
  }
  
  private HashMap<String, DatabaseValue> stdSubValues; 
  private boolean issubValuesRead = false;
  private EzArrayList<DatabaseValue> subValues;
}
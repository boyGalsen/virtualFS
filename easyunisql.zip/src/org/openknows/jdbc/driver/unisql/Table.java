package org.openknows.jdbc.driver.unisql;


public interface Table {
  
  public static final String MEMORY = "Memory";
  public static final String FILE = "File";
  public static final String JDBC = "JDBC";
  
  public String getName();
  public String getType();
  public String getDescription();

  public MetaData getMetaData() throws DatabaseException;
  public TableAccessor getAccessor() throws DatabaseException;
	public InsertTableAccessor getInsertAccessor() throws DatabaseException;
}

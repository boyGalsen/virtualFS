package org.openknows.jdbc.driver.unisql;


public abstract class RowFilter implements TableAccessor {

  public RowFilter() {
  }
  
  public void init() throws DatabaseException {
  }
  
  public RowFilter applyOn(final TableAccessor accessor) throws DatabaseException {
    applyOn(accessor, null);
    return this;
  }
    
  public RowFilter applyOn(final TableAccessor accessor, final ColumnFilter columnFilter) throws DatabaseException {
		this.accessor = accessor;
    this.columnFilter = columnFilter;
		findNextValid();
    return this;
  }

  public MetaData getMetaData() throws DatabaseException {
    return columnFilter == null ? accessor.getMetaData() : columnFilter.getMetaData();
  }

  public MetaData getOriginalMetaData() throws DatabaseException {
    return accessor.getMetaData();
  }

  public boolean hasNext() throws DatabaseException {
    return hasNext;
  }

  public Row getNext() throws DatabaseException {
  	if (!hasNext) throw new DatabaseException("no more value");
  	final Row row = nextRow;
  	findNextValid();
    return columnFilter == null ? row : columnFilter.setRow(row);
  }

  public void close() throws DatabaseException {
  	accessor.close();
  }

  private void findNextValid() throws DatabaseException {
		hasNext = accessor.hasNext(); 
  	while (hasNext) {
      nextRow = accessor.getNext();
      if (check(nextRow)) return;
			hasNext = accessor.hasNext(); 
  	}
  }

  protected abstract boolean check(Row row);

  private Row nextRow = null;
  private boolean hasNext = false;
  private TableAccessor accessor;
  private ColumnFilter columnFilter;
}

package org.openknows.jdbc.driver.unisql;

import java.util.ArrayList;

public class ColumnFilter implements Row {
  
  public ColumnFilter(final MetaData fromMetaData) {
    this.metaData = new TableMetaData();
    this.fromMetaData = fromMetaData;
  }
  
  public int getElementCount() {
    return this.metaData.getColumnCount();
  }

  public void add(String columnName, String mappedColumn) {
    this.metaData.add(Column.getAndInit(columnName, fromMetaData.findColumnByName(mappedColumn).getType()));
    this.mappedNames.add(mappedColumn);
  }

  public void add(int mappedColumn) {
    final Column column = fromMetaData.getColumn(mappedColumn);
    this.metaData.add(column);
    this.mappedNames.add(column.getName());
  }
  
  public void add(String mappedColumn) {
    final Column column = fromMetaData.findColumnByName(mappedColumn);
    this.metaData.add(column);
    this.mappedNames.add(mappedColumn);
  }

  public void compute() {
    if (this.mappedTables == null) {
      final int n = metaData.getColumnCount();
      this.mappedTables = new int[n];
      for (int i = 0; i < n ; i++) {
        this.mappedTables[i] = fromMetaData.getColumnIndex(this.mappedNames.get(i));
      }
    } 
  }
  
  public Row setRow(Row row) {
    this.row = row;
    return this;
  }

  public DatabaseValue getDatabaseValue(int index) {
    compute();
    return row.getDatabaseValue(mappedTables[index-1]);
  }

  public DatabaseValue getDatabaseValue(String columnName) {
    return getDatabaseValue(metaData.getColumnIndex(columnName));
  }

  public Object getValue(int index) {
    compute();
    return row.getValue(mappedTables[index-1]);
  }

  public Object getValue(String columnName) {
    return getValue(metaData.getColumnIndex(columnName));
  }
  
  public boolean isNull(int index) {
    compute();
    return row.isNull(mappedTables[index-1]);
  }

  public boolean isNull(String columnName) {
    return isNull(metaData.getColumnIndex(columnName));
  }

  public String getAsString(int index) {
    compute();
    return row.getAsString(mappedTables[index-1]);
  }

  public String getAsString(String columnName) {
    return getAsString(metaData.getColumnIndex(columnName));
  }

  public Long getAsInteger(int index) {
    compute();
    return row.getAsInteger(mappedTables[index-1]);
  }

  public Long getAsInteger(String columnName) {
    return getAsInteger(metaData.getColumnIndex(columnName));
  }

  public Double getAsDouble(int index) {
    compute();
    return row.getAsDouble(mappedTables[index-1]);
  }

  public Double getAsDouble(String columnName) {
    return getAsDouble(metaData.getColumnIndex(columnName));
  }

  public Boolean getAsBoolean(int index) {
    compute();
    return row.getAsBoolean(mappedTables[index-1]);
  }

  public Boolean getAsBoolean(String columnName) {
    return getAsBoolean(metaData.getColumnIndex(columnName));
  }
  
  public MetaData getMetaData() {
    return metaData;
  }
  
  private final TableMetaData metaData;
  private final MetaData fromMetaData;
  private final ArrayList<String> mappedNames = new ArrayList<String>();
  private Row row;
  private int[] mappedTables;
}

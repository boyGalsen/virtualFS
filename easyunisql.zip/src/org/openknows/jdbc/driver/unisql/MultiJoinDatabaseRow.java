package org.openknows.jdbc.driver.unisql;

import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;


public class MultiJoinDatabaseRow extends AbstractDatabaseRow {
  
  public Row init(final MetaData metadata, final MultiJoinDatabaseRowAccessor rowAccessor, final Row[] rows) {
    super.init(metadata);
    this.rows = rows.clone();
    this.rowAccessor = rowAccessor;
    return this;
  }
  
  @Override
  public DatabaseValue getDatabaseValue(final int index) {
    final Row row = rows[rowAccessor.getRowIndex(index)];
    return (row == null) ? JDBCDatabaseValue.NULL : row.getDatabaseValue(rowAccessor.getRowRelativeIndex(index));
  }
  
  private MultiJoinDatabaseRowAccessor rowAccessor;
  private Row[] rows;
  
  public static interface MultiJoinDatabaseRowAccessor {
    
    public int getRowIndex(int index);
    public int getRowRelativeIndex(int index);
  }
}

package org.openknows.jdbc.driver.unisql.memory;

public class SortedMemoryTable {

}

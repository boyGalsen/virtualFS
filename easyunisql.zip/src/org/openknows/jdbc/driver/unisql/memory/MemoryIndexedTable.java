package org.openknows.jdbc.driver.unisql.memory;

import com.easyrms.util.array.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;

public class MemoryIndexedTable implements Table {

  public MemoryIndexedTable init(final String name, final IndexRule indexRule, final MetaData fromMetaData) {
    final TableMetaData metaData = new TableMetaData();
    this.columnMapping = new int[fromMetaData.getColumnCount()];
    for (int i = 1, n = columnMapping.length, j = indexRule.getIndexSize() + 1; i <= n; i++) {
      final int k = indexRule.get(i);
      columnMapping[i - 1] = k <= 0
        ? j++
        : k;
    }
    for (int i = 1, n = columnMapping.length; i <= n; i++) {
      metaData.add(fromMetaData.getColumn(columnMapping[i - 1]));
    }
    this.metaData = metaData;
    this.name = name;
    this.indexLength = indexRule.getIndexSize();
    this.keys = new DatabaseValue[indexLength];
    this.values = new HashIndexMap<DatabaseValue>(indexLength);
    this.rowLength = metaData.getColumnCount();
    return this;
  }

  public MemoryIndexedTable init(final String name, final int indexLength, final MetaData metaData) {
    this.name = name;
    this.metaData = metaData;
    this.indexLength = indexLength;
    this.keys = new DatabaseValue[indexLength];
    this.values = new HashIndexMap<DatabaseValue>(indexLength);
    this.rowLength = metaData.getColumnCount();
    return this;
  }

  public void insert(final TableAccessor tableAccessor) throws DatabaseException {
    final InsertTableAccessor insertAccessort = getMappingInsertAccessor();
    while (tableAccessor.hasNext()) {
      insertAccessort.insert(tableAccessor.getNext());
    }
    insertAccessort.close();
    tableAccessor.close();
  }

  private void insert(final Row row) {
    int i = 1;
    while (i <= indexLength) {
      keys[i - 1] = row.getDatabaseValue(i);
      i++;
    }
    if (rowLength > indexLength) {
      final ArrayList<DatabaseValue> addList = new ArrayList<DatabaseValue>();
      while (i <= rowLength) {
        addList.add(row.getDatabaseValue(i++));
      }
      values.add(keys, addList);
    }
    else {
      values.add(keys);
    }
  }

  public String getName() {
    return name;
  }

  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }

  public TableAccessor getAccessor() throws DatabaseException {
    final Iterator<List<DatabaseValue>> rows = values.iterator();
    return new TableAccessor() {

      public void init() throws DatabaseException {}

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return rows.hasNext();
      }

      public Row getNext() throws DatabaseException {
        return new ListDatabaseRow().init(metaData, rows.next());
      }

      public void close() throws DatabaseException {}
    };
  }

  public TableAccessor getAccessor(final DatabaseValue[] keys) throws DatabaseException {
    final Iterator<List<DatabaseValue>> rows = values.iterator(keys);
    return new TableAccessor() {

      public void init() throws DatabaseException {}

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return rows.hasNext();
      }

      public Row getNext() throws DatabaseException {
        return new ListDatabaseRow().init(metaData, rows.next());
      }

      public void close() throws DatabaseException {}
    };
  }

  public InsertTableAccessor getMappingInsertAccessor() throws DatabaseException {
    final int[] columnMapping = this.columnMapping;
    return new AbstractInsertTableAccessor() {

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      @Override
      protected void internalInsert(final Row row) throws DatabaseException {
        MemoryIndexedTable.this.insert(new MappingRow().init(metaData, row, columnMapping));
      }

      public void close() throws DatabaseException {}
    };
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return new AbstractInsertTableAccessor() {

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      @Override
      protected void internalInsert(final Row row) throws DatabaseException {
        MemoryIndexedTable.this.insert(row);
      }

      public void close() throws DatabaseException {}
    };
  }

  public String getType() {
    return Table.MEMORY;
  }

  public String getDescription() {
    return null;
  }

  private String name;
  private MetaData metaData;
  private HashIndexMap<DatabaseValue> values;
  private int indexLength;
  private DatabaseValue[] keys;
  private int rowLength;
  private int[] columnMapping;
}
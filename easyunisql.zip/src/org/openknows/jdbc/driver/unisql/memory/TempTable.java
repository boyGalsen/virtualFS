package org.openknows.jdbc.driver.unisql.memory;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.sql.*;

import java.util.*;

public final class TempTable {

  public static MemoryTable createFrom(TEMP_TABLE table) throws DatabaseException {
    final TableMetaData metaData = new TableMetaData();
    for (final String column : table.getColumns()) {
      metaData.add(Column.getAndInit(column, ColumnType.STRING));
    }
    final MemoryTable memTable = new MemoryTable(table.getName(), metaData, null);
    final InsertTableAccessor insertAccessort = memTable.getInsertAccessor();
    try {
      final int columnCount = metaData.getColumnCount();
      for (final ArrayList<OPERATION> row : table.getValues()) {
        final DatabaseValue[] rowValues = new DatabaseValue[columnCount];
        for (int i = 0; i < columnCount; i++) {
          rowValues[i] = row.get(i).getOperation(null, metaData).process(null, null);
        }
        insertAccessort.insert(rowValues);
      }
    }
    finally {
      insertAccessort.close();
    }
    return memTable;
  }
}

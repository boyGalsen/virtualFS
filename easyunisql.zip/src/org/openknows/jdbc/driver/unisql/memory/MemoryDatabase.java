package org.openknows.jdbc.driver.unisql.memory;

import com.easyrms.cache.*;
import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;

import java.util.*;



public class MemoryDatabase {
  
  public MemoryDatabase(final JDBCConnectionDriver driver, final String name) throws DatabaseException {
    this.name = name;
    this.driver = driver;
    add(null, allTables);
    final TableMetaData dualMetaData = new TableMetaData();
    //dualMetaData.add(Column.getAndInit("DUAL", ColumnType.STRING));
    final MemoryTable dual = new MemoryTable("DUAL", dualMetaData, null);
    final InsertTableAccessor insert = dual.getInsertAccessor();
    insert.insert(new DatabaseValue[] {});
    insert.close();
    add(PUBLIC, dual);
  }
  
  public JDBCConnectionDriver getDriver() {
    return this.driver;
  }
  
  public String getName() {
    return this.name;
  }
  
  public Table getCatalogs() {
    return catalogsTable;  
  }
  
  public Table getAllTables() {
    return allTables;
  }
  
  public Table getTables(final String catalog) {
    return catalogs.get(StringUtil.NVL(catalog, PUBLIC).toUpperCase());
  }

  public Table findTable(final String catalog, final String name) throws DatabaseException {
    return tables.get(StringUtil.NVL(catalog, PUBLIC).toUpperCase(), name.toUpperCase());
  }
  
  public void add(final String catalog, final Table table) throws DatabaseException {
    final String[] value = new String[] {
      StringUtil.NVL(catalog, PUBLIC), 
      null, 
      "TABLE", 
      table.getName(), 
      table.getDescription(), 
      null, 
      null, 
      null, 
      null, 
      "USER",};
    catalogs.get(StringUtil.NVL(catalog, PUBLIC).toUpperCase()).addValue(value);
    allTables.addValue(value);
    tables.put(StringUtil.NVL(catalog, PUBLIC).toUpperCase(), table.getName().toUpperCase(), table);
  }
  
  public void addVView(String name, String table) {
    vviews.put(name, table); 
  }
  
  public void removeVView(String name) {
    vviews.remove(name);
  }
  
  public boolean remove(final String catalog, final Table table) throws DatabaseException {
    if (!tables.containsKey(StringUtil.NVL(catalog, PUBLIC).toUpperCase(), table.getName().toUpperCase())) return false;
    tables.remove(StringUtil.NVL(catalog, PUBLIC).toUpperCase(), table.getName().toUpperCase());
    return true;
  }
  
  public boolean remove(final String catalog, final String table) throws DatabaseException {
    if (!tables.containsKey(StringUtil.NVL(catalog, PUBLIC).toUpperCase(), table.toUpperCase())) return false;
    tables.remove(StringUtil.NVL(catalog, PUBLIC).toUpperCase(), table.toUpperCase());
    return true;
  }

  private final Cache<String, SimpleMemoryTable> catalogs = Caches.newCacheInstance(new Creator<String, SimpleMemoryTable>(){

    public SimpleMemoryTable create(String key) {
      return new SimpleMemoryTable(key, tableColumns);
    }
  });  
  
  private final HashMap<String, String> vviews = new HashMap<String, String>();
  private final String name;
  private final JDBCConnectionDriver driver;
  private static final String[] tableColumns = new String[] { "TABLE_CAT", "TABLE_SHEM", "TABLE_TYPE", "TABLE_NAME", "REMARK", "TYPE_CAT", 
  "TYPE_SCHEM", 
  "TYPE_NAME" ,
  "SELF_REFERENCING_COL_NAME", 
  "REF_GENERATION",};
  private final SimpleMemoryTable catalogsTable = new SimpleMemoryTable("CATALOGS", new String[] { "TABLE_CAT",});
  private final SimpleMemoryTable allTables = new SimpleMemoryTable("TABLES", tableColumns);
  private final HashMap2D<String, String, Table>tables = new HashMap2D<String, String, Table>();
  public static final String CATALOGS = "CATALOGS";
  public static final String PUBLIC = "PUBLIC";
  public static final String COLUMN_NAME = "NAME";
  public static final String COLUMN_TYPE = "TYPE";
  public static final String COLUMN_DESCRIPTION = "DESCRIPTION";
}

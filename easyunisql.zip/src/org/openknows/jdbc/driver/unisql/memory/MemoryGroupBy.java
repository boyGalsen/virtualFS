package org.openknows.jdbc.driver.unisql.memory;

import com.easyrms.util.array.*;

import org.openknows.jdbc.driver.unisql.operation.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;

public class MemoryGroupBy implements Table {

  public MetaData getMetaData() {
    return this.groupByMetaData;
  }

  public MemoryGroupBy init(final String name, final MetaData metaData) {
    this.name = name;
    return this;
  }

  public String getName() {
    return this.name;
  }

  /*public void addColumn(final String name) {
    addColumn(name, name);
  }*/

  /*public void addColumn(final String name, final String mappingColumn) {
    this.groupByMetaData.add(Column.getAndInit(name, this.metaData.findColumnByName(mappingColumn).getType()));
    columnMapping.add(mappingColumn);
  }*/

  public void addColumn(final Operation operation) {
    this.groupByMetaData.add(Column.getAndInit(operation.getName(), operation.getType()));
    columnMapping.add(operation);
  }

  public void addOperation(final Operation operation) {
    this.groupByMetaData.add(Column.getAndInit(operation.getName(), operation.getType()));
    operations.add(operation);
  }

  public void setHaving(final Operation operation) {
    this.groupByMetaData.add(Column.getAndInit("HAVING_SQL_OPERATION", operation.getType()));
    operations.add(operation);
  }

  public void compute() {
    final int n = columnMapping.size();
    //columnsMapping = new int[n];
    values = new DatabaseValue[n];
    // final int m = operations.size();
    // operationValues = new DatabaseValue[m];
    //for (int i = 0; i < n; i++) {
    //  columnsMapping[i] = this.metaData.getColumnIndex(columnMapping.get(i));
    //}
    this.result = new HashIndexMap<DatabaseValue>(n);
  }

  public void insert(Row row) {
    final int n = columnMapping.size();
    final int m = operations.size();
    for (int i = 0; i < n; i++) {
      values[i] = columnMapping.get(i).process(row, JDBCDatabaseValue.NULL);//row.getDatabaseValue(columnsMapping[i]);
    }
    final List<List<DatabaseValue>> previousValues = this.result.get(values, null);
    if (previousValues == null) {
      final ArrayList<DatabaseValue> operationValues = new ArrayList<DatabaseValue>();
      for (int i = 0; i < m; i++) {
        operationValues.add(operations.get(i).process(row, JDBCDatabaseValue.NULL));
      }
      final List<List<DatabaseValue>> newValue = new ArrayList<List<DatabaseValue>>(1);
      newValue.add(operationValues);
      this.result.put(values, newValue);
    }
    else {
      for (int i = 0; i < m; i++) {
        previousValues.get(0).set(i, operations.get(i).process(row, previousValues.get(0).get(i)));
      }
      this.result.put(values, previousValues);
    }
  }

  public TableAccessor getAccessor() throws DatabaseException {
    final Iterator<List<DatabaseValue>> accessorValue = result.iterator();
    final TableAccessor accessor = new TableAccessor() {

      public void init() throws DatabaseException {
        findNext();
      }

      public MetaData getMetaData() throws DatabaseException {
        return groupByMetaData;
      }

      public boolean hasNext() throws DatabaseException {
        return hasNext;
      }

      public Row getNext() throws DatabaseException {
        if (!hasNext) throw new IndexOutOfBoundsException();
        final Row result = nextRow;
        findNext();
        return result;
      }

      private void findNext() {
        hasNext = accessorValue.hasNext();
        if (hasNext) nextRow = new ListDatabaseRow().init(groupByMetaData, accessorValue.next());
      }

      public void close() throws DatabaseException {}

      private boolean hasNext = false;
      private Row nextRow = null;
    };
    accessor.init();
    return accessor;
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }

  public String getType() {
    return Table.MEMORY;
  }

  public String getDescription() {
    return null;
  }

  private ArrayList<Operation> columnMapping = new ArrayList<Operation>();
  //private int[] columnsMapping;
  private DatabaseValue[] values;
  // private DatabaseValue[] operationValues;
  private ArrayList<Operation> operations = new ArrayList<Operation>();
  //private MetaData metaData;
  private TableMetaData groupByMetaData = new TableMetaData();
  private HashIndexMap<DatabaseValue> result;
  private String name;

}

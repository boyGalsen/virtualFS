package org.openknows.jdbc.driver.unisql.memory;

import org.openknows.jdbc.driver.unisql.*;

public class MemoryColumnsTable {

  public static Table getTable(MetaData data) throws DatabaseException {
    final SimpleMemoryTable table = new SimpleMemoryTable("Columns", new String[] {"Name", "Description"});
    for (int i = 0, n = data.getColumnCount(); i < n; i++) {
      final Column column = data.getColumn(i);
      table.addValue(new String[] {column.getName(), column.getDescription()});
    }
    return table;
  }
}

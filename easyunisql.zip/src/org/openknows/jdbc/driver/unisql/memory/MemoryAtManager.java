package org.openknows.jdbc.driver.unisql.memory;

import com.easyrms.util.preferences.*;

import java.util.HashSet;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;


public class MemoryAtManager implements AtManager {
  
  public String getPrefix() {
    return "mem";
  }
  
  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    return database.remove(MemoryDatabase.PUBLIC, name);
  }

  public void init(Parameters properties) {
  }
  
  public Table createTable(final MemoryDatabase database, final String file, final String name, final MetaData metaData) throws DatabaseException {
    final TableMetaData newmetaData = new TableMetaData();
    final HashSet<String> columnNames = new HashSet<String>();
    for (int i = 1, n = metaData.getColumnCount(); i <= n ; i++) {
      final Column mI = metaData.getColumn(i);
      final String description = mI.getDescription();
      final String finalName = !columnNames.contains(description) ? description : mI.getName();
      newmetaData.add(Column.getAndInit(finalName, description, mI.getType()));
    }
    final MemoryTable memOutTable = new MemoryTable(name, newmetaData, null);
    database.add(MemoryDatabase.PUBLIC, memOutTable);
    return memOutTable;
  }

  public Table getTable(final MemoryDatabase database, final String file, final String name) throws DatabaseException {
    return database.findTable(MemoryDatabase.PUBLIC, name);
  }
}

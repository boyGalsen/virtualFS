package org.openknows.jdbc.driver.unisql.memory;


import java.util.*;

import org.openknows.jdbc.driver.unisql.*;

public class SimpleMemoryTable implements Table {
  
  public static final SimpleMemoryTable emptyTable = new SimpleMemoryTable("emptyReference", new String[] {"result"});
  
  public SimpleMemoryTable(final String name, final String[] column) {
    this.name = name;
    this.columns = column;
    this.metadata = new TableMetaData();
    for (int i = 0, n = columns.length; i < n; i++) {
      final String columnName = column[i];
      this.metadata.add(Column.getAndInit(columnName, ColumnType.STRING));
    }
  }
  
  public void addValue(final String[] values)throws DatabaseException  {
    if (values.length < this.columns.length) throw new DatabaseException("Not enought Values");
    if (values.length > this.columns.length) throw new DatabaseException("Too Many Values");
    this.values.add(new SimpleMemoryRow().init(this.metadata, values));
  }
  
  public TableAccessor getAccessor() throws DatabaseException {
    return new TableAccessor() {

      public void close() throws DatabaseException {
        it = null;
      }

      public MetaData getMetaData() throws DatabaseException {
        return metadata;
      }

      public Row getNext() throws DatabaseException {
        return it.next();
      }

      public boolean hasNext() throws DatabaseException {
        return it.hasNext();
      }

      public void init() throws DatabaseException {
        it = values.iterator();
      }
      
      private Iterator<Row> it = values.iterator();
    };
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }

  public MetaData getMetaData() throws DatabaseException {
    return metadata;
  }

  public String getName() {
    return name;
  }
  
  public String getType() {
    return Table.MEMORY;
  }
  
  public String getDescription() {
    return null;
  }

  private ArrayList<Row> values = new ArrayList<Row>();

  private final TableMetaData metadata;
  private final String name;
  private final String[] columns;
}

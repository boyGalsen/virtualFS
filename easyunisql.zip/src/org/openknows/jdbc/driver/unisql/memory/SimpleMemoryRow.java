package org.openknows.jdbc.driver.unisql.memory;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;

public class SimpleMemoryRow extends AbstractDatabaseRow {

  public SimpleMemoryRow init(final MetaData metadata, final String[] values) {
    final DatabaseValue[] dvalues = new DatabaseValue[values.length];
    int i = 0;
    for (int j = 0, m = values.length; j < m; j++) {
      final String value = values[j];
      dvalues[i++] = JDBCDatabaseValue.getAndInit(value);
    }
    return init(metadata, dvalues);
  }

  public SimpleMemoryRow init(final MetaData metadata, final DatabaseValue[] values) {
    super.init(metadata);
    this.values = values;
    return this;
  }

  @Override
  public DatabaseValue getDatabaseValue(int index) {
    return values[index - 1];
  }

  private DatabaseValue[] values;
}

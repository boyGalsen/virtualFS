package org.openknows.jdbc.driver.unisql.memory;


import java.util.*;

import org.openknows.jdbc.driver.unisql.*;


public class MemoryTable implements Table {
  
  public MemoryTable(final String name, final MetaData metaData, final RowComparator comparator) {
    this.metaData = metaData ;
    this.name = name;
    this.comparator = comparator;
    this.isSorted = (comparator == null);
  }
  
  public String getName() {
    return this.name;
  }

  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
  
  public void insert(final TableAccessor tableAccessor) throws DatabaseException {
    final InsertTableAccessor insertAccessort = getInsertAccessor();
    while (tableAccessor.hasNext()) {
      insertAccessort.insert(tableAccessor.getNext());
    }
    insertAccessort.close();
    tableAccessor.close();
    isSorted = (comparator == null);
  }
  
  public TableAccessor getAccessor() throws DatabaseException {
    if (!isSorted) {
      Collections.sort(rows, comparator);
      isSorted = true;
    }
    final int rowsSize = this.rows.size();
    return new TwoWayTableAccessor() {

      public void init() throws DatabaseException {}

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return index < rowsSize;
      }

      public Row getNext() throws DatabaseException {
        if (index >= rowsSize) {
          index = rowsSize;
          throw new DatabaseException("No more row"); 
        }
        return rows.get(index++);
      }

      public void close() throws DatabaseException {}
      
      private int index = 0;

      public Row absolute(int row) throws DatabaseException {
        if (row > rowsSize || row < 1) throw new DatabaseException("Illegal Argument "+row);
        index = row-1;
        return getNext();
      }

      public void afterLast() throws DatabaseException {
        index = rowsSize;
      }

      public void beforeFirst() throws DatabaseException {
        index = 0;
      }

      public Row getFirst() throws DatabaseException {
        if (rowsSize == 0) throw new DatabaseException("No Rows");
        index = 0;
        return getNext();
      }

      public Row getLast() throws DatabaseException {
        if (rowsSize == 0) throw new DatabaseException("No Rows");
        index = rowsSize-1;
        return getNext();
      }

      public Row getPrevious() throws DatabaseException {
        if (index < 0) {
          index = 0;
          throw new DatabaseException("No more row"); 
        }
        return rows.get(--index);
      }

      public int getRowIndex() throws DatabaseException {
        return index + 1;
      }

      public boolean hasPrevious() throws DatabaseException {
        return index > 0;
      }

      public Row relative(int row) throws DatabaseException {
        index = index + row - 1;
        if (index >= rowsSize) {
          index = rowsSize;
          throw new DatabaseException("Illegal Argument "+row);
        }
        if (index < 0) {
          index = 0;
          throw new DatabaseException("Illegal Argument "+row);
        }
        return getNext();
      }
    };
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return new AbstractInsertTableAccessor() {

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }
      
      @Override
      protected void internalInsert(final Row row) throws DatabaseException {
        rows.add(row);
      }

      public void close() throws DatabaseException {
      }
    };
  }
  
  public String getType() {
    return Table.MEMORY;
  }
  
  public String getDescription() {
    return null;
  }
  
  public int getRowCount() {
    return rows.size();
  }

  private final String name;
  private final MetaData metaData;
  private final RowComparator comparator;
  private boolean isSorted;
  private ArrayList<Row> rows = new ArrayList<Row>();
}
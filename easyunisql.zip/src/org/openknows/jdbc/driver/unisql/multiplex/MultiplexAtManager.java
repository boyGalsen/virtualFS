package org.openknows.jdbc.driver.unisql.multiplex;

import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.memory.*;

import org.openknows.jdbc.driver.unisql.*;

public class MultiplexAtManager implements AtManager {
  
  public static MultiplexAtManager reference = new MultiplexAtManager();

  public String getPrefix() {
    return "multiplex";
  }

  public void init(Parameters properties) {
  }
  
  public AtTable createTable(MemoryDatabase database, String file, String name, MetaData metaData) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public AtTable getTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    return new MultiplexFileTable().init(database, file, name);
  }
}
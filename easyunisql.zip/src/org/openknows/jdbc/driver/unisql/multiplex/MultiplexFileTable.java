package org.openknows.jdbc.driver.unisql.multiplex;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;
import org.openknows.jdbc.driver.unisql.memory.MemoryTable;
import org.openknows.jdbc.driver.unisql.sql.AT_TABLE;


public class MultiplexFileTable implements Table, AtTable {
  
  public MultiplexFileTable init(final MemoryDatabase database, final String file, final String name) throws DatabaseException {
    final int index = file.indexOf("#");
    return new MultiplexFileTable().init(database, Integer.parseInt(file.substring(0, index)), "@"+file.substring(index+1), name);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return this.name;
  }
  
  public String getName() {
    return this.name;
  }

  public MultiplexFileTable init(final MemoryDatabase database, final int columnCount, final String subFile, final String name) throws DatabaseException {
    this.name = name;
      final int index1 = subFile.indexOf(":");
      final String prefix = subFile.substring(0, index1+1);
      final String fileName = subFile.substring(index1+1);
      final Table mappedTable = database.getDriver().getAtManager().get(database, new AT_TABLE(prefix, fileName, name));
      if (mappedTable == null) {
        throw new DatabaseException("Unsupported File"+subFile);
      }
      final TableMetaData metaData = new TableMetaData();
      final MetaData mappedMetaData = mappedTable.getMetaData();
      for (int i = 1; i <= columnCount; i++) {
        final Column cI= mappedMetaData.getColumn(i);
        metaData.add(Column.getAndInit(cI.getDescription(), cI.getDescription(), cI.getType()));
      }
      metaData.add(Column.getAndInit("MULTIPLEXEDCOLUMN", "MULTIPLEXEDCOLUMN", ColumnType.STRING));
      metaData.add(Column.getAndInit("MULTIPLEXEDDATA", "MULTIPLEXEDDATA", mappedMetaData.getColumn(columnCount+1).getType()));
      final MemoryTable newTable = new MemoryTable(name, metaData, null);
      final TableAccessor mappedAdAccessor = mappedTable.getAccessor();
      final InsertTableAccessor newTableInsert = newTable.getInsertAccessor();
      
      try {
        final int n = mappedMetaData.getColumnCount();
        while (mappedAdAccessor.hasNext()) {
          final Row row = mappedAdAccessor.getNext();
          final DatabaseValue[] fixedValue = new DatabaseValue[columnCount]; 
          for (int i = 1 ; i <= columnCount; i++) {
            fixedValue[i-1] = row.getDatabaseValue(i);
          }
          for (int j = columnCount+1 ; j <= n; j++) {
            final DatabaseValue[] values = new DatabaseValue[columnCount+2];
            System.arraycopy(fixedValue, 0, values, 0, columnCount);
            values[columnCount] = JDBCDatabaseValue.getAndInit(mappedMetaData.getColumn(j).getDescription());
            values[columnCount+1] = row.getDatabaseValue(j);
            newTableInsert.insert(values);
          }
        }
      }
      finally {
        newTableInsert.close();
        mappedAdAccessor.close();
      }
      
      this.table = newTable;
      this.metaData = this.table.getMetaData();
      return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
      return table.getAccessor();
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

	public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return null;
	}
  
  private MetaData metaData;
  private String name;
  private Table table;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}
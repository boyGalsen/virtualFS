package org.openknows.jdbc.driver.unisql;


public class JoinDatabaseRow extends AbstractDatabaseRow {
  
  public Row init(final MetaData metadata, final Row a, final Row b) {
    super.init(metadata);
    this.a = a;
    this.b = b;
    this.limit = a.getElementCount();
    return this;
  }
  
  @Override
  public DatabaseValue getDatabaseValue(final int index) {
    return (index <= limit) ? a.getDatabaseValue(index) : b.getDatabaseValue(index - limit);
  }
  
  private Row a;
  private int limit;
  private Row b;
}
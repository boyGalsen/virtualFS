package org.openknows.jdbc.driver.unisql;


import com.easyrms.util.*;

import java.util.ArrayList;


public class UnionJoinFilter implements Table {

  
  public UnionJoinFilter init(final String name, final String[] names, final TableAccessor[] accessors) throws DatabaseException {
    this.name = name;
    this.metaData = new TableMetaData();
    
    //final MetaData[] metaDatas = new MetaData[accessors.length];
    final int filterSize = accessors.length;
    final ArrayList<Integer> rowsIndex = new ArrayList<Integer>(); 
    final ArrayList<Integer> rowsRelativeIndex = new ArrayList<Integer>(); 
    for (int i = 0, n = filterSize; i < n ; i = i+1) {
      final MetaData metaData = accessors[i].getMetaData();
      final String tableName = names[i];
      final Integer I = IntegerCache.get(i);
      for (int j = 1, m = metaData.getColumnCount(); j <= m ; j++) {
        final Column column = metaData.getColumn(j);
        this.metaData.add(Column.getAndInit(tableName == null ? column.getName() : tableName+"."+column.getName(), column.getDescription(), column.getType()));
        final Integer J = IntegerCache.get(j);
        rowsIndex.add(I);
        rowsRelativeIndex.add(J);
      }
      //if (i > 0) tables[i] = DatabaseUtil.copy(accessors[i], new MemoryTable(tableName, metaData, null));
    }
    //final TableAccessor firstTableAccessor = accessors[0];
    
    final MultiJoinDatabaseRow.MultiJoinDatabaseRowAccessor rowAccessor = new MultiJoinDatabaseRow.MultiJoinDatabaseRowAccessor() {

      public int getRowIndex(int index) {
        return rowsIndex.get(index-1).intValue();
      }

      public int getRowRelativeIndex(int index) {
        return rowsRelativeIndex.get(index-1).intValue();
      }
      
    };
    
    this.accessor = new TableAccessor() {

      public void init() throws DatabaseException {
        for (int i = 0; i < filterSize; i++) {
          this.findAccessor[i] = accessors[i];
          this.rows[i] = null;
        }
        findNext();
      }

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return hasNext;
      }

      public Row getNext() throws DatabaseException {
        if (!hasNext) throw new IndexOutOfBoundsException();
        final Row result = nextRow;
        findNext();
        return result;
      }
      
      private void findNext() throws DatabaseException {
        do {
          if (this.findAccessor[currentAccessor] == null) {
            if (currentAccessor == filterSize-1) return;
            currentAccessor++;
          }
          else {
            hasNext = this.findAccessor[currentAccessor].hasNext();
            if (!hasNext) {
              this.rows[currentAccessor] = null;
              this.findAccessor[currentAccessor] = null;
              if (currentAccessor == filterSize-1) return;
              currentAccessor++;
            }
            else {
              this.rows[currentAccessor] = this.findAccessor[currentAccessor].getNext();
              nextRow = new MultiJoinDatabaseRow().init(metaData, rowAccessor, rows);
              if (filter.check(nextRow)) {
                rowCount++;
                return;
              }
              nextRow = null;
              hasNext = false;
            }
          }
        } while (true);
      }

      public void close() throws DatabaseException {}
      
      private boolean hasNext;
      private TableAccessor[] findAccessor = new TableAccessor[filterSize];
      private int rowCount;
      private int currentAccessor;
      private Row[] rows = new Row[filterSize];
      
      //private TableAccessor accessorA = accessorA;
      private Row nextRow;
    };
    return this;
  }

  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getType() {
    return Table.MEMORY;
  }
  
  public String getDescription() {
    return null;
  }

  public TableAccessor getAccessor() throws DatabaseException {
    if (!isInit) {
      isInit = true;
      accessor.init();
    }
    return accessor;
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }
  
  private TableMetaData metaData;
  private String name;
  private TableAccessor accessor;
  
  public void setRowFilter(RowFilterRule filter) {
    this.filter = (filter == null) ? RowFilterRule.referenceTrue : filter;
  }
  
  private boolean isInit = false;
  private RowFilterRule filter = RowFilterRule.referenceTrue;
}

package org.openknows.jdbc.driver.unisql;


public abstract class AbstractDatabaseRow implements Row {
  
  public Row init(final MetaData metadata) {
    this.metadata = metadata;
    return this;
  }
  
  public final int getElementCount() {
    return this.metadata.getColumnCount();
  }

	public String getAsString(final int index) {
    final DatabaseValue o = getDatabaseValue(index);
    return (o.isNull()) ? null : o.getStringValue();
	}

	public final String getAsString(final String value) {
		return getAsString(metadata.getColumnIndex(value));
	}

  public Long getAsInteger(final int index) {
    final DatabaseValue o = getDatabaseValue(index);
    return (o.isNull()) ? null : o.getIntegerValue();
  }

  public final Long getAsInteger(final String value) {
    return getAsInteger(metadata.getColumnIndex(value));
  }

  public Double getAsDouble(final int index) {
    final DatabaseValue o = getDatabaseValue(index);
    return (o.isNull()) ? null : o.getDoubleValue();
  }

  public Double getAsDouble(final String value) {
    return getAsDouble(metadata.getColumnIndex(value));
  }
  
  public Boolean getAsBoolean(final int index) {
    final DatabaseValue o = getDatabaseValue(index);
    return (o.isNull()) ? null : o.getBooleanValue();
  }

  public final Boolean getAsBoolean(final String value) {
    return getAsBoolean(metadata.getColumnIndex(value));
  }
  
  public Object getValue(final int index) {
    final DatabaseValue o = getDatabaseValue(index);
    if (o.isNull()) return null;
    switch (metadata.getColumn(index).getType()) {
      case LONG : return getAsInteger(index);
      case DOUBLE : return getAsDouble(index);
      case BOOLEAN : return getAsBoolean(index);
      case STRING : return getAsString(index);
      default : throw new IllegalStateException();
    }
  }
  
  public final Object getValue(final String value) {
    return getValue(metadata.getColumnIndex(value));
  }
  
  public boolean isNull(final int index) {
    return getDatabaseValue(index).isNull();
  }

  public final boolean isNull(final String value) {
    return isNull(metadata.getColumnIndex(value));
  }
  
  public final MetaData getMetaData() {
    return this.metadata;
  }

  public abstract DatabaseValue getDatabaseValue(final int index);

  public DatabaseValue getDatabaseValue(final String value) {
    return getDatabaseValue(metadata.getColumnIndex(value));
  }
  
  protected MetaData metadata;
}

package org.openknows.jdbc.driver.unisql;

public interface Database {
}

package org.openknows.jdbc.driver.unisql.memo;

import com.easyrms.util.net.*;
import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.*;

public interface MemoLet {

  public void init(Parameters properties);
  public AtTable onGet(URI uri);
  
}

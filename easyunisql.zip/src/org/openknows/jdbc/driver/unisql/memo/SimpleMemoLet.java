package org.openknows.jdbc.driver.unisql.memo;

import com.easyrms.util.*;
import com.easyrms.util.net.*;
import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;


public class SimpleMemoLet extends AbstractSimpleMemoLet {
  
  public void init(Parameters properties) {
    metaData = new TableMetaData();
    metaData.add(Column.getAndInit("TIME", ColumnType.LONG));
    metaData.add(Column.getAndInit("NBPROCESSOR", ColumnType.LONG));
    metaData.add(Column.getAndInit("MAXMEMORY", ColumnType.LONG));
    metaData.add(Column.getAndInit("TOTALMEMORY", ColumnType.LONG));
    metaData.add(Column.getAndInit("FREEMEMORY", ColumnType.LONG));
  }

  @Override
  protected TableMetaData getMetadata(URI uri) throws DatabaseException {
    return metaData;
  }  

  @Override
  protected MemoryTable getAsTable(String name, URI uri) throws DatabaseException {
    final MemoryTable memoryTable = new MemoryTable(name, this.metaData, null);
    final InsertTableAccessor is = memoryTable.getInsertAccessor();
    try {
      final DatabaseRow row = new DatabaseRow();
      row.init(this.metaData);
      int i = 1;
      row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(StampUtil.getStampValue())));
      row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(Runtime.getRuntime().availableProcessors())));
      row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(Runtime.getRuntime().maxMemory())));
      row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(Runtime.getRuntime().totalMemory())));
      row.set(i++, JDBCDatabaseValue.getAndInit(LongCache.get(Runtime.getRuntime().freeMemory())));
      is.insert(row);
    }
    finally {
      is.close();
    }
    return memoryTable;
  }
  
  private TableMetaData metaData;
}
package org.openknows.jdbc.driver.unisql.memo;

import com.easyrms.util.net.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;

public abstract class AbstractSimpleMemoLet implements MemoLet {
  
  protected abstract TableMetaData getMetadata(URI uri) throws DatabaseException;
  
  protected TableAccessor getAccessor(String name, URI uri) throws DatabaseException {
    final Table memoryTable = getAsTable(name, uri);
    return memoryTable.getAccessor();
  }
  
  protected abstract Table getAsTable(String name, URI uri) throws DatabaseException;
  

  public AtTable onGet(URI uri) {
    final URI clonedURI = (uri == null) ? null : uri.clone();
    return new AtTable() {

      public AtTable init(MemoryDatabase database, String file, String name) throws DatabaseException {
        this.name = name;
        return this;
      }

      public TableAccessor getAccessor() throws DatabaseException {
        return AbstractSimpleMemoLet.this.getAccessor(name, clonedURI);
      }

      public String getDescription() {
        return name;
      }

      public InsertTableAccessor getInsertAccessor() throws DatabaseException {
        return null;
      }

      public MetaData getMetaData() throws DatabaseException {
        return AbstractSimpleMemoLet.this.getMetadata(clonedURI);
      }

      public String getName() {
        return name;
      }

      public String getType() {
        return MEMORY;
      }
      
      private String name;
    };
  }
}
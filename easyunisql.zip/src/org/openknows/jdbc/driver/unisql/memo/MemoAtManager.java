package org.openknows.jdbc.driver.unisql.memo;

import com.easyrms.util.*;
import com.easyrms.util.net.*;
import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.AtManager;
import org.openknows.jdbc.driver.unisql.AtTable;
import org.openknows.jdbc.driver.unisql.DatabaseException;
import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;

public class MemoAtManager implements AtManager {
  
  public static MemoAtManager reference = new MemoAtManager();

  public String getPrefix() {
    return "memo";
  }

  public void init(Parameters properties) {
    for (final ParametersTuple o : properties) {
      final String key = o.getParameter();
      if (key.startsWith("org.openknows.jdbc.driver.unisql.memo.MemoAtManager.")) {
        try {
          final MemoLet memoLet = (MemoLet)Class.forName(key.substring("org.openknows.jdbc.driver.unisql.memo.MemoAtManager.".length())).newInstance();
          memoLet.init(properties);
          memolets.register(o.getParameterValue(), memoLet);
        }
        catch (Throwable ignored) {
          System.err.println(key);
          EasyRMS.trace.log(ignored);
        }
      }
    }
  }
  
  public AtTable createTable(MemoryDatabase database, String file, String name, MetaData metaData) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public AtTable getTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    Trace.reference.log("getMemoFile="+file);
    final URI uri = URI.getURI(file);
    Trace.reference.log("getMemoFile2="+uri);
    try {
      final MemoLet memoLet = memolets.dispatch(uri);
      return memoLet.onGet(uri).init(database, file, name);
    }
    finally {
      uri.close();
    }
  }
  
  private final SimpleMemoLetDispatcher memolets = new SimpleMemoLetDispatcher();
}
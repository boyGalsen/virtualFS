package org.openknows.jdbc.driver.unisql.memo;

import com.easyrms.util.net.*;


public interface MemoLetDispatcher {

  public MemoLet dispatch(URI uri);
  
}

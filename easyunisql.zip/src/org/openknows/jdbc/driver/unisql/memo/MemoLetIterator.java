package org.openknows.jdbc.driver.unisql.memo;

import java.util.*;

public interface MemoLetIterator<T> {
  
   Class<T> getClassType();
   Iterator<T> getIterator();
}

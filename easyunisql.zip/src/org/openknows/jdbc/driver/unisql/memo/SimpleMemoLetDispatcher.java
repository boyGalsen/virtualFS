package org.openknows.jdbc.driver.unisql.memo;

import com.easyrms.util.*;
import com.easyrms.util.net.*;

import org.openknows.common.matcher.*;


public class SimpleMemoLetDispatcher implements MemoLetDispatcher {

  public MemoLet dispatch(URI uri) {
    return rule.get().match(uri.toString(false));
  }
  
  public void setDefault(MemoLet memoLet) {
    matcher.setDefaultValue(memoLet);
    rule.reset();
  }

  public void register(String startWith, MemoLet memoLet) {
    Trace.reference.log(memoLet+"="+startWith);
    matcher.addStartWith(startWith, memoLet);
    rule.reset();
  }
  
  private final ObjectMatcher<MemoLet> matcher = new ObjectMatcher<MemoLet>();
  private final ObjectReference<ObjectRule<MemoLet>> rule = new AutoCreateReference<ObjectRule<MemoLet>>() {

    @Override
    protected ObjectRule<MemoLet> create() {
      return matcher.compile();
    }
    
  };

}

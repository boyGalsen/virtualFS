package org.openknows.jdbc.driver.unisql;


import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.util.ArrayList;
import java.util.HashSet;

import org.openknows.jdbc.driver.unisql.memory.MemoryTable;


public class MultiJoinFilter implements Table {

  public MultiJoinFilter init(final String name, EzArray<String> names, EzArray<TableAccessor> accessors, final int outer) throws DatabaseException {
    return init(name, ObjectArrays.toArray(names, new String[names.getCount()]), ObjectArrays.toArray(accessors, new TableAccessor[accessors.getCount()]), outer); 
  }
  
  
  public MultiJoinFilter init(final String name, final String[] names, final TableAccessor[] accessors, final int outer) throws DatabaseException {
    if (outer == 2) {
      final String tmpName = names[0];
      final TableAccessor tmpAccessor = accessors[0];
      names[0] = names[1];
      names[1] = tmpName;
      accessors[0] = accessors[1];
      accessors[1] = tmpAccessor;
    }
    
    this.name = name;
    this.metaData = new TableMetaData();
    
    //final MetaData[] metaDatas = new MetaData[accessors.length];
    final int filterSize = accessors.length;
    final Table[] tables = new Table[filterSize];
    int mapSize = 0;
    for (int i = (outer == 2) ? filterSize-1 : 0, n = filterSize; (outer == 2) ? i >= 0 : i < n ; i = ((outer == 2) ? i-1 : i+1)) {
      final MetaData metaData = accessors[i].getMetaData();
      mapSize += metaData.getColumnCount();
    }
    final ArrayList<Integer> rowsIndex = new ArrayList<Integer>(mapSize); 
    final ArrayList<Integer> rowsRelativeIndex = new ArrayList<Integer>(mapSize); 
    for (int i = (outer == 2) ? filterSize-1 : 0, n = filterSize; (outer == 2) ? i >= 0 : i < n ; i = ((outer == 2) ? i-1 : i+1)) {
      final MetaData metaData = accessors[i].getMetaData();
      final String tableName = names[i];
      final Integer I = IntegerCache.get(i);
      for (int j = 1, m = metaData.getColumnCount(); j <= m ; j++) {
        final Column column = metaData.getColumn(j);
        this.metaData.add(Column.getAndInit(tableName == null ? column.getName() : tableName+"."+column.getName(), column.getDescription(), column.getType()));
        final Integer J = IntegerCache.get(j);
        rowsIndex.add(I);
        rowsRelativeIndex.add(J);
      }
      if (i > 0) tables[i] = DatabaseUtil.copy(accessors[i], new MemoryTable(tableName, metaData, null));
    }
    final TableAccessor firstTableAccessor = accessors[0];
    
    final MultiJoinDatabaseRow.MultiJoinDatabaseRowAccessor rowAccessor = new MultiJoinDatabaseRow.MultiJoinDatabaseRowAccessor() {

      public int getRowIndex(int index) {
        return rowsIndex.get(index-1).intValue();
      }

      public int getRowRelativeIndex(int index) {
        return rowsRelativeIndex.get(index-1).intValue();
      }
      
    };
    this.accessor = new TableAccessor() {

      public void init() throws DatabaseException {
        this.findAccessor[0] = firstTableAccessor;
        if (outer == 3) {
          fullJoinMatches = new HashSet<Long>();
        }
        findNext();
      }

      public MetaData getMetaData() throws DatabaseException {
        return metaData;
      }

      public boolean hasNext() throws DatabaseException {
        return hasNext;
      }

      public Row getNext() throws DatabaseException {
        if (!hasNext) throw new IndexOutOfBoundsException();
        final Row result = nextRow;
        findNext();
        return result;
      }
      
      private void findNext() throws DatabaseException {
        int tableIndex = filterSize-1;
        do {
          if (isAllClose) {
            nextRow = null;
            hasNext = false;
            return;
          }
          else if (isCurrentClose) {
            if (this.findAccessor[1] == null) {
              currentJoinIndex = 0;
              this.findAccessor[1] = tables[1].getAccessor();
            }
            hasNext = this.findAccessor[1].hasNext();
            while (hasNext) {
              this.rows[0] = null;
              this.rows[1] = this.findAccessor[1].getNext();
              currentJoinIndex++;
              if (!fullJoinMatches.contains(LongCache.get(currentJoinIndex))) {
                fullJoinMatches.add(LongCache.get(currentJoinIndex));
                nextRow = new MultiJoinDatabaseRow().init(metaData, rowAccessor, rows);
                return;
              }
              hasNext = this.findAccessor[1].hasNext();
            }
            nextRow = null;
            this.findAccessor[1].close();
            this.findAccessor[1] = null;
            hasNext = false;
            isAllClose = true;
            return;
          }
          else if (this.findAccessor[tableIndex] == null) {
            if (tableIndex == 0) return;
            tableIndex--;
          }
          else {
            hasNext = this.findAccessor[tableIndex].hasNext();
            if (!hasNext) {
              if (tableIndex >= filterSize-1){
                this.findAccessor[tableIndex].close();
                this.findAccessor[tableIndex] = null;
                if (rowCount == 0 && outer > 0) {
                  this.rows[tableIndex] = null;
                  nextRow = new MultiJoinDatabaseRow().init(metaData, rowAccessor, rows);
                  hasNext = true;
                  rowCount++;
                  return;
                }
              }
              else if (tableIndex == 0) {
                if (outer == 3) {
                  isCurrentClose = true;
                }
                else {
                  isAllClose = true;
                }
                
                
                /*if (outer == 3) {
                  if (this.findAccessor[1] == null) {
                    currentJoinIndex = 0;
                    this.findAccessor[1] = tables[1].getAccessor();
                  }
                  hasNext = this.findAccessor[1].hasNext();
                  while (hasNext) {
                    currentJoinIndex++;
                    if (!fullJoinMatches.contains(LongCache.get(currentJoinIndex))) {
                      fullJoinMatches.add(LongCache.get(currentJoinIndex));
                      this.rows[0] = null;
                      this.rows[1] = this.findAccessor[1].getNext();
                      nextRow = new MultiJoinDatabaseRow().init(metaData, rowAccessor, rows);
                      return;
                    }
                    hasNext = this.findAccessor[1].hasNext();
                  }
                  nextRow = null;
                  this.findAccessor[1] = null;
                  hasNext = false;
                }*/
                this.findAccessor[tableIndex].close();
                this.findAccessor[tableIndex] = null;
                
              }
            }
            else if (tableIndex >= filterSize-1){
              this.rows[tableIndex] = this.findAccessor[tableIndex].getNext();
              currentJoinIndex++;
              nextRow = new MultiJoinDatabaseRow().init(metaData, rowAccessor, rows);
              if (filter.check(nextRow)) {
                if (outer == 3) {
                  fullJoinMatches.add(LongCache.get(currentJoinIndex));
                }
                rowCount++;
                return;
              }
              nextRow = null;
              hasNext = false;
            }
            else {
              this.rows[tableIndex] = this.findAccessor[tableIndex].getNext();
              tableIndex++;
              rowCount = 0;
              currentJoinIndex = 0;
              this.findAccessor[tableIndex] = tables[tableIndex].getAccessor();
            }
          }
        } while (true);
      }

      public void close() throws DatabaseException {}
      
      private boolean hasNext;
      private boolean isCurrentClose;
      private boolean isAllClose;
      private TableAccessor[] findAccessor = new TableAccessor[filterSize];
      private int rowCount;
      private HashSet<Long> fullJoinMatches;
      private int currentJoinIndex;
      private Row[] rows = new Row[filterSize];
      
      //private TableAccessor accessorA = accessorA;
      private Row nextRow;
    };
    return this;
  }

  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getType() {
    return Table.MEMORY;
  }
  
  public String getDescription() {
    return null;
  }

  public TableAccessor getAccessor() throws DatabaseException {
    if (!isInit) {
      isInit = true;
      accessor.init();
    }
    return accessor;
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
    return null;
  }
  
  private TableMetaData metaData;
  private String name;
  private TableAccessor accessor;
  
  public void setRowFilter(RowFilterRule filter) {
    this.filter = (filter == null) ? RowFilterRule.referenceTrue : filter;
  }
  
  private boolean isInit = false;
  private RowFilterRule filter = RowFilterRule.referenceTrue;
}
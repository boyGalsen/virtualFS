package org.openknows.jdbc.driver.unisql;

public class IndexFilter {

  public IndexFilter init(final IndexRule rule, final MetaData fromMetaData) {
    this.length = rule.getIndexSize();
    this.mapping = new int[fromMetaData.getColumnCount()];
    for (int i = 1, n = this.mapping.length; i <= n; i++) {
      final int k = rule.get(i);
      if (k >= 0) mapping[i-1] = k;
    }
    
    return this;
  }
  
  public DatabaseValue[] getKey(final Row row) {
    final DatabaseValue[] key = new DatabaseValue[length];
    for (int i = 0 ; i < length ; i++) {
      key[i] = row.getDatabaseValue(mapping[i]);
    }
    return key;
  }
  
  private int[] mapping;
  private int length;
}

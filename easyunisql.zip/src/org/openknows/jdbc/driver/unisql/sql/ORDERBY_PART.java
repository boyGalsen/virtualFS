package org.openknows.jdbc.driver.unisql.sql;

import java.util.*;

public class ORDERBY_PART {

  public void add(final ORDERBY_COLUMN selectElement) {
    list.add(selectElement);
  }
  
  public final List<ORDERBY_COLUMN> getElements() {
    return list;
  }
  
  public final int size() {
    return list.size();
  }
  
  private final ArrayList<ORDERBY_COLUMN> list = new ArrayList<ORDERBY_COLUMN>();
}

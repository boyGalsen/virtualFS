package org.openknows.jdbc.driver.unisql.sql;


public abstract class GEN_IN_TEST_OPERATION extends GROUP_TEST {
  
  public GEN_IN_TEST_OPERATION(final OPERATION operation) {
    this.operation = operation;
  }
  
  public OPERATION getColumn() {
    return this.operation;
  }

  public void addTest(final OPERATION part) {
    addPart(new UNIQUE_EQUALS_OPERATION(getColumn(), part));
  }
  
  private final OPERATION operation;
}
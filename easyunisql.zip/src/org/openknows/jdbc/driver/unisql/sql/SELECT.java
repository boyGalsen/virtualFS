package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;

public class SELECT implements EXECUTABLE {
  
  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();

  public void subSelectCompile(JDBCRequestDecoder requestDecoder) throws Throwable {
    if (fromPart != null) fromPart.subSelectCompile(requestDecoder, this);
    if (wherePart != null) wherePart.subSelectCompile(requestDecoder, this);
    if (havingPart != null) havingPart.subSelectCompile(requestDecoder, this);
  }

  public SELECTION_PART selectionPart = null;
  public FROM_PART fromPart = null;
  public WHERE_PART wherePart = null;
  public WHERE_PART havingPart = null;
  public GROUP_BY_PART groupbyPart = null;
  public ORDERBY_PART orderBy = null;
  public HAVING_PART having = null;
}

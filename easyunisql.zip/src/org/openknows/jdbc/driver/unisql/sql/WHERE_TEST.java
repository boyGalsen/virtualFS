package org.openknows.jdbc.driver.unisql.sql;

public abstract class WHERE_TEST extends OPERATION {

  // public abstract void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable;

  // public abstract RowFilterRule getRowFilter(String name, MetaData metaData);
  // public abstract RowFilterRule getRowFilter(String name, TABLE table, MetaData metaData);

  // public abstract Operation getGroupRowFilter(String name, MetaData metaData);
  public boolean isGroupTest() {
    return false;
  }
}
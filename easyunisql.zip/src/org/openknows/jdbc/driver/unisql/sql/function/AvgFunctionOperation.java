package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class AvgFunctionOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue[] values) {
    return values[0];
  }
  
  private static DatabaseValue getSum(DatabaseValue previousValue, DatabaseValue newValue) {
    if (previousValue != null && previousValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (newValue != null && newValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (previousValue == null || previousValue == JDBCDatabaseValue.NULL) return newValue;
    if (newValue == null || newValue == JDBCDatabaseValue.NULL) return previousValue;
    return JDBCDatabaseValue.getAndInit(MathUtils.getDouble(previousValue.getdoubleValue()+newValue.getdoubleValue()));
  }
  
  private static DatabaseValue getCount(DatabaseValue previousValue, DatabaseValue newValue) {
    if (previousValue != null && previousValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (newValue != null && newValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (previousValue == null || previousValue == JDBCDatabaseValue.NULL) return JDBCDatabaseValue.getAndInit(new Integer(1)).initSubValues(previousValue, newValue);
    return JDBCDatabaseValue.getAndInit(LongCache.get(previousValue.getintValue()+1)).initSubValues(previousValue, newValue);
  }
  
  public AvgFunctionOperation() {
    super("AVG", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {

      private final String sumkey = ids.getNewID();
      private final String countkey = ids.getNewID();
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        final DatabaseValue sum = getSum(previousValue == null ? null : previousValue.getSubValue(sumkey), value);
        final DatabaseValue count = getCount(previousValue == null ? null : previousValue.getSubValue(countkey), value);
        if ((sum != null && sum.isIgnored()) || (count != null && count.isIgnored())) return JDBCDatabaseValue.IGNORED;
        if ((sum == null || sum.isNull()) && (count == null || count.isNull())) return JDBCDatabaseValue.NULL; 
        final JDBCDatabaseValue result = JDBCDatabaseValue.getAndInit(new Double((count == null) ? 0.0 : (sum == null ? 0.0 : sum.getdoubleValue())/count.getdoubleValue()));
        result.setSubValue(sumkey, sum);
        result.setSubValue(countkey, count);
        return result;
      }
    };
  }
}
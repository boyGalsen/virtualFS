package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import java.util.ArrayList;
import java.util.List;

import org.openknows.jdbc.driver.unisql.DatabaseException;
import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCConnectionDriver;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;
import org.openknows.jdbc.driver.unisql.operation.Operation;
import org.openknows.jdbc.driver.unisql.sql.function.FunctionOperation;


public class FUNCTION_OPERATION extends OPERATION {

  public FUNCTION_OPERATION(JDBCConnectionDriver driver, String functionName, String name) throws DatabaseException {
    this.name = JDBCUtil.upper(name);
    this.functionName = JDBCUtil.upper(functionName);
    this.function = driver.getFunctionManager().get(this.functionName);
  }
  
  private String functionName;
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getFunctionName() {
    return this.functionName;
  }
  
  protected final String getInternalName() {
    return this.name;
  }
  protected final int getInternalOperationCount() {
    return this.operations.size();
  }
  protected final OPERATION getInternalOperation(int i) {
    return this.operations.get(i);
  }
  
  @Override
  public String getName() {
    if (this.name != null) return name;
    final StringBuilder outName = StreamUtils.getStringBuilder();
    try  {
      outName.append(this.functionName).append("(");
      boolean isFirst = true;
      for (final OPERATION operation : operations) {
        if (operation != null) {
          outName.append(isFirst ? "" : ",").append(operation.getName());
          isFirst = false;
        }
      }
      outName.append(")");
      return outName.toString();
    }
    finally {
      StreamUtils.free(outName);
    }
  }
  
  public void add(OPERATION operation) {
    operations.add(operation);
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    for (final OPERATION operation : operations) {
      operation.subSelectCompile(requestDecoder, originalSelect);
    }
  }
  
  @Override
  public boolean applyOn(TABLE table) {
    for (final OPERATION operation : operations) {
      if (operation != null) {
        if (!operation.applyOn(table)) return false;
      }
    }
    return true;
  }
  
  @Override
  public String toString() {
    if (this.name == null) return this.functionName;
    return this.name;
  }
  
  private String name;

  @Override
  public Operation getOperation(final String name, MetaData metaData) {
    //groupName = name;
    return function.getOperation(name, metaData, operations.toArray(new OPERATION[operations.size()]));
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    //groupName = name;
    return function.getGroupOperation(name, metaData, operations.toArray(new OPERATION[operations.size()]));
  }

  /*
  @Override
  public void buildToJava(StringBuilder buffer, OPERATION_TYPE type) {
    if (isGroupOperation()) {
      buffer.append("JDBCDatabaseValue.getAndInit(row.getAsDouble(\"");
      buffer.append("");
      buffer.append("\"))");
    }
    else {
      function.buildToJava(buffer, type, operations.toArray(new OPERATION[operations.size()]));
    }
  }

  @Override
  public void buildToSQL(StringBuilder buffer, OPERATION_TYPE type) {
    function.buildToSQL(buffer, type, operations.toArray(new OPERATION[operations.size()]));
  }
*/
  @Override
  public Boolean isNumber() {
    return function.isNumber();
  }
  
  @Override
  public boolean isGroupOperation() {
    return function.isGroupOperation(operations.toArray(new OPERATION[operations.size()]));
  }
  
  //private String groupName;
  private final FunctionOperation function;
  private final List<OPERATION> operations = new ArrayList<OPERATION>(); 
}
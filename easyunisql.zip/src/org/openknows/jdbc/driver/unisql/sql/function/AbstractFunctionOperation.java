package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.preferences.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.operation.*;
import org.openknows.jdbc.driver.unisql.sql.*;


public abstract class AbstractFunctionOperation implements FunctionOperation {
  
  protected AbstractFunctionOperation(final String name, final Boolean isNumber, final boolean isGroupOperation) {
    this.name = name;
    this.isNumber = isNumber;
    this.isGroupOperation = isGroupOperation;
  }
  
  public void init(Parameters properties) {
  }
  
  public final void init(Properties properties) {
  }
  
  public final String getName() {
    return name;
  }
  
  public final Boolean isNumber() {
    return isNumber;
  }
  
  public final boolean isGroupOperation(final OPERATION[] operations) {
    if (this.isGroupOperation) {
      for (int j = 0, m = operations.length; j < m; j++) {
        final OPERATION operation = operations[j];
        if (operation != null && operation.isGroupOperation()) throw new IllegalStateException();
      }
    }
    else {
      for (int j = 0, m = operations.length; j < m; j++) {
        final OPERATION operation = operations[j];
        if (operation != null && operation.isGroupOperation()) return true;
      }
    }
    return this.isGroupOperation;
  }

  public Operation getOperation(final String name, final MetaData metaData, final OPERATION[] operations) {
    if (isGroupOperation(operations)) {
      final Boolean isNumber = isNumber();
      return new Operation(name, (isNumber != null && isNumber.booleanValue()) ? ColumnType.DOUBLE : ColumnType.STRING) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
        
      };
    }
    final Operation[] realOperations = new Operation[operations == null ? 0 : operations.length];
    if (operations != null) {
      int i = 0;
      for (int j = 0, m = operations.length; j < m; j++) {
        final OPERATION operation = operations[j];
        final SELECT_ELEMENT element = OPERATION_SELECT_ELEMENT.get(operation, name);
        final Operation realOperation;
        if (element instanceof COLUMN_SELECT_ELEMENT) {
          realOperation = element.getOperation(name, metaData);//new Get(metaData, ((COLUMN_SELECT_ELEMENT)element).getColumnFullName());
        }
        else if (element instanceof OPERATION_SELECT_ELEMENT) {
          realOperation = element.getOperation(name, metaData);//new ComplexOperation((OPERATION_SELECT_ELEMENT)element);
        }
        else {
          throw new IllegalArgumentException();
        }
        realOperations[i++] = realOperation;
      }
    }
    return getOperation(name, realOperations); 
  }
  
  public Operation getGroupOperation(String name, MetaData metaData, OPERATION[] operations) {
    if (!isGroupOperation(operations)) throw new IllegalStateException("Not Valid If Is Not Group Oeration");
    final Operation[] realOperations = new Operation[operations == null ? 0 : operations.length];
    if (operations != null) {
      int i = 0;
      for (int j = 0, m = operations.length; j < m; j++) {
        final OPERATION operation = operations[j];
        final SELECT_ELEMENT element = OPERATION_SELECT_ELEMENT.get(operation, name);
        final Operation realOperation;
        if (element instanceof COLUMN_SELECT_ELEMENT) {
          realOperation = element.getGroupOperation(name, metaData);//new Get(metaData, ((COLUMN_SELECT_ELEMENT)element).getColumnFullName());
        }
        else if (element instanceof OPERATION_SELECT_ELEMENT) {
          realOperation = element.getGroupOperation(name, metaData);//new ComplexOperation((OPERATION_SELECT_ELEMENT)element);
        }
        else {
          throw new IllegalArgumentException();
        }
        realOperations[i++] = realOperation;
      }
    }
    return getGroupOperation(name, realOperations); 
  }
  
  protected Operation getOperation(String name, Operation... realOperation) {
    throw new IllegalStateException("Not Valid If Is Not Implemented");
  }

  protected Operation getGroupOperation(String name, Operation... realOperation) {
    throw new IllegalStateException("Not Valid If Is Not Implemented");
  }

  private final boolean isGroupOperation;
  private final Boolean isNumber;
  private final String name;
}
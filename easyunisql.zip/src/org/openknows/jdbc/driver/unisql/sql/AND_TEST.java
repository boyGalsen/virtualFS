package org.openknows.jdbc.driver.unisql.sql;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class AND_TEST extends GROUP_TEST {
  
  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    //final int indexA = metaData.getColumnIndex(columnA.getName());
    //final int indexB = metaData.getColumnIndex(columnB.getName());
    final ArrayList<Operation> rules = new ArrayList<Operation>();
    for (int i = 0, n = parts.size(); i < n ; i++) {
      final Operation filter = parts.get(i).getGroupOperation(name, metaData);
      if (filter != null) rules.add(filter);
    }
    
    return new Operation(name, ColumnType.BOOLEAN) {

      /*public DatabaseValue check(Row row, DatabaseValue previousValue) {
        if (rules.size() == 0) return JDBCDatabaseValue.getAndInit(Boolean.TRUE);
        for (final RowFilterRule rule : rules) {
          if (!rule.check(row, previousValue).getbooleanValue()) return JDBCDatabaseValue.getAndInit(Boolean.FALSE);
        }
        return JDBCDatabaseValue.getAndInit(Boolean.TRUE);
      }*/
      private final String[] keys = getIDs(rules.size());

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        if (rules.size() == 0) return JDBCDatabaseValue.getAndInit(Boolean.TRUE);
        final DatabaseValue[] subValues = new DatabaseValue[rules.size()];
        int i = 0;
        for (final Operation rule : rules) {
          subValues[i] = rule.process(row, previousValue == null ? null : previousValue.getSubValue(keys[i]));
          i++;
        }
        for (final DatabaseValue value : subValues) {
          if (!value.getbooleanValue()) return JDBCDatabaseValue.getAndInit(Boolean.FALSE).initSubValues(subValues);
        }
        return JDBCDatabaseValue.getAndInit(Boolean.TRUE).initSubValues(subValues).setSubValue(keys, subValues);
        /*boolean 
        for (final RowFilterRule rule : rules) {
          if (!rule.check(row, previousValue).getbooleanValue()) return JDBCDatabaseValue.getAndInit(Boolean.FALSE);
        }*/
      }
    };
  }

  @Override
  public String getName() {
    return null;
  }

  @Override
  public Operation getOperation(final String name, final MetaData metaData) {
    if (isGroupOperation()) {
      return new Operation(name, ColumnType.BOOLEAN) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
      };
    }

    final ArrayList<Operation> rules = new ArrayList<Operation>();
    for (int i = 0, n = parts.size(); i < n ; i++) {
      final Operation filter = parts.get(i).getOperation(name, metaData);
      if (filter != null) rules.add(filter);
    }
    
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String[] keys = getIDs(rules.size());

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        if (rules.size() == 0) return JDBCDatabaseValue.getAndInit(Boolean.TRUE);
        final DatabaseValue[] subValues = new DatabaseValue[rules.size()];
        int i = 0;
        for (final Operation rule : rules) {
          subValues[i] = rule.process(row, previousValue == null ? null : previousValue.getSubValue(keys[i]));
          i++;
        }
        for (final DatabaseValue value : subValues) {
          if (!value.getbooleanValue()) return JDBCDatabaseValue.getAndInit(Boolean.FALSE).initSubValues(subValues);
        }
        return JDBCDatabaseValue.getAndInit(Boolean.TRUE).initSubValues(subValues).setSubValue(keys, subValues);
        /*boolean 
        for (final RowFilterRule rule : rules) {
          if (!rule.check(row, previousValue).getbooleanValue()) return JDBCDatabaseValue.getAndInit(Boolean.FALSE);
        }*/
      }
    };
  }


  @Override
  public Boolean isNumber() {
    return Boolean.FALSE;
  }
}
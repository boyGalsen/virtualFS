package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;

public class JDBC_TABLE implements TABLE {

  public JDBC_TABLE(final String database, final String request, final String name) {
    this.database = database;
    this.request = request;
    this.name = JDBCUtil.upper(name);
  }
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) {
  }
  
  public String getDatabase() {
    return this.database;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getRequest() {
    return this.request;
  }
  
  private final String database;
  private final String request; 
  private final String name;
}

package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;

public abstract class GROUPOPERATION_SELECT_ELEMENT implements SELECT_ELEMENT {
  
  public boolean applyOn(TABLE table) {
    return false;
  }
  
  public GROUPOPERATION_SELECT_ELEMENT(final String name) {
    this.name = JDBCUtil.upper(name);
  }
  
  public void setName (String name) {
    this.name = name;
  }
  
  public String getName() {
    return name;
  }
  
  public boolean isGroupOperation() {
    return true;
  }
  
  protected String name;

}

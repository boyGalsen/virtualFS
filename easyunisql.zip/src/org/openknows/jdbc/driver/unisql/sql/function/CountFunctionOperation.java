package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class CountFunctionOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue[] values) {
    return values[0];
  }
  
  public CountFunctionOperation() {
    super("COUNT", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    
    return new GroupByOperation(name, ColumnType.LONG) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        if (previousValue == null) return JDBCDatabaseValue.getAndInit(LongCache.get(1));
        return JDBCDatabaseValue.getAndInit(LongCache.get(previousValue.getintValue() + 1));
      }
    };
  }
}
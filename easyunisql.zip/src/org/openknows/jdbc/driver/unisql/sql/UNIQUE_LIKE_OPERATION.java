package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class UNIQUE_LIKE_OPERATION extends DUAL_TEST_OPERATION {
  
  public static WHERE_TEST get(final OPERATION columnA, final OPERATION columnB) {
    return new UNIQUE_LIKE_OPERATION(columnA, columnB);
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    final Operation operationA = columnA.getGroupOperation(name, metaData);
    final Operation operationB = columnB.getGroupOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue vA = operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue vB = operationB.process(row, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return (JDBCUtil.isLike(vA.getStringValue(), vB.getStringValue().replace(".", "\\.").replace("%", ".*"))
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(vA, vB)
            .setSubValue(partAKey, vA)
            .setSubValue(partBKey, vB);
      }
    };
  }
  
  public UNIQUE_LIKE_OPERATION(final OPERATION columnA, final OPERATION columnB) {
    super(columnA, columnB);
  }

  @Override
  public Operation getOperation(final String name, MetaData metaData) {
    if (isGroupOperation()) {
      return new Operation(name, ColumnType.BOOLEAN) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
      };
    }
    final Operation operationA = columnA.getOperation(name, metaData);
    final Operation operationB = columnB.getOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue vA = operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue vB = operationB.process(row, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return (JDBCUtil.isLike(vA.getStringValue(), vB.getStringValue().replace(".", "\\.").replace("%", ".*"))
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(vA, vB)
            .setSubValue(partAKey, vA)
            .setSubValue(partBKey, vB);
      }
    };
  }

  @Override
  public String getName() {
    return this.columnA.getName()+" LIKE "+this.columnB.getName();
  }
}
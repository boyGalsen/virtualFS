package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;

public class SIMPLE_JOIN extends ABSTRACT_JOIN {

  public SIMPLE_JOIN(TABLE tableA, TABLE tableB) {
    super(tableA, tableB);
    outer = 0;
  }

  public SIMPLE_JOIN(TABLE tableA, TABLE tableB, WHERE_PART where) {
    super(tableA, tableB, where);
    outer = 0;
  }
  
  public SIMPLE_JOIN(TABLE tableA, TABLE tableB, int outer) {
    super(tableA, tableB);
    this.outer = outer;
  }

  public SIMPLE_JOIN(TABLE tableA, TABLE tableB, WHERE_PART where, int outer) {
    super(tableA, tableB, where);
    this.outer = outer;
  }

  @Override
  protected Table getFilteredTable(String[] names, TableAccessor[] accessors) throws DatabaseException {
    try {
      final MultiJoinFilter filter = new MultiJoinFilter().init("", names, accessors, outer);
      if (getWherePart() != null) {
        filter.setRowFilter(SelectDecoderPart.computeRowFilter(getWherePart().getTest(), filter.getMetaData()));
      }
      return filter;
    }
    catch (DatabaseException e) {
      throw e;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }
  
  private final int outer;
  
}

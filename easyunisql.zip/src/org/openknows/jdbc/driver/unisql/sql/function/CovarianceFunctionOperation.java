package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class CovarianceFunctionOperation extends AbstractFunctionOperation {
  
  private static class DynJDBCDatabaseValueCovariance extends DynJDBCDatabaseValue {

    @Override
    protected Object buildOriginalValue() {
      final EzArray<DatabaseValue> valuesA = ((DynJDBCDatabaseValue)getSubValue(partAKey)).getSubValues();
      final EzArray<DatabaseValue> valuesB = ((DynJDBCDatabaseValue)getSubValue(partBKey)).getSubValues();
      double sumA = 0.0;
      double sumB = 0.0;
      final int count = valuesA.getCount();
      for (int i = 0; i < count; i++) {
        final DatabaseValue valuesAI = valuesA.get(i); 
        if (!valuesAI.isNull()) {
          sumA += valuesAI.getdoubleValue();
        }
        final DatabaseValue valuesBI = valuesB.get(i); 
        if (!valuesBI.isNull()) {
          sumB += valuesBI.getdoubleValue();
        }
      }
      final double averageA = sumA/count;
      final double averageB = sumB/count;
      double sumT = 0.0;
      for (int i = 0; i < count; i++) {
        final DatabaseValue valuesAI = valuesA.get(i); 
        final DatabaseValue valuesBI = valuesB.get(i); 
        sumT += ((valuesAI.isNull() ? 0.0 : valuesAI.getdoubleValue()) - averageA) * ((valuesBI.isNull() ? 0.0 : valuesBI.getdoubleValue()) - averageB);
      }
      return MathUtils.getDouble(sumT/count);
    }
  }
    
  public CovarianceFunctionOperation() {
    super("Statistics.Cov", Boolean.TRUE, true);
  }

  private static final String partAKey = "covX_"+StampUtil.getStampValue();
  private static final String partBKey = "covY_"+StampUtil.getStampValue();

  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    
    return new GroupByOperation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(row, (previousValue == null) ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = realOperation[1].process(row, (previousValue == null) ? null : previousValue.getSubValue(partBKey));
        final DynJDBCDatabaseValue covariance = (DynJDBCDatabaseValueCovariance)((previousValue == null || previousValue == JDBCDatabaseValue.NULL) ? new DynJDBCDatabaseValueCovariance() : previousValue);
        
        final DynJDBCDatabaseValue subValueA = (DynJDBCDatabaseValue)((previousValue == null || previousValue == JDBCDatabaseValue.NULL) ? new DynJDBCDatabaseValue() : previousValue.getSubValue(partAKey));
        subValueA.addSubValue(partAValue);
        final DynJDBCDatabaseValue subValueB = (DynJDBCDatabaseValue)((previousValue == null || previousValue == JDBCDatabaseValue.NULL) ? new DynJDBCDatabaseValue() : previousValue.getSubValue(partBKey));
        subValueB.addSubValue(partBValue);
        covariance.setSubValue(partAKey, subValueA);
        covariance.setSubValue(partBKey, subValueB);
        return covariance;
      }
    };
  }
}
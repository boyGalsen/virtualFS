package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class STRING_OPERATION extends OPERATION {
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
  }

  public STRING_OPERATION(String value) {
    this.value = value; 
  }
  
  @Override
  public String getName() {
    return value;
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    return new ConstantOperation(name, this.value);      
  }

  @Override
  public Operation getOperation(String name, MetaData metaData) {
    return new ConstantOperation(name, this.value);      
  }
  
  public String getValue() {
    return this.value;
  }
  
  @Override
  public boolean applyOn(final TABLE table) {
    return true;
  }
  
  private final String value;

  /*
  @Override
  public void buildToJava(StringBuilder buffer, OPERATION_TYPE type) {
    switch (type) {
      case NUMBER : throw new IllegalStateException();
      default : buffer.append("\"").append(value).append("\"");
    }
  }

  @Override
  public void buildToSQL(StringBuilder buffer, OPERATION_TYPE type) {
    switch (type) {
      case NUMBER : throw new IllegalStateException();
      default : buffer.append("'").append(value).append("'");
    }
  }
  */
  @Override
  public Boolean isNumber() { return Boolean.FALSE; }
}

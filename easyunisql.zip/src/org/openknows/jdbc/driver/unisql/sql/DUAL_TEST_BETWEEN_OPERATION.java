package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class DUAL_TEST_BETWEEN_OPERATION extends DUAL_TEST_OPERATION {
  
  public static WHERE_TEST get(final OPERATION columnA, final OPERATION columnB, final OPERATION columnC) {
    return new DUAL_TEST_BETWEEN_OPERATION(columnA, columnB, columnC);
  }
  
  @Override
  public boolean isGroupOperation() { 
    return this.columnA.isGroupOperation() || this.columnB.isGroupOperation() || this.columnC.isGroupOperation(); 
  }
  @Override
  public boolean applyOn(final TABLE table) {
    return this.columnA.applyOn(table) && this.columnB.applyOn(table) && this.columnC.applyOn(table);
  }
  @Override
  public boolean canApplyOn(final TABLE table) {
    return this.columnA.canApplyOn(table) || this.columnB.canApplyOn(table) || this.columnC.canApplyOn(table);
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    if (this.columnA != null) this.columnA.subSelectCompile(requestDecoder, originalSelect);
    if (this.columnB != null) this.columnB.subSelectCompile(requestDecoder, originalSelect);
    if (this.columnC != null) this.columnC.subSelectCompile(requestDecoder, originalSelect);
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    final Operation operationA = columnA.getGroupOperation(name, metaData);
    final Operation operationB = columnB.getGroupOperation(name, metaData);
    final Operation operationC = columnC.getGroupOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      private final String partCKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
        final DatabaseValue valueA = operationA.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue valueB = operationB.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        final DatabaseValue valueC = operationC.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partCKey));
        return (JDBCUtil.isBetween(valueA.getDoubleValue(), valueB.getDoubleValue(), valueC.getDoubleValue()) 
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(valueA, valueB, valueC)
            .setSubValue(partAKey, valueA)
            .setSubValue(partBKey, valueB)
            .setSubValue(partCKey, valueC);
      }
    };
  }


  public DUAL_TEST_BETWEEN_OPERATION(final OPERATION columnA, final OPERATION columnB, final OPERATION columnC) {
    super(columnA, columnB);
    this.columnC = columnC;
  }
  
  /*
  @Override
  public void buildToJava(final StringBuilder buffer) {
      buffer.append("(JDBCUtil.").append("isBetween").append("(");
      columnA.buildToJava(buffer, OPERATION.OPERATION_TYPE.NUMBER);
      buffer.append(", ");
      columnB.buildToJava(buffer, OPERATION.OPERATION_TYPE.NUMBER);
      buffer.append(", ");
      columnC.buildToJava(buffer, OPERATION.OPERATION_TYPE.NUMBER);
      buffer.append("))");
  }
  
  @Override
  public void buildToSQL(final StringBuilder buffer) {
      buffer.append("(");
      columnA.buildToSQL(buffer, OPERATION.OPERATION_TYPE.NUMBER);
      buffer.append(" between ");
      columnB.buildToSQL(buffer, OPERATION.OPERATION_TYPE.NUMBER);
      buffer.append(" and ");
      columnC.buildToSQL(buffer, OPERATION.OPERATION_TYPE.NUMBER);
      buffer.append(")");
  }

  */
  private final OPERATION columnC;


  @Override
  public String getName() {
    return columnA.getName()+" BETWEEN "+columnB.getName()+" AND "+columnC.getName();
  }

  @Override
  public Operation getOperation(final String name, MetaData metaData) {
    if (isGroupOperation()) {
      return new Operation(name, ColumnType.BOOLEAN) {
  
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
      };
    }
    final Operation operationA = columnA.getOperation(name, metaData);
    final Operation operationB = columnB.getOperation(name, metaData);
    final Operation operationC = columnC.getOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      private final String partCKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
        final DatabaseValue valueA = operationA.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue valueB = operationB.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        final DatabaseValue valueC = operationC.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partCKey));
        return (JDBCUtil.isBetween(valueA.getDoubleValue(), valueB.getDoubleValue(), valueC.getDoubleValue()) 
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(valueA, valueB, valueC)
            .setSubValue(partAKey, valueA)
            .setSubValue(partBKey, valueB)
            .setSubValue(partCKey, valueC);
      }
    };  
  }
}
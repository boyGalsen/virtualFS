package org.openknows.jdbc.driver.unisql.sql.function;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class DecodeOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(final DatabaseValue... values) {
    final DatabaseValue compareValue = values[0];
    if (compareValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    for (int i = 1, n = values.length-1; i < n; i=i+2) {
      if (JDBCUtil.equals(compareValue, values[i])) return values[i+1];
    }
    return values[values.length - 1];
  }
  
  public DecodeOperation() {
    super("decode", null, false);
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {

      private final String[] keys = getIDs(realOperation.length);
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue[] subValues = new DatabaseValue[realOperation.length];
        int i = 0;
        for (int j = 0, m = realOperation.length; j < m; j++) {
          final Operation operation = realOperation[j];
          subValues[i] = operation.process(originalRow, previousValue == null ? null : previousValue.getSubValue(keys[i]));
          i++;
        }
        return JDBCDatabaseValue.getAndInit(execute(subValues))
          .initSubValues(subValues)
          .setSubValue(keys, subValues);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue[] subValues = new DatabaseValue[realOperation.length];
        int i = 0;
        for (int j = 0, m = realOperation.length; j < m; j++) {
          final Operation operation = realOperation[j];
          subValues[i] = operation.process(originalRow, null);
          i++;
        }
        return JDBCDatabaseValue.getAndInitNumber(execute(subValues));
      }    
    };
  }

}
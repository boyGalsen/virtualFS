package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import org.openknows.jdbc.driver.unisql.ColumnType;
import org.openknows.jdbc.driver.unisql.DatabaseValue;
import org.openknows.jdbc.driver.unisql.Row;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.operation.Operation;

public class GreatestOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue executeDouble(DatabaseValue... values) {
    if (values[0] == null) return values[1];
    if (values[1] == null) return values[0];
    return (values[0].getdoubleValue() >= values[1].getdoubleValue()) ? values[0] : values[1];
  }
  
  public static DatabaseValue executeLong(DatabaseValue... values) {
    if (values[0] == null) return values[1];
    if (values[1] == null) return values[0];
    return (values[0].getintValue() >= values[1].getintValue()) ? values[0] : values[1];
  }
  
  public static DatabaseValue executeString(DatabaseValue... values) {
    if (values[0] == null) return values[1];
    if (values[1] == null) return values[0];
    return (StringComparator.compare(values[0].getStringValue(), values[1].getStringValue()) >= 0) ? values[0] : values[1];
  }
  
  public static DatabaseValue executeDate(DatabaseValue... values) {
    if (values[0] == null) return values[1];
    if (values[1] == null) return values[0];
    return (ObjectComparator.reference.compare(values[0].getDateValue(), values[1].getDateValue()) >= 0) ? values[0] : values[1];
  }
  
  public static DatabaseValue executeBoolean(DatabaseValue... values) {
    if (values[0] == null) return values[1];
    if (values[1] == null) return values[0];
    return (ObjectComparator.reference.compare(values[0].getBooleanValue(), values[1].getBooleanValue()) >= 0) ? values[0] : values[1];
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    final ColumnType columnTypeA = realOperation[0].getType();
    final ColumnType columnTypeB = realOperation[1].getType();
    if (columnTypeA == ColumnType.STRING && columnTypeB == ColumnType.STRING) {
      return new Operation(name, ColumnType.STRING) {

        private final String partAKey = ids.getNewID();
        private final String partBKey = ids.getNewID();
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
          final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
          return JDBCDatabaseValue.getAndInit(executeString(partAValue, partBValue))
            .initSubValues(partAValue, partBValue)
            .setSubValue(partAKey, partAValue)
            .setSubValue(partBKey, partBValue);
        }    
      };      
    }
    if (columnTypeA == ColumnType.LONG && columnTypeB == ColumnType.LONG) {
      return new Operation(name, ColumnType.LONG) {

        private final String partAKey = ids.getNewID();
        private final String partBKey = ids.getNewID();
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
          final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
          return JDBCDatabaseValue.getAndInitNumber(executeLong(partAValue, partBValue))
            .initSubValues(partAValue, partBValue)
            .setSubValue(partAKey, partAValue)
            .setSubValue(partBKey, partBValue);
        }    
      };      
    }
    if (columnTypeA == ColumnType.DATE && columnTypeB == ColumnType.DATE) {
      return new Operation(name, ColumnType.DATE) {

        private final String partAKey = ids.getNewID();
        private final String partBKey = ids.getNewID();
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
          final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
          return JDBCDatabaseValue.getAndInit(executeDate(partAValue, partBValue))
            .initSubValues(partAValue, partBValue)
            .setSubValue(partAKey, partAValue)
            .setSubValue(partBKey, partBValue);
        }    
      };      
    }
    if (columnTypeA == ColumnType.BOOLEAN && columnTypeB == ColumnType.BOOLEAN) {
      return new Operation(name, ColumnType.BOOLEAN) {

        private final String partAKey = ids.getNewID();
        private final String partBKey = ids.getNewID();
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
          final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
          return JDBCDatabaseValue.getAndInit(executeBoolean(partAValue, partBValue))
            .initSubValues(partAValue, partBValue)
            .setSubValue(partAKey, partAValue)
            .setSubValue(partBKey, partBValue);
        }    
      };      
    }
    return new Operation(name, ColumnType.DOUBLE) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return JDBCDatabaseValue.getAndInitNumber(executeDouble(partAValue, partBValue))
          .initSubValues(partAValue, partBValue)
          .setSubValue(partAKey, partAValue)
          .setSubValue(partBKey, partBValue);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    final ColumnType columnTypeA = realOperation[0].getType();
    final ColumnType columnTypeB = realOperation[1].getType();
    if (columnTypeA == ColumnType.STRING && columnTypeB == ColumnType.STRING) {
      return new Operation(name, ColumnType.STRING) {
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
          final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
          return JDBCDatabaseValue.getAndInit(executeString(partAValue, partBValue))
            .initSubValues(partAValue, partBValue);
        }    
      };
    }  
    if (columnTypeA == ColumnType.LONG && columnTypeB == ColumnType.LONG) {
      return new Operation(name, ColumnType.LONG) {
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
          final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
          return JDBCDatabaseValue.getAndInitNumber(executeLong(partAValue, partBValue))
            .initSubValues(partAValue, partBValue);
        }    
      };
    }
    if (columnTypeA == ColumnType.DATE && columnTypeB == ColumnType.DATE) {
      return new Operation(name, ColumnType.DATE) {
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
          final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
          return JDBCDatabaseValue.getAndInit(executeDate(partAValue, partBValue))
            .initSubValues(partAValue, partBValue);
        }    
      };
    }
    if (columnTypeA == ColumnType.BOOLEAN && columnTypeB == ColumnType.BOOLEAN) {
      return new Operation(name, ColumnType.BOOLEAN) {
        
        @Override
        public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
          final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
          final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
          return JDBCDatabaseValue.getAndInit(executeBoolean(partAValue, partBValue))
            .initSubValues(partAValue, partBValue);
        }    
      };
    }
    return new Operation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
        final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
        return JDBCDatabaseValue.getAndInitNumber(executeDouble(partAValue, partBValue))
          .initSubValues(partAValue, partBValue);
      }    
    };
  }
  
  public GreatestOperation() {
    super("greatest", Boolean.TRUE, false);
  }
}
package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class COLUMN_SELECT_ELEMENT implements SELECT_ELEMENT {

  public COLUMN_SELECT_ELEMENT(String table, String column, String name) {
    this.table = JDBCUtil.upper(table);
    this.column = JDBCUtil.upper(column);
    this.name = JDBCUtil.upper(name);
  }
  
  public Operation getGroupOperation(String name, MetaData metaData) {
    return getOperation(name, metaData);
  }

  public Operation getOperation(String name, MetaData metaData) {
    final int index = metaData.getColumnIndex(name, getColumnFullName());
    return new Operation(name, metaData.getColumn(index).getType()) {
        @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        return originalRow.getDatabaseValue(index);
      }
    };
  }

  
  public boolean isGroupOperation() {
    return false;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getTable() {
    return this.table;
  }
  
  public String getName() {
    return (this.name == null) ? getColumnFullName() : name;
  }
  
  public String getColumn() {
    return this.column;
  }
  
  public boolean applyOn(TABLE table) {
    return this.table == null || this.table.equals(table.getName());
  }
  
  public String getColumnFullName() {
    return (this.table == null) ? this.column : this.table+"."+this.column;
  }
  
  @Override
  public String toString() {
    if (this.name == null) return getColumnFullName();
    return this.name;
  }
  
  private final String table;
  private String name;
  private final String column;
}

package org.openknows.jdbc.driver.unisql.sql;

public interface EXECUTABLE {

  public void setVariables(VARIABLES variables);
  public VARIABLES getVariables();
}

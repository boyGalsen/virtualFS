package org.openknows.jdbc.driver.unisql.sql;

import java.util.ArrayList;

public class COLUMN_LIST {

  public void add(String name) { columns.add(name); }
  
  private final ArrayList<String> columns = new ArrayList<String>();
}

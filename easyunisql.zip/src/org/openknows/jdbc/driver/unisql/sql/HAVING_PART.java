package org.openknows.jdbc.driver.unisql.sql;


import java.util.*;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;


public class HAVING_PART {

  public void subSelectCompile(JDBCRequestDecoder requestDecoder) {
  }

  public void add(final GROUPOPERATION_SELECT_ELEMENT selectElement) {
    list.add(selectElement);
  }
  
  public List<GROUPOPERATION_SELECT_ELEMENT> getElements() {
    return list;
  }
  
  public int size() {
    return list.size();
  }
  
  private final ArrayList<GROUPOPERATION_SELECT_ELEMENT> list = new ArrayList<GROUPOPERATION_SELECT_ELEMENT>();
}

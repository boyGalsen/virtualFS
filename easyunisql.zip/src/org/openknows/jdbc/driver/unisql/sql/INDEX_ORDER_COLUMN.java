package org.openknows.jdbc.driver.unisql.sql;

public class INDEX_ORDER_COLUMN implements ORDERBY_COLUMN {

  public INDEX_ORDER_COLUMN(int index, boolean desc) {
    this.desc = desc;
    this.index = index;
  }
  
  public int getIndex() {
    return this.index;
  }
  
  public boolean isDesc() {
    return this.desc;
  }
  
  private final boolean desc;
  private final int index;
}

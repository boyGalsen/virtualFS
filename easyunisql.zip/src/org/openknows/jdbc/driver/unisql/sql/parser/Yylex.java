package org.openknows.jdbc.driver.unisql.sql.parser;
import com.easyrms.util.*;

import java_cup.runtime.*;


public class Yylex implements java_cup.runtime.Scanner {
	private final int YY_BUFFER_SIZE = 512;
	private final int YY_F = -1;
	private final int YY_NO_STATE = -1;
	private final int YY_NOT_ACCEPT = 0;
	private final int YY_START = 1;
	private final int YY_END = 2;
	private final int YY_NO_ANCHOR = 4;
	private final int YY_BOL = 65536;
	private final int YY_EOF = 65537;

  public static Trace trace = Trace.reference;
  int requestStack;
  StringBuilder requestBuilder;
  StringBuilder nameBlockBuilder = new StringBuilder();
	private java.io.BufferedReader yy_reader;
	private int yy_buffer_index;
	private int yy_buffer_read;
	private int yy_buffer_start;
	private int yy_buffer_end;
	private char yy_buffer[];
	private int yychar;
	private boolean yy_at_bol;
	private int yy_lexical_state;

	public Yylex (java.io.Reader reader) {
		this ();
		if (null == reader) {
			throw (new Error("Error: Bad input stream initializer."));
		}
		yy_reader = new java.io.BufferedReader(reader);
	}

	public Yylex (java.io.InputStream instream) {
		this ();
		if (null == instream) {
			throw (new Error("Error: Bad input stream initializer."));
		}
		yy_reader = new java.io.BufferedReader(new java.io.InputStreamReader(instream));
	}

	private Yylex () {
		yy_buffer = new char[YY_BUFFER_SIZE];
		yy_buffer_read = 0;
		yy_buffer_index = 0;
		yy_buffer_start = 0;
		yy_buffer_end = 0;
		yychar = 0;
		yy_at_bol = true;
		yy_lexical_state = YYINITIAL;
	}

	private boolean yy_eof_done = false;
	private final int PROTECTED_BLOCK_NAME = 10;
	private final int REGISTER2 = 9;
	private final int REQUESTUNION = 5;
	private final int REGISTER = 8;
	private final int ANTI_PROTECTED_BLOCK_NAME = 11;
	private final int ACTIVATE = 6;
	private final int UNION_BLOCK = 12;
	private final int YYINITIAL = 0;
	private final int JDBC_REQUEST = 2;
	private final int BLOCK_NAME = 3;
	private final int REQUEST = 4;
	private final int JDBC_BLOC = 1;
	private final int CATALOG = 7;
	private final int TMP_BLOC = 13;
	private final int yy_state_dtrans[] = {
		0,
		237,
		238,
		21,
		239,
		247,
		248,
		249,
		250,
		251,
		253,
		254,
		111,
		255
	};
	private void yybegin (int state) {
		yy_lexical_state = state;
	}
	private int yy_advance ()
		throws java.io.IOException {
		int next_read;
		int i;
		int j;

		if (yy_buffer_index < yy_buffer_read) {
			return yy_buffer[yy_buffer_index++];
		}

		if (0 != yy_buffer_start) {
			i = yy_buffer_start;
			j = 0;
			while (i < yy_buffer_read) {
				yy_buffer[j] = yy_buffer[i];
				++i;
				++j;
			}
			yy_buffer_end = yy_buffer_end - yy_buffer_start;
			yy_buffer_start = 0;
			yy_buffer_read = j;
			yy_buffer_index = j;
			next_read = yy_reader.read(yy_buffer,
					yy_buffer_read,
					yy_buffer.length - yy_buffer_read);
			if (-1 == next_read) {
				return YY_EOF;
			}
			yy_buffer_read = yy_buffer_read + next_read;
		}

		while (yy_buffer_index >= yy_buffer_read) {
			if (yy_buffer_index >= yy_buffer.length) {
				yy_buffer = yy_double(yy_buffer);
			}
			next_read = yy_reader.read(yy_buffer,
					yy_buffer_read,
					yy_buffer.length - yy_buffer_read);
			if (-1 == next_read) {
				return YY_EOF;
			}
			yy_buffer_read = yy_buffer_read + next_read;
		}
		return yy_buffer[yy_buffer_index++];
	}
	private void yy_move_end () {
		if (yy_buffer_end > yy_buffer_start &&
		    '\n' == yy_buffer[yy_buffer_end-1])
			yy_buffer_end--;
		if (yy_buffer_end > yy_buffer_start &&
		    '\r' == yy_buffer[yy_buffer_end-1])
			yy_buffer_end--;
	}
	private boolean yy_last_was_cr=false;
	private void yy_mark_start () {
		yychar = yychar
			+ yy_buffer_index - yy_buffer_start;
		yy_buffer_start = yy_buffer_index;
	}
	private void yy_mark_end () {
		yy_buffer_end = yy_buffer_index;
	}
	private void yy_to_mark () {
		yy_buffer_index = yy_buffer_end;
		yy_at_bol = (yy_buffer_end > yy_buffer_start) &&
		            ('\r' == yy_buffer[yy_buffer_end-1] ||
		             '\n' == yy_buffer[yy_buffer_end-1] ||
		             2028/*LS*/ == yy_buffer[yy_buffer_end-1] ||
		             2029/*PS*/ == yy_buffer[yy_buffer_end-1]);
	}
	private java.lang.String yytext () {
		return (new java.lang.String(yy_buffer,
			yy_buffer_start,
			yy_buffer_end - yy_buffer_start));
	}
	private int yylength () {
		return yy_buffer_end - yy_buffer_start;
	}
	private char[] yy_double (final char buf[]) {
		final char newbuf[] = new char[2*buf.length];
		System.arraycopy(buf, 0, newbuf, 0, buf.length);
		return newbuf;
	}
	private final int YY_E_INTERNAL = 0;
	private final int YY_E_MATCH = 1;
	private java.lang.String yy_error_string[] = {
		"Error: Internal error.\n",
		"Error: Unmatched input.\n"
	};
	private void yy_error (int code,boolean fatal) {
		java.lang.System.out.print(yy_error_string[code]);
		java.lang.System.out.flush();
		if (fatal) {
			throw new Error("Fatal Error.\n");
		}
	}
	private int[][] unpackFromString(int size1, int size2, String st) {
		int colonIndex = -1;
		String lengthString;
		int sequenceLength = 0;
		int sequenceInteger = 0;

		int commaIndex;
		String workString;

		int res[][] = new int[size1][size2];
		for (int i= 0; i < size1; i++) {
			for (int j= 0; j < size2; j++) {
				if (sequenceLength != 0) {
					res[i][j] = sequenceInteger;
					sequenceLength--;
					continue;
				}
				commaIndex = st.indexOf(',');
				workString = (commaIndex==-1) ? st :
					st.substring(0, commaIndex);
				st = st.substring(commaIndex+1);
				colonIndex = workString.indexOf(':');
				if (colonIndex == -1) {
					res[i][j]=Integer.parseInt(workString);
					continue;
				}
				lengthString =
					workString.substring(colonIndex+1);
				sequenceLength=Integer.parseInt(lengthString);
				workString=workString.substring(0,colonIndex);
				sequenceInteger=Integer.parseInt(workString);
				res[i][j] = sequenceInteger;
				sequenceLength--;
			}
		}
		return res;
	}
	private int yy_acpt[] = {
		/* 0 */ YY_NOT_ACCEPT,
		/* 1 */ YY_NO_ANCHOR,
		/* 2 */ YY_NO_ANCHOR,
		/* 3 */ YY_NO_ANCHOR,
		/* 4 */ YY_NO_ANCHOR,
		/* 5 */ YY_NO_ANCHOR,
		/* 6 */ YY_NO_ANCHOR,
		/* 7 */ YY_NO_ANCHOR,
		/* 8 */ YY_NO_ANCHOR,
		/* 9 */ YY_NO_ANCHOR,
		/* 10 */ YY_NO_ANCHOR,
		/* 11 */ YY_NO_ANCHOR,
		/* 12 */ YY_NO_ANCHOR,
		/* 13 */ YY_NO_ANCHOR,
		/* 14 */ YY_NO_ANCHOR,
		/* 15 */ YY_NO_ANCHOR,
		/* 16 */ YY_NO_ANCHOR,
		/* 17 */ YY_NO_ANCHOR,
		/* 18 */ YY_NO_ANCHOR,
		/* 19 */ YY_NO_ANCHOR,
		/* 20 */ YY_NO_ANCHOR,
		/* 21 */ YY_NO_ANCHOR,
		/* 22 */ YY_NO_ANCHOR,
		/* 23 */ YY_NO_ANCHOR,
		/* 24 */ YY_NO_ANCHOR,
		/* 25 */ YY_NO_ANCHOR,
		/* 26 */ YY_NO_ANCHOR,
		/* 27 */ YY_NO_ANCHOR,
		/* 28 */ YY_NO_ANCHOR,
		/* 29 */ YY_NO_ANCHOR,
		/* 30 */ YY_NO_ANCHOR,
		/* 31 */ YY_NO_ANCHOR,
		/* 32 */ YY_NO_ANCHOR,
		/* 33 */ YY_NO_ANCHOR,
		/* 34 */ YY_NO_ANCHOR,
		/* 35 */ YY_NO_ANCHOR,
		/* 36 */ YY_NO_ANCHOR,
		/* 37 */ YY_NO_ANCHOR,
		/* 38 */ YY_NO_ANCHOR,
		/* 39 */ YY_NO_ANCHOR,
		/* 40 */ YY_NO_ANCHOR,
		/* 41 */ YY_NO_ANCHOR,
		/* 42 */ YY_NO_ANCHOR,
		/* 43 */ YY_NO_ANCHOR,
		/* 44 */ YY_NO_ANCHOR,
		/* 45 */ YY_NO_ANCHOR,
		/* 46 */ YY_NO_ANCHOR,
		/* 47 */ YY_NO_ANCHOR,
		/* 48 */ YY_NO_ANCHOR,
		/* 49 */ YY_NO_ANCHOR,
		/* 50 */ YY_NO_ANCHOR,
		/* 51 */ YY_NO_ANCHOR,
		/* 52 */ YY_NO_ANCHOR,
		/* 53 */ YY_NO_ANCHOR,
		/* 54 */ YY_NO_ANCHOR,
		/* 55 */ YY_NO_ANCHOR,
		/* 56 */ YY_NO_ANCHOR,
		/* 57 */ YY_NO_ANCHOR,
		/* 58 */ YY_NO_ANCHOR,
		/* 59 */ YY_NO_ANCHOR,
		/* 60 */ YY_NO_ANCHOR,
		/* 61 */ YY_NO_ANCHOR,
		/* 62 */ YY_NO_ANCHOR,
		/* 63 */ YY_NO_ANCHOR,
		/* 64 */ YY_NO_ANCHOR,
		/* 65 */ YY_NO_ANCHOR,
		/* 66 */ YY_NO_ANCHOR,
		/* 67 */ YY_NO_ANCHOR,
		/* 68 */ YY_NO_ANCHOR,
		/* 69 */ YY_NO_ANCHOR,
		/* 70 */ YY_NO_ANCHOR,
		/* 71 */ YY_NO_ANCHOR,
		/* 72 */ YY_NO_ANCHOR,
		/* 73 */ YY_NO_ANCHOR,
		/* 74 */ YY_NO_ANCHOR,
		/* 75 */ YY_NO_ANCHOR,
		/* 76 */ YY_NO_ANCHOR,
		/* 77 */ YY_NO_ANCHOR,
		/* 78 */ YY_NO_ANCHOR,
		/* 79 */ YY_NO_ANCHOR,
		/* 80 */ YY_NO_ANCHOR,
		/* 81 */ YY_NO_ANCHOR,
		/* 82 */ YY_NO_ANCHOR,
		/* 83 */ YY_NO_ANCHOR,
		/* 84 */ YY_NO_ANCHOR,
		/* 85 */ YY_NO_ANCHOR,
		/* 86 */ YY_NO_ANCHOR,
		/* 87 */ YY_NO_ANCHOR,
		/* 88 */ YY_NO_ANCHOR,
		/* 89 */ YY_NO_ANCHOR,
		/* 90 */ YY_NO_ANCHOR,
		/* 91 */ YY_NO_ANCHOR,
		/* 92 */ YY_NO_ANCHOR,
		/* 93 */ YY_NO_ANCHOR,
		/* 94 */ YY_NO_ANCHOR,
		/* 95 */ YY_NO_ANCHOR,
		/* 96 */ YY_NO_ANCHOR,
		/* 97 */ YY_NO_ANCHOR,
		/* 98 */ YY_NO_ANCHOR,
		/* 99 */ YY_NO_ANCHOR,
		/* 100 */ YY_NO_ANCHOR,
		/* 101 */ YY_NO_ANCHOR,
		/* 102 */ YY_NO_ANCHOR,
		/* 103 */ YY_NO_ANCHOR,
		/* 104 */ YY_NO_ANCHOR,
		/* 105 */ YY_NO_ANCHOR,
		/* 106 */ YY_NO_ANCHOR,
		/* 107 */ YY_NO_ANCHOR,
		/* 108 */ YY_NO_ANCHOR,
		/* 109 */ YY_NO_ANCHOR,
		/* 110 */ YY_NO_ANCHOR,
		/* 111 */ YY_NO_ANCHOR,
		/* 112 */ YY_NO_ANCHOR,
		/* 113 */ YY_NO_ANCHOR,
		/* 114 */ YY_NO_ANCHOR,
		/* 115 */ YY_NO_ANCHOR,
		/* 116 */ YY_NO_ANCHOR,
		/* 117 */ YY_NO_ANCHOR,
		/* 118 */ YY_NO_ANCHOR,
		/* 119 */ YY_NO_ANCHOR,
		/* 120 */ YY_NO_ANCHOR,
		/* 121 */ YY_NO_ANCHOR,
		/* 122 */ YY_NO_ANCHOR,
		/* 123 */ YY_NOT_ACCEPT,
		/* 124 */ YY_NO_ANCHOR,
		/* 125 */ YY_NO_ANCHOR,
		/* 126 */ YY_NO_ANCHOR,
		/* 127 */ YY_NO_ANCHOR,
		/* 128 */ YY_NO_ANCHOR,
		/* 129 */ YY_NO_ANCHOR,
		/* 130 */ YY_NO_ANCHOR,
		/* 131 */ YY_NO_ANCHOR,
		/* 132 */ YY_NO_ANCHOR,
		/* 133 */ YY_NO_ANCHOR,
		/* 134 */ YY_NO_ANCHOR,
		/* 135 */ YY_NO_ANCHOR,
		/* 136 */ YY_NO_ANCHOR,
		/* 137 */ YY_NO_ANCHOR,
		/* 138 */ YY_NO_ANCHOR,
		/* 139 */ YY_NO_ANCHOR,
		/* 140 */ YY_NO_ANCHOR,
		/* 141 */ YY_NOT_ACCEPT,
		/* 142 */ YY_NO_ANCHOR,
		/* 143 */ YY_NO_ANCHOR,
		/* 144 */ YY_NO_ANCHOR,
		/* 145 */ YY_NO_ANCHOR,
		/* 146 */ YY_NO_ANCHOR,
		/* 147 */ YY_NO_ANCHOR,
		/* 148 */ YY_NOT_ACCEPT,
		/* 149 */ YY_NO_ANCHOR,
		/* 150 */ YY_NO_ANCHOR,
		/* 151 */ YY_NO_ANCHOR,
		/* 152 */ YY_NO_ANCHOR,
		/* 153 */ YY_NO_ANCHOR,
		/* 154 */ YY_NO_ANCHOR,
		/* 155 */ YY_NOT_ACCEPT,
		/* 156 */ YY_NO_ANCHOR,
		/* 157 */ YY_NO_ANCHOR,
		/* 158 */ YY_NO_ANCHOR,
		/* 159 */ YY_NO_ANCHOR,
		/* 160 */ YY_NO_ANCHOR,
		/* 161 */ YY_NO_ANCHOR,
		/* 162 */ YY_NOT_ACCEPT,
		/* 163 */ YY_NO_ANCHOR,
		/* 164 */ YY_NO_ANCHOR,
		/* 165 */ YY_NOT_ACCEPT,
		/* 166 */ YY_NO_ANCHOR,
		/* 167 */ YY_NO_ANCHOR,
		/* 168 */ YY_NOT_ACCEPT,
		/* 169 */ YY_NO_ANCHOR,
		/* 170 */ YY_NO_ANCHOR,
		/* 171 */ YY_NOT_ACCEPT,
		/* 172 */ YY_NO_ANCHOR,
		/* 173 */ YY_NO_ANCHOR,
		/* 174 */ YY_NOT_ACCEPT,
		/* 175 */ YY_NO_ANCHOR,
		/* 176 */ YY_NO_ANCHOR,
		/* 177 */ YY_NOT_ACCEPT,
		/* 178 */ YY_NO_ANCHOR,
		/* 179 */ YY_NO_ANCHOR,
		/* 180 */ YY_NOT_ACCEPT,
		/* 181 */ YY_NO_ANCHOR,
		/* 182 */ YY_NO_ANCHOR,
		/* 183 */ YY_NOT_ACCEPT,
		/* 184 */ YY_NO_ANCHOR,
		/* 185 */ YY_NO_ANCHOR,
		/* 186 */ YY_NOT_ACCEPT,
		/* 187 */ YY_NO_ANCHOR,
		/* 188 */ YY_NO_ANCHOR,
		/* 189 */ YY_NOT_ACCEPT,
		/* 190 */ YY_NO_ANCHOR,
		/* 191 */ YY_NO_ANCHOR,
		/* 192 */ YY_NOT_ACCEPT,
		/* 193 */ YY_NO_ANCHOR,
		/* 194 */ YY_NO_ANCHOR,
		/* 195 */ YY_NOT_ACCEPT,
		/* 196 */ YY_NO_ANCHOR,
		/* 197 */ YY_NOT_ACCEPT,
		/* 198 */ YY_NO_ANCHOR,
		/* 199 */ YY_NOT_ACCEPT,
		/* 200 */ YY_NO_ANCHOR,
		/* 201 */ YY_NOT_ACCEPT,
		/* 202 */ YY_NO_ANCHOR,
		/* 203 */ YY_NOT_ACCEPT,
		/* 204 */ YY_NO_ANCHOR,
		/* 205 */ YY_NOT_ACCEPT,
		/* 206 */ YY_NO_ANCHOR,
		/* 207 */ YY_NOT_ACCEPT,
		/* 208 */ YY_NO_ANCHOR,
		/* 209 */ YY_NOT_ACCEPT,
		/* 210 */ YY_NO_ANCHOR,
		/* 211 */ YY_NOT_ACCEPT,
		/* 212 */ YY_NO_ANCHOR,
		/* 213 */ YY_NOT_ACCEPT,
		/* 214 */ YY_NO_ANCHOR,
		/* 215 */ YY_NOT_ACCEPT,
		/* 216 */ YY_NO_ANCHOR,
		/* 217 */ YY_NOT_ACCEPT,
		/* 218 */ YY_NO_ANCHOR,
		/* 219 */ YY_NOT_ACCEPT,
		/* 220 */ YY_NO_ANCHOR,
		/* 221 */ YY_NOT_ACCEPT,
		/* 222 */ YY_NO_ANCHOR,
		/* 223 */ YY_NOT_ACCEPT,
		/* 224 */ YY_NOT_ACCEPT,
		/* 225 */ YY_NOT_ACCEPT,
		/* 226 */ YY_NOT_ACCEPT,
		/* 227 */ YY_NOT_ACCEPT,
		/* 228 */ YY_NOT_ACCEPT,
		/* 229 */ YY_NOT_ACCEPT,
		/* 230 */ YY_NOT_ACCEPT,
		/* 231 */ YY_NOT_ACCEPT,
		/* 232 */ YY_NOT_ACCEPT,
		/* 233 */ YY_NOT_ACCEPT,
		/* 234 */ YY_NOT_ACCEPT,
		/* 235 */ YY_NOT_ACCEPT,
		/* 236 */ YY_NOT_ACCEPT,
		/* 237 */ YY_NOT_ACCEPT,
		/* 238 */ YY_NOT_ACCEPT,
		/* 239 */ YY_NOT_ACCEPT,
		/* 240 */ YY_NOT_ACCEPT,
		/* 241 */ YY_NOT_ACCEPT,
		/* 242 */ YY_NOT_ACCEPT,
		/* 243 */ YY_NOT_ACCEPT,
		/* 244 */ YY_NOT_ACCEPT,
		/* 245 */ YY_NOT_ACCEPT,
		/* 246 */ YY_NOT_ACCEPT,
		/* 247 */ YY_NOT_ACCEPT,
		/* 248 */ YY_NOT_ACCEPT,
		/* 249 */ YY_NOT_ACCEPT,
		/* 250 */ YY_NOT_ACCEPT,
		/* 251 */ YY_NOT_ACCEPT,
		/* 252 */ YY_NOT_ACCEPT,
		/* 253 */ YY_NOT_ACCEPT,
		/* 254 */ YY_NOT_ACCEPT,
		/* 255 */ YY_NOT_ACCEPT,
		/* 256 */ YY_NOT_ACCEPT,
		/* 257 */ YY_NO_ANCHOR,
		/* 258 */ YY_NO_ANCHOR,
		/* 259 */ YY_NO_ANCHOR,
		/* 260 */ YY_NO_ANCHOR,
		/* 261 */ YY_NO_ANCHOR,
		/* 262 */ YY_NOT_ACCEPT,
		/* 263 */ YY_NO_ANCHOR,
		/* 264 */ YY_NOT_ACCEPT,
		/* 265 */ YY_NOT_ACCEPT,
		/* 266 */ YY_NOT_ACCEPT,
		/* 267 */ YY_NOT_ACCEPT,
		/* 268 */ YY_NOT_ACCEPT,
		/* 269 */ YY_NOT_ACCEPT,
		/* 270 */ YY_NOT_ACCEPT,
		/* 271 */ YY_NOT_ACCEPT,
		/* 272 */ YY_NOT_ACCEPT,
		/* 273 */ YY_NOT_ACCEPT,
		/* 274 */ YY_NO_ANCHOR,
		/* 275 */ YY_NO_ANCHOR,
		/* 276 */ YY_NO_ANCHOR,
		/* 277 */ YY_NO_ANCHOR,
		/* 278 */ YY_NO_ANCHOR,
		/* 279 */ YY_NOT_ACCEPT,
		/* 280 */ YY_NOT_ACCEPT,
		/* 281 */ YY_NOT_ACCEPT,
		/* 282 */ YY_NOT_ACCEPT,
		/* 283 */ YY_NOT_ACCEPT,
		/* 284 */ YY_NOT_ACCEPT,
		/* 285 */ YY_NO_ANCHOR,
		/* 286 */ YY_NO_ANCHOR,
		/* 287 */ YY_NO_ANCHOR,
		/* 288 */ YY_NO_ANCHOR,
		/* 289 */ YY_NO_ANCHOR,
		/* 290 */ YY_NO_ANCHOR,
		/* 291 */ YY_NO_ANCHOR,
		/* 292 */ YY_NO_ANCHOR,
		/* 293 */ YY_NO_ANCHOR,
		/* 294 */ YY_NO_ANCHOR,
		/* 295 */ YY_NO_ANCHOR,
		/* 296 */ YY_NO_ANCHOR,
		/* 297 */ YY_NO_ANCHOR,
		/* 298 */ YY_NO_ANCHOR,
		/* 299 */ YY_NO_ANCHOR,
		/* 300 */ YY_NO_ANCHOR,
		/* 301 */ YY_NO_ANCHOR,
		/* 302 */ YY_NO_ANCHOR,
		/* 303 */ YY_NO_ANCHOR,
		/* 304 */ YY_NO_ANCHOR,
		/* 305 */ YY_NO_ANCHOR,
		/* 306 */ YY_NO_ANCHOR,
		/* 307 */ YY_NO_ANCHOR,
		/* 308 */ YY_NO_ANCHOR,
		/* 309 */ YY_NO_ANCHOR,
		/* 310 */ YY_NO_ANCHOR,
		/* 311 */ YY_NO_ANCHOR,
		/* 312 */ YY_NO_ANCHOR,
		/* 313 */ YY_NO_ANCHOR,
		/* 314 */ YY_NOT_ACCEPT,
		/* 315 */ YY_NO_ANCHOR,
		/* 316 */ YY_NO_ANCHOR,
		/* 317 */ YY_NO_ANCHOR,
		/* 318 */ YY_NOT_ACCEPT,
		/* 319 */ YY_NO_ANCHOR,
		/* 320 */ YY_NO_ANCHOR,
		/* 321 */ YY_NO_ANCHOR,
		/* 322 */ YY_NO_ANCHOR,
		/* 323 */ YY_NO_ANCHOR,
		/* 324 */ YY_NO_ANCHOR,
		/* 325 */ YY_NO_ANCHOR,
		/* 326 */ YY_NO_ANCHOR,
		/* 327 */ YY_NO_ANCHOR,
		/* 328 */ YY_NO_ANCHOR,
		/* 329 */ YY_NO_ANCHOR,
		/* 330 */ YY_NO_ANCHOR,
		/* 331 */ YY_NO_ANCHOR,
		/* 332 */ YY_NO_ANCHOR,
		/* 333 */ YY_NO_ANCHOR,
		/* 334 */ YY_NO_ANCHOR,
		/* 335 */ YY_NO_ANCHOR,
		/* 336 */ YY_NO_ANCHOR,
		/* 337 */ YY_NO_ANCHOR,
		/* 338 */ YY_NO_ANCHOR,
		/* 339 */ YY_NO_ANCHOR,
		/* 340 */ YY_NO_ANCHOR,
		/* 341 */ YY_NO_ANCHOR,
		/* 342 */ YY_NO_ANCHOR,
		/* 343 */ YY_NO_ANCHOR,
		/* 344 */ YY_NO_ANCHOR,
		/* 345 */ YY_NOT_ACCEPT,
		/* 346 */ YY_NO_ANCHOR,
		/* 347 */ YY_NO_ANCHOR,
		/* 348 */ YY_NO_ANCHOR,
		/* 349 */ YY_NO_ANCHOR,
		/* 350 */ YY_NOT_ACCEPT,
		/* 351 */ YY_NO_ANCHOR,
		/* 352 */ YY_NO_ANCHOR,
		/* 353 */ YY_NO_ANCHOR,
		/* 354 */ YY_NO_ANCHOR,
		/* 355 */ YY_NO_ANCHOR,
		/* 356 */ YY_NO_ANCHOR,
		/* 357 */ YY_NO_ANCHOR,
		/* 358 */ YY_NO_ANCHOR,
		/* 359 */ YY_NO_ANCHOR,
		/* 360 */ YY_NO_ANCHOR,
		/* 361 */ YY_NO_ANCHOR,
		/* 362 */ YY_NO_ANCHOR,
		/* 363 */ YY_NO_ANCHOR,
		/* 364 */ YY_NO_ANCHOR,
		/* 365 */ YY_NO_ANCHOR,
		/* 366 */ YY_NO_ANCHOR
	};
	private int yy_cmap[] = unpackFromString(1,65538,
"27:9,20,21,27,20,24,27:18,20,45,47,27:4,23,36,40,38,41,37,42,32,43,46:10,35" +
",27,19,22,44,39,34,1,16,2,7,6,18,11,26,4,29,30,9,17,13,10,15,31,12,8,3,14,5" +
",25,33,28,33,27,48,27:2,33,27,1,16,2,7,6,18,11,26,4,29,30,9,17,13,10,15,31," +
"12,8,3,14,5,25,33,28,33,27:65413,0:2")[0];

	private int yy_rmap[] = unpackFromString(1,367,
"0,1:13,2,3,1:5,4,1:2,5,6,7,1,8,9,1:8,10,11,12,13,9,14,15,9:2,1:6,9:3,16,17," +
"1,9:20,1,9:2,1,18,1,18:4,19,1,20,21,22,23,24,1,25,26,1:2,27:6,1:4,28,1:2,29" +
":2,1:5,30,1,31,32,33,1,34,35,36,37,19:4,25,38,1,39,40,41,42,43,44,45,46,47," +
"48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,16,70,71," +
"72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96," +
"97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,11" +
"6,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,1" +
"35,136,137,138,139,17,8,140,58,141,142,143,144,145,146,147,148,149,150,151," +
"152,40,153,154,27,155,29,156,157,158,159,160,161,162,163,164,165,166,167,16" +
"8,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,1" +
"87,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205," +
"206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224" +
",225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,9," +
"243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259")[0];

	private int yy_nxt[][] = unpackFromString(260,49,
"1,123,141,-1,148,-1:2,155,162,-1:3,262,-1,165,-1:84,14:19,-1:2,14:2,-1,14:1" +
"0,-1:3,14:2,-1,14:8,-1:20,15:2,-1:2,15,-1:12,15,-1:11,1,124:19,22:2,124:2,-" +
"1,124:11,22,124:3,22,124:6,23,124,-1,349:7,40,163,349:3,166,349:5,-1:6,349:" +
"2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:24,47,-1:46,26:2,-1:2,26,-1:25,241" +
":22,48,241:25,-1,349:18,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:2" +
"4,50,-1:27,349:18,-1:6,349:2,-1,349:4,127,349,240,-1,41,-1:9,39,-1:3,349,53" +
",349:16,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:42,58,-1:9,349:12" +
",299,349:5,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:6,300,34" +
"9:11,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,56:18,-1:6,56:2,-1" +
",56:4,169,56,240,-1,41,-1:9,56,-1:3,57:18,-1:6,57:2,-1,57:4,-1,57,-1:12,57," +
"-1:3,83:19,-1:2,83:2,-1,83:24,-1,89:19,-1:2,89:2,-1,89:24,-1,89:7,131,89:11" +
",-1:2,89:2,-1,89:24,-1,89:7,132,89:11,-1:2,89:2,-1,89:24,-1,89:7,133,89:11," +
"-1:2,89:2,-1,89:24,-1,89:7,134,89:11,-1:2,89:2,-1,89:24,-1,135:7,97,135:11," +
"-1:2,135:2,-1,135:24,-1,135:19,-1:2,135:2,-1,135:24,-1,259:12,146,259:5,-1:" +
"4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1,259:18,-1:4,25" +
"9,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,1,138,261:18,112:2,26" +
"1:2,-1,261:4,278,261:6,112,261:3,112,261:6,113,261,-1,261:19,-1:2,261:2,-1," +
"261:11,-1,261:3,-1,261:6,-1,261,-1:32,140,-1:13,121,-1:4,168,-1:47,124:19,-" +
"1:2,124:2,-1,124:11,-1,124:3,-1,124:6,-1,124,-1,349:11,324,349:6,-1:6,349:2" +
",-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,56:18,-1:6,56:2,-1,56:4,169,56,24" +
"0,-1,41,-1:9,127,-1:3,246:18,-1:6,246:2,-1,246:4,-1,246,-1:12,246,-1:3,83:1" +
"2,85,83:6,-1:2,83:2,-1,83:24,-1,89:9,91,89:9,-1:2,89:2,-1,89:24,-1,136:18,2" +
"52:4,101,252,136:7,252,136,252,136,252:3,136,252:2,136:2,252,136:4,-1,261:8" +
",147,261:10,-1:2,261:2,-1,261:11,-1,261:3,-1,261:6,-1,261,-1,256:22,122,256" +
":25,-1:46,140,-1:3,264,-1:10,279,-1:37,349:7,42,349:4,43,349:5,-1:6,349:2,-" +
"1,349:4,169,349,240,-1,41,-1:9,349,-1:3,242:6,345,242:21,350,242:5,49,242:1" +
"3,-1,83:9,86,83:9,-1:2,83:2,-1,83:24,-1,89:5,92,89:13,-1:2,89:2,-1,89:24,-1" +
",259:6,102,259:11,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,25" +
"9:4,-1,261:8,114,261:10,-1:2,261:2,-1,261:11,-1,261:3,-1,261:6,-1,261,-1:13" +
",171,-1:36,349:11,44,45,328,349:4,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:" +
"9,349,-1:24,51,-1:27,83:11,87,83:7,-1:2,83:2,-1,83:24,-1,89:11,93,89:7,-1:2" +
",89:2,-1,89:24,-1,259:3,170,259:14,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259" +
",-1:2,259:2,-1,259:4,-1,261:3,161,261:15,-1:2,261:2,-1,261:11,-1,261:3,-1,2" +
"61:6,-1,261,-1:6,174,-1:5,177,-1:37,349:5,346,349:12,-1:6,349:2,-1,46,349:3" +
",169,349,240,-1,41,-1:9,349,-1:3,243:46,52,243,-1,83:12,88,83:6,-1:2,83:2,-" +
"1,83:24,-1,89:12,94,89:6,-1:2,89:2,-1,89:24,-1,259:5,173,259:12,-1:4,259,-1" +
",259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1,261:12,115,261:6,-1:2," +
"261:2,-1,261:11,-1,261:3,-1,261:6,-1,261,-1:6,180,-1:43,349:8,54,349:9,-1:6" +
",349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,259:7,263,259:10,-1:4,259,-" +
"1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:15,186,-1:34,349:6,55" +
",349:11,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,259:2,176,259:1" +
"5,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:3,189,-1:" +
"46,259:4,179,259:13,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1," +
"259:4,-1:8,195,-1:41,349:2,59,349:15,-1:6,349:2,-1,349:4,169,349,240,-1,41," +
"-1:9,349,-1:3,259:11,103,259:6,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:" +
"2,259:2,-1,259:4,-1:8,197,267,-1:40,349,60,349:16,-1:6,349:2,-1,349:4,169,3" +
"49,240,-1,41,-1:9,349,-1:3,259:18,-1:4,259,-1,259,104,259:5,-1,259,-1,259,-" +
"1:3,259,-1:2,259:2,-1,259:4,-1:10,199,-1:39,349:5,61,349:12,-1:6,349:2,-1,3" +
"49:4,169,349,240,-1,41,-1:9,349,-1:3,259:5,185,259:12,-1:4,259,-1,259:7,-1," +
"259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:3,2,-1:5,281,-1:40,349:2,62,349:" +
"15,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,259:18,-1:4,259,-1,1" +
"88,259:6,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:11,265,-1:38,349:8,6" +
"3,349:9,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,259:11,105,259:" +
"6,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:7,280,-1:" +
"42,349:16,64,349,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,259:9," +
"191,259:8,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:4" +
",201,-1:45,349:8,65,349:9,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1" +
":3,259:11,194,259:6,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1," +
"259:4,-1,203,-1:48,349:12,66,349:5,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1" +
":9,349,-1:3,259:6,106,259:11,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2," +
"259:2,-1,259:4,-1:6,207,-1:43,349:7,67,349:10,-1:6,349:2,-1,349:4,169,349,2" +
"40,-1,41,-1:9,349,-1:3,209,269,-1:47,349:5,68,349:12,-1:6,349:2,-1,349:4,16" +
"9,349,240,-1,41,-1:9,349,-1:17,3,-1:34,349:11,69,349:6,-1:6,349:2,-1,349:4," +
"169,349,240,-1,41,-1:9,349,-1:7,213,-1:44,349:11,70,349:6,-1:6,349:2,-1,349" +
":4,169,349,240,-1,41,-1:9,349,-1:11,215,-1:40,349:11,71,349:6,-1:6,349:2,-1" +
",349:4,169,349,240,-1,41,-1:9,349,-1:5,217,-1:46,349:14,72,349:3,-1:6,349:2" +
",-1,349:4,169,349,240,-1,41,-1:9,349,-1:14,219,-1:37,349:2,73,349:15,-1:6,3" +
"49:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:4,221,-1:47,349:12,74,349:5,-1:" +
"6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:10,271,-1:41,349:5,75,349:12" +
",-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,283,-1:48,349:7,76,349" +
":10,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:12,227,-1:39,349:2,77" +
",349:15,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:8,4,-1:43,349:10," +
"78,349:7,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:5,5,-1:46,349:8," +
"80,349:9,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:5,272,-1:46,349:" +
"12,81,349:5,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:6,228,-1:50,6" +
",-1:45,7,-1:51,8,-1:53,9,-1:53,232,-1:38,233,-1:48,10,-1:47,234,-1:49,11,-1" +
":54,12,-1:37,235,-1:50,236,-1:51,13,-1:42,1,14:19,15:2,14:2,15,14:10,16,17," +
"15,14:2,16,14:8,1,18:35,19,18:3,20,18:8,1,24,125,344,142,349,352,313,353,31" +
"7,149,354,355,260,356,349,156,349,321,25,26:2,27,28,26,357,358,126,349,323," +
"349:2,29,349,143,126,30,31,32,33,34,35,36,37,38,150,39,157,126,-1,242:34,49" +
",242:13,-1,242:34,128,242:13,-1,242:34,79,242:13,-1,246:18,-1:6,246:2,-1,24" +
"6:4,-1,246,-1:2,82,-1:9,246,-1:2,1,-1:48,1,83:9,129,83:6,311,365,83,84:2,83" +
":2,-1,83:24,1,89:2,343,89:13,312,366,89,90:2,89:2,-1,89:24,1,95,135:18,96:2" +
",135:2,-1,135:24,1,98,259:5,276,259:6,287,290,259:3,99:3,100,136,-1,292,259" +
":6,99,259,99,259,99:3,259,99:2,259:2,99,259:4,-1,252:22,137,252:25,1,107:20" +
",-1,107:2,-1,107:22,108,109,1,110:20,-1,110:2,-1,110:24,1,116:22,139,-1,116" +
":12,117,116,118,119,116:2,120,116:2,121,116:2,-1,83:16,144,83:2,-1:2,83:2,-" +
"1,83:24,-1,89:16,130,89:2,-1:2,89:2,-1,89:24,-1,331,349:8,172,349:3,293,349" +
":4,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:8,183,-1:43,259:7,182," +
"259:10,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1:3,19" +
"2,-1:49,211,-1:45,205,-1:53,268,-1:45,224,-1:57,223,-1:38,225,-1:49,229,-1:" +
"49,231,-1:45,242:8,244,242:25,49,242:13,-1,83:5,151,83:13,-1:2,83:2,-1,83:2" +
"4,-1,89:8,145,89:10,-1:2,89:2,-1,89:24,-1,259:11,153,259:6,-1:4,259,-1,259:" +
"7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1,349:7,175,349:10,-1:6,349:2" +
",-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,261:9,154,261:9,-1:2,261:2,-1,261" +
":11,-1,261:3,-1,261:6,-1,261,-1:6,266,-1:43,282,-1:53,270,-1:45,226,-1:48,2" +
"30,-1:46,242,245,242:32,49,242:13,-1,83:9,158,83:9,-1:2,83:2,-1,83:24,-1,89" +
":5,152,89:13,-1:2,89:2,-1,89:24,-1,259:7,160,259:10,-1:4,259,-1,259:7,-1,25" +
"9,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1,349:18,-1:6,349:2,-1,349:2,178,349" +
",169,349,240,-1,41,-1:9,349,-1:3,89:9,159,89:9,-1:2,89:2,-1,89:24,-1,164,25" +
"9:17,-1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1,349:17" +
",181,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,259:3,167,259:14,-" +
"1:4,259,-1,259:7,-1,259,-1,259,-1:3,259,-1:2,259:2,-1,259:4,-1,349:8,184,34" +
"9:9,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:9,187,349:8,-1:" +
"6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:8,190,349:9,-1:6,349:2" +
",-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:3,193,349:14,-1:6,349:2,-1,34" +
"9:4,169,349,240,-1,41,-1:9,349,-1:3,349:9,196,349:8,-1:6,349:2,-1,349:4,169" +
",349,240,-1,41,-1:9,349,-1:3,349:8,198,349:9,-1:6,349:2,-1,349:4,169,349,24" +
"0,-1,41,-1:9,349,-1:3,349:5,200,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,4" +
"1,-1:9,349,-1:3,349:5,202,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9" +
",349,-1:3,349:5,204,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-" +
"1:3,349:13,206,349:4,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,34" +
"9:18,-1:6,349,208,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:9,210,349:8," +
"-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:11,212,349:6,-1:6,3" +
"49:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:8,214,349:9,-1:6,349:2,-1" +
",349:4,169,349,240,-1,41,-1:9,349,-1:3,349,216,349:16,-1:6,349:2,-1,349:4,1" +
"69,349,240,-1,41,-1:9,349,-1:3,349:12,218,349:5,-1:6,349:2,-1,349:4,169,349" +
",240,-1,41,-1:9,349,-1:3,220,349:17,-1:6,349:2,-1,349:4,169,349,240,-1,41,-" +
"1:9,349,-1:3,349:5,222,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,34" +
"9,-1:3,359,83:4,257,83:13,-1:2,83:2,-1,83:24,-1,360,89:4,258,89:13,-1:2,89:" +
"2,-1,89:24,-1,349:5,277,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,3" +
"49,-1:3,273,242:33,49,242:13,-1,83:10,274,83:8,-1:2,83:2,-1,83:24,-1,89:15," +
"275,89:3,-1:2,89:2,-1,89:24,-1,349:3,288,349,291,349:12,-1:6,349:2,-1,349:4" +
",169,349,240,-1,41,-1:9,349,-1:3,242:15,284,242:18,49,242:13,-1,83:3,285,83" +
":15,-1:2,83:2,-1,83:24,-1,89:10,286,89:8,-1:2,89:2,-1,89:24,-1,349:11,294,3" +
"49,295,349:4,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,89:3,289,8" +
"9:15,-1:2,89:2,-1,89:24,-1,349:9,296,349:8,-1:6,349:2,-1,349:4,169,349,240," +
"-1,41,-1:9,349,-1:3,349:9,297,349:8,-1:6,349:2,-1,349:4,169,349,240,-1,41,-" +
"1:9,349,-1:3,349:15,298,349:2,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,34" +
"9,-1:3,349:13,335,349:4,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3" +
",349:8,336,349:9,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:2," +
"301,349:15,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:9,302,34" +
"9:8,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:10,303,349:7,-1" +
":6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:2,337,349:15,-1:6,349" +
":2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:3,304,349:14,-1:6,349:2,-1," +
"349:4,169,349,240,-1,41,-1:9,349,-1:3,349:5,305,349:12,-1:6,349:2,-1,349:4," +
"169,349,240,-1,41,-1:9,349,-1:3,349:4,339,349:13,-1:6,349:2,-1,349:4,169,34" +
"9,240,-1,41,-1:9,349,-1:3,306,349:17,-1:6,349:2,-1,349:4,169,349,240,-1,41," +
"-1:9,349,-1:3,349:5,307,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,3" +
"49,-1:3,349:13,340,349:4,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:" +
"3,349:18,-1:6,341,349,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:3,308,34" +
"9:14,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:11,309,349:6,-" +
"1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349:5,310,349:12,-1:6,34" +
"9:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,315,83:18,-1:2,83:2,-1,83:24,-" +
"1,316,89:18,-1:2,89:2,-1,89:24,-1,325,349:17,-1:6,349:2,-1,349:4,169,349,24" +
"0,-1,41,-1:9,349,-1:3,242:13,314,242:20,49,242:13,-1,349:2,338,349:15,-1:6," +
"349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,83:2,319,83:16,-1:2,83:2,-1," +
"83:24,-1,320,89:18,-1:2,89:2,-1,89:24,-1,242:6,318,242:27,49,242:13,-1,89:2" +
",322,89:16,-1:2,89:2,-1,89:24,-1,349:18,-1:6,349:2,-1,349:3,326,169,349,240" +
",-1,41,-1:9,349,-1:3,349:5,327,349:12,-1:6,349:2,-1,349:4,169,349,240,-1,41" +
",-1:9,349,-1:3,349:11,329,349:6,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9," +
"349,-1:3,349:3,330,349:14,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1" +
":3,349:12,332,349:5,-1:6,349:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,349" +
":18,-1:6,349,333,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,334,349:17,-1:6,3" +
"49:2,-1,349:4,169,349,240,-1,41,-1:9,349,-1:3,83:12,342,83:6,-1:2,83:2,-1,8" +
"3:24,-1,89:12,348,89:6,-1:2,89:2,-1,89:24,-1,83,347,83:17,-1:2,83:2,-1,83:2" +
"4,-1,89,351,89:17,-1:2,89:2,-1,89:24,-1,83:12,361,83:6,-1:2,83:2,-1,83:24,-" +
"1,89:12,362,89:6,-1:2,89:2,-1,89:24,-1,83:13,363,83:5,-1:2,83:2,-1,83:24,-1" +
",89:13,364,89:5,-1:2,89:2,-1,89:24");

	public java_cup.runtime.Symbol next_token ()
		throws java.io.IOException {
		int yy_lookahead;
		int yy_anchor = YY_NO_ANCHOR;
		int yy_state = yy_state_dtrans[yy_lexical_state];
		int yy_next_state = YY_NO_STATE;
		int yy_last_accept_state = YY_NO_STATE;
		boolean yy_initial = true;
		int yy_this_accept;

		yy_mark_start();
		yy_this_accept = yy_acpt[yy_state];
		if (YY_NOT_ACCEPT != yy_this_accept) {
			yy_last_accept_state = yy_state;
			yy_mark_end();
		}
		while (true) {
			if (yy_initial && yy_at_bol) yy_lookahead = YY_BOL;
			else yy_lookahead = yy_advance();
			yy_next_state = YY_F;
			yy_next_state = yy_nxt[yy_rmap[yy_state]][yy_cmap[yy_lookahead]];
			if (YY_EOF == yy_lookahead && true == yy_initial) {
				return null;
			}
			if (YY_F != yy_next_state) {
				yy_state = yy_next_state;
				yy_initial = false;
				yy_this_accept = yy_acpt[yy_state];
				if (YY_NOT_ACCEPT != yy_this_accept) {
					yy_last_accept_state = yy_state;
					yy_mark_end();
				}
			}
			else {
				if (YY_NO_STATE == yy_last_accept_state) {
					throw (new Error("Lexical Error: Unmatched Input."));
				}
				else {
					yy_anchor = yy_acpt[yy_last_accept_state];
					if (0 != (YY_END & yy_anchor)) {
						yy_move_end();
					}
					yy_to_mark();
					switch (yy_last_accept_state) {
					case 1:
						
					case -2:
						break;
					case 2:
						{ yybegin(REQUEST); trace.traceln(new String(yytext())); return new Symbol(sym.SET,new String(yytext())); }
					case -3:
						break;
					case 3:
						{ yybegin(REQUEST); trace.traceln("DROP"+new String(yytext())); return new Symbol(sym.DROP,new String(yytext())); }
					case -4:
						break;
					case 4:
						{ yybegin(REQUEST); trace.traceln("CREATE"+new String(yytext())); return new Symbol(sym.CREATE,new String(yytext())); }
					case -5:
						break;
					case 5:
						{ yybegin(REQUEST); trace.traceln(new String(yytext())); return new Symbol(sym.INSERT,new String(yytext())); }
					case -6:
						break;
					case 6:
						{ yybegin(REQUEST); trace.traceln(new String(yytext())); return new Symbol(sym.DELETE,new String(yytext())); }
					case -7:
						break;
					case 7:
						{ yybegin(REQUEST); trace.traceln("SELECT0:"+new String(yytext())); return new Symbol(sym.SELECT,new String(yytext())); }
					case -8:
						break;
					case 8:
						{ yybegin(REQUEST); trace.traceln(new String(yytext())); return new Symbol(sym.UPDATE,new String(yytext())); }
					case -9:
						break;
					case 9:
						{ yybegin(CATALOG); trace.traceln(new String(yytext())); return new Symbol(sym.CATALOG,new String(yytext())); }
					case -10:
						break;
					case 10:
						{ yybegin(ACTIVATE); trace.traceln(new String(yytext())); return new Symbol(sym.ACTIVATE,new String(yytext())); }
					case -11:
						break;
					case 11:
						{ yybegin(REQUEST); trace.traceln(new String(yytext())); return new Symbol(sym.DESCRIBE,new String(yytext())); }
					case -12:
						break;
					case 12:
						{ yybegin(REGISTER); trace.traceln(new String(yytext())); return new Symbol(sym.REGISTER,new String(yytext())); }
					case -13:
						break;
					case 13:
						{ yybegin(ACTIVATE); trace.traceln(new String(yytext())); return new Symbol(sym.DESACTIVATE,new String(yytext())); }
					case -14:
						break;
					case 14:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.NAME,new String(yytext())); }
					case -15:
						break;
					case 15:
						{ yybegin(REQUEST);  }
					case -16:
						break;
					case 16:
						{}
					case -17:
						break;
					case 17:
						{ yybegin(JDBC_REQUEST); trace.traceln(new String(yytext())); requestBuilder = new StringBuilder(); requestStack = 0; }
					case -18:
						break;
					case 18:
						{ requestBuilder.append(yytext()); }
					case -19:
						break;
					case 19:
						{ requestBuilder.append(yytext()); ++requestStack;}
					case -20:
						break;
					case 20:
						{ if (requestStack == 0) { trace.traceln(new String(yytext())); yybegin(REQUEST); try {trace.traceln(requestBuilder.toString()); return new Symbol(sym.SQLREQUEST, requestBuilder.toString());} finally {requestBuilder = null;} } else {requestBuilder.append(yytext()); --requestStack;}}
					case -21:
						break;
					case 21:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("NAME:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.NAME, nameBlockBuilder.toString());  }
					case -22:
						break;
					case 22:
						{}
					case -23:
						break;
					case 23:
						{ System.out.print("0"+new String(yytext())); yybegin(PROTECTED_BLOCK_NAME); }
					case -24:
						break;
					case 24:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -25:
						break;
					case 25:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.LEATHER,new String(yytext()));}
					case -26:
						break;
					case 26:
						{  }
					case -27:
						break;
					case 27:
						{trace.traceln(new String(yytext())); return new Symbol(sym.EQUALS,new String(yytext()));}
					case -28:
						break;
					case 28:
						{}
					case -29:
						break;
					case 29:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.POINT,new String(yytext())); }
					case -30:
						break;
					case 30:
						{ trace.traceln(new String("STARTGROUP:"+yytext())); return new Symbol(sym.STARTGROUP,new String(yytext())); }
					case -31:
						break;
					case 31:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.VIRG,new String(yytext())); }
					case -32:
						break;
					case 32:
						{ trace.traceln("MULT:"+new String(yytext())); return new Symbol(sym.MULT,new String(yytext())); }
					case -33:
						break;
					case 33:
						{ trace.traceln("VARIABLE:"+new String(yytext())); return new Symbol(sym.VARIABLE,new String(yytext())); }
					case -34:
						break;
					case 34:
						{ trace.traceln(new String("ENDGROUP:"+yytext())); return new Symbol(sym.ENDGROUP,new String(yytext())); }
					case -35:
						break;
					case 35:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.PLUS,new String(yytext()));}
					case -36:
						break;
					case 36:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MOINS,new String(yytext()));}
					case -37:
						break;
					case 37:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.DIV,new String(yytext()));}
					case -38:
						break;
					case 38:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.GREATER,new String(yytext()));}
					case -39:
						break;
					case 39:
						{ trace.traceln("NUMBER:"+new String(yytext())); return new Symbol(sym.NUMBER,new String(yytext())); }
					case -40:
						break;
					case 40:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.AS,new String(yytext())); }
					case -41:
						break;
					case 41:
						{ trace.traceln("FUNCTIONSTART:"+new String(yytext())); return new Symbol(sym.FUNCTIONSTART,new String(yytext())); }
					case -42:
						break;
					case 42:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.IS,new String(yytext())); }
					case -43:
						break;
					case 43:
						{ trace.traceln("IN!:"+new String(yytext())); return new Symbol(sym.IN,new String(yytext())); }
					case -44:
						break;
					case 44:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.OR,new String(yytext())); }
					case -45:
						break;
					case 45:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ON,new String(yytext())); }
					case -46:
						break;
					case 46:
						{ trace.traceln("BY"+new String(yytext())); return new Symbol(sym.BY,new String(yytext())); }
					case -47:
						break;
					case 47:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.LEATHEREQUALS,new String(yytext()));}
					case -48:
						break;
					case 48:
						{ trace.traceln("STRING"+new String(yytext())); return new Symbol(sym.STRING,new String(yytext())); }
					case -49:
						break;
					case 49:
						{ yybegin(BLOCK_NAME); nameBlockBuilder.setLength(0); trace.traceln("AT_ELE"+new String(yytext())); return new Symbol(sym.AT_ELE,new String(yytext())); }
					case -50:
						break;
					case 50:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.GREATEREQUALS,new String(yytext()));}
					case -51:
						break;
					case 51:
						{trace.traceln(new String(yytext())); return new Symbol(sym.NOTEQUALS,new String(yytext()));}
					case -52:
						break;
					case 52:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -53:
						break;
					case 53:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ASC,new String(yytext())); }
					case -54:
						break;
					case 54:
						{ trace.traceln("ALL:"+new String(yytext())); return new Symbol(sym.ALL,new String(yytext())); }
					case -55:
						break;
					case 55:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.AND,new String(yytext())); }
					case -56:
						break;
					case 56:
						{ trace.traceln("TABLE_NAME:"+new String(yytext())); return new Symbol(sym.TABLE_NAME,new String(yytext())); }
					case -57:
						break;
					case 57:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.AT_BASE,new String(yytext())); }
					case -58:
						break;
					case 58:
						{ trace.traceln("EMPTYFUNCTION:"+new String(yytext())); return new Symbol(sym.EMPTYFUNCTION,new String(yytext())); }
					case -59:
						break;
					case 59:
						{ trace.traceln("NOT!:"+new String(yytext())); return new Symbol(sym.NOT,new String(yytext())); }
					case -60:
						break;
					case 60:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.DESC,new String(yytext())); }
					case -61:
						break;
					case 61:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.LIKE,new String(yytext())); }
					case -62:
						break;
					case 62:
						{ trace.traceln("LEFT"+new String(yytext())); return new Symbol(sym.LEFT,new String(yytext())); }
					case -63:
						break;
					case 63:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.NULL,new String(yytext())); }
					case -64:
						break;
					case 64:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.FROM,new String(yytext())); }
					case -65:
						break;
					case 65:
						{ trace.traceln("FULL:"+new String(yytext())); return new Symbol(sym.FULL,new String(yytext())); }
					case -66:
						break;
					case 66:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.JOIN,new String(yytext())); }
					case -67:
						break;
					case 67:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.CROSS,new String(yytext())); }
					case -68:
						break;
					case 68:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.TABLE,new String(yytext())); }
					case -69:
						break;
					case 69:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.INNER,new String(yytext())); }
					case -70:
						break;
					case 70:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ORDER,new String(yytext())); }
					case -71:
						break;
					case 71:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.OUTER,new String(yytext())); }
					case -72:
						break;
					case 72:
						{ trace.traceln("GROUP"+new String(yytext())); return new Symbol(sym.GROUP,new String(yytext())); }
					case -73:
						break;
					case 73:
						{ trace.traceln("RIGHT"+new String(yytext())); return new Symbol(sym.RIGHT,new String(yytext())); }
					case -74:
						break;
					case 74:
						{ trace.traceln("UNION:"+new String(yytext())); yybegin(UNION_BLOCK);  }
					case -75:
						break;
					case 75:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.WHERE,new String(yytext())); }
					case -76:
						break;
					case 76:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.EQUALS,new String(yytext())); }
					case -77:
						break;
					case 77:
						{ trace.traceln("SELECT1:"+new String(yytext())); return new Symbol(sym.SELECT, new String(yytext())); }
					case -78:
						break;
					case 78:
						{ trace.traceln("HAVING"+new String(yytext())); return new Symbol(sym.HAVING,new String(yytext())); }
					case -79:
						break;
					case 79:
						{ yybegin(JDBC_BLOC); trace.traceln(new String(yytext())); return new Symbol(sym.AT_JDBC,new String(yytext())); }
					case -80:
						break;
					case 80:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.NATURAL,new String(yytext())); }
					case -81:
						break;
					case 81:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.BETWEEN,new String(yytext())); }
					case -82:
						break;
					case 82:
						{ yybegin(TMP_BLOC); trace.traceln("STARTTEMP"+new String(yytext())); return new Symbol(sym.START_TEMP,new String(yytext())); }
					case -83:
						break;
					case 83:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -84:
						break;
					case 84:
						{}
					case -85:
						break;
					case 85:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ON,new String(yytext())); }
					case -86:
						break;
					case 86:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MEMO,new String(yytext())); }
					case -87:
						break;
					case 87:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MANAGER,new String(yytext())); }
					case -88:
						break;
					case 88:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.FUNCTION,new String(yytext())); }
					case -89:
						break;
					case 89:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -90:
						break;
					case 90:
						{}
					case -91:
						break;
					case 91:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MEMO,new String(yytext())); }
					case -92:
						break;
					case 92:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.TABLE,new String(yytext())); }
					case -93:
						break;
					case 93:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MANAGER,new String(yytext())); }
					case -94:
						break;
					case 94:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.FUNCTION,new String(yytext())); }
					case -95:
						break;
					case 95:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -96:
						break;
					case 96:
						{}
					case -97:
						break;
					case 97:
						{ yybegin(REGISTER2); trace.traceln(new String(yytext())); return new Symbol(sym.AS,new String(yytext())); }
					case -98:
						break;
					case 98:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -99:
						break;
					case 99:
						{}
					case -100:
						break;
					case 100:
						{trace.traceln(new String(yytext())); return new Symbol(sym.EQUALS,new String(yytext()));}
					case -101:
						break;
					case 101:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.STRING, new String(yytext())); }
					case -102:
						break;
					case 102:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.AND,new String(yytext())); }
					case -103:
						break;
					case 103:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.USER,new String(yytext())); }
					case -104:
						break;
					case 104:
						{ trace.traceln("WITH:"+new String(yytext())); return new Symbol(sym.WITH,new String(yytext())); }
					case -105:
						break;
					case 105:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.DRIVER,new String(yytext())); }
					case -106:
						break;
					case 106:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.PASSWORD, new String(yytext())); }
					case -107:
						break;
					case 107:
						{ System.out.print("5"+new String(yytext())); nameBlockBuilder.append(new String(yytext())); }
					case -108:
						break;
					case 108:
						{ System.out.print("4"+new String(yytext())); yybegin(BLOCK_NAME); }
					case -109:
						break;
					case 109:
						{ yybegin(ANTI_PROTECTED_BLOCK_NAME); }
					case -110:
						break;
					case 110:
						{ yybegin(PROTECTED_BLOCK_NAME); System.out.print("3:"+new String(yytext())); nameBlockBuilder.append(new String(yytext())); }
					case -111:
						break;
					case 111:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -112:
						break;
					case 112:
						{}
					case -113:
						break;
					case 113:
						{ System.out.print("0"+new String(yytext())); yybegin(PROTECTED_BLOCK_NAME); }
					case -114:
						break;
					case 114:
						{ trace.traceln("UNION_ALL:"+new String(yytext())); yybegin(REQUEST); return new Symbol(sym.UNION_ALL,new String("UNION "+yytext())); }
					case -115:
						break;
					case 115:
						{ trace.traceln("UNION_JOIN:"+new String(yytext())); yybegin(REQUEST); return new Symbol(sym.UNION_JOIN,new String("UNION "+yytext())); }
					case -116:
						break;
					case 116:
						{ }
					case -117:
						break;
					case 117:
						{ trace.traceln("VIRG"+new String(yytext())); return new Symbol(sym.VIRG,new String(yytext())); }
					case -118:
						break;
					case 118:
						{ trace.traceln("VARIABLE:"+new String(yytext())); return new Symbol(sym.VARIABLE,new String(yytext())); }
					case -119:
						break;
					case 119:
						{ yybegin(REQUEST); return new Symbol(sym.END_TEMP, "");}
					case -120:
						break;
					case 120:
						{ trace.traceln("SEPROW"+new String(yytext())); return new Symbol(sym.SEPROW,new String(yytext())); }
					case -121:
						break;
					case 121:
						{ trace.traceln("NUMBER:"+new String(yytext())); return new Symbol(sym.NUMBER,new String(yytext())); }
					case -122:
						break;
					case 122:
						{ trace.traceln("STRING"+new String(yytext())); return new Symbol(sym.STRING,new String(yytext())); }
					case -123:
						break;
					case 124:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("NAME:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.NAME, nameBlockBuilder.toString());  }
					case -124:
						break;
					case 125:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -125:
						break;
					case 126:
						{}
					case -126:
						break;
					case 127:
						{ trace.traceln("NUMBER:"+new String(yytext())); return new Symbol(sym.NUMBER,new String(yytext())); }
					case -127:
						break;
					case 128:
						{ yybegin(BLOCK_NAME); nameBlockBuilder.setLength(0); trace.traceln("AT_ELE"+new String(yytext())); return new Symbol(sym.AT_ELE,new String(yytext())); }
					case -128:
						break;
					case 129:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -129:
						break;
					case 130:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -130:
						break;
					case 131:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MEMO,new String(yytext())); }
					case -131:
						break;
					case 132:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.TABLE,new String(yytext())); }
					case -132:
						break;
					case 133:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.MANAGER,new String(yytext())); }
					case -133:
						break;
					case 134:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.FUNCTION,new String(yytext())); }
					case -134:
						break;
					case 135:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -135:
						break;
					case 136:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -136:
						break;
					case 137:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.STRING, new String(yytext())); }
					case -137:
						break;
					case 138:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -138:
						break;
					case 139:
						{ }
					case -139:
						break;
					case 140:
						{ trace.traceln("NUMBER:"+new String(yytext())); return new Symbol(sym.NUMBER,new String(yytext())); }
					case -140:
						break;
					case 142:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -141:
						break;
					case 143:
						{}
					case -142:
						break;
					case 144:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -143:
						break;
					case 145:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -144:
						break;
					case 146:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -145:
						break;
					case 147:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -146:
						break;
					case 149:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -147:
						break;
					case 150:
						{}
					case -148:
						break;
					case 151:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -149:
						break;
					case 152:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -150:
						break;
					case 153:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -151:
						break;
					case 154:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -152:
						break;
					case 156:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -153:
						break;
					case 157:
						{}
					case -154:
						break;
					case 158:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -155:
						break;
					case 159:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -156:
						break;
					case 160:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -157:
						break;
					case 161:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -158:
						break;
					case 163:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -159:
						break;
					case 164:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -160:
						break;
					case 166:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -161:
						break;
					case 167:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -162:
						break;
					case 169:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -163:
						break;
					case 170:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -164:
						break;
					case 172:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -165:
						break;
					case 173:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -166:
						break;
					case 175:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -167:
						break;
					case 176:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -168:
						break;
					case 178:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -169:
						break;
					case 179:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -170:
						break;
					case 181:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -171:
						break;
					case 182:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -172:
						break;
					case 184:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -173:
						break;
					case 185:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -174:
						break;
					case 187:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -175:
						break;
					case 188:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -176:
						break;
					case 190:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -177:
						break;
					case 191:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -178:
						break;
					case 193:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -179:
						break;
					case 194:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -180:
						break;
					case 196:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -181:
						break;
					case 198:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -182:
						break;
					case 200:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -183:
						break;
					case 202:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -184:
						break;
					case 204:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -185:
						break;
					case 206:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -186:
						break;
					case 208:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -187:
						break;
					case 210:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -188:
						break;
					case 212:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -189:
						break;
					case 214:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -190:
						break;
					case 216:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -191:
						break;
					case 218:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -192:
						break;
					case 220:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -193:
						break;
					case 222:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -194:
						break;
					case 257:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -195:
						break;
					case 258:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -196:
						break;
					case 259:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -197:
						break;
					case 260:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -198:
						break;
					case 261:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -199:
						break;
					case 263:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -200:
						break;
					case 274:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -201:
						break;
					case 275:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -202:
						break;
					case 276:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -203:
						break;
					case 277:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -204:
						break;
					case 278:
						{ nameBlockBuilder.append(new String(yytext())); trace.traceln("ELEMENTUNION:"+nameBlockBuilder.toString()); yybegin(REQUEST); return new Symbol(sym.ELEMENT, nameBlockBuilder.toString());  }
					case -205:
						break;
					case 285:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -206:
						break;
					case 286:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -207:
						break;
					case 287:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -208:
						break;
					case 288:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -209:
						break;
					case 289:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -210:
						break;
					case 290:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -211:
						break;
					case 291:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -212:
						break;
					case 292:
						{ trace.traceln(new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -213:
						break;
					case 293:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -214:
						break;
					case 294:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -215:
						break;
					case 295:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -216:
						break;
					case 296:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -217:
						break;
					case 297:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -218:
						break;
					case 298:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -219:
						break;
					case 299:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -220:
						break;
					case 300:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -221:
						break;
					case 301:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -222:
						break;
					case 302:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -223:
						break;
					case 303:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -224:
						break;
					case 304:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -225:
						break;
					case 305:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -226:
						break;
					case 306:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -227:
						break;
					case 307:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -228:
						break;
					case 308:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -229:
						break;
					case 309:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -230:
						break;
					case 310:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -231:
						break;
					case 311:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -232:
						break;
					case 312:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -233:
						break;
					case 313:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -234:
						break;
					case 315:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -235:
						break;
					case 316:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -236:
						break;
					case 317:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -237:
						break;
					case 319:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -238:
						break;
					case 320:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -239:
						break;
					case 321:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -240:
						break;
					case 322:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -241:
						break;
					case 323:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -242:
						break;
					case 324:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -243:
						break;
					case 325:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -244:
						break;
					case 326:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -245:
						break;
					case 327:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -246:
						break;
					case 328:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -247:
						break;
					case 329:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -248:
						break;
					case 330:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -249:
						break;
					case 331:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -250:
						break;
					case 332:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -251:
						break;
					case 333:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -252:
						break;
					case 334:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -253:
						break;
					case 335:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -254:
						break;
					case 336:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -255:
						break;
					case 337:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -256:
						break;
					case 338:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -257:
						break;
					case 339:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -258:
						break;
					case 340:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -259:
						break;
					case 341:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -260:
						break;
					case 342:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -261:
						break;
					case 343:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -262:
						break;
					case 344:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -263:
						break;
					case 346:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -264:
						break;
					case 347:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -265:
						break;
					case 348:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -266:
						break;
					case 349:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -267:
						break;
					case 351:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -268:
						break;
					case 352:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -269:
						break;
					case 353:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -270:
						break;
					case 354:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -271:
						break;
					case 355:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -272:
						break;
					case 356:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -273:
						break;
					case 357:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -274:
						break;
					case 358:
						{ trace.traceln("Element:"+new String(yytext())); return new Symbol(sym.ELEMENT,new String(yytext())); }
					case -275:
						break;
					case 359:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -276:
						break;
					case 360:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -277:
						break;
					case 361:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -278:
						break;
					case 362:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -279:
						break;
					case 363:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -280:
						break;
					case 364:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -281:
						break;
					case 365:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -282:
						break;
					case 366:
						{ trace.traceln("NAME:"+new String(yytext())); return new Symbol(sym.NAME, new String(yytext())); }
					case -283:
						break;
					default:
						yy_error(YY_E_INTERNAL,false);
					case -1:
					}
					yy_initial = true;
					yy_state = yy_state_dtrans[yy_lexical_state];
					yy_next_state = YY_NO_STATE;
					yy_last_accept_state = YY_NO_STATE;
					yy_mark_start();
					yy_this_accept = yy_acpt[yy_state];
					if (YY_NOT_ACCEPT != yy_this_accept) {
						yy_last_accept_state = yy_state;
						yy_mark_end();
					}
				}
			}
		}
	}
}

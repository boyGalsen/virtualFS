package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.ColumnType;
import org.openknows.jdbc.driver.unisql.DatabaseValue;
import org.openknows.jdbc.driver.unisql.Row;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.GroupByOperation;
import org.openknows.jdbc.driver.unisql.operation.Operation;


public class KurtosisOperation extends AbstractFunctionOperation {
  
  private static class DynJDBCDatabaseValueKurtosis extends DynJDBCDatabaseValue {

    @Override
    protected Object buildOriginalValue() {
      final EzArray<DatabaseValue> values = getSubValues();
      double sum = 0.0;
      int count = 0;
      for (int i = 0, n = values.getCount(); i < n; i++) {
        final DatabaseValue value = values.get(i);
        count++;
        if (!value.isNull()) {
          sum += value.getdoubleValue();
        }
      }
      final double average = sum/count;
      double sum2 = 0.0;
      double sum4 = 0.0;
      for (int i = 0, n = values.getCount(); i < n; i++) {
        final DatabaseValue value = values.get(i);
        if (!value.isNull()) {
          final double doubelValue = value.getdoubleValue();
          sum2 += (doubelValue - average) * (doubelValue - average);
          sum4 += (doubelValue - average) * (doubelValue - average) * (doubelValue - average) * (doubelValue - average);
        }
      }
      final double std = Math.sqrt(sum2/count);
      return MathUtils.getDouble(((sum4/count) / (std*std*std*std))-3);
    }
  }
    
  public KurtosisOperation() {
    super("Statistics.Kurtosis", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        final DynJDBCDatabaseValueKurtosis variance = (DynJDBCDatabaseValueKurtosis)((previousValue == null || previousValue == JDBCDatabaseValue.NULL) ? new DynJDBCDatabaseValueKurtosis() : previousValue);
        variance.addSubValue(value);
        return variance;
      }
    };
  }
}
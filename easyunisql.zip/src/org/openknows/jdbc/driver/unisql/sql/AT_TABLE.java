package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.*;

public class AT_TABLE implements TABLE {

  public AT_TABLE(final String at, final String file, final String name) {
    this.at = JDBCUtil.upper(at);
    this.file = file;
    this.name = JDBCUtil.upper(name);
  }
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) {
  }
  
  public String getAt() {
    return this.at;
  }
  
  public String getFile() {
    return this.file;
  }
  
  public String getName() {
    return this.name;
  }
  
  private final String at;
  private final String file;
  private final String name;
}
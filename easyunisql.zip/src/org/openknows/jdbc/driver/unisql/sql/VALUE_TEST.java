package org.openknows.jdbc.driver.unisql.sql;

public interface VALUE_TEST {

}

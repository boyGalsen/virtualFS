package org.openknows.jdbc.driver.unisql.sql;

public class REGISTER implements EXECUTABLE {

  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();

  public String url;
  public String name;
  public String driver;
  public String user;
  public String password;
}

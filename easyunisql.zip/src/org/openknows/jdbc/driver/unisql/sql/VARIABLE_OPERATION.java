package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class VARIABLE_OPERATION extends OPERATION {

  public VARIABLE_OPERATION(int index) {
    this.index = index; 
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
  }
  

  @Override
  public String getName() {
    return ":"+index;
  }

  public DatabaseValue getValue() {
    return value;
  }
  
  public void setValue(DatabaseValue value) {
    this.value = value;
  }
  
  @Override
  public boolean applyOn(final TABLE table) {
    return true;
  }
  
  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    return new Operation(name, value.isDoubleAvailable() ? ColumnType.DOUBLE : ColumnType.STRING) {

      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        return VARIABLE_OPERATION.this.value;
      }
    };
  }

  @Override
  public Operation getOperation(String name, MetaData metaData) {
    return new Operation(name, value.isDoubleAvailable() ? ColumnType.DOUBLE : ColumnType.STRING) {

      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        return VARIABLE_OPERATION.this.value;
      }
    };
  }

  
  public int getIndex() {
    return this.index;
  }
  
  private DatabaseValue value;
  private final int index;

  /*
  @Override
  public void buildToJava(StringBuilder buffer, OPERATION_TYPE type) {
    if (value.isNull()) { 
      buffer.append("null"); 
    }
    else {
      switch (type) {
        case NUMBER : {
          if (value.isDoubleAvailable()) { 
            buffer.append(value.getOriginalValue());
          }
          else {
            throw new IllegalStateException();
          }
        }
        default : {      
          if (value.isDoubleAvailable()) { 
            buffer.append(value.getOriginalValue());
          }
          else {
            buffer.append("\"").append(value.getStringValue()).append("\"");
          }
        }
      }
    }
  }

  @Override
  public void buildToSQL(StringBuilder buffer, OPERATION_TYPE type) {
    if (value.isNull()) { 
      buffer.append("null"); 
    }
    else {
      switch (type) {
        case NUMBER : {
          if (value.isDoubleAvailable()) { 
            buffer.append(value.getOriginalValue());
          }
          else {
            throw new IllegalStateException();
          }
        }
        default :         
          if (value.isDoubleAvailable()) { 
            buffer.append(value.getOriginalValue());
          }
          else {
            buffer.append("'").append(value.getStringValue()).append("'");
          }
      }
    }
  }
  */
  @Override
  public Boolean isNumber() { return value.isDoubleAvailable() ? Boolean.TRUE : Boolean.FALSE; }
}

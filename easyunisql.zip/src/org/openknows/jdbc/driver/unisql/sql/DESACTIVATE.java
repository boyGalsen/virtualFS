package org.openknows.jdbc.driver.unisql.sql;

import java.util.*;

public class DESACTIVATE implements EXECUTABLE {
  
  public static final int MANAGER = 0;
  public static final int FUNCTION = 1;
  public static final int MEMO = 2;
  
  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();
  
  public int type;
  public ArrayList<String> parameters = new ArrayList<String>();
}

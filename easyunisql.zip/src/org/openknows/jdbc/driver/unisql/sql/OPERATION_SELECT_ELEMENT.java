package org.openknows.jdbc.driver.unisql.sql;


import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class OPERATION_SELECT_ELEMENT implements SELECT_ELEMENT {
  
  public static SELECT_ELEMENT get(OPERATION operation, String name) {
    /*if (operation instanceof SIMPLE_ELEMENT_OPERATION) {
      final SELECT_ELEMENT e = ((SIMPLE_ELEMENT_OPERATION)operation).getElement();
      //e.setName(name);
      return e;
    }*/
    return new OPERATION_SELECT_ELEMENT(operation, name);
  }
  
  public boolean isNumber() {
    return this.operation.isNumber() != null && this.operation.isNumber().booleanValue();
  }

  public OPERATION_SELECT_ELEMENT(OPERATION operation, String name) {
    this.operation = operation;
    this.name = name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getName() {
    return this.name == null ? this.operation.getName() : this.name;
  }

  public boolean applyOn(TABLE table) {
    return this.operation.applyOn(table);
  }

  public String getColumnFullName() {
    return name;
  }
  
  public Operation getGroupOperation(String name, MetaData metaData) {
    return this.operation.getGroupOperation(name, metaData);
  }

  public Operation getOperation(String name, MetaData metaData) { 
    return this.operation.getOperation(name, metaData);
  }
  
  
  //public String toString() {
  /*  final StringBuilder buffer = StreamUtils.stringBuilderPool.getNew();
    try {
      this.operation.buildToJava(buffer, isNumber() ? OPERATION_TYPE.NUMBER : OPERATION_TYPE.STRING);
      return buffer.toString();
    }
    finally {
      StreamUtils.stringBuilderPool.free(buffer);
    }*/
  //}

  public boolean isGroupOperation() {
    return operation.isGroupOperation();
  }

  private final OPERATION operation;
  private String name;
}
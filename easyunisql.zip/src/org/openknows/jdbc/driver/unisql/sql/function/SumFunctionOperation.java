package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class SumFunctionOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue[] values) {
    return values[0];
  }
  
  public SumFunctionOperation() {
    super("SUM", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        if (value == null || value.isNull() || value.getdoubleValue() == 0.0) return (previousValue == null || previousValue.isNull()) ? JDBCDatabaseValue.getAndInit(MathUtils.getDouble(0)) : previousValue;
        if (previousValue == null || previousValue.isNull() || previousValue.getdoubleValue() == 0.0) return JDBCDatabaseValue.getAndInit(value);
        return JDBCDatabaseValue.getAndInit(MathUtils.getDouble(previousValue.getdoubleValue() + value.getdoubleValue()));
      }
    };
  }
}
package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;

public abstract class DUAL_TEST extends WHERE_TEST {

  public void subSelectCompile(JDBCRequestDecoder requestDecoder) throws Throwable {
  }
  
  public DUAL_TEST(final SELECT_ELEMENT columnA, final SELECT_ELEMENT columnB) {
    this.columnA = columnA;
    this.columnB = columnB;
  }
  
  /*
  @Override
  public final boolean buildToJavaOR(final StringBuilder buffer, final TABLE table) {
    buffer.append("false");
    return false;
  }
  
  @Override
  public final boolean buildToJavaAND(final StringBuilder buffer, final TABLE table) {
    buffer.append("true");
    return false;
  }
  
  @Override
  public final boolean buildToSQLOR(final StringBuilder buffer, final TABLE table) {
    buffer.append("1=0");
    return false;
  }
  
  @Override
  public final boolean buildToSQLAND(final StringBuilder buffer, final TABLE table) {
    buffer.append("1=1");
    return false;
  }
  */
  public final SELECT_ELEMENT columnA;
  public final SELECT_ELEMENT columnB;
}

package org.openknows.jdbc.driver.unisql.sql;

import java.util.ArrayList;

public class SELECT_LIST implements EXECUTABLE {

  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();

  public void add(SELECT select) {
    selects.add(select);
  }
  
  public SELECT[] toArray() {
    return selects.toArray(new SELECT[selects.size()]);
  }
  
  public int size() {
    return selects.size();
  }
  
  public SELECT get(int i) {
    return selects.get(i);
  }
  
  private final ArrayList<SELECT> selects = new ArrayList<SELECT>();
}

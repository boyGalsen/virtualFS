package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class MinFunctionOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue[] values) {
    return values[0];
  }
  
  public MinFunctionOperation() {
    super("MIN", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        if (value == null || value.isNull() || value.getdoubleValue() == 0.0) return (previousValue == null || previousValue.isNull()) ? JDBCDatabaseValue.getAndInit(MathUtils.getDouble(0)) : previousValue;
        if (previousValue == null || previousValue.isNull()) return value; 
        final Double valueAsDouble = value.getDoubleValue();
        final Double previousValueAsDouble = previousValue.getDoubleValue();
        if (valueAsDouble == null) return previousValue;
        if (previousValueAsDouble == null) return value; 
        return (previousValueAsDouble.doubleValue() <= valueAsDouble.doubleValue()) ? previousValue : value;
      }
    };
  }
}
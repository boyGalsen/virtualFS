package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.operation.Operation;

public interface SELECT_ELEMENT {

  public String getName();
  public void setName(String name);
  
  public abstract Operation getGroupOperation(String name, MetaData metaData);
  public abstract Operation getOperation(String name, MetaData metaData);
  
  public boolean isGroupOperation();
  
  public boolean applyOn(final TABLE table);
}

package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class MedianFunctionOperation extends AbstractFunctionOperation {
  
  private static class DynJDBCDatabaseValueMedian extends DynJDBCDatabaseValue {

    @Override
    protected Object buildOriginalValue() {
      final EzArray<DatabaseValue> values = getSubValues();
      int count = 0;
      final double[] doubleValues = new double[values.getCount()];
      for (int i = 0, n = values.getCount(); i < n; i++) {
        final DatabaseValue value = values.get(i);
        doubleValues[count++] = value.isNull() ? 0.0 : value.getdoubleValue();
      }
      Arrays.sort(doubleValues);
      return MathUtils.getDouble(count%2 == 0 ? (doubleValues[count/2]+doubleValues[(count/2)+1])/2 : doubleValues[(count-1)/2]);
    }
  }
    
  public MedianFunctionOperation() {
    super("Statistics.Median", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        final DynJDBCDatabaseValueMedian variance = (DynJDBCDatabaseValueMedian)((previousValue == null || previousValue == JDBCDatabaseValue.NULL) ? new DynJDBCDatabaseValueMedian() : previousValue);
        variance.addSubValue(value);
        return variance;
      }
    };
  }
}
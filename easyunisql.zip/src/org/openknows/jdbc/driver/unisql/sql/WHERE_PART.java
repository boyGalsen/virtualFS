package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;

public class WHERE_PART {
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect)  throws Throwable {
    if (test != null) test.subSelectCompile(requestDecoder, originalSelect);
  }

  public WHERE_PART setTest(WHERE_TEST test) {
    this.test = test;
    return this;
  }
  
  public WHERE_TEST getTest() {
    return this.test;
  }
  
  private WHERE_TEST test= null;
}

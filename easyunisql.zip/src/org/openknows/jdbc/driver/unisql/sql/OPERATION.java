package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public abstract class OPERATION {
  
  public abstract Operation getOperation(String name, MetaData metaData);
  
  public Operation getOperation(String name, TABLE table, MetaData metaData) {
    if (applyOn(table)) return getOperation(name, metaData);
    return null;
  }
  
  public abstract Operation getGroupOperation(String name, MetaData metaData);
  
  public boolean isGroupOperation() { return false; }
  public abstract void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws  Throwable;
  
  public abstract Boolean isNumber();
  public abstract String getName();
  
  public boolean applyOn(final TABLE table) { return false; }
  public boolean canApplyOn(final TABLE table) { return applyOn(table); }
  
  public static enum OPERATION_TYPE {
    STRING,
    NUMBER;
  }
}

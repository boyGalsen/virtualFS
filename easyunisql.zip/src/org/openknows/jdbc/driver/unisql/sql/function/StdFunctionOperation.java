package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class StdFunctionOperation extends AbstractFunctionOperation {
  
  private static class DynJDBCDatabaseValueStd extends DynJDBCDatabaseValue {

    @Override
    protected Object buildOriginalValue() {
      final EzArray<DatabaseValue> values = getSubValues();
      double sum = 0.0;
      int count = 0;
      for (int i = 0, n = values.getCount(); i < n; i++) {
        final DatabaseValue value = values.get(i);
        count++;
        if (!value.isNull()) {
          sum += value.getdoubleValue();
        }
      }
      final double average = sum/count;
      double sum2 = 0.0;
      for (int i = 0, n = values.getCount(); i < n; i++) {
        final DatabaseValue value = values.get(i);
        if (!value.isNull()) {
          final double doubleValue = value.getdoubleValue();
          sum2 += (doubleValue - average) * (doubleValue - average);
        }
      }
      return MathUtils.getDouble(Math.sqrt(sum2/count));
    }
  }
    
  public StdFunctionOperation() {
    super("Statistics.Std", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        final DynJDBCDatabaseValueStd variance = (DynJDBCDatabaseValueStd)((previousValue == null || previousValue == JDBCDatabaseValue.NULL) ? new DynJDBCDatabaseValueStd() : previousValue);
        variance.addSubValue(value);
        return variance;
      }
    };
  }
}
package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class AbsOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(final DatabaseValue value) {
    if (value == null || value.isNull()) return JDBCDatabaseValue.NULL;
    if (value.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if ("".equals(value.getStringValue())) return value;
    if (value.getdoubleValue() >= 0) return value;
    return (value.isIntAvailable() && value.isIntAvailable()) 
      ? JDBCDatabaseValue.getAndInit(LongCache.get(Math.abs(value.getintValue())))
      : JDBCDatabaseValue.getAndInit(MathUtils.getDouble(Math.abs(value.getdoubleValue())));
  }
  
  public AbsOperation() {
    super("Math.Abs", null, false);
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {

      private final String partAKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        return JDBCDatabaseValue.getAndInit(execute(partAValue))
          .initSubValues(partAValue)
          .setSubValue(partAKey, partAValue);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
        return JDBCDatabaseValue.getAndInitNumber(execute(partAValue))
          .initSubValues(partAValue);
      }    
    };
  }
}
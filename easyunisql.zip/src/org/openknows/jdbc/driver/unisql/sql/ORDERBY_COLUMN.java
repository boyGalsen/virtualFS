package org.openknows.jdbc.driver.unisql.sql;

public interface ORDERBY_COLUMN {

  public boolean isDesc();
}

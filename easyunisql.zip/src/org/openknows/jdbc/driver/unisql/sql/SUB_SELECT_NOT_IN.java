package org.openknows.jdbc.driver.unisql.sql;

import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;

public class SUB_SELECT_NOT_IN extends NOT_IN_TEST_OPERATION {

  public SUB_SELECT_NOT_IN(OPERATION column, SELECT select) {
    super(column);
    this.select = select;
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws  Throwable {
    final SelectDecoderPart part = new SelectDecoderPart(requestDecoder);
    JDBCDecoderResult result = part.compile(select);
    final MetaData metaData = result.getMetaData();
    if (metaData.getColumnCount() != 1) throw new IllegalArgumentException("Not Valid Column Count:"+metaData.getColumnCount());
    final Column c = metaData.getColumn(1);
    final ResultSet rs = result.getResultSet();
    switch (c.getType()) {
      case DOUBLE : 
      case LONG : {
        while (rs.next()) {
          addPart(new UNIQUE_EQUALS_OPERATION(getColumn(), new NUMBER_OPERATION(rs.getString(1))));
        }
      } break;
      default : {
        while (rs.next()) {
          addPart(new UNIQUE_EQUALS_OPERATION(getColumn(), new STRING_OPERATION(rs.getString(1))));
        }
      } 
    }
    rs.close();
  }

  private SELECT select;
}
package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;

public class UNIQUE_TEST_GREATER_NUMBER2 extends CONSTANT_TEST implements VALUE_TEST {

  public UNIQUE_TEST_GREATER_NUMBER2(final String numberA, final String numberB, final boolean withEquals) {
    super(withEquals ? JDBCUtil.isGreaterOrEquals(new Double(numberA), new Double(numberB)) : JDBCUtil.isGreater(new Double(numberA), new Double(numberB)));
  }
}

package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class SIMPLE_ELEMENT_OPERATION extends OPERATION {

  public SIMPLE_ELEMENT_OPERATION(SELECT_ELEMENT element) {
    this.element = element;
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
  }
  
  public SELECT_ELEMENT getElement() {
    return this.element;
  }
  
  @Override
  public String getName() {
    return element.getName();
  }
  
  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    return getOperation(name, metaData);
  }

  @Override
  public Operation getOperation(String name, MetaData metaData) {
    return element.getOperation(name, metaData);
  }

  /*
  @Override
  public void buildToJava(StringBuilder buffer, OPERATION_TYPE type) {
    switch (type) { 
      case NUMBER : buffer.append("row.getAsDouble(\"").append(element).append("\")"); break;
      default : buffer.append("row.getAsString(\"").append(element).append("\")");
    }
  }

  @Override
  public void buildToSQL(StringBuilder buffer, OPERATION_TYPE type) {
    switch (type) { 
      case NUMBER : buffer.append(element); break;
      default : buffer.append(element);
    }
  }
  */
  @Override
  public boolean applyOn(TABLE table) {
    return element.applyOn(table);
  }
  
  @Override
  public Boolean isNumber() { return null; }

  private final SELECT_ELEMENT element;
}

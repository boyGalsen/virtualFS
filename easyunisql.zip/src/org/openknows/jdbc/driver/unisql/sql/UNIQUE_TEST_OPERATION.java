package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.*;


public abstract class UNIQUE_TEST_OPERATION extends WHERE_TEST {

  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    this.columnA.subSelectCompile(requestDecoder, originalSelect);
  }
  
  public UNIQUE_TEST_OPERATION(final OPERATION columnA) {
    this.columnA = columnA;
  }
  public final OPERATION columnA;
}

package org.openknows.jdbc.driver.unisql.sql;

public class CREATE_TABLE_AS implements EXECUTABLE {

  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();
  
  public void setTable(final TABLE table) { this.table = table; }
  public TABLE getTable() { return this.table; }
  private TABLE table;
  
  public void setSelect(final SELECT select) { this.select = select; }
  public SELECT getSELECT() { return this.select; }
  private SELECT select;
  
}
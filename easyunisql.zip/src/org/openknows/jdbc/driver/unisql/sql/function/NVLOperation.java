package org.openknows.jdbc.driver.unisql.sql.function;

import org.openknows.jdbc.driver.unisql.ColumnType;
import org.openknows.jdbc.driver.unisql.DatabaseValue;
import org.openknows.jdbc.driver.unisql.Row;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.operation.Operation;

public class NVLOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(final DatabaseValue... values) {
    if (values[0] == null ||  values[0].isNull() || "".equals(values[0].getStringValue())) return values[1];
    return values[0];
  }
  
  public NVLOperation() {
    super("NVL", null, false);
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.STRING) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return JDBCDatabaseValue.getAndInit(execute(partAValue, partBValue))
          .initSubValues(partAValue, partBValue)
          .setSubValue(partAKey, partAValue)
          .setSubValue(partBKey, partBValue);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.STRING) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
        final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
        return JDBCDatabaseValue.getAndInitNumber(execute(partAValue, partBValue))
          .initSubValues(partAValue, partBValue);
      }    
    };
  }

}
package org.openknows.jdbc.driver.unisql.sql;

public abstract class WHERE_CONTAINER extends WHERE_TEST {

  public abstract void addPart(final WHERE_TEST part);
  
  public WHERE_CONTAINER getParent() {
    return this.parent;
  }
  
  public WHERE_CONTAINER(final WHERE_CONTAINER parent) {
    this.parent = parent;
  }
  
  private final WHERE_CONTAINER parent;
}

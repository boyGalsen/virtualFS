package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.executor.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;

import java.util.*;

public abstract class ABSTRACT_JOIN implements JOIN {

  public ABSTRACT_JOIN(final TABLE tableA, final TABLE tableB) {
    this.tableA = tableA;
    this.tableB = tableB;
    this.where = null;
  }

  public ABSTRACT_JOIN(final TABLE tableA, final TABLE tableB, final WHERE_PART where) {
    this.tableA = tableA;
    this.tableB = tableB;
    this.where = where;
  }

  public TABLE getFirstTable() { return tableA; }
  public TABLE getSecondTable() { return tableB; }
  public WHERE_PART getWherePart() { return where; }
  public String getName() { return null; }
  
  public void subSelectCompile(final JDBCRequestDecoder requestDecoder, final SELECT originalSelect) throws Throwable {
    EzPoolExecutor.DEFAULT.run(new EzRunnableTaskArray("abstractJoinSubCompile", 3) {

      @Override
      protected void run(int i) {
        try {
          if (i == 0) tableA.subSelectCompile(requestDecoder, originalSelect);
          if (i == 1) tableB.subSelectCompile(requestDecoder, originalSelect);
          if (i == 2 && where != null) where.subSelectCompile(requestDecoder, originalSelect);
        }
        catch (Throwable forward) {
          ExceptionUtils.newRuntimeException(forward);
        }
      }

      @Override
      public String description(int i) {
        return null;
      }

      @Override
      public void fillContext(int i, EzTaskContext context) {}
      
    });
    //final HashMap<String, Table> tablesByName = new HashMap<String, Table>();
    //final HashMap<Table, RowFilterRule> filterRules = new HashMap<Table, RowFilterRule>();
    final ArrayList<Table> tables = new ArrayList<Table>(); 
    final WHERE_TEST wherePart = originalSelect.wherePart == null ? null : originalSelect.wherePart.getTest();
    final TABLE[] allTables = new TABLE[] {tableA, tableB}; 
    for (int i = 0, n = allTables.length; i < n; i++) {
      final TABLE table = allTables[i];
      if (table instanceof SUB_SELECT_TABLE) {
        final SUB_SELECT_TABLE subTable = (SUB_SELECT_TABLE)table;
        final Table fileTable = SelectDecoderPart.computeTableFilter(subTable.getTable(), wherePart);//new ExcelFileTable().init(new File(excelTable.getFile()), excelTable.getName());
        tables.add(fileTable);
        //filterRules.put(fileTable, SelectDecoderPart.computeRowFilter(false, subTable, wherePart, fileTable.getMetaData()));
        //tablesByName.put(subTable.getName(), fileTable);
      }
      else if (table instanceof TEMP_TABLE) {
        final TEMP_TABLE tempTable = (TEMP_TABLE)table;
        final Table memoryTable = SelectDecoderPart.computeTableFilter(TempTable.createFrom(tempTable), wherePart);
        tables.add(memoryTable);
        //filterRules.put(memoryTable, SelectDecoderPart.computeRowFilter(false, tempTable, wherePart, memoryTable.getMetaData()));
        //tablesByName.put(tempTable.getName(), memoryTable);
      }
      else if (table instanceof JOIN) {
        final JOIN subTable = (JOIN)table;
        final Table fileTable = SelectDecoderPart.computeTableFilter(subTable.getTable(), wherePart);
        tables.add(fileTable);
        //filterRules.put(fileTable, SelectDecoderPart.computeRowFilter(false, subTable, wherePart, fileTable.getMetaData()));
        //tablesByName.put(subTable.getName(), fileTable);
      }
      else if (table instanceof AT_TABLE) {
        final AT_TABLE atTable = (AT_TABLE)table;
        final Table fileTable = SelectDecoderPart.computeTableFilter(requestDecoder.getDatabase().getDriver().getAtManager().get(requestDecoder.getDatabase(), atTable), wherePart);//new ExcelFileTable().init(new File(excelTable.getFile()), excelTable.getName());
        tables.add(fileTable);
        //filterRules.put(fileTable, SelectDecoderPart.computeRowFilter(false, atTable, wherePart, fileTable.getMetaData()));
        //tablesByName.put(atTable.getName(), fileTable);
      }
      else if (table instanceof BASE_TABLE) {
        final BASE_TABLE jdbcTable = (BASE_TABLE)table;
        final Table fileTable = SelectDecoderPart.computeTableFilter(new JDBCTable().init(jdbcTable.getDatabasePart(), StringUtil.NVL(jdbcTable.getName(), jdbcTable.getTableNamePart()), "select * from "+jdbcTable.getTableNamePart(), ObjectArrays.emptyObjectArray), wherePart);
        tables.add(fileTable);
        //filterRules.put(fileTable, SelectDecoderPart.computeRowFilter(false, jdbcTable, wherePart, fileTable.getMetaData()));
        //tablesByName.put(jdbcTable.getName(), fileTable);
      }
      else if (table instanceof SIMPLE_TABLE) {
        final SIMPLE_TABLE jdbcTable = (SIMPLE_TABLE)table;
        final Table fileTable = SelectDecoderPart.computeTableFilter(requestDecoder.getDatabase().findTable(jdbcTable.getCatalog(), jdbcTable.getTable()), wherePart);
        tables.add(fileTable);
        //filterRules.put(fileTable, SelectDecoderPart.computeRowFilter(false, jdbcTable, wherePart, fileTable.getMetaData()));
        //tablesByName.put(jdbcTable.getName(), fileTable);
      }
      else if (table instanceof JDBC_TABLE) {
        final JDBC_TABLE jdbcTable = (JDBC_TABLE)table;
        final Table fileTable = SelectDecoderPart.computeTableFilter(new JDBCTable().init("jdbc:jdbcpool:"+jdbcTable.getDatabase(), jdbcTable.getName(), jdbcTable.getRequest(), ObjectArrays.emptyObjectArray), wherePart);
        tables.add(fileTable);
        //filterRules.put(fileTable, SelectDecoderPart.computeRowFilter(false, jdbcTable, wherePart, fileTable.getMetaData()));
        //tablesByName.put(jdbcTable.getName(), fileTable);
      }
    }
    final String[] names = new String[tables.size()];
    final TableAccessor[] accessors = new TableAccessor[names.length];
    EzPoolExecutor.DEFAULT.run(new EzRunnableTaskArray("abstractJoinAccessor", names.length) {

      @Override
      protected void run(int i) {
        try {
          names[i] = tables.get(i).getName();
          //final RowFilterRule filterRule = filterRules.get(tables.get(i));
          accessors[i] = /*(filterRule != null) ? new NewRowFilter().applyOn(tables.get(i).getAccessor(), filterRule) :*/ tables.get(i).getAccessor();
        }
        catch (Throwable forward) {
          ExceptionUtils.newRuntimeException(forward);
        }
      }

      @Override
      public String description(int i) {
        return null;
      }

      @Override
      public void fillContext(int i, EzTaskContext context) {}
      
    });
    
    /*for (int i = 0, n = names.length; i < n; i++) {
      names[i] = tables.get(i).getName();
      //final RowFilterRule filterRule = filterRules.get(tables.get(i));
      accessors[i] = tables.get(i).getAccessor();
    }*/
    final Table filter = getFilteredTable(names, accessors);
    this.table = new Table() {

      public TableAccessor getAccessor() throws DatabaseException { return filter.getAccessor(); }
      public String getDescription() { return null; }
      public InsertTableAccessor getInsertAccessor() throws DatabaseException { return null; }
      public MetaData getMetaData() throws DatabaseException { return filter.getMetaData(); }
      public String getName() { return null; }
      public String getType() { return null; }
    };    
  }
  
  public Table getTable() {
    return this.table;
  }
  
  protected abstract Table getFilteredTable(String[] names, TableAccessor[] accessors) throws DatabaseException;
  
  private Table table;

  private TABLE tableA;
  private TABLE tableB;
  private WHERE_PART where;
}
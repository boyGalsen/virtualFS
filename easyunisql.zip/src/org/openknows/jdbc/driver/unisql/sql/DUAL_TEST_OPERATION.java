package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;
import org.openknows.jdbc.driver.unisql.operation.Operation;

public abstract class DUAL_TEST_OPERATION extends WHERE_TEST {

  public DUAL_TEST_OPERATION(final OPERATION columnA, final OPERATION columnB) {
    this.columnA = columnA;
    this.columnB = columnB;
  }

  @Override
  public abstract Operation getOperation(String name, MetaData metaData);

  @Override
  public abstract Operation getGroupOperation(String name, MetaData metaData);

  @Override
  public boolean isGroupOperation() {
    return this.columnA.isGroupOperation() || this.columnB.isGroupOperation();
  }

  @Override
  public boolean applyOn(final TABLE table) {
    return this.columnA.applyOn(table) && (this.columnB == null || this.columnB.applyOn(table));
  }

  @Override
  public boolean canApplyOn(final TABLE table) {
    return this.columnA.canApplyOn(table) && this.columnB.canApplyOn(table);
  }

  @Override
  public Boolean isNumber() {
    return Boolean.FALSE;
  }

  @Override
  public abstract String getName();

  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    if (this.columnA != null) this.columnA.subSelectCompile(requestDecoder, originalSelect);
    if (this.columnB != null) this.columnB.subSelectCompile(requestDecoder, originalSelect);
  }

  public final OPERATION columnA;
  public final OPERATION columnB;
}

package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class Std2FunctionOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue[] values) {
    return values[0];
  }
  
  private static DatabaseValue getSum(DatabaseValue previousValue, DatabaseValue newValue) {
    if (previousValue != null && previousValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (newValue != null && newValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (previousValue == null || previousValue == JDBCDatabaseValue.NULL) return newValue;
    if (newValue == null || newValue == JDBCDatabaseValue.NULL) return previousValue;
    return JDBCDatabaseValue.getAndInit(MathUtils.getDouble(previousValue.getdoubleValue()+newValue.getdoubleValue()));
  }
  
  private static DatabaseValue getSum2(DatabaseValue previousValue, DatabaseValue newValue) {
    if (previousValue != null && previousValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (newValue != null && newValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (newValue == null || newValue == JDBCDatabaseValue.NULL) return previousValue;
    if (previousValue == null || previousValue == JDBCDatabaseValue.NULL) return JDBCDatabaseValue.getAndInit(MathUtils.getDouble(newValue.getdoubleValue()*newValue.getdoubleValue()));
    return JDBCDatabaseValue.getAndInit(MathUtils.getDouble(previousValue.getdoubleValue()+newValue.getdoubleValue()*newValue.getdoubleValue()));
  }
  
  private static DatabaseValue getCount(DatabaseValue previousValue, DatabaseValue newValue) {
    if (previousValue != null && previousValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (newValue != null && newValue.isIgnored()) return JDBCDatabaseValue.IGNORED;
    if (previousValue == null || previousValue == JDBCDatabaseValue.NULL) return JDBCDatabaseValue.getAndInit(LongCache.get(1)).initSubValues(previousValue, newValue);
    return JDBCDatabaseValue.getAndInit(LongCache.get(previousValue.getintValue()+1)).initSubValues(previousValue, newValue);
  }
  
  public Std2FunctionOperation() {
    super("STD", Boolean.TRUE, true);
  }
  
  @Override
  protected Operation getGroupOperation(String name, final Operation... realOperation) {
    return new GroupByOperation(name, ColumnType.DOUBLE) {

      private final String sumkey = ids.getNewID();
      private final String sum2key = ids.getNewID();
      private final String countkey = ids.getNewID();
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue value = realOperation[0].process(row, previousValue);
        final DatabaseValue sum = getSum(previousValue == null ? null : previousValue.getSubValue(sumkey), value);
        final DatabaseValue sum2 = getSum2(previousValue == null ? null : previousValue.getSubValue(sum2key), value);
        final DatabaseValue count = getCount(previousValue == null ? null : previousValue.getSubValue(countkey), value);
        if ((sum != null && sum.isIgnored()) || (count != null && count.isIgnored())) return JDBCDatabaseValue.IGNORED;
        if ((sum == null || sum.isNull()) && (count == null || count.isNull())) return JDBCDatabaseValue.NULL; 
        final JDBCDatabaseValue result = JDBCDatabaseValue.getAndInit(
          MathUtils.getDouble((count == null || count.getdoubleValue() == 0 || sum == null || sum.getdoubleValue() == 0) 
            ? 0.0 
            : Math.sqrt((sum2.getdoubleValue()/count.getdoubleValue()) - ((sum.getdoubleValue()/count.getdoubleValue())*(sum.getdoubleValue()/count.getdoubleValue())))));
        result.setSubValue(sumkey, sum);
        result.setSubValue(sum2key, sum2);
        result.setSubValue(countkey, count);
        return result;
      }
    };
  }
}
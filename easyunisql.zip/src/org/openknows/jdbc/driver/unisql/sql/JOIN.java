package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.Table;


public interface JOIN extends TABLE {

  public Table getTable();
  
  public TABLE getFirstTable();   
  public TABLE getSecondTable();
  public WHERE_PART getWherePart();
  
}

package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.ColumnType;
import org.openknows.jdbc.driver.unisql.DatabaseValue;
import org.openknows.jdbc.driver.unisql.Row;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.operation.Operation;

public class TrimOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(final DatabaseValue value) {
    if (value == null ||  value.isNull() || "".equals(value.getStringValue())) return value;
    final String stringValue = value.getStringValue();
    final String trimedValue = stringValue.trim();
    return (trimedValue.equals(stringValue))
      ? value
      : JDBCDatabaseValue.getAndInit(trimedValue);
  }
  
  public TrimOperation() {
    super("String.Trim", null, false);
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.STRING) {

      private final String partAKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        return JDBCDatabaseValue.getAndInit(execute(partAValue))
          .initSubValues(partAValue)
          .setSubValue(partAKey, partAValue);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.STRING) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
        return JDBCDatabaseValue.getAndInitNumber(execute(partAValue))
          .initSubValues(partAValue);
      }    
    };
  }
}
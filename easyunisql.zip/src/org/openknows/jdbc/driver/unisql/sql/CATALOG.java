package org.openknows.jdbc.driver.unisql.sql;

public class CATALOG implements EXECUTABLE {
  
  public static final int MANAGER = 0;
  public static final int FUNCTION = 1;
  public static final int MEMO = 2;
  public static final int TABLE = 3;
  
  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();
  
}

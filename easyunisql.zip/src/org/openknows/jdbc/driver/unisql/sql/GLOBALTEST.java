package org.openknows.jdbc.driver.unisql.sql;

import java.util.ArrayList;
import java.util.List;

import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;
import org.openknows.jdbc.driver.unisql.operation.Operation;


public class GLOBALTEST extends WHERE_TEST {
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    if (this.currentTest != null) currentTest.subSelectCompile(requestDecoder, originalSelect); 
  }
  
  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    if (this.currentTest != null) return this.currentTest.getGroupOperation(name, metaData);
    return null;
  }

  public List<UNIQUE_EQUALS_OPERATION> getJoin() {
    if (currentTest == null) return null;
    if (currentTest instanceof UNIQUE_EQUALS_OPERATION) {
      final ArrayList<UNIQUE_EQUALS_OPERATION> result = new ArrayList<UNIQUE_EQUALS_OPERATION>();
      result.add((UNIQUE_EQUALS_OPERATION)currentTest);
      return result;
    }
    if (currentTest instanceof AND_TEST) {
      ArrayList<UNIQUE_EQUALS_OPERATION> result = null;
      for (final WHERE_TEST test : ((AND_TEST)currentTest)) {
        if (test instanceof UNIQUE_EQUALS_OPERATION) {
          if (result == null) result = new ArrayList<UNIQUE_EQUALS_OPERATION>();
          result.add((UNIQUE_EQUALS_OPERATION)test);
        }
      }
      return result;
    }
    return null;
  }

  public void add(WHERE_TEST test) {
    if (currentTest == null) {
      currentTest = test;
    }
    else if (currentTest instanceof AND_TEST) {
      ((AND_TEST)currentTest).addPart(test);
    }
    else if (currentTest instanceof OR_TEST) {
      ((OR_TEST)currentTest).addPart(test);
    }
  }
  
  public void startGroup() {
  }
  
  public void closeGroup()  {
    
  }
  
  public void setNOT() {
    
  }
  
  public void setAND() {
    final WHERE_TEST oldCurrent = currentTest;
    currentTest = new AND_TEST();
    ((AND_TEST)currentTest).addPart(oldCurrent);
  }
  
  public void setOR() {
    final WHERE_TEST oldCurrent = currentTest;
    currentTest = new OR_TEST();
    ((OR_TEST)currentTest).addPart(oldCurrent);
  }
  
  /*
  @Override
  public void buildToJava(StringBuilder buffer) {
    currentTest.buildToJava(buffer);
  }
  
  @Override
  public boolean buildToJavaOR(final StringBuilder buffer, final TABLE table) {
    return currentTest.buildToJavaOR(buffer, table);
  }
  
  @Override
  public boolean buildToJavaAND(final StringBuilder buffer, final TABLE table) {
    return currentTest.buildToJavaAND(buffer, table);
  }

  @Override
  public void buildToSQL(StringBuilder buffer) {
    currentTest.buildToSQL(buffer);
  }
  
  @Override
  public boolean buildToSQLOR(final StringBuilder buffer, final TABLE table) {
    return currentTest.buildToSQLOR(buffer, table);
  }
  
  @Override
  public boolean buildToSQLAND(final StringBuilder buffer, final TABLE table) {
    return currentTest.buildToSQLAND(buffer, table);
  }
*/
  private WHERE_TEST currentTest = null;

  @Override
  public String getName() {
    if (this.currentTest != null) return currentTest.getName();
    return null;
  }

  @Override
  public Operation getOperation(String name, MetaData metaData) {
    if (this.currentTest != null) return currentTest.getOperation(name, metaData);
    return null;
  }

  @Override
  public Boolean isNumber() {
    if (this.currentTest != null) return currentTest.isNumber();
    return null;
  }
}
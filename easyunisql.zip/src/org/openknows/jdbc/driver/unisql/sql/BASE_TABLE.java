package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.*;

public class BASE_TABLE implements TABLE {

  public BASE_TABLE(final String table, final String name) {
    this.name = JDBCUtil.upper(name);
    this.table = JDBCUtil.upper(table);
  }
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) {
  }

  public String getTableNamePart() {
    return this.table.substring(0, this.table.indexOf("@"));
  }

  public String getDatabasePart() {
    return this.table.substring(this.table.indexOf("@")+1);
  }

  public String getName() {
    return this.name;
  }
  
  public String getTable() {
    return this.table;
  }
  
  private final String table;
  private final String name;
}

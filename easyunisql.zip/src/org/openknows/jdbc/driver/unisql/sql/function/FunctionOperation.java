package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.operation.Operation;
import org.openknows.jdbc.driver.unisql.sql.OPERATION;

public interface FunctionOperation {

  public void init(Parameters properties); 
  public String getName();
  public Boolean isNumber(); 
  
  public boolean isGroupOperation(OPERATION[] operations);
  public Operation getOperation(String name, MetaData metaData, OPERATION[] operations);
  public Operation getGroupOperation(String name, MetaData metaData, OPERATION[] operations);
}
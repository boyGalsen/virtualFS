package org.openknows.jdbc.driver.unisql.sql;

public class INSERT implements EXECUTABLE {
  
  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();

  public void setINTO(final String value) {
  }

  public void setCOLUMN(final COLUMN_LIST list) {
  }
  
  public void setVALUES(final VALUE_ITERATOR valueIterator) {
  }
}

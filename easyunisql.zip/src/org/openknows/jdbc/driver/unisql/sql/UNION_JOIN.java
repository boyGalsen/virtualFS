package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.SelectDecoderPart;


public class UNION_JOIN extends ABSTRACT_JOIN {

  public UNION_JOIN(TABLE tableA, TABLE tableB) {
    super(tableA, tableB);
  }

  public UNION_JOIN(TABLE tableA, TABLE tableB, WHERE_PART where) {
    super(tableA, tableB, where);
  }
  
  @Override
  protected Table getFilteredTable(String[] names, TableAccessor[] accessors) throws DatabaseException {
    try {
      final UnionJoinFilter filter = new UnionJoinFilter().init("", names, accessors);
      if (getWherePart() != null) {
        filter.setRowFilter(SelectDecoderPart.computeRowFilter(getWherePart().getTest(), filter.getMetaData()));
      }
      return filter;
    }
    catch (DatabaseException e) {
      throw e;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }
}
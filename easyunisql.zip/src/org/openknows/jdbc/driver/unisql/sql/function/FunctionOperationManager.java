package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;
import com.easyrms.util.preferences.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;

public class FunctionOperationManager {
  
  //public static FunctionOperationManager reference = new FunctionOperationManager();
  
  private static final String getType(FunctionOperation function) {
    return JDBCUtil.upper(function.getName());
  }

  public boolean register(String className, Parameters parameters) throws DatabaseException {
    try {
      if (!functionByClass.containsKey(className)) {
        register((FunctionOperation)Class.forName(className).newInstance(), parameters);
        return true;
      }
      return false;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public boolean unregister(String className, Parameters parameters) throws DatabaseException {
    try {
      if (functionByClass.containsKey(className)) {
        unregister(functionByClass.get(className), parameters);
        return true;
      }
      return false;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public void register(final FunctionOperation function, final Parameters properties) {
    final String type = getType(function);
    if (!functions.containsKey(type)) {
      function.init(properties);
      functionByClass.put(function.getClass().getName(), function);
      final FunctionOperation previous = functions.put(type, function);
      if (previous != null && function.getClass() != previous.getClass()) throw new IllegalArgumentException("Allready Existing "+JDBCUtil.upper(function.getName()));
    }
  }
  
  public void unregister(final FunctionOperation function, final Parameters properties) {
    final String type = getType(function);
    if (functions.containsKey(type)) {
      functionByClass.remove(function.getClass().getName());
      functions.remove(type);
    }
  }
  
  public FunctionOperation get(final String functionName) throws DatabaseException {
    final FunctionOperation function = functions.get(JDBCUtil.upper(functionName));
    if (function == null) throw new DatabaseException("Unknow SQL Function "+functionName);
    return function; 
  }
  
  private final HashMap<String, FunctionOperation> functionByClass = new HashMap<String, FunctionOperation>(); 
  private final HashMap<String, FunctionOperation> functions = new HashMap<String, FunctionOperation>(); 
}

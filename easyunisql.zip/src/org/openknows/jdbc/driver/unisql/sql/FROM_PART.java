package org.openknows.jdbc.driver.unisql.sql;


import java.util.ArrayList;
import java.util.List;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;

public class FROM_PART {
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect)  throws Throwable {
    for (int i = 0, n = list.size(); i < n; i++) {
      final TABLE table = list.get(i);
      table.subSelectCompile(requestDecoder, originalSelect);
    }
  }
  
  public void setOneTable(final TABLE table) {
    list.clear();
    list.add(table);
  }

  public TABLE getOneTable() {
    return list.get(0);
  }

  public void add(final TABLE table) {
    list.add(table);
  }
  
  public int getCount() {
    return list.size();
  }
  
  public TABLE getTable(final int index) {
    return list.get(index);
  }
  
  public List<TABLE> getTable() {
    return list;
  }
  
  private final ArrayList<TABLE> list = new ArrayList<TABLE>();
}

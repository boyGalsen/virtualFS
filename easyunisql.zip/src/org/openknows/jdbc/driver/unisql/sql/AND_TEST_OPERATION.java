package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class AND_TEST_OPERATION extends DUAL_TEST_OPERATION {
  
  public AND_TEST_OPERATION(final OPERATION columnA, final OPERATION columnB) {
    super(columnA, columnB);
  }
  
  @Override
  public Operation getOperation(final String name, final TABLE table, MetaData metaData) {
    if (isGroupOperation() || !canApplyOn(table)) {
      return new Operation(name, ColumnType.BOOLEAN) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return JDBCDatabaseValue.getAndInit(Boolean.TRUE);
        }
      };
    }
    final Operation operationA = columnA.getOperation(name, metaData);
    final Operation operationB = columnB.getOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue vA = !columnA.canApplyOn(table) ? JDBCDatabaseValue.getAndInit(Boolean.TRUE) : operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue vB = !columnB.canApplyOn(table) ? JDBCDatabaseValue.getAndInit(Boolean.TRUE) : operationB.process(row, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return (vA.getbooleanValue() && vB.getbooleanValue()
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(vA, vB)
            .setSubValue(partAKey, vA)
            .setSubValue(partBKey, vB);
      }
    };
  }
  
  @Override
  public boolean canApplyOn(final TABLE table) {
    return this.columnA.canApplyOn(table) || this.columnB.canApplyOn(table);
  }
  
  @Override
  public Operation getOperation(final String name, MetaData metaData) {
    if (isGroupOperation()) {
      return new Operation(name, ColumnType.BOOLEAN) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
      };
    }
    final Operation operationA = columnA.getOperation(name, metaData);
    final Operation operationB = columnB.getOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue vA = operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue vB = operationB.process(row, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return (vA.getbooleanValue() && vB.getbooleanValue()
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(vA, vB)
            .setSubValue(partAKey, vA)
            .setSubValue(partBKey, vB);
      }
    };
  }

  @Override
  public String getName() {
    return this.columnA.getName()+" AND "+this.columnB.getName();
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    final Operation operationA = columnA.getGroupOperation(name, metaData);
    final Operation operationB = columnB.getGroupOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {
      
      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();

      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue vA = operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue vB = operationB.process(row, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return (vA.getbooleanValue() && vB.getbooleanValue()
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(vA, vB)
            .setSubValue(partAKey, vA)
            .setSubValue(partBKey, vB);
      }
    };
  }
}
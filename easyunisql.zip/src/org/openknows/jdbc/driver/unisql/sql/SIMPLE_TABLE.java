package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;

public class SIMPLE_TABLE implements TABLE {

  public SIMPLE_TABLE(final String table, final String name) {
    this(table, MemoryDatabase.PUBLIC, name);
  }

  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) {
  }

  public SIMPLE_TABLE(final String table, final String catalog, final String name) {
    this.name = JDBCUtil.upper(name);
    this.table = JDBCUtil.upper(table);
    this.catalog = JDBCUtil.upper(catalog);
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getCatalog() {
    return this.catalog;
  }
  
  public String getTable() {
    return this.table;
  }
  
  private final String catalog;
  private final String table;
  private final String name;
}

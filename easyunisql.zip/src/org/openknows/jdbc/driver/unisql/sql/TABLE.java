package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;

public interface TABLE {
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect)  throws Throwable;

  public String getName();
}

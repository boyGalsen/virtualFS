package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.ColumnType;
import org.openknows.jdbc.driver.unisql.DatabaseValue;
import org.openknows.jdbc.driver.unisql.Row;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.operation.Operation;


public class LowestOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue... values) {
    if (values[0] == null) return values[1];
    if (values[1] == null) return values[0];
    return (values[0].getdoubleValue() <= values[1].getdoubleValue()) ? values[0] : values[1];
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return JDBCDatabaseValue.getAndInit(execute(partAValue, partBValue))
          .initSubValues(partAValue, partBValue)
          .setSubValue(partAKey, partAValue)
          .setSubValue(partBKey, partBValue);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
        final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
        return JDBCDatabaseValue.getAndInitNumber(execute(partAValue, partBValue))
          .initSubValues(partAValue, partBValue);
      }    
    };
  }
  
  public LowestOperation() {
    super("lowest", Boolean.TRUE, false);
  }
}
package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class MOINS_OPERATION extends OPERATION {
  
  public MOINS_OPERATION(final OPERATION partB) {
    this(null, partB);
  }

  public MOINS_OPERATION(final OPERATION partA, final OPERATION partB) {
    this.partA = partA;
    this.partB = partB;
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    this.partA.subSelectCompile(requestDecoder, originalSelect);
    this.partB.subSelectCompile(requestDecoder, originalSelect);
  }

  @Override
  public String getName() {
    if (this.partA == null) return "-"+partB.getName();
    return partA.getName()+"-"+partB.getName();
  }

  @Override
  public boolean isGroupOperation() { 
    return partA.isGroupOperation() || partB.isGroupOperation(); 
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    final Operation partAOperation = partA.getGroupOperation(name, metaData);
    final Operation partBOperation = partB.getGroupOperation(name, metaData);
    return new Operation(name, ColumnType.DOUBLE) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = partAOperation.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = partBOperation.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        if (partAValue == null) {
          if (partBValue == null) return null;
          return partBValue;
        }
        if (partBValue == null) return partAValue;
        return ((partAValue.isIntAvailable() && partBValue.isIntAvailable()) 
          ? JDBCDatabaseValue.getAndInit(JDBCUtil.sub(partAValue.getIntegerValue(), partBValue.getIntegerValue()))
          : JDBCDatabaseValue.getAndInit(JDBCUtil.sub(partAValue.getDoubleValue(), partBValue.getDoubleValue())))
          .initSubValues(partAValue, partBValue)
          .setSubValue(partAKey, partAValue)
          .setSubValue(partBKey, partBValue);
      }    
    };
  }

  @Override
  public Operation getOperation(final String name, MetaData metaData) {
    if (isGroupOperation()) {
      return new Operation(name, ColumnType.DOUBLE) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
      };
    }
    final Operation partAOperation = partA.getOperation(name, metaData);
    final Operation partBOperation = partB.getOperation(name, metaData);
    return new Operation(name, ColumnType.DOUBLE) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = partAOperation.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = partBOperation.process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        if (partAValue == null) {
          if (partBValue == null) return null;
          return partBValue;
        }
        if (partBValue == null) return partAValue;
        return ((partAValue.isIntAvailable() && partBValue.isIntAvailable()) 
          ? JDBCDatabaseValue.getAndInit(JDBCUtil.sub(partAValue.getIntegerValue(), partBValue.getIntegerValue()))
          : JDBCDatabaseValue.getAndInit(JDBCUtil.sub(partAValue.getDoubleValue(), partBValue.getDoubleValue())))
          .initSubValues(partAValue, partBValue)
          .setSubValue(partAKey, partAValue)
          .setSubValue(partBKey, partBValue);
      }    
    };
  }

  /*
  @Override
  public void buildToJava(final StringBuilder buffer, final OPERATION_TYPE type) {
    if (partA == null) {
      buffer.append("(-(");
      partB.buildToJava(buffer, type);
      buffer.append("))");
    }
    else {
      buffer.append("JDBCUtil.sub((");
      partA.buildToJava(buffer, type);
      buffer.append("),(");
      partB.buildToJava(buffer, type);
      buffer.append("))");
    }
  }

  @Override
  public void buildToSQL(final StringBuilder buffer, final OPERATION_TYPE type) {
    if (partA == null) {
      buffer.append("-(");
      partB.buildToJava(buffer, type);
      buffer.append(")");
    }
    else {
      buffer.append("(");
      partA.buildToJava(buffer, type);
      buffer.append(")-(");
      partB.buildToJava(buffer, type);
      buffer.append(")");
    }
  }  
*/
  @Override
  public boolean applyOn(final TABLE table) {
    if (partA == null) return partB.applyOn(table);
    return partA.applyOn(table) && partB.applyOn(table);
  }

  @Override
  public Boolean isNumber() { return Boolean.TRUE; }

  private final OPERATION partA;
  private final OPERATION partB; 
}
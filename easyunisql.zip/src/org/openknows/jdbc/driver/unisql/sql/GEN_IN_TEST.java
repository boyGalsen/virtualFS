package org.openknows.jdbc.driver.unisql.sql;


public abstract class GEN_IN_TEST extends GROUP_TEST {
  
  public GEN_IN_TEST(final SELECT_ELEMENT column) {
    this.column = column;
  }
  
  public SELECT_ELEMENT getColumn() {
    return this.column;
  }

  private final SELECT_ELEMENT column;
}
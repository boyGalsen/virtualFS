package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.memory.*;

public class SUB_SELECT_TABLE implements TABLE {

  public SUB_SELECT_TABLE(final SELECT_LIST select, final String name) {
    this.select = select;
    this.name = JDBCUtil.upper(name);
  }

  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    final SelectListDecoderPart part = new SelectListDecoderPart(requestDecoder);
    final TableAccessor accessor = part.compileAccessor(requestDecoder.getDatabase(), select);
    final MetaData metaData = accessor.getMetaData();
    if (name != null) {
      table = new MemoryTable(name, metaData, null);
      //final InsertTableAccessor insert = table.getInsertAccessor();
      try {
        DatabaseUtil.copyAndClone(accessor, table);
        
        //final int n = metaData.getColumnCount();
        //while (accessor.hasNext()) {
        //  final Row row = accessor.getNext();
        //  final DatabaseValue[] values = new DatabaseValue[n];
        //  for (int i = 1; i <= n; i++) {
        //    values[i - 1] = row.getDatabaseValue(i);
        //  }
        //  insert.insert(values);
        //}
      }
      finally {
        //insert.close();
        accessor.close();
      }
    }
    else {
      this.table = new Table() {

        public TableAccessor getAccessor() throws DatabaseException {
          return accessor;
        }

        public String getDescription() {
          return null;
        }

        public InsertTableAccessor getInsertAccessor() throws DatabaseException {
          return null;
        }

        public MetaData getMetaData() throws DatabaseException {
          return metaData;
        }

        public String getName() {
          return null;
        }

        public String getType() {
          return null;
        }
      };
    }
  }

  public String getName() {
    return this.name;
  }

  public Table getTable() {
    return this.table;
  }

  private Table table;
  private final SELECT_LIST select;
  private final String name;
}
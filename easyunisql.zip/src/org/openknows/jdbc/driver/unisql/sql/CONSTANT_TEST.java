package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class CONSTANT_TEST extends WHERE_TEST {
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder) throws Throwable {
  }

  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
  }

  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    return new Operation(name, ColumnType.BOOLEAN) {

      @Override
      public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
        return isTrue ? JDBCDatabaseValue.getAndInit(Boolean.TRUE) : JDBCDatabaseValue.getAndInit(Boolean.FALSE);
      }
    };
  }

  public CONSTANT_TEST(final boolean isTrue) {
    this.isTrue = isTrue;
  }
  /*
  @Override
  public void buildToJava(final StringBuilder buffer) {
    buffer.append(isTrue ? "true" : "false");
  }
  
  @Override
  public void buildToSQL(final StringBuilder buffer) {
    buffer.append(isTrue ? "true" : "false");
  }

  @Override
  public final boolean buildToJavaOR(final StringBuilder buffer, final TABLE table) {
    buffer.append(isTrue ? "true" : "false");
    return true;
  }
  
  @Override
  public final boolean buildToJavaAND(final StringBuilder buffer, final TABLE table) {
    buffer.append(isTrue ? "true" : "false");
    return true;
  }
  
  @Override
  public final boolean buildToSQLOR(final StringBuilder buffer, final TABLE table) {
    buffer.append(isTrue ? "1=1" : "1=0");
    return true;
  }
  
  @Override
  public final boolean buildToSQLAND(final StringBuilder buffer, final TABLE table) {
    buffer.append(isTrue ? "1=1" : "1=0");
    return true;
  }
  */
  private final boolean isTrue;


  @Override
  public Operation getOperation(String name, MetaData metaData) {
    return new Operation(name, ColumnType.BOOLEAN) {

      @Override
      public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
        return isTrue ? JDBCDatabaseValue.getAndInit(Boolean.TRUE) : JDBCDatabaseValue.getAndInit(Boolean.FALSE);
      }
    };
  }

  @Override
  public Boolean isNumber() {
    return Boolean.FALSE;
  }

  @Override
  public String getName() {
    return isTrue ? "TRUE" : "FALSE";
  }
}
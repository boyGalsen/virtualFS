package org.openknows.jdbc.driver.unisql.sql;


public class VVIEW implements EXECUTABLE  {

  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();

  public String name;
  public String map;
}

package org.openknows.jdbc.driver.unisql.sql;

import java.util.regex.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.operation.*;

public class NUMBER_OPERATION extends OPERATION {

  public NUMBER_OPERATION(String value) {
    this.value = value; 
  }
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
  }
  
  @Override
  public String getName() {
    return value;
  }
  
  public String getValue() {
    return this.value;
  }
  
  @Override
  public boolean applyOn(final TABLE table) {
    return true;
  }
  
  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    if (intPattern.matcher(value).matches()) return new ConstantOperation(name, Integer.valueOf(this.value));      
    return new ConstantOperation(name, Double.valueOf(this.value));      
  }

  @Override
  public Operation getOperation(String name, MetaData metaData) {
    if (intPattern.matcher(value).matches()) return new ConstantOperation(name, Integer.valueOf(this.value));      
    return new ConstantOperation(name, Double.valueOf(this.value));      
  }
  
  private static final Pattern intPattern = Pattern.compile("[0-9]+");
  private final String value;

  /*
  @Override
  public void buildToJava(StringBuilder buffer, OPERATION_TYPE type) {
    if (value.matches("[0-9]+")) {
      switch (type) {
        case NUMBER : buffer.append("new Integer(").append(value).append(")"); break;
        default : buffer.append("\"").append(value).append("\"");
      }
    }
    else {
      switch (type) {
        case NUMBER : buffer.append("new Double(").append(value).append(")"); break;
        default : buffer.append("\"").append(value).append("\"");
      }
    }
  }

  @Override
  public void buildToSQL(StringBuilder buffer, OPERATION_TYPE type) {
    switch (type) {
      case NUMBER : buffer.append(value); break;
      default : buffer.append("'").append(value).append("'");
    }
  }
  */
  @Override
  public Boolean isNumber() { 
    return Boolean.TRUE; 
  }
}

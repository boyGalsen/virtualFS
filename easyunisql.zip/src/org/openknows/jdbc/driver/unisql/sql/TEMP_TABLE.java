package org.openknows.jdbc.driver.unisql.sql;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;
import org.openknows.jdbc.driver.unisql.jdbc.JDBCUtil;

import java.util.*;

public class TEMP_TABLE implements TABLE {

  public TEMP_TABLE(final String name, final String displayName) {
    this.name = (displayName == null) ? JDBCUtil.upper(name.substring(name.indexOf(":")+1, name.lastIndexOf("("))) : JDBCUtil.upper(displayName);
  }
  
  public void setName(final String displayName) {
    this.name = displayName;
  }
  
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) {
  }
  
  public String getName() {
    return this.name;
  }
  
  public ArrayList<String> getColumns() {
    return columns;
  }
  
  public ArrayList<ArrayList<OPERATION>> getValues() {
    return values;
  }
  
  public void addColumn(String columnName) {
    columns.add(columnName.substring(1, columnName.length()-1));
  }
  
  public void addNewRow() {
    currentValues = new ArrayList<OPERATION>(columns.size());
    values.add(currentValues);
  }
  
  public void addValue(OPERATION value) {
    currentValues.add(value);
  }
  
  
  private final ArrayList<String> columns = new ArrayList<String>();
  private final ArrayList<ArrayList<OPERATION>> values = new ArrayList<ArrayList<OPERATION>>();
  private ArrayList<OPERATION> currentValues = null; 
  
  private String name;
}

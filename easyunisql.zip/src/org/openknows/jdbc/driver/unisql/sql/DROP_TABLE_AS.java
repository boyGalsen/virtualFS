package org.openknows.jdbc.driver.unisql.sql;

public class DROP_TABLE_AS implements EXECUTABLE {

  public void setVariables(final VARIABLES variables) { this.variables = variables; }
  public VARIABLES getVariables() { return this.variables; }
  private VARIABLES variables = new VARIABLES();
  
  public void setTable(final TABLE table) { this.table = table; }
  
  public TABLE getTable() {return this.table;}
  
  private TABLE table;
}
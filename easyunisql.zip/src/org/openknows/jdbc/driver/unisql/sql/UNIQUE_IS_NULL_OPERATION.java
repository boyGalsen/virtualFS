package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.operation.*;


public class UNIQUE_IS_NULL_OPERATION extends UNIQUE_TEST_OPERATION {
  
  public static WHERE_TEST get(final OPERATION columnA) {
    return new UNIQUE_IS_NULL_OPERATION(columnA);
  }
  
  @Override
  public Operation getGroupOperation(String name, MetaData metaData) {
    final Operation operationA = columnA.getGroupOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue v = operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        return (v.isNull()
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(v)
            .setSubValue(partAKey, v);
      }
    };
  }

  public UNIQUE_IS_NULL_OPERATION(final OPERATION columnA) {
    super(columnA);
  }

  @Override
  public String getName() {
    return columnA.getName()+" IS NULL";
  }

  @Override
  public Operation getOperation(final String name, MetaData metaData) {
    if (isGroupOperation()) {
      return new Operation(name, ColumnType.BOOLEAN) {
  
        @Override
        public DatabaseValue process(Row originalRow, DatabaseValue previousValue) {
          return originalRow.getDatabaseValue(name);
        }
      };
    }
    final Operation operationA = columnA.getOperation(name, metaData);
    return new Operation(name, ColumnType.BOOLEAN) {

      private final String partAKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(Row row, DatabaseValue previousValue) {
        final DatabaseValue v = operationA.process(row, previousValue == null ? null : previousValue.getSubValue(partAKey));
        return (v.isNull()
          ? JDBCDatabaseValue.getAndInit(Boolean.TRUE)
          : JDBCDatabaseValue.getAndInit(Boolean.FALSE))
            .initSubValues(v)
            .setSubValue(partAKey, v);
      }
    };
  }

  @Override
  public Boolean isNumber() {
    return Boolean.FALSE;
  }
}
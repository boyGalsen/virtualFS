package org.openknows.jdbc.driver.unisql.sql;


import java.util.ArrayList;
import java.util.Iterator;

import org.openknows.jdbc.driver.unisql.jdbc.JDBCRequestDecoder;

public abstract class GROUP_TEST extends WHERE_TEST implements Iterable<WHERE_TEST> {
  
  @Override
  public void subSelectCompile(JDBCRequestDecoder requestDecoder, SELECT originalSelect) throws Throwable {
    for (int i = 0, n = parts.size(); i < n; i++) {
      final WHERE_TEST part = parts.get(i);
      if (part != null) {
        part.subSelectCompile(requestDecoder, originalSelect);
      }
    }
  }
  
  public void addPart(final WHERE_TEST part) {
    this.parts.add(part);
  }
  
  public WHERE_TEST getPart(final int i) {
    return this.parts.get(i);
  }
  
  public int getPartCount() {
    return this.parts.size();
  }
  
  public Iterator<WHERE_TEST> iterator() {
    return this.parts.iterator();
  }
  
  protected final ArrayList<WHERE_TEST> parts = new ArrayList<WHERE_TEST>();
}
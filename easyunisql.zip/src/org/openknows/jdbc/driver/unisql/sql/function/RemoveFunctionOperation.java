package org.openknows.jdbc.driver.unisql.sql.function;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.ColumnType;
import org.openknows.jdbc.driver.unisql.DatabaseValue;
import org.openknows.jdbc.driver.unisql.Row;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;
import org.openknows.jdbc.driver.unisql.operation.Operation;

public class RemoveFunctionOperation extends AbstractFunctionOperation {
  
  public static DatabaseValue execute(DatabaseValue... values) {
    DatabaseValue result = JDBCDatabaseValue.NULL;
    for (int i = 0, n = values.length; i < n; i++) {
      final DatabaseValue value = values[i];
      if (result == null) {
        result = value;
      }
      else {
        result = (result.isIntAvailable() && value.isIntAvailable()) 
          ? JDBCDatabaseValue.getAndInit(LongCache.get(result.getintValue()-value.getintValue()))
          : JDBCDatabaseValue.getAndInit(MathUtils.getDouble(result.getdoubleValue()-value.getdoubleValue()));
      }
    }
    return result;
  }
  
  @Override
  protected Operation getGroupOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {

      private final String partAKey = ids.getNewID();
      private final String partBKey = ids.getNewID();
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partAKey));
        final DatabaseValue partBValue = realOperation[1].process(originalRow, previousValue == null ? null : previousValue.getSubValue(partBKey));
        return JDBCDatabaseValue.getAndInit(execute(partAValue, partBValue))
          .initSubValues(partAValue, partBValue)
          .setSubValue(partAKey, partAValue)
          .setSubValue(partBKey, partBValue);
      }    
    };
  }

  @Override
  protected Operation getOperation(final String name, final Operation... realOperation) {
    return new Operation(name, ColumnType.DOUBLE) {
      
      @Override
      public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
        final DatabaseValue partAValue = realOperation[0].process(originalRow, null);
        final DatabaseValue partBValue = realOperation[1].process(originalRow, null);
        return JDBCDatabaseValue.getAndInitNumber(execute(partAValue, partBValue))
          .initSubValues(partAValue, partBValue);
      }    
    };
  }
  
  public RemoveFunctionOperation() {
    super("remove", Boolean.TRUE, false);
  }
}
package org.openknows.jdbc.driver.unisql.sql;

import java.util.*;


public class GROUP_BY_PART {

  public void add(final SELECT_ELEMENT selectElement) {
    list.add(selectElement);
  }
  
  public List<SELECT_ELEMENT> getElements() {
    return list;
  }
  
  public int size() {
    return list.size();
  }
  
  private final ArrayList<SELECT_ELEMENT> list = new ArrayList<SELECT_ELEMENT>();
}

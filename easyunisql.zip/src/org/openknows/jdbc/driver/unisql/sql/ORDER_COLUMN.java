package org.openknows.jdbc.driver.unisql.sql;

import com.easyrms.util.comparator.*;


public class ORDER_COLUMN implements ORDERBY_COLUMN {

  public ORDER_COLUMN(String table, String column, boolean desc) {
    this.table = table;
    this.column = column;
    this.desc = desc;
  }
  
  public String getTable() {
    return this.table;
  }
  
  public String getColumn() {
    return this.column;
  }
  
  public boolean isDesc() {
    return this.desc;
  }
  
  public String getFullName() {
    if (StringComparator.isNotNull(table)) return table+"."+column;
    return column;
  }
  
  private final boolean desc;
  private final String table;
  private final String column;
}

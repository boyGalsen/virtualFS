package org.openknows.jdbc.driver.unisql.sql;

import java.util.ArrayList;

public class VARIABLES {
  
  public VARIABLE_OPERATION addOperation() {
    final VARIABLE_OPERATION newVariable = new VARIABLE_OPERATION(variables.size());
    variables.add(newVariable);
    return newVariable;
  }
  
  public int getVariableCount() {
    return variables.size();
  }
  public VARIABLE_OPERATION getVariable(int index) {
    return variables.get(index);
  }
  public VARIABLE_OPERATION[] getVariable() {
    return variables.toArray(new VARIABLE_OPERATION[variables.size()]);
  }
  
  private final ArrayList<VARIABLE_OPERATION> variables = new ArrayList<VARIABLE_OPERATION>(); 
}

package org.openknows.jdbc.driver.unisql.sql;

import java.util.*;


public class SELECTION_PART {
  
  public void setAllSelect() {
    this.allSelect = true;
  }
  
  public void add(final SELECT_ELEMENT selectElement) {
    list.add(selectElement);
    if (selectElement.isGroupOperation()) {
      withGroupOperationList = true;
      groupOperationList.add(selectElement);
    }
  }
  
  public boolean isWithGroupElements() {
    return withGroupOperationList;
  }
  
  public List<SELECT_ELEMENT> getGroupElements() {
    return groupOperationList;
  }
  
  public List<SELECT_ELEMENT> getElements() {
    return list;
  }
  
  public boolean isAllSelect() {
    return allSelect; 
  }
  
  public int size() {
    return list.size();
  }
  
  private boolean allSelect = false;
  private final ArrayList<SELECT_ELEMENT> list = new ArrayList<SELECT_ELEMENT>();
  private boolean withGroupOperationList = false; 
  private final ArrayList<SELECT_ELEMENT> groupOperationList = new ArrayList<SELECT_ELEMENT>();
}
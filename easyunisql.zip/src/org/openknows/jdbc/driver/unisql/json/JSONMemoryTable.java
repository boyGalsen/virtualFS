package org.openknows.jdbc.driver.unisql.json;

import com.easyrms.util.*;
import com.easyrms.util.io.JSONWriter;

import org.openknows.jdbc.driver.unisql.*;

import java.io.*;
import javax.json.*;
import javax.json.stream.*;


public class JSONMemoryTable {

  public JSONMemoryTable(String value) {
    try (JsonParser parser = Json.createParser(new StringReader(value))) {
      JsonParser.Event event = null;
      while (parser.hasNext()) {
        event = parser.next();
        System.out.print("event=" + event);
        switch (event) {
          case KEY_NAME:
            System.out.print(" cle=" + parser.getString());
            break;
          case VALUE_STRING:
            System.out.print(" valeur=" + parser.getString());
            break;
          case VALUE_NUMBER:
            if (parser.isIntegralNumber()) {
              System.out.println(" valeur=" + parser.getInt());
            } else {
              System.out.println(" valeur=" + parser.getBigDecimal());
            }
            break;
          case VALUE_NULL:
            System.out.print(" valeur=null");
            break;
        }
        System.out.println("");
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

  }
  
  public static void writeTo(JSONWriter out, Table table) throws IOException {
    try {
      out.openObject();
      out.writeContent("name", table.getName());
      out.writeContent("description", table.getDescription());
      out.writeContent("type", table.getType());
      out.openObject("metadata");
      final MetaData metaData = table.getMetaData();
      for (int i = 1, n = metaData.getColumnCount(); i <= n; i++) {
         final Column columnI = metaData.getColumn(i);
         out.writeContent("name", columnI.getName());
         out.writeContent("description", columnI.getDescription());
         out.writeContent("type", columnI.getType().getName());
      }
      out.closeObject();    
      out.openArray("data");
      final TableAccessor accessor = table.getAccessor();
      while(accessor.hasNext()) {
        final Row row = accessor.getNext();
        out.openArray();
        for (int i = 1, n = metaData.getColumnCount(); i <= n; i++) {
          out.writeContent(metaData.getColumn(i).getName(), row.getAsString(i));
        }
        out.closeArray();
      }
      out.closeArray();
      out.closeObject();
    }
    catch (IOException forward) {
      throw forward;
    }
    catch (Throwable ignored) {
      throw ExceptionUtils.newIOException("cannot write json", ignored);
    }
  }
}

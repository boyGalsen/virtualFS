package org.openknows.jdbc.driver.unisql;


public final class Column {

  public static Column getAndInit(final String name, final ColumnType type) {
    return new Column().init(name, type);
  }

  public static Column getAndInit(final String name, final String description, final ColumnType type) {
    return new Column().init(name, description, type);
  }
  
  public String getDescription() {
    return this.description;
  }
  
  private Column() {
  }

	public Column init(final String name, final ColumnType type) {
		this.name = name;
    this.type = type;
    this.description = name;
    return this;
	}

  public Column init(final String name, final String description, final ColumnType type) {
    this.name = name;
    this.type = type;
    this.description = description;
    return this;
  }

  public String getName() {
 	  return this.name;
  }
  
  public ColumnType getType() {
    return this.type;
  }
  
  public void close() {
  }
  
  private String name;
  private String description;
  private ColumnType type;
}
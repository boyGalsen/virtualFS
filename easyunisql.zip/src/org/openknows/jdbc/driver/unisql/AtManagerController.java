package org.openknows.jdbc.driver.unisql;


import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.preferences.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;

public class AtManagerController {
  
  private static final String getType(AtManager manager) {
    return "@"+manager.getPrefix().toUpperCase()+":";
  }

  public boolean register(String className, Parameters parameters) throws DatabaseException {
    try {
      if (!managerByClass.containsKey(className)) {
        register((AtManager)Class.forName(className).newInstance(), parameters);
        return true;
      }
      return false;
    }
    catch (DatabaseException e) {
      throw e;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public boolean unregister(String className, Parameters parameters) throws DatabaseException {
    try {
      if (managerByClass.containsKey(className)) {
        unregister(managerByClass.get(className), parameters);
        return true;
      }
      return false;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public void register(AtManager manager, final Parameters properties) throws DatabaseException {
    final String type = getType(manager);
    if (!managers.containsKey(type)) {
      manager.init(properties);
      managerByClass.put(manager.getClass().getName(), manager);
      final AtManager previous = managers.put(type, manager);
      if (previous != null && manager.getClass() != previous.getClass()) throw new IllegalArgumentException("Allready Existing "+manager.getPrefix().toUpperCase());
    }
  }
  
  public void unregister(AtManager manager, final Parameters properties) {
    final String type = getType(manager);
    if (managers.containsKey(type)) {
      managerByClass.remove(manager.getClass().getName());
      managers.remove(type);
    }
  }
  
  public Table get(final MemoryDatabase database, final AT_TABLE table) throws DatabaseException {
    Trace.reference.log("find="+table.getAt().toUpperCase());
    return managers.get(table.getAt().toUpperCase()).getTable(database, table.getFile(), table.getName());
  }

  public boolean drop(final MemoryDatabase database, final AT_TABLE table) throws DatabaseException {
    return managers.get(table.getAt().toUpperCase()).dropTable(database, table.getFile(), table.getName());
  }
  
  public Table create(final MemoryDatabase database, final AT_TABLE table, MetaData metaData) throws DatabaseException {
    return managers.get(table.getAt().toUpperCase()).createTable(database, table.getFile(), table.getName(), metaData);
  }
  
  public String[] getSuffixes() {
    final ArrayList<String> suffixes = ObjectArrays.getArrayList();
    try {
      for (final AtManager manager : managers.values()) {
        final String prefix = manager.getPrefix();
        if (prefix.length() > 0) {
          suffixes.add(prefix);
        }
      }
      return suffixes.toArray(new String[0]);
    }
    finally {
      ObjectArrays.free(suffixes);
    }
  }
  
  private final HashMap<String, AtManager> managerByClass = new HashMap<String, AtManager>();
  private final HashMap<String, AtManager> managers = new HashMap<String, AtManager>();
}
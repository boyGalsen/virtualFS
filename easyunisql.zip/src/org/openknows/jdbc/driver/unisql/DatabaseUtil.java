package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.*;

public class DatabaseUtil {

  public static Table copy(final Table from, final Table to) throws DatabaseException {
    final TableAccessor fromAccessor = from.getAccessor();
    try {
      return copy(fromAccessor, to);
    }
    finally {
      fromAccessor.close();
    }
  }

  public static Table copy(final TableAccessor from, final Table to) throws DatabaseException {
    final InsertTableAccessor insertAccessort = to.getInsertAccessor();
    try {
      while (from.hasNext()) {
        insertAccessort.insert(from.getNext());
      }
    }
    finally {
      insertAccessort.close();
    }
    return to;
  }

  public static Table copyAndClone(final TableAccessor from, final Table to) throws DatabaseException {
    return copyAndClone(new TableAccessor[] { from,}, to);
  }
  
  public static Table copyAndClone(final EzArray<TableAccessor> froms, final Table to) throws DatabaseException {
    final InsertTableAccessor insertAccessort = to.getInsertAccessor();
    try {
      for (int i = 0, n = froms.getCount(); i < n; i++) {
        final TableAccessor from = froms.get(i);
        if (from != null) {
          while (from.hasNext()) {
            insertAccessort.insert(clone(from.getNext()));
          }
        }
      }
    }
    finally {
      insertAccessort.close();
    }
    return to;
  }

  
  public static Table copyAndClone(final TableAccessor[] froms, final Table to) throws DatabaseException {
    final InsertTableAccessor insertAccessort = to.getInsertAccessor();
    try {
      for (int i = 0, n = froms.length; i < n; i++) {
        final TableAccessor from = froms[i];
        if (from != null) {
          while (from.hasNext()) {
            insertAccessort.insert(clone(from.getNext()));
          }
        }
      }
    }
    finally {
      insertAccessort.close();
    }
    return to;
  }

  public static Row clone(final Row row) {
    final MetaData metaData = row.getMetaData();
    final DatabaseRow newRow = new DatabaseRow().init(metaData);
    for (int i = 1, n = metaData.getColumnCount(); i <= n; i++) {
      newRow.set(i, row.getDatabaseValue(i));
    }
    return newRow;
  }
}

package org.openknows.jdbc.driver.unisql;

public abstract class JoinFilterRule {
  
  public abstract boolean check(final Row a, final Row b);
}

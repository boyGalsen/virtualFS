package org.openknows.jdbc.driver.unisql;


public class NewRowFilter implements TableAccessor {

  public NewRowFilter() {
  }
  
  public void init() throws DatabaseException {
  }
  
  public TableAccessor applyOn(final TableAccessor accessor, final RowFilterRule rowFilter) throws DatabaseException {
    return applyOn(accessor, rowFilter, null);
  }
    
  public TableAccessor applyOn(final TableAccessor accessor, final RowFilterRule rowFilter, final ColumnFilter columnFilter) throws DatabaseException {
		this.accessor = accessor;
    this.rowFilter = rowFilter;
    this.columnFilter = columnFilter;
		findNextValid();
    return this;
  }

  public MetaData getMetaData() throws DatabaseException {
    return (columnFilter == null) ? accessor.getMetaData() : columnFilter.getMetaData();
  }

  public MetaData getOriginalMetaData() throws DatabaseException {
    return accessor.getMetaData();
  }

  public boolean hasNext() throws DatabaseException {
    return hasNext;
  }

  public Row getNext() throws DatabaseException {
  	if (!hasNext) {
  	  throw new DatabaseException("no more value");
  	}
  	final Row row = nextRow;
  	findNextValid();
    return columnFilter == null ? row : columnFilter.setRow(row);
  }

  public void close() throws DatabaseException {
  	accessor.close();
  }

  private void findNextValid() throws DatabaseException {
		hasNext = accessor.hasNext(); 
  	while (hasNext) {
      nextRow = accessor.getNext();
      if (rowFilter.check(nextRow)) return;
			hasNext = accessor.hasNext(); 
  	}
  }

  private Row nextRow = null;
  private boolean hasNext = false;
  private TableAccessor accessor;
  private ColumnFilter columnFilter;
  private RowFilterRule rowFilter;
}

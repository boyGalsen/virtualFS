package org.openknows.jdbc.driver.unisql;

import java.util.ArrayList;


public class Line {

  public void clear() {
 	 values.clear();
 }
 
 public void set(int column, String value) {
 	 if (values.size() < column) {
 		 for (int i = 0 , n = values.size() ; i < n ; i++) {
       values.add(null);
     }
 		 values.add(value);
 	 }
 	 else {
 	 	 values.add(column, value);
 	 }
 }

 public String getString(int column) {
 	 return values.get(column);
 }
 
  
  private ArrayList<String> values = new ArrayList<String>();
}

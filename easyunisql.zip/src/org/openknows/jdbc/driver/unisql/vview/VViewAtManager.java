package org.openknows.jdbc.driver.unisql.vview;

import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;

public class VViewAtManager implements AtManager {
  
  static final String prefix = "vview";
  
  public String getPrefix() {
    return prefix;
  }

  public void init(Parameters properties) {
  }
  
  public Table createTable(MemoryDatabase database, String file, String name, MetaData metaData) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    throw new DatabaseException("Not Implemented Yet");
  }

  public Table getTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    return null;
  }
}
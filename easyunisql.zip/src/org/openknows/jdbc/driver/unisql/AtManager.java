package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;


public interface AtManager {

  public void init(Parameters properties); 
  public String getPrefix();
  
  public Table getTable(MemoryDatabase database, String file, String name) throws DatabaseException;

  public Table createTable(MemoryDatabase database, String file, String name, MetaData data) throws DatabaseException;

  /**
   * return true is is dropped;
   * */
  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException;

}

package org.openknows.jdbc.driver.unisql;

import org.openknows.jdbc.driver.unisql.jdbcmap.*;

import java.util.*;


public class DatabaseRow extends AbstractDatabaseRow {
  
  @Override
  public DatabaseRow init(final MetaData metadata) {
		super.init(metadata);
		this.values = new DatabaseValue[metadata.getColumnCount()];
    Arrays.fill(this.values, JDBCDatabaseValue.NULL);
    return this;
	}

  public void set(final int i, final DatabaseValue value) {
  	this.values[i-1] = value;
  }

  @Override
  public DatabaseValue getDatabaseValue(final int index) {
    return values[index-1];
  }
  
  private DatabaseValue[] values;
}

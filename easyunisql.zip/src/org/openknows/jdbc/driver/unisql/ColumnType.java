package org.openknows.jdbc.driver.unisql;

public enum ColumnType {

  LONG("long"),
  DOUBLE("double"),
  STRING("string"),
  BOOLEAN("boolean"),
  DATE("date");
  
  private ColumnType(final String name) {
    this.name = name;
  }
  
  public String getName() {
    return name;
  }
  
  private final String name;
}

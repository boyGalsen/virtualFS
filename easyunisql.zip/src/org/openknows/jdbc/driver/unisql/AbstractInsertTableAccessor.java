package org.openknows.jdbc.driver.unisql;

import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;

public abstract class AbstractInsertTableAccessor implements InsertTableAccessor {
  
  protected abstract void internalInsert(final Row row) throws DatabaseException;
  
  public final void insert(final Row row) throws DatabaseException {
    internalInsert(row);
  }
  

  public final void insert(final String[] column, final Object[] values) throws DatabaseException {
    final MetaData metaData = getMetaData();
    if (column == null || values == null || column.length != values.length) throw new DatabaseException("not valid arguments");
    try {
      final Object[] allValues = new Object[metaData.getColumnCount()];
      for (int i = 0, n = column.length; i < n ; i++) {
        allValues[metaData.getColumnIndex(column[i])-1] = values[i]; 
      }
      insert(allValues);
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public final void insert(final int[] column, final Object[] values) throws DatabaseException {
    final MetaData metaData = getMetaData();
    if (column == null || values == null || column.length != values.length) throw new DatabaseException("not valid arguments");
    try {
      final Object[] allValues = new Object[metaData.getColumnCount()];
      for (int i = 0, n = column.length; i < n ; i++) {
        allValues[column[i]-1] = values[i]; 
      }
      insert(allValues);
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public final void insert(final String[] column, final DatabaseValue[] values) throws DatabaseException {
    final MetaData metaData = getMetaData();
    if (column == null || values == null || column.length != values.length) throw new DatabaseException("not valid arguments");
    try {
      final DatabaseValue[] allValues = new DatabaseValue[metaData.getColumnCount()];
      for (int i = 0, n = column.length; i < n ; i++) {
        allValues[metaData.getColumnIndex(column[i])-1] = values[i]; 
      }
      insert(allValues);
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

  public final void insert(final int[] column, final DatabaseValue[] values) throws DatabaseException {
    final MetaData metaData = getMetaData();
    if (column == null || values == null || column.length != values.length) throw new DatabaseException("not valid arguments");
    try {
      final DatabaseValue[] allValues = new DatabaseValue[metaData.getColumnCount()];
      for (int i = 0, n = column.length; i < n ; i++) {
        allValues[column[i]-1] = values[i]; 
      }
      insert(allValues);
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }
  
  public final void insert(final Object[] values) throws DatabaseException {
    final MetaData metaData = getMetaData();
    final DatabaseRow row = new DatabaseRow();
    row.init(metaData);
    for (int j = 1, n = metaData.getColumnCount() ; j <= n ; j++) {
      switch (metaData.getColumn(j).getType()) {
        case LONG: {
          row.set(j , JDBCDatabaseValue.getAndInit((Integer)values[j-1]));
        } break;
        case DOUBLE: {
          row.set(j , JDBCDatabaseValue.getAndInit((Double)values[j-1]));
        } break;
        case BOOLEAN : {
          row.set(j , JDBCDatabaseValue.getAndInit((Boolean)values[j-1]));
        } break;
        case STRING : {
          row.set(j , JDBCDatabaseValue.getAndInit((String)values[j-1]));
        } break;
        default:
          throw new DatabaseException("Unvalid type");
      }
    }
    internalInsert(row);
  }
  

  public final void insert(final DatabaseValue[] values) throws DatabaseException {
    internalInsert(new ListDatabaseRow().init(getMetaData(), values));
  }
}

package org.openknows.jdbc.driver.unisql;


public interface TableAccessor {
	
  public void init() throws DatabaseException;
	public MetaData getMetaData() throws DatabaseException ;
  public boolean hasNext() throws DatabaseException ;
  public Row getNext() throws DatabaseException ;
  public void close() throws DatabaseException ;
}

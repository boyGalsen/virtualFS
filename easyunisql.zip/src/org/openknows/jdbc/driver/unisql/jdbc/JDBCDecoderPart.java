package org.openknows.jdbc.driver.unisql.jdbc;


import org.openknows.jdbc.driver.unisql.MetaData;
import org.openknows.jdbc.driver.unisql.sql.EXECUTABLE;

public interface JDBCDecoderPart<T extends EXECUTABLE> {

  public Class<T> getImplClass();
  public JDBCDecoderResult compile(T executable) throws Throwable;
  public MetaData getMetaData(T executable) throws Throwable;
}

package org.openknows.jdbc.driver.unisql.jdbc;

import org.openknows.jdbc.driver.unisql.*;

public class JDBCUtil {

  public static boolean isNotNull(String s1) {
    return (s1 != null && !"".equals(s1)); 
  }

  public static boolean isNull(String s1) {
    return (s1 == null || "".equals(s1)); 
  }

  public static boolean isNull(Double d1) {
    return (d1 == null); 
  }

  public static boolean isNotNull(Double d1) {
    return (d1 != null); 
  }

  public static boolean isEquals(String s1, String s2) {
    return (s1 != null && s1.equals(s2)); 
  }
  
  public static boolean isNotEquals(String s1, String s2) {
    if (s1 == s2) return false;
    if (s1 == null || s2 == null) return true;
    return !s1.equals(s2);
  }
  
  public static boolean isLike(String s1, String s2) {
    return (s1 != null && s1.matches(s2)); 
  }

  public static boolean isNotLike(String s1, String s2) {
    return (s1 == null || !s1.matches(s2)); 
  }

  public static boolean isNotEquals(Double d1, double d2) {
    return (d1 == null || d1.doubleValue() != d2); 
  }
  
  public static boolean isNotEquals(Double d1, Double d2) {
    if (d1 == d2) return false;
    if (d1 == null || d2 == null) return true;
    return d1.doubleValue() != d2.doubleValue();
  }
  
  public static boolean isEquals(double d1, double d2) {
    return d1 == d2; 
  }
  
  public static boolean isEquals(Double d1, double d2) {
    return d1 != null && d1.doubleValue() == d2; 
  }

  public static boolean isEquals(double d1, Double d2) {
    return d2 != null && d2.doubleValue() == d1; 
  }

  public static boolean isEquals(Double d1, Double d2) {
    return d1 != null && d2 != null && d1.doubleValue() == d2.doubleValue();
  }

  public static boolean equals(DatabaseValue v1, DatabaseValue v2) {
    if (v1 == v2) return true;
    if (v1 == null || v2 == null) return false;
    if (v1.isNull() && v2.isNull()) return true;
    if (v1.isNull() || v2.isNull()) return false;
    return isEquals(v1.getStringValue(), v2.getStringValue());
  }

  public static boolean isGreater(Double d1, double d2) {
    return d1 != null && d1.doubleValue() > d2;
  }

  public static boolean isGreater(Double d1, Double d2) {
    return d1 != null && d2 != null && d1.doubleValue() > d2.doubleValue();
  }

  public static boolean isGreaterOrEquals(Double d1, double d2) {
    return d1 != null && d1.doubleValue() >= d2;
  }

  public static boolean isGreaterOrEquals(Double d1, Double d2) {
    return d1 != null && d2 != null && d1.doubleValue() >= d2.doubleValue();
  }


  public static boolean isLeather(Double d1, double d2) {
    return d1 != null && d1.doubleValue() < d2;
  }

  public static boolean isLeather(Double d1, Double d2) {
    return d1 != null && d2 != null && d1.doubleValue() < d2.doubleValue();
  }

  public static boolean isLeatherOrEquals(Double d1, double d2) {
    return d1 != null && d1.doubleValue() <= d2;
  }

  public static boolean isLeatherOrEquals(Double d1, Double d2) {
    return d1 == d2 || (d1 != null && d2 != null && d1.doubleValue() <= d2.doubleValue());
  }

  public static boolean isBetween(Double d1, Double d2, Double d3) {
    if (d1 == null || d2 == null || d3 == null) return false;
    final double d1Value = d1.doubleValue();
    return d1Value >= d2.doubleValue() && d1Value <= d3.doubleValue();
  }
  
  public static boolean isBetween(Double d1, Double d2, double d3) {
    if (d1 == null || d2 == null) return false;
    final double d1Value = d1.doubleValue();
    return d1Value >= d2.doubleValue() && d1Value <= d3;
  }
  
  public static boolean isBetween(Double d1, double d2, Double d3) {
    if (d1 == null || d3 == null) return false;
    final double d1Value = d1.doubleValue();
    return d1Value >= d2 && d1Value <= d3.doubleValue();
  }
  
  public static boolean isBetween(Double d1, double d2, double d3) {
    if (d1 == null) return false;
    final double d1Value = d1.doubleValue();
    return d1Value >= d2 && d1Value <= d3;
  }
  
  
  public static Double add(double d1, double d2) {
    return new Double(d1 + d2);
  }
  
  public static Long add(Long d1, Long d2) {
    return d1 == null ? null : d2 == null ? null : new Long(d1.longValue() + d2.longValue());
  }
  
  public static Double add(Double d1, Double d2) {
    return d1 == null ? null : d2 == null ? null : new Double(d1.doubleValue() + d2.doubleValue());
  }
  
  public static Double add(Double d1, double d2) {
    return d1 == null ? null : new Double(d1.doubleValue() + d2);
  }

  public static Double add(double d1, Double d2) {
    return d2 == null ? null : new Double(d2.doubleValue() + d1);
  }
  
  public static Double sub(double d1, double d2) {
    return new Double(d1 - d2);
  }
  
  public static Long sub(Long d1, Long d2) {
    return d1 == null ? null : d2 == null ? null : new Long(d1.longValue() - d2.longValue());
  }
  
  public static Double sub(Double d1, Double d2) {
    return d1 == null ? null : d2 == null ? null : new Double(d1.doubleValue() - d2.doubleValue());
  }
  
  public static Double sub(Double d1, double d2) {
    return d1 == null ? null : new Double(d1.doubleValue() - d2);
  }

  public static Double sub(double d1, Double d2) {
    return d2 == null ? null : new Double(d1 - d2.doubleValue());
  }

  public static Double mult(double d1, double d2) {
    return new Double(d1 * d2);
  }
  
  public static Long mult(Long d1, Long d2) {
    return d1 == null ? null : d2 == null ? null : new Long(d1.longValue() * d2.longValue());
  }
  
  public static Double mult(Double d1, Double d2) {
    return d1 == null ? null : d2 == null ? null : new Double(d1.doubleValue() * d2.doubleValue());
  }
  
  public static Double mult(Double d1, double d2) {
    return d1 == null ? null : new Double(d1.doubleValue() * d2);
  }

  public static Double mult(double d1, Double d2) {
    return d2 == null ? null : new Double(d2.doubleValue() * d1);
  }
  
  public static Double div(double d1, double d2) {
    return new Double(d1 / d2);
  }
  
  public static Double div(Double d1, Double d2) {
    return d1 == null ? null : d2 == null ? null : new Double(d1.doubleValue() / d2.doubleValue());
  }
  
  public static Double div(Double d1, double d2) {
    return d1 == null ? null : new Double(d1.doubleValue() / d2);
  }

  public static Double div(double d1, Double d2) {
    return d2 == null ? null : new Double(d1 / d2.doubleValue());
  }
 
  public static String upper(String value) {
    return value == null ? null : value.toUpperCase();
  }
  
  
  public static final MetaData noMetaData = new MetaData() {

    public Column findColumnByName(String name) {
      return null;
    }

    public Column getColumn(int i) {
      return null;
    }

    public int getColumnCount() {
      return 0;
    }

    public int getColumnIndex(Column column) {
      return -1;
    }

    public int getColumnIndex(String columnName) {
      return -1;
    }
    
    public int getColumnIndex(String columnName, String alternative) {
      return -1;
    } 
  };
  
  public static final JDBCResultSet noResultSet = new JDBCResultSet(new TableAccessor() {

    public void close() throws DatabaseException {}

    public MetaData getMetaData() throws DatabaseException {
      return noMetaData;
    }

    public Row getNext() throws DatabaseException {
      return null;
    }

    public boolean hasNext() throws DatabaseException {
      return false;
    }

    public void init() throws DatabaseException {}
    
  });
}


package org.openknows.jdbc.driver.unisql.jdbc;


import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;


public class DestivateDecoderPart implements JDBCDecoderPart<DESACTIVATE> {
  
  public DestivateDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }
  
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final DESACTIVATE executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase(); 
    final ResultSet resultSet = null;
    final int updateCount = internalCompile(database, executable);
    return new JDBCDecoderResult() {

      public MetaData getMetaData() { return null; }
      public PreparedStatement getPreparedStatement() { return null; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return false;}

    };
  }

  public MetaData getMetaData(final DESACTIVATE executable) throws Throwable {
    return null;
  }

  public int internalCompile(final MemoryDatabase database, final DESACTIVATE set) throws Throwable {
    try {
      switch (set.type) {
        case DESACTIVATE.MANAGER : {
          final String name = set.parameters.get(0);
          return JDBCConnectionDriver.getReference().getAtManager().unregister(name, JDBCConnectionDriver.getParameters()) ? 1 : 0;
        }
        case DESACTIVATE.FUNCTION : {
          final String name = set.parameters.get(0);
          return JDBCConnectionDriver.getReference().getFunctionManager().unregister(name, JDBCConnectionDriver.getParameters()) ? 1 : 0;
        }
        case DESACTIVATE.MEMO :
        default : 
      }
      return 0;
    }
    catch (Throwable ignored) {
      throw ignored;
    }
  }

  public Class<DESACTIVATE> getImplClass() {
    return DESACTIVATE.class;
  }
}
package org.openknows.jdbc.driver.unisql.jdbc;


import java.io.*;
import java.math.*;
import java.net.*;
import java.sql.*;
import java.sql.Date;
import java.util.*;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;
import org.openknows.jdbc.driver.unisql.sql.parser.*;


public class JDBCCallableStatement implements CallableStatement {
  
  private final JDBCConnection connection;
  private final String sqlRequest;
  private final Object request;
  private final ResultSetMetaData metaData;
  private ResultSet resultSet;
  private int updateCount;
  private final JDBCStatement statement;
  
  JDBCCallableStatement(final JDBCConnection connection, final String sqlRequest) throws SQLException {
    this.connection = connection;
    this.sqlRequest = sqlRequest;
    this.statement = new JDBCStatement(connection);
    
    Object request = null;
    try {
      request = parser.compute(connection.getDatabase().getDriver(), this.sqlRequest);
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
    }
    this.request = request;
    try {
      this.metaData = (request instanceof SELECT) ? new JDBCResultSetMetaData(connection.getRequestCompiler().compileMetaData((SELECT)this.request)) 
       : new JDBCResultSet(SimpleMemoryTable.emptyTable.getAccessor()).getMetaData();
    }
    catch (Throwable ignored) {
      throw new SQLException(ExceptionUtils.getMessage(ignored));
    }
  }

  public Array getArray(int i) throws SQLException {
    return null;
  }

  public Array getArray(String parameterName) throws SQLException {
    return null;
  }

  public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
    return null;
  }

  public BigDecimal getBigDecimal(String parameterName) throws SQLException {
    return null;
  }

  public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
    return null;
  }

  public Blob getBlob(int i) throws SQLException {
    return null;
  }

  public Blob getBlob(String parameterName) throws SQLException {
    return null;
  }

  public boolean getBoolean(int parameterIndex) throws SQLException {
    return false;
  }

  public boolean getBoolean(String parameterName) throws SQLException {
    return false;
  }

  public byte getByte(int parameterIndex) throws SQLException {
    return 0;
  }

  public byte getByte(String parameterName) throws SQLException {
    return 0;
  }

  public byte[] getBytes(int parameterIndex) throws SQLException {
    return null;
  }

  public byte[] getBytes(String parameterName) throws SQLException {
    return null;
  }

  public Clob getClob(int i) throws SQLException {
    return null;
  }

  public Clob getClob(String parameterName) throws SQLException {
    return null;
  }

  public Date getDate(int parameterIndex) throws SQLException {
    return null;
  }

  public Date getDate(String parameterName) throws SQLException {
    return null;
  }

  public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
    return null;
  }

  public Date getDate(String parameterName, Calendar cal) throws SQLException {
    return null;
  }

  public double getDouble(int parameterIndex) throws SQLException {
    return 0;
  }

  public double getDouble(String parameterName) throws SQLException {
    return 0;
  }

  public float getFloat(int parameterIndex) throws SQLException {
    return 0;
  }

  public float getFloat(String parameterName) throws SQLException {
    return 0;
  }

  public int getInt(int parameterIndex) throws SQLException {
    return 0;
  }

  public int getInt(String parameterName) throws SQLException {
    return 0;
  }

  public long getLong(int parameterIndex) throws SQLException {
    return 0;
  }

  public long getLong(String parameterName) throws SQLException {
    return 0;
  }

  public Object getObject(int parameterIndex) throws SQLException {
    return null;
  }

  public Object getObject(String parameterName) throws SQLException {
    return null;
  }

  public Object getObject(int arg0, Map<String, Class<?>> arg1) throws SQLException {
    return null;
  }

  public Object getObject(String arg0, Map<String, Class<?>> arg1) throws SQLException {
    return null;
  }

  public Ref getRef(int i) throws SQLException {
    return null;
  }

  public Ref getRef(String parameterName) throws SQLException {
    return null;
  }

  public short getShort(int parameterIndex) throws SQLException {
    return 0;
  }

  public short getShort(String parameterName) throws SQLException {
    return 0;
  }

  public String getString(int parameterIndex) throws SQLException {
    return null;
  }

  public String getString(String parameterName) throws SQLException {
    return null;
  }

  public Time getTime(int parameterIndex) throws SQLException {
    return null;
  }

  public Time getTime(String parameterName) throws SQLException {
    return null;
  }

  public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
    return null;
  }

  public Time getTime(String parameterName, Calendar cal) throws SQLException {
    return null;
  }

  public Timestamp getTimestamp(int parameterIndex) throws SQLException {
    return null;
  }

  public Timestamp getTimestamp(String parameterName) throws SQLException {
    return null;
  }

  public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
    return null;
  }

  public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
    return null;
  }

  public URL getURL(int parameterIndex) throws SQLException {
    return null;
  }

  public URL getURL(String parameterName) throws SQLException {
    return null;
  }

  public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {}

  public void registerOutParameter(String parameterName, int sqlType) throws SQLException {}

  public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {}

  public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException {}

  public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {}

  public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {}

  public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {}

  public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {}

  public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {}

  public void setBoolean(String parameterName, boolean x) throws SQLException {}

  public void setByte(String parameterName, byte x) throws SQLException {}

  public void setBytes(String parameterName, byte[] x) throws SQLException {}

  public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {}

  public void setDate(String parameterName, Date x) throws SQLException {}

  public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {}

  public void setDouble(String parameterName, double x) throws SQLException {}

  public void setFloat(String parameterName, float x) throws SQLException {}

  public void setInt(String parameterName, int x) throws SQLException {}

  public void setLong(String parameterName, long x) throws SQLException {}

  public void setNull(String parameterName, int sqlType) throws SQLException {}

  public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {}

  public void setObject(String parameterName, Object x) throws SQLException {}

  public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {}

  public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {}

  public void setShort(String parameterName, short x) throws SQLException {}

  public void setString(String parameterName, String x) throws SQLException {}

  public void setTime(String parameterName, Time x) throws SQLException {}

  public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {}

  public void setTimestamp(String parameterName, Timestamp x) throws SQLException {}

  public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {}

  public void setURL(String parameterName, URL val) throws SQLException {}

  public boolean wasNull() throws SQLException {
    return false;
  }

  public void addBatch() throws SQLException {}

  public void clearParameters() throws SQLException {}

  public boolean execute() throws SQLException {
    resultSet = null;
    updateCount = 0;
    try {
      final boolean result = statement.execute(sqlRequest);
      resultSet = statement.getResultSet();
      updateCount = statement.getUpdateCount();
      return result;
    }
    catch (Throwable ignored) {
      resultSet = null;
      updateCount = 0;
      return false;
    } 
  }

  public ResultSet executeQuery() throws SQLException {
    execute();
    return getResultSet();
  }

  public int executeUpdate() throws SQLException {
    execute();
    return updateCount;
  }

  public ResultSetMetaData getMetaData() throws SQLException {
    return metaData;
  }

  public ParameterMetaData getParameterMetaData() throws SQLException {
    return null;
  }

  public void setArray(int i, Array x) throws SQLException {}

  public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {}

  public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {}

  public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {}

  public void setBlob(int i, Blob x) throws SQLException {}

  public void setBoolean(int parameterIndex, boolean x) throws SQLException {}

  public void setByte(int parameterIndex, byte x) throws SQLException {}

  public void setBytes(int parameterIndex, byte[] x) throws SQLException {}

  public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {}

  public void setClob(int i, Clob x) throws SQLException {}

  public void setDate(int parameterIndex, Date x) throws SQLException {}

  public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {}

  public void setDouble(int parameterIndex, double x) throws SQLException {}

  public void setFloat(int parameterIndex, float x) throws SQLException {}

  public void setInt(int parameterIndex, int x) throws SQLException {}

  public void setLong(int parameterIndex, long x) throws SQLException {}

  public void setNull(int parameterIndex, int sqlType) throws SQLException {}

  public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException {}

  public void setObject(int parameterIndex, Object x) throws SQLException {}

  public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {}

  public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {}

  public void setRef(int i, Ref x) throws SQLException {}

  public void setShort(int parameterIndex, short x) throws SQLException {}

  public void setString(int parameterIndex, String x) throws SQLException {}

  public void setTime(int parameterIndex, Time x) throws SQLException {}

  public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {}

  public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {}

  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {}

  public void setURL(int parameterIndex, URL x) throws SQLException {}

  public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {}

  public void addBatch(String sql) throws SQLException {}

  public void cancel() throws SQLException {}

  public void clearBatch() throws SQLException {}

  public void clearWarnings() throws SQLException {}

  public void close() throws SQLException {}

  public boolean execute(String sql) throws SQLException {
    return new JDBCStatement(connection).execute(sql);  
  }

  public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
    return new JDBCStatement(connection).execute(sql, autoGeneratedKeys);  
  }

  public boolean execute(String sql, int[] columnIndexes) throws SQLException {
    return new JDBCStatement(connection).execute(sql, columnIndexes);  
  }

  public boolean execute(String sql, String[] columnNames) throws SQLException {
    return new JDBCStatement(connection).execute(sql, columnNames);  
  }

  public int[] executeBatch() throws SQLException {
    return null;
  }

  public ResultSet executeQuery(String sql) throws SQLException {
    return new JDBCStatement(connection).executeQuery(sql);  
  }

  public int executeUpdate(String sql) throws SQLException {
    return new JDBCStatement(connection).executeUpdate(sql);  
  }

  public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
    return new JDBCStatement(connection).executeUpdate(sql, autoGeneratedKeys);  
  }

  public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
    return new JDBCStatement(connection).executeUpdate(sql, columnIndexes);  
  }

  public int executeUpdate(String sql, String[] columnNames) throws SQLException {
    return new JDBCStatement(connection).executeUpdate(sql, columnNames);  
  }

  public Connection getConnection() throws SQLException {
    return connection;
  }

  public int getFetchDirection() throws SQLException {
    return 0;
  }

  public int getFetchSize() throws SQLException {
    return 0;
  }

  public ResultSet getGeneratedKeys() throws SQLException {
    return null;
  }

  public int getMaxFieldSize() throws SQLException {
    return 0;
  }

  public int getMaxRows() throws SQLException {
    return 0;
  }

  public boolean getMoreResults() throws SQLException {
    return false;
  }

  public boolean getMoreResults(int current) throws SQLException {
    return false;
  }

  public int getQueryTimeout() throws SQLException {
    return 0;
  }

  public ResultSet getResultSet() throws SQLException {
    return resultSet;
  }

  public int getResultSetConcurrency() throws SQLException {
    return 0;
  }

  public int getResultSetHoldability() throws SQLException {
    return 0;
  }

  public int getResultSetType() throws SQLException {
    return 0;
  }

  public int getUpdateCount() throws SQLException {
    return updateCount;
  }

  public SQLWarning getWarnings() throws SQLException {
    return null;
  }

  public void setCursorName(String name) throws SQLException {}

  public void setEscapeProcessing(boolean enable) throws SQLException {}

  public void setFetchDirection(int direction) throws SQLException {}

  public void setFetchSize(int rows) throws SQLException {}

  public void setMaxFieldSize(int max) throws SQLException {}

  public void setMaxRows(int max) throws SQLException {}

  public void setQueryTimeout(int seconds) throws SQLException {}   ///add for jdk1.6

  public Reader getCharacterStream(int parameterIndex) throws SQLException {
    return null;
  }

  public Reader getCharacterStream(String parameterName) throws SQLException {
    return null;
  }

  public Reader getNCharacterStream(int parameterIndex) throws SQLException {
    return null;
  }

  public Reader getNCharacterStream(String parameterName) throws SQLException {
    return null;
  }

  public NClob getNClob(int parameterIndex) throws SQLException {
    return null;
  }

  public NClob getNClob(String parameterName) throws SQLException {
    return null;
  }

  public String getNString(int parameterIndex) throws SQLException {
    return null;
  }

  public String getNString(String parameterName) throws SQLException {
    return null;
  }

  public RowId getRowId(int parameterIndex) throws SQLException {
    return null;
  }

  public RowId getRowId(String parameterName) throws SQLException {
    return null;
  }

  public SQLXML getSQLXML(int parameterIndex) throws SQLException {
    return null;
  }

  public SQLXML getSQLXML(String parameterName) throws SQLException {
    return null;
  }

  public void setAsciiStream(String parameterName, InputStream x) throws SQLException {}

  public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {}

  public void setBinaryStream(String parameterName, InputStream x) throws SQLException {}

  public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {}

  public void setBlob(String parameterName, Blob x) throws SQLException {}

  public void setBlob(String parameterName, InputStream inputStream) throws SQLException {}

  public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException {}

  public void setCharacterStream(String parameterName, Reader reader) throws SQLException {}

  public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {}

  public void setClob(String parameterName, Clob x) throws SQLException {}

  public void setClob(String parameterName, Reader reader) throws SQLException {}

  public void setClob(String parameterName, Reader reader, long length) throws SQLException {}

  public void setNCharacterStream(String parameterName, Reader value) throws SQLException {}

  public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException {}

  public void setNClob(String parameterName, NClob value) throws SQLException {}

  public void setNClob(String parameterName, Reader reader) throws SQLException {}

  public void setNClob(String parameterName, Reader reader, long length) throws SQLException {}

  public void setNString(String parameterName, String value) throws SQLException {}

  public void setRowId(String parameterName, RowId x) throws SQLException {}

  public void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {}

  public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {}

  public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {}

  public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {}

  public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {}

  public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {}

  public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {}

  public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {}

  public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {}

  public void setClob(int parameterIndex, Reader reader) throws SQLException {}

  public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {}

  public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {}

  public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {}

  public void setNClob(int parameterIndex, NClob value) throws SQLException {}

  public void setNClob(int parameterIndex, Reader reader) throws SQLException {}

  public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {}

  public void setNString(int parameterIndex, String value) throws SQLException {}

  public void setRowId(int parameterIndex, RowId x) throws SQLException {}

  public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {}

  public boolean isClosed() throws SQLException {
    return false;
  }

  public boolean isPoolable() throws SQLException {
    return false;
  }

  public void setPoolable(boolean poolable) throws SQLException {}

  public boolean isWrapperFor(Class<?> iface) throws SQLException {
    return false;
  }

  public <T> T unwrap(Class<T> iface) throws SQLException {
    return null;
  }

  public void closeOnCompletion() throws SQLException {}

  public <T> T getObject(int arg0, Class<T> arg1) throws SQLException {
    return null;
  }

  public <T> T getObject(String arg0, Class<T> arg1) throws SQLException {
    return null;
  }

  public boolean isCloseOnCompletion() throws SQLException {
    return false;
  }
  
  
}

package org.openknows.jdbc.driver.unisql.jdbc;


import com.easyrms.util.array.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCTable;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;
import org.openknows.jdbc.driver.unisql.sql.*;


public class SetDecoderPart implements JDBCDecoderPart<SET> {
  
  public SetDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }
  
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final SET executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase(); 
    final ResultSet resultSet = null;
    final int updateCount = internalCompile(database, executable);
    return new JDBCDecoderResult() {

      public PreparedStatement getPreparedStatement() { return null; }
      public MetaData getMetaData() { return null; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return false;}
    };
  }

  public MetaData getMetaData(final SET executable) throws Throwable {
    return null;
  }

  public int internalCompile(final MemoryDatabase database, final SET set) throws Throwable {
    if (set.table instanceof AT_TABLE) {
      final AT_TABLE excelTable = (AT_TABLE)set.table;
      final Table fileTable = database.getDriver().getAtManager().get(database, excelTable);//new ExcelFileTable().init(new File(excelTable.getFile()), excelTable.getName());
      database.add(set.catalog, fileTable);
      return 1;
    }
    else if (set.table instanceof SIMPLE_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else if (set.table instanceof BASE_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else if (set.table instanceof JDBC_TABLE) {
      final JDBC_TABLE jdbcTable = (JDBC_TABLE)set.table;
      final JDBCTable fileTable = new JDBCTable().init(jdbcTable.getDatabase(), jdbcTable.getName(), jdbcTable.getRequest(), ObjectArrays.emptyObjectArray);
      database.add(set.catalog, fileTable);
      return 1;
    }
    return 0;
  }

  public Class<SET> getImplClass() {
    return SET.class;
  }
}
package org.openknows.jdbc.driver.unisql.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.openknows.jdbc.driver.unisql.MetaData;


public interface JDBCDecoderResult {

  public MetaData getMetaData();
  public PreparedStatement getPreparedStatement();
  public ResultSet getResultSet();
  public int getUpdateCount();
  public boolean isSelect();
}

package org.openknows.jdbc.driver.unisql.jdbc;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.sql.*;
import java.util.*;

import org.openknows.jdbc.driver.pool.*;
import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;

public class JDBCRequestDecoder {

  public JDBCRequestDecoder(final MemoryDatabase database) {
    this.database = database;
    register(new SelectDecoderPart(this));
    register(new SelectListDecoderPart(this));
    register(new SetDecoderPart(this));
    register(new RegisterDecoderPart(this));
    register(new CreateDecoderPart(this));
    register(new DropDecoderPart(this));
    register(new ActivateDecoderPart(this));
    register(new DestivateDecoderPart(this));
  }

  private final void register(final JDBCDecoderPart part) {
    this.decoders.add(part);
  }

  public void populateParameters(final EXECUTABLE executable, final IntObjectMap<Object> parameters) throws SQLException {
    final VARIABLES variables = executable.getVariables();
    for (int i = 0, n = variables.getVariableCount(); i < n; i++) {
      final VARIABLE_OPERATION variable = variables.getVariable(i);
      final int index = variable.getIndex();
      if (!parameters.containsKey(index)) throw new SQLException("Not set value");
      final Object value = parameters.get(index);
      if (value == null) {
        variable.setValue(JDBCDatabaseValue.NULL);
      }
      else if (value instanceof JDBCDatabaseValue) {
        variable.setValue((JDBCDatabaseValue)value);
      }
      else if (value instanceof String) {
        variable.setValue(JDBCDatabaseValue.getAndInit(((String)value)));
      }
      else if (value instanceof Boolean) {
        variable.setValue(JDBCDatabaseValue.getAndInit(((Boolean)value)));
      }
      else if (value instanceof Integer) {
        variable.setValue(JDBCDatabaseValue.getAndInit(((Integer)value)));
      }
      else if (value instanceof Double) {
        variable.setValue(JDBCDatabaseValue.getAndInit(((Double)value)));
      }
      else if (value instanceof Long) {
        variable.setValue(JDBCDatabaseValue.getAndInit(((Long)value)));
      }
      else if (value instanceof Number) {
        final Number v = (Number)value;
        if (v.longValue() == v.doubleValue()) {
          variable.setValue(JDBCDatabaseValue.getAndInit(LongCache.get(v.longValue())));
        }
        else {
          variable.setValue(JDBCDatabaseValue.getAndInit(MathUtils.getDouble(v.doubleValue())));
        }
      }
      else {
        variable.setValue(JDBCDatabaseValue.getAndInit(value.toString()));
      }
    }
  }

  public JDBCDecoderResult execute(final EXECUTABLE executable) throws Throwable {
    for (JDBCDecoderPart decoder : decoders) {
      if (decoder.getImplClass().isInstance(executable)) { 
        return decoder.compile(executable); 
      }
    }
    throw new IllegalStateException("Unsupported Executable");
  }

  public MetaData compileMetaData(final EXECUTABLE select) {
    try {
      for (JDBCDecoderPart decoder : decoders) {
        if (decoder.getImplClass().isInstance(select)) {
          return decoder.getMetaData(select);
        }
      }
      throw new IllegalStateException("Unsupported Executable");
    }
    catch (Throwable ignored) {
      return null;
    }
  }

  public ParameterMetaData compileParameterMetaData(final EXECUTABLE select) {
    try {
      final VARIABLES variables = select.getVariables();
      return new ParameterMetaData() {

        public String getParameterClassName(int param) throws SQLException {
          return null;
        }

        public int getParameterCount() throws SQLException {
          return variables.getVariableCount();
        }

        public int getParameterMode(int param) throws SQLException {
          return 0;
        }

        public int getParameterType(int param) throws SQLException {
          return 0;
        }

        public String getParameterTypeName(int param) throws SQLException {
          return null;
        }

        public int getPrecision(int param) throws SQLException {
          return 0;
        }

        public int getScale(int param) throws SQLException {
          return 0;
        }

        public int isNullable(int param) throws SQLException {
          return 0;
        }

        public boolean isSigned(int param) throws SQLException {
          return false;
        }

        public boolean isWrapperFor(Class<?> iface) throws SQLException {
          return false;
        }

        public <T> T unwrap(Class<T> iface) throws SQLException {
          return null;
        }
      };
    }
    catch (Throwable ignored) {
      return null;
    }
  }

  public int excecute(final REGISTER set) throws Throwable {
    try {
      final Properties properties = new Properties();
      properties.put("user", set.user);
      properties.put("password", set.password);
      PoolDriverConnectionDriver.addDataSource(set.name, set.driver, set.url, properties);
      return 1;
    }
    catch (Throwable ignored) {
      throw ignored;
    }
  }

  public MemoryDatabase getDatabase() {
    return this.database;
  }

  private final MemoryDatabase database;
  private final EzArrayList<JDBCDecoderPart> decoders = new EzArrayList<JDBCDecoderPart>();

  public static final int SELECT = 0;
  public static final int INSERT = 1;
  public static final int UPDATE = 2;
  public static final int DELETE = 3;
  public static final int CREATE = 4;
  public static final int DESCRIBE = 5;
  public static final int SET = 6;

  public static final String SELECT_STRING = "SELECT";
  public static final String INSERT_STRING = "INSERT";
  public static final String UPDATE_STRING = "UPDATE";
  public static final String DELETE_STRING = "DELETE";
}

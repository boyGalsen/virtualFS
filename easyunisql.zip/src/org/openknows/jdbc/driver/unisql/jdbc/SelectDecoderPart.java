package org.openknows.jdbc.driver.unisql.jdbc;

import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.executor.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.operation.*;
import org.openknows.jdbc.driver.unisql.sql.*;

import java.sql.*;
import java.util.*;


public class SelectDecoderPart implements JDBCDecoderPart<SELECT> {
  
  public SelectDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }
  
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final SELECT executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase();
    final TableAccessor accessor = compileAccessor(database, executable);
    final ResultSet resultSet = new JDBCResultSet(accessor);
    final MetaData metaData = accessor.getMetaData();
    final int updateCount = -1;
    return new JDBCDecoderResult() {

      public PreparedStatement getPreparedStatement() { return null; }
      public MetaData getMetaData() { return metaData; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return true;}
    };
  }

  public MetaData getMetaData(final SELECT executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase();
    return compileAccessor(database, executable).getMetaData();
  }
  
  private Table composeTable(final MemoryDatabase database, final TABLE table, final WHERE_TEST wherePart, final HashMap<String, Table> tablesByName) throws Throwable {
    if (table instanceof JOIN) {
      final JOIN subTable = (JOIN)table;
      final Table fileTable = computeTableFilter(subTable.getTable(), wherePart);
      //filterRules.put(fileTable, computeRowFilter(false, subTable, wherePart, fileTable.getMetaData()));
      tablesByName.put(subTable.getName(), fileTable);
      return fileTable;
    }
    else if (table instanceof TEMP_TABLE) {
      final TEMP_TABLE tempTable = (TEMP_TABLE)table;
      final Table memoryTable = computeTableFilter(TempTable.createFrom(tempTable),wherePart);
      //filterRules.put(memoryTable, computeRowFilter(false, tempTable, wherePart, memoryTable.getMetaData()));
      tablesByName.put(tempTable.getName(), memoryTable);
      return memoryTable;
    }
    else if (table instanceof SUB_SELECT_TABLE) {
      final SUB_SELECT_TABLE subTable = (SUB_SELECT_TABLE)table;
      final Table fileTable = computeTableFilter(subTable.getTable(), wherePart);
      //filterRules.put(fileTable, computeRowFilter(false, subTable, wherePart, fileTable.getMetaData()));
      tablesByName.put(subTable.getName(), fileTable);
      return fileTable;
    }
    else if (table instanceof AT_TABLE) {
      final AT_TABLE atTable = (AT_TABLE)table;
      final Table fileTable = computeTableFilter(database.getDriver().getAtManager().get(database, atTable), wherePart);//new ExcelFileTable().init(new File(excelTable.getFile()), excelTable.getName());
      //filterRules.put(fileTable, computeRowFilter(false, atTable, wherePart, fileTable.getMetaData()));
      tablesByName.put(atTable.getName(), fileTable);
      return fileTable;
    }
    else if (table instanceof BASE_TABLE) {
      final BASE_TABLE jdbcTable = (BASE_TABLE)table;
      final Table fileTable = computeTableFilter(new JDBCTable().init(jdbcTable.getDatabasePart(), StringUtil.NVL(jdbcTable.getName(), jdbcTable.getTableNamePart()), "select * from "+jdbcTable.getTableNamePart(), ObjectArrays.emptyObjectArray), wherePart);
      //filterRules.put(fileTable, computeRowFilter(false, jdbcTable, wherePart, fileTable.getMetaData()));
      tablesByName.put(jdbcTable.getName(), fileTable);
      return fileTable;
    }
    else if (table instanceof SIMPLE_TABLE) {
      final SIMPLE_TABLE jdbcTable = (SIMPLE_TABLE)table;
      final Table fileTable = computeTableFilter(database.findTable(jdbcTable.getCatalog(), jdbcTable.getTable()), wherePart);
      //filterRules.put(fileTable, computeRowFilter(false, jdbcTable, wherePart, fileTable.getMetaData()));
      tablesByName.put(jdbcTable.getName(), fileTable);
      return fileTable;
    }
    else if (table instanceof JDBC_TABLE) {
      final JDBC_TABLE jdbcTable = (JDBC_TABLE)table;
      final Table fileTable = computeTableFilter(new JDBCTable().init(jdbcTable.getDatabase(), jdbcTable.getName(), jdbcTable.getRequest(), ObjectArrays.emptyObjectArray), wherePart);
      //filterRules.put(fileTable, computeRowFilter(false, jdbcTable, wherePart, fileTable.getMetaData()));
      tablesByName.put(jdbcTable.getName(), fileTable);
      return fileTable;
    }
    return null;
  }
  
  public TableAccessor compileAccessor(final MemoryDatabase database, final SELECT select) throws Throwable {
    select.subSelectCompile(this.decoder);
    final HashMap<String, Table> tablesByName = new HashMap<String, Table>();
    //final HashMap<Table, RowFilterRule> filterRules = new HashMap<Table, RowFilterRule>();
    final WHERE_TEST wherePart = (select.wherePart == null ? null : select.wherePart.getTest());
    final List<TABLE> listTables = select.fromPart.getTable();
    final int tableSize = listTables.size();
    final EzArrayList<Table> tables = new EzArrayList<Table>(tableSize); 
    EzPoolExecutor.DEFAULT.call(
      new EzCallableTaskArray<Table>("selectDecoderPartTable", tableSize) {

      @Override
      public String description(int i) {
        return "byTable";
      }

      @Override
      public void fillContext(int i, EzTaskContext context) {
      }

      @Override
      public Table call(int i) {
        try {
          return composeTable(database, listTables.get(i), wherePart, tablesByName);
        }
        catch (Throwable forward) {
          throw new RuntimeException(forward);
        }
      }
    }, tables);
    final EzArrayList<String> names = new EzArrayList<String>(tableSize);
    for (int i = 0, n = tableSize; i < n; i++) {
      names.add(tables.get(i).getName());
    }
    final EzArrayList<TableAccessor> accessors = new EzArrayList<TableAccessor>(tableSize);
    EzPoolExecutor.DEFAULT.call(
      new EzCallableTaskArray<TableAccessor>("selectDecoderPartAccessor", tableSize) {

      @Override
      public String description(int i) {
        return "byTable";
      }

      @Override
      public void fillContext(int i, EzTaskContext context) {
      }

      @Override
      public TableAccessor call(int i) {
        try {
          return tables.get(i).getAccessor();
        }
        catch (Throwable forward) {
          throw new RuntimeException(forward);
        }
      }
    }, accessors);
    final MultiJoinFilter filter = new MultiJoinFilter().init("", names, accessors, 0);
    if (wherePart != null) {
      filter.setRowFilter(computeRowFilter(wherePart, filter.getMetaData()));
    }
    TableAccessor accessor = filter.getAccessor();
    if (select.groupbyPart != null || select.havingPart != null || select.selectionPart.isWithGroupElements()) {
      final MetaData metadata = accessor.getMetaData();
      final MemoryGroupBy groupBy = new MemoryGroupBy().init("", metadata);
      int currentOPE = 0;
      if (select.groupbyPart != null) {
        for (final SELECT_ELEMENT element : select.groupbyPart.getElements()) {
          currentOPE++;
          //groupBy.addColumn(element.toString());
          final OPERATION_SELECT_ELEMENT operationElement = (OPERATION_SELECT_ELEMENT)element;
          final Operation operation = operationElement.getOperation(StringUtil.NVL(operationElement.getName(), "COLUMN_"+currentOPE), metadata);
          if (operation != null) {
            groupBy.addColumn(operation);
          }
        }
      }
      for (final SELECT_ELEMENT element : select.selectionPart.getGroupElements()) {
        currentOPE++;
        final OPERATION_SELECT_ELEMENT operationElement = (OPERATION_SELECT_ELEMENT)element;
        final Operation groupByOperation = operationElement.getGroupOperation(StringUtil.NVL(operationElement.getName(), "COLUMN_"+currentOPE), metadata);
        if (groupByOperation != null) {
          groupBy.addOperation(groupByOperation);
        }
      }
      if (select.havingPart != null) {
        groupBy.addOperation(select.havingPart.getTest().getGroupOperation(HAVINGPARTOPERATIONVIRTUALCOLUMN, metadata));
      }
      groupBy.compute();
//      DatabaseUtil.copy(accessor, groupBy);
      while (accessor.hasNext()) { 
        groupBy.insert(accessor.getNext()); 
      }
      accessor.close();
      accessor = groupBy.getAccessor();
      final TableAccessor groupByAccessor = accessor;
      if (select.havingPart != null) {
        //new SimpleTable()
        //final MultiJoinFilter filter2 = new MultiJoinFilter().init("", names, accessor);
        final WHERE_TEST havingPart = (select.havingPart == null ? null : select.havingPart.getTest());
        final RowFilterRule havingFilter = computeHavingRowFilter(havingPart, metadata);
        accessor = new RowFilter() {

          @Override
          protected boolean check(Row row) {
            return havingFilter.check(row);
          }
        }.applyOn(groupByAccessor);
      }
      //TableAccessor accessor = filter.getAccessor();
      
    }
    if (select.selectionPart.isAllSelect()) {
      if (select.orderBy != null) {
        final MetaData metaData = accessor.getMetaData();
        final RowComparator comparator = computeOrderBy(metaData, select.orderBy);
        if (comparator != null) {
          final MemoryTable orderByTable = new MemoryTable(null, metaData, comparator);
          DatabaseUtil.copyAndClone(accessor, orderByTable);
          accessor.close();
          accessor = orderByTable.getAccessor();
        }
      }
      return accessor;
    }
    final MetaData metaData = accessor.getMetaData();
    final OperationColumnFilter columnFilter = new OperationColumnFilter(metaData);
    int currentOPE = 0;
    for (final SELECT_ELEMENT element : select.selectionPart.getElements()) {
      currentOPE++;
      columnFilter.add(element.getOperation(StringUtil.NVL(element.getName(),  "COLUMN_"+currentOPE), metaData));
    }
    accessor = new TableAccessorFilter(accessor, columnFilter);
    if (select.orderBy != null) {
      final MetaData metaData2 = accessor.getMetaData();
      final RowComparator comparator = computeOrderBy(metaData2, select.orderBy);
      if (comparator != null) {
        final MemoryTable orderByTable = new MemoryTable(null, metaData2, comparator);
        DatabaseUtil.copyAndClone(accessor, orderByTable);
        accessor.close();
        accessor = orderByTable.getAccessor();
      }
    }
    return accessor;
  }
  
  public RowComparator computeOrderBy(final MetaData metaData, final ORDERBY_PART orderBy) {
    final List<ORDERBY_COLUMN> columns = orderBy.getElements();
    final int n = columns.size();
    if (n <= 0) return null;
    final int[] sort = new int[n];
    for (int j = 0; j < n; j++) {
      final ORDERBY_COLUMN column = columns.get(j);
      final int i;
      if (column instanceof INDEX_ORDER_COLUMN) {
        i = ((INDEX_ORDER_COLUMN)column).getIndex(); 
      }
      else {
        i = metaData.getColumnIndex(((ORDER_COLUMN)column).getFullName());
      }
      sort[j] = (column.isDesc()) ? -i : i;
    }
    return new RowComparator(metaData, sort);
  }
  
  /*public static RowFilterRule computeRowFilter(final boolean constant, final TABLE table, final WHERE_TEST wherePart, final MetaData metaData) throws Throwable {
    if (wherePart == null) return RowFilterRule.referenceTrue;
    return RowFilterRule.referenceTrue;
  }*/
  
  public static Table computeTableFilter(final Table table, final WHERE_TEST wherePart) {
    return table;
  }

  public static RowFilterRule computeHavingRowFilter(final WHERE_TEST wherePart, final MetaData metaData) throws Throwable {
    if (wherePart == null) return RowFilterRule.referenceTrue;
    return new RowFilterRule() {

      public boolean check(Row row) {
        return row.getAsBoolean(HAVINGPARTOPERATIONVIRTUALCOLUMN).booleanValue();
      }
    };
  }

  public static RowFilterRule computeRowFilter(final WHERE_TEST wherePart, final MetaData metaData) throws Throwable {
    if (wherePart == null) return RowFilterRule.referenceTrue;
    final Operation operation = wherePart.getOperation(null, metaData);
    if (operation == null) return RowFilterRule.referenceTrue;
    return new RowFilterRule() {

      public boolean check(Row row) {
        final DatabaseValue value = operation.process(row, null);
        return value.getbooleanValue();
      }
    };
  }

  public Class<SELECT> getImplClass() {
    return SELECT.class;
  }
  
  private static final String HAVINGPARTOPERATIONVIRTUALCOLUMN = "HAVINGPARTOPERATIONVIRTUALCOLUMN";
}
package org.openknows.jdbc.driver.unisql.jdbc;


import com.easyrms.util.*;

import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;

public class JDBCResultSetMetaData implements ResultSetMetaData {
  
  JDBCResultSetMetaData(MetaData metaData) {
   this.metaData = metaData;
  }

  public int getColumnCount() throws SQLException {
    return this.metaData.getColumnCount();
  }

  public boolean isAutoIncrement(int column) throws SQLException {
    return false;
  }

  public boolean isCaseSensitive(int column) throws SQLException {
    return false;
  }

  public boolean isSearchable(int column) throws SQLException {
    return false;
  }

  public boolean isCurrency(int column) throws SQLException {
    return false;
  }

  public int isNullable(int column) throws SQLException {
    return 0;
  }

  public boolean isSigned(int column) throws SQLException {
    return false;
  }

  public int getColumnDisplaySize(int column) throws SQLException {
    return 0;
  }

  public String getColumnLabel(int column) throws SQLException {
    return metaData.getColumn(column).getDescription();
  }

  public String getColumnName(int column) throws SQLException {
    return metaData.getColumn(column).getName();
  }

  public String getSchemaName(int column) throws SQLException {
    return null;
  }

  public int getPrecision(int column) throws SQLException {
    switch (metaData.getColumn(column).getType()) {
      case DOUBLE : return doublePrecision;
      case LONG : return longPrecision;
      case STRING : return stringPrecision;
      default : return 0;
    }
  }
  
  private static final int doublePrecision = MathUtils.getDouble(Double.MAX_VALUE).toString().length();
  private static final int longPrecision = LongCache.get(Long.MAX_VALUE).toString().length();
  private static final int stringPrecision = Integer.MAX_VALUE;

  public int getScale(int column) throws SQLException {
    switch (metaData.getColumn(column).getType()) {
      case DOUBLE : return 8;
      default : return 0;
    }
  }

  public String getTableName(int column) throws SQLException {
    return null;
  }

  public String getCatalogName(int column) throws SQLException {
    return null;
  }

  public int getColumnType(int column) throws SQLException {
    switch (metaData.getColumn(column).getType()) {
      case LONG : return Types.BIGINT;
      case DOUBLE : return Types.DOUBLE;
      case STRING : return Types.LONGNVARCHAR;
      case DATE : return Types.TIMESTAMP;
      case BOOLEAN : return Types.BOOLEAN;
      default : throw new IllegalArgumentException("Unknown Type "+metaData.getColumn(column).getType().getName());
    }
  }

  public String getColumnTypeName(int column) throws SQLException {
    return null;
  }

  public boolean isReadOnly(int column) throws SQLException {
    return false;
  }

  public boolean isWritable(int column) throws SQLException {
    return false;
  }

  public boolean isDefinitelyWritable(int column) throws SQLException {
    return false;
  }

  public String getColumnClassName(int column) throws SQLException {
    return null;
  }
  
  private MetaData metaData;

  public boolean isWrapperFor(Class<?> iface) throws SQLException {
    return false;
  }

  public <T> T unwrap(Class<T> iface) throws SQLException {
    return null;
  }

}

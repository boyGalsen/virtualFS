package org.openknows.jdbc.driver.unisql.jdbc;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import org.openknows.jdbc.driver.pool.*;
import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;
import org.openknows.jdbc.driver.unisql.sql.REGISTER;


public class RegisterDecoderPart implements JDBCDecoderPart<REGISTER> {
  
  public RegisterDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }
  
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final REGISTER executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase(); 
    final ResultSet resultSet = null;
    final int updateCount = internalCompile(database, executable);
    return new JDBCDecoderResult() {

      public MetaData getMetaData() { return null; }
      public PreparedStatement getPreparedStatement() { return null; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return false;}

    };
  }

  public MetaData getMetaData(final REGISTER executable) throws Throwable {
    return null;
  }

  public int internalCompile(final MemoryDatabase database, final REGISTER set) throws Throwable {
    try {
      final Properties properties = new Properties();
      properties.put("user", set.user);
      properties.put("password", set.password);
      PoolDriverConnectionDriver.addDataSource(set.name, set.driver, set.url, properties);
      return 1;
    }
    catch (Throwable ignored) {
      throw ignored;
    }
  }

  public Class<REGISTER> getImplClass() {
    return REGISTER.class;
  }
}
package org.openknows.jdbc.driver.unisql.jdbc;


import com.easyrms.util.*;
import com.easyrms.util.executor.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;
import org.openknows.jdbc.driver.unisql.memory.MemoryTable;
import org.openknows.jdbc.driver.unisql.sql.SELECT_LIST;

public class SelectListDecoderPart implements JDBCDecoderPart<SELECT_LIST> {
  
  public SelectListDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
    this.selectDecoderPart = new SelectDecoderPart(decoder);
  }
  
  private final SelectDecoderPart selectDecoderPart;
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final SELECT_LIST executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase();
    final TableAccessor accessor = compileAccessor(database, executable);
    final ResultSet resultSet = new JDBCResultSet(accessor);
    final MetaData metaData = accessor.getMetaData();
    final int updateCount = -1;
    return new JDBCDecoderResult() {

      public PreparedStatement getPreparedStatement() { return null; }
      public MetaData getMetaData() { return metaData; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return true;}
    };
  }

  public MetaData getMetaData(final SELECT_LIST executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase();
    return compileAccessor(database, executable).getMetaData();
  }

  public TableAccessor compileAccessor(final MemoryDatabase database, final SELECT_LIST select) throws Throwable {
    final int tableSize = select.size();
    if (tableSize <= 0) throw new IllegalArgumentException();
    final EzArray<TableAccessor> accessors = EzPoolExecutor.DEFAULT.call(
        new EzCallableTaskArray<TableAccessor>("selectListDecoderPartAccessor", tableSize) {

        @Override
        public String description(int i) {
          return "byTable";
        }

        @Override
        public void fillContext(int i, EzTaskContext context) {
        }

        @Override
        public TableAccessor call(int i) {
          try {
            return selectDecoderPart.compileAccessor(database, select.get(i));
          }
          catch (Throwable forward) {
            throw new RuntimeException(forward);
          }
        }
      }); 
    if (tableSize == 1) return accessors.get(0);
    try {
      final MetaData metaData = accessors.get(0).getMetaData();
      final MemoryTable combinedTable = new MemoryTable(null, metaData, null);
      for (int i = 1; i < tableSize; i++) {
        final MetaData currentMetadata = accessors.get(i).getMetaData();
        if (metaData.getColumnCount() != currentMetadata.getColumnCount()) throw new IllegalArgumentException("waiting "+metaData.getColumnCount());
      }
      DatabaseUtil.copyAndClone(accessors, combinedTable);
      return combinedTable.getAccessor();
    }
    finally {
      EzPoolExecutor.DEFAULT.call(
        new EzCallableTaskArray<Void>("selectListDecoderPartClose", tableSize) {

        @Override
        public String description(int i) {
          return "byTable";
        }

        @Override
        public void fillContext(int i, EzTaskContext context) {
        }

        @Override
        public Void call(int i) {
          try {
            accessors.get(i).close();
            return null;
          }
          catch (Throwable forward) {
            throw new RuntimeException(forward);
          }
        }
      });
    }
  }
  
  public Class<SELECT_LIST> getImplClass() {
    return SELECT_LIST.class;
  }
}
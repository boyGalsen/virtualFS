package org.openknows.jdbc.driver.unisql.jdbc;


import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;


public class ActivateDecoderPart implements JDBCDecoderPart<ACTIVATE> {
  
  public ActivateDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }
  
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final ACTIVATE executable) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase(); 
    final ResultSet resultSet = null;
    final int updateCount = internalCompile(database, executable);
    return new JDBCDecoderResult() {

      public MetaData getMetaData() { return null; }
      public PreparedStatement getPreparedStatement() { return null; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return false;}

    };
  }

  public MetaData getMetaData(final ACTIVATE executable) throws Throwable {
    return null;
  }

  public int internalCompile(final MemoryDatabase database, final ACTIVATE set) throws Throwable {
    try {
      switch (set.type) {
        case ACTIVATE.MANAGER : {
          final String name = set.parameters.get(0);
          return JDBCConnectionDriver.getReference().getAtManager().register(name, JDBCConnectionDriver.getParameters()) ? 1 : 0;
        }
        case ACTIVATE.FUNCTION : {
          final String name = set.parameters.get(0);
          return JDBCConnectionDriver.getReference().getFunctionManager().register(name, JDBCConnectionDriver.getParameters()) ? 1 : 0;
        }
        case ACTIVATE.MEMO :
        default : 
      }
      return 0;
    }
    catch (Throwable ignored) {
      throw ignored;
    }
  }

  public Class<ACTIVATE> getImplClass() {
    return ACTIVATE.class;
  }
}
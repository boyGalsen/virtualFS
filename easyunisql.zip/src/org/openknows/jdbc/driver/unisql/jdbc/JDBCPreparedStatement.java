package org.openknows.jdbc.driver.unisql.jdbc;


import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.io.*;
import java.math.*;
import java.net.*;
import java.sql.*;
import java.sql.Date;
import java.util.*;

import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;
import org.openknows.jdbc.driver.unisql.sql.parser.*;


public class JDBCPreparedStatement implements PreparedStatement {
  
  private final JDBCConnection connection;
  private final String sqlRequest;
  private final EXECUTABLE request;
  private final ResultSetMetaData metaData;
  private final ParameterMetaData parameterMetaData;
  private ResultSet resultSet;
  private int updateCount;
  private final IntObjectMap<Object> parameters = new IntObjectMap<Object>();
  private final JDBCStatement statement;
  
  JDBCPreparedStatement(final JDBCConnection connection, final String sqlRequest) throws SQLException {
    this.connection = connection;
    this.sqlRequest = sqlRequest;
    this.statement = new JDBCStatement(connection);
    EXECUTABLE request = null;
    try {
      request = parser.compute(connection.getDatabase().getDriver(), this.sqlRequest);
    }
    catch (Throwable ignored) {
    }
    this.request = request;
    try {
      this.parameterMetaData = connection.getRequestCompiler().compileParameterMetaData(this.request);
      this.metaData = (request instanceof SELECT) 
        ? new JDBCResultSetMetaData(connection.getRequestCompiler().compileMetaData(this.request)) 
        : new JDBCResultSet(SimpleMemoryTable.emptyTable.getAccessor()).getMetaDataAndClose();
    }
    catch (Throwable ignored) {
      throw new SQLException(ExceptionUtils.getMessage(ignored));
    }
  }

  public void addBatch() throws SQLException {}

  public void clearParameters() throws SQLException {
    parameters.clear();
  }

  public boolean execute() throws SQLException {
    resultSet = null;
    updateCount = 0;
    try {
      statement.setParameters(parameters);
      final boolean result = statement.execute(sqlRequest);
      updateCount = statement.getUpdateCount();
      resultSet = statement.getResultSet();
      return result;
    }
    catch (Throwable ignored) {
      resultSet = null;
      updateCount = 0;
      return false;
    }
  }

  public ResultSet executeQuery() throws SQLException {
    execute();
    return getResultSet();
  }

  public int executeUpdate() throws SQLException {
    execute();
    return getUpdateCount();
  }

  public ResultSetMetaData getMetaData() throws SQLException {
    return metaData;
  }

  public ParameterMetaData getParameterMetaData() throws SQLException {
    return parameterMetaData;
  }

  public void setArray(int i, Array x) throws SQLException {}

  public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
    parameters.put(parameterIndex, LongCache.get(x.intValue()));
  }

  public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBlob(int i, Blob x) throws SQLException {}

  public void setBoolean(int parameterIndex, boolean x) throws SQLException {
    parameters.put(parameterIndex, Boolean.valueOf(x));
  }

  public void setByte(int parameterIndex, byte x) throws SQLException {
    parameters.put(parameterIndex, new String(new byte[]{x,}));
  }

  public void setBytes(int parameterIndex, byte[] x) throws SQLException {
    parameters.put(parameterIndex, new String(x));
  }

  public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setClob(int i, Clob x) throws SQLException {}

  public void setDate(int parameterIndex, Date x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setDouble(int parameterIndex, double x) throws SQLException {
    parameters.put(parameterIndex, new Double(x));
  }

  public void setFloat(int parameterIndex, float x) throws SQLException {
    parameters.put(parameterIndex, new Double(x));
  }

  public void setInt(int parameterIndex, int x) throws SQLException {
    parameters.put(parameterIndex, IntegerCache.get(x));
  }

  public void setLong(int parameterIndex, long x) throws SQLException {
    parameters.put(parameterIndex, LongCache.get(x));
  }

  public void setNull(int parameterIndex, int sqlType) throws SQLException {
    parameters.put(parameterIndex, null);
  }

  public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
    parameters.put(parameterIndex, null);
  }

  public void setObject(int parameterIndex, Object x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setRef(int i, Ref x) throws SQLException {}

  public void setShort(int parameterIndex, short x) throws SQLException {
    parameters.put(parameterIndex, IntegerCache.get(x));
  }

  public void setString(int parameterIndex, String x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTime(int parameterIndex, Time x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setURL(int parameterIndex, URL x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void addBatch(String sql) throws SQLException {}

  public void cancel() throws SQLException {}

  public void clearBatch() throws SQLException {}

  public void clearWarnings() throws SQLException {}

  public void close() throws SQLException {}

  public boolean execute(String sql) throws SQLException {
    final JDBCStatement statement = new JDBCStatement(connection).setParameters(parameters);
    final boolean result = statement.execute(sql);
    this.updateCount = statement.getUpdateCount();
    this.resultSet = statement.getResultSet();
    return result;
  }

  public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
    final JDBCStatement statement = new JDBCStatement(connection).setParameters(parameters);
    final boolean result = statement.execute(sql, autoGeneratedKeys);
    this.updateCount = statement.getUpdateCount();
    this.resultSet = statement.getResultSet();
    return result;
  }

  public boolean execute(String sql, int[] columnIndexes) throws SQLException {
    final JDBCStatement statement = new JDBCStatement(connection).setParameters(parameters);
    final boolean result = statement.execute(sql, columnIndexes);
    this.updateCount = statement.getUpdateCount();
    this.resultSet = statement.getResultSet();
    return result;
  }

  public boolean execute(String sql, String[] columnNames) throws SQLException {
    final JDBCStatement statement = new JDBCStatement(connection).setParameters(parameters);
    final boolean result = statement.execute(sql, columnNames);
    this.updateCount = statement.getUpdateCount();
    this.resultSet = statement.getResultSet();
    return result;
  }

  public int[] executeBatch() throws SQLException {
    return null;
  }

  public ResultSet executeQuery(String sql) throws SQLException {
    return new JDBCStatement(connection).setParameters(parameters).executeQuery(sql);  
  }

  public int executeUpdate(String sql) throws SQLException {
    return new JDBCStatement(connection).setParameters(parameters).executeUpdate(sql);  
  }

  public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
    return new JDBCStatement(connection).setParameters(parameters).executeUpdate(sql, autoGeneratedKeys);  
  }

  public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
    return new JDBCStatement(connection).setParameters(parameters).executeUpdate(sql, columnIndexes);  
  }

  public int executeUpdate(String sql, String[] columnNames) throws SQLException {
    return new JDBCStatement(connection).setParameters(parameters).executeUpdate(sql, columnNames);  
  }

  public Connection getConnection() throws SQLException {
    return connection;
  }

  public int getFetchDirection() throws SQLException {
    return 0;
  }

  public int getFetchSize() throws SQLException {
    return 0;
  }

  public ResultSet getGeneratedKeys() throws SQLException {
    return null;
  }

  public int getMaxFieldSize() throws SQLException {
    return 0;
  }

  public int getMaxRows() throws SQLException {
    return 0;
  }

  public boolean getMoreResults() throws SQLException {
    return false;
  }

  public boolean getMoreResults(int current) throws SQLException {
    return false;
  }

  public int getQueryTimeout() throws SQLException {
    return 0;
  }

  public ResultSet getResultSet() throws SQLException {
    return resultSet;
  }

  public int getResultSetConcurrency() throws SQLException {
    return 0;
  }

  public int getResultSetHoldability() throws SQLException {
    return 0;
  }

  public int getResultSetType() throws SQLException {
    return 0;
  }

  public int getUpdateCount() throws SQLException {
    return updateCount;
  }

  public SQLWarning getWarnings() throws SQLException {
    return null;
  }

  public void setCursorName(String name) throws SQLException {}

  public void setEscapeProcessing(boolean enable) throws SQLException {}

  public void setFetchDirection(int direction) throws SQLException {}

  public void setFetchSize(int rows) throws SQLException {}

  public void setMaxFieldSize(int max) throws SQLException {}

  public void setMaxRows(int max) throws SQLException {}

  public void setQueryTimeout(int seconds) throws SQLException {}

  public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {}

  public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {}

  public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setClob(int parameterIndex, Reader reader) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(value));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(value));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNClob(int parameterIndex, NClob value) throws SQLException {}

  public void setNClob(int parameterIndex, Reader reader) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNString(int parameterIndex, String value) throws SQLException {
    try {
      parameters.put(parameterIndex, value);
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setRowId(int parameterIndex, RowId x) throws SQLException {}

  public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {}

  public boolean isClosed() throws SQLException { return false; }
  public boolean isPoolable() throws SQLException { return false; }
  public void setPoolable(boolean poolable) throws SQLException {}
  public boolean isWrapperFor(Class<?> iface) throws SQLException { return false; }
  public <T> T unwrap(Class<T> iface) throws SQLException { return null; }

  public void closeOnCompletion() throws SQLException {}

  public boolean isCloseOnCompletion() throws SQLException {
    return false;
  }
  
  
}
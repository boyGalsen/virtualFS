package org.openknows.jdbc.driver.unisql.jdbc;


import com.easyrms.cache.*;
import com.easyrms.util.*;
import com.easyrms.util.preferences.*;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.logging.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.function.*;

public class JDBCConnectionDriver implements Driver {
  
  
  private static final String defaultProperties = ""
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.tsv.TSVAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.csv.CSVAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.dbf.DBFAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.diamon.DiamonAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.command.CommandAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.excel.ExcelAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.sqlxml.SQLXMLAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.memory.MemoryAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.memo.MemoAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.jdbc.driver.unisql.multiplex.MultiplexAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.interfaces.fols.FolsStatAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.org.openknows.interfaces.opera.OperaReportAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.com.easyrms.db.unisql.database.ez.EzAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.AtManagerController.com.easyrms.db.unisql.database.ezmemo.EzServerAtManager=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.AbsOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.AddFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.AvgFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.CountFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.DecodeOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.DivisedFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.GreatestOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.LowestOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.MaxFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.MinFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.MultiplyFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.NVLOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.TrimOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.LowerCaseOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.UpperCaseOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.RemoveFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.SumFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.VarianceFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.StdFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.Std2FunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.MedianFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.KurtosisOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.SkeenessOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.org.openknows.jdbc.driver.unisql.sql.function.CovarianceFunctionOperation=true\r\n"
      +"org.openknows.jdbc.driver.unisql.memo.MemoAtManager.org.openknows.jdbc.driver.unisql.memo.SimpleMemoLet=/system\r\n"
      +"org.openknows.jdbc.driver.unisql.memo.MemoAtManager.com.ezrms.uniws.RestMemoLet=/ezrms\r\n";

  private static Parameters parameters;
  static  {
    final Properties defaultProperties = new Properties(System.getProperties());
    try (final Reader input = new StringReader(JDBCConnectionDriver.defaultProperties)) {
      try {
        defaultProperties.load(input);
      }
      finally {
        input.close();
      }
    }
    catch (Exception ignored) {
    }
    try (final InputStream input = ParametersUtil.class.getClassLoader().getResourceAsStream("unisql.properties")) {
      try {
         final Properties properties = new Properties(defaultProperties);
         properties.load(input);
         parameters = ParametersUtil.valueOf(properties);
      }
      finally {
        input.close();
      }
    }
    catch (Exception ignored) {
      parameters = ParametersUtil.valueOf(defaultProperties);
    }
  }
  public static Parameters getParameters() {
    return parameters;
  }

  private static JDBCConnectionDriver reference;
  
  public static void register() {
    getReference();
  }
  
  public static synchronized JDBCConnectionDriver getReference() {
    if (reference == null) {
      reference = new JDBCConnectionDriver();
    }
    return reference;
  } 
  
  public static final String URL_PREFIX = "jdbc:unisql:";
  private static final int MAJOR_VERSION = 1;
  private static final int MINOR_VERSION = 1;

  public JDBCConnectionDriver() {
    atManager = new AtManagerController();
    final Parameters parameters = getParameters();
    for (final ParametersTuple parameter : parameters) {
      final String key = parameter.getParameter();
      if (key.startsWith("org.openknows.jdbc.driver.unisql.AtManagerController.")) {
        try {
          if (ParametersUtil.getBoolean(parameters, key, false)) {
            atManager.register(key.substring("org.openknows.jdbc.driver.unisql.AtManagerController.".length()), parameters);
          }
        }
        catch (Throwable ignored) {
          System.err.println(key);
          EasyRMS.trace.log(ignored);
        }
      }
    }
     
    functionManager = new FunctionOperationManager();
    for (final ParametersTuple parameter : parameters) {
      final String key = parameter.getParameter();
      if (key.startsWith("org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.")) {
        try {
          if (ParametersUtil.getBoolean(parameters, key, false)) {
            functionManager.register((FunctionOperation)Class.forName(key.substring("org.openknows.jdbc.driver.unisql.sql.function.FunctionOperationManager.".length())).newInstance(), parameters);
          }
        }
        catch (Throwable ignored) {
          System.err.println(key);
          EasyRMS.trace.log(ignored);
        }
      }
    }
    /*functionManager.register(new NVLOperation());
    functionManager.register(new DecodeOperation());
    functionManager.register(new GreatestOperation());
    functionManager.register(new LowestOperation());

    functionManager.register(new CountFunctionOperation());
    functionManager.register(new SumFunctionOperation());
    functionManager.register(new MinFunctionOperation());
    functionManager.register(new MaxFunctionOperation());
    functionManager.register(new AvgFunctionOperation());

    functionManager.register(new AbsOperation());
    functionManager.register(new AddFunctionOperation());
    functionManager.register(new RemoveFunctionOperation());
    functionManager.register(new DivisedFunctionOperation());
    functionManager.register(new MultiplyFunctionOperation());*/
    try  {
      DriverManager.registerDriver(this);
    }
    catch (Throwable ignored) {
    }
  }
  
  public FunctionOperationManager getFunctionManager() {
    return functionManager;
  }

  public AtManagerController getAtManager() {
    return atManager;
  }

  public Connection connect(String url, Properties props) throws SQLException {
    if (!url.startsWith(URL_PREFIX)) { return null; }
    final String name = url.substring(URL_PREFIX.length());
    return new JDBCConnection(databases.get(name));
  }

  public boolean acceptsURL(String url) {
    return url.startsWith(URL_PREFIX);
  }

  public int getMajorVersion() {
    return MAJOR_VERSION;
  }

  public int getMinorVersion() {
    return MINOR_VERSION;
  }

  public DriverPropertyInfo[] getPropertyInfo(String str, Properties props) {
    return new DriverPropertyInfo[0];
  }

  public boolean jdbcCompliant() {
    return false;
  }
  
  private final AtManagerController atManager;
  private final FunctionOperationManager functionManager;
  
  private final Cache<String, MemoryDatabase> databases = Caches.newCacheInstance(new Creator<String, MemoryDatabase>(){

    public MemoryDatabase create(final String key) {
      try {
        return new MemoryDatabase(JDBCConnectionDriver.this, key);
      }
      catch (final Throwable ignored) {
      }
      return null;
    }
  });

  public Logger getParentLogger() throws SQLFeatureNotSupportedException {
    throw new SQLFeatureNotSupportedException("Not Available");
  }
  
  
}
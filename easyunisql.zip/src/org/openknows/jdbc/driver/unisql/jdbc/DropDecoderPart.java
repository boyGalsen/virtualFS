package org.openknows.jdbc.driver.unisql.jdbc;


import java.sql.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;


public class DropDecoderPart implements JDBCDecoderPart<DROP_TABLE_AS> {
  
  public DropDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }
  
  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final DROP_TABLE_AS create) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase(); 
    final ResultSet resultSet = null;
    final int updateCount = internalCompile(database, create);
    return new JDBCDecoderResult() {

      public MetaData getMetaData() { return null; }
      public PreparedStatement getPreparedStatement() { return null; }
      public ResultSet getResultSet() { return resultSet; }
      public int getUpdateCount() { return updateCount; }
      public boolean isSelect() { return false;}
    };
  }

  public MetaData getMetaData(final DROP_TABLE_AS executable) throws Throwable {
    return null;
  }

  public int internalCompile(final MemoryDatabase database, final DROP_TABLE_AS drop) throws Throwable {
    final TABLE table = drop.getTable();
    boolean isDroped;
    if (table instanceof AT_TABLE) {
      final AT_TABLE excelTable = (AT_TABLE)table;
      isDroped = database.getDriver().getAtManager().drop(database, excelTable);
    }
    else if (table instanceof SIMPLE_TABLE) {
      final SIMPLE_TABLE jdbcTable = (SIMPLE_TABLE)table;
      isDroped = database.remove(jdbcTable.getCatalog(), jdbcTable.getTable());
    }
    else if (table instanceof BASE_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else if (table instanceof JDBC_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else {
      return 0;
    }
    return isDroped ? 1 : 0;
  }

  public Class<DROP_TABLE_AS> getImplClass() {
    return DROP_TABLE_AS.class;
  }
}
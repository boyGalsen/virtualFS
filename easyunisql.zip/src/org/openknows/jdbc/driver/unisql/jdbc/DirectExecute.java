package org.openknows.jdbc.driver.unisql.jdbc;

import org.openknows.jdbc.driver.unisql.*;

public final class DirectExecute {

  public static JDBCResultSet toResultSet(TableAccessor accessor) {
    return new JDBCResultSet(accessor);
  }
}

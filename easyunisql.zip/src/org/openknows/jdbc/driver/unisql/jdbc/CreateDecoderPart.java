package org.openknows.jdbc.driver.unisql.jdbc;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;
import org.openknows.jdbc.driver.unisql.sql.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;

public class CreateDecoderPart implements JDBCDecoderPart<CREATE_TABLE_AS> {

  public CreateDecoderPart(final JDBCRequestDecoder decoder) {
    this.decoder = decoder;
  }

  private final JDBCRequestDecoder decoder;

  public JDBCDecoderResult compile(final CREATE_TABLE_AS create) throws Throwable {
    final MemoryDatabase database = decoder.getDatabase();
    final ResultSet resultSet = JDBCUtil.noResultSet;
    final int updateCount = internalCompile(database, create);
    return new JDBCDecoderResult() {

      public MetaData getMetaData() {
        return JDBCUtil.noMetaData;
      }

      public PreparedStatement getPreparedStatement() {
        return null;
      }

      public ResultSet getResultSet() {
        return resultSet;
      }

      public int getUpdateCount() {
        return updateCount;
      }

      public boolean isSelect() {
        return false;
      }
    };
  }

  public MetaData getMetaData(final CREATE_TABLE_AS executable) throws Throwable {
    return null;
  }

  public int internalCompile(final MemoryDatabase database, final CREATE_TABLE_AS create) throws Throwable {
    final SelectDecoderPart part = new SelectDecoderPart(decoder);
    TableAccessor result = part.compileAccessor(database, create.getSELECT());
    final MetaData metaData = result.getMetaData();
    final TABLE table = create.getTable();
    final org.openknows.jdbc.driver.unisql.Table outTable;
    if (table instanceof AT_TABLE) {
      final AT_TABLE excelTable = (AT_TABLE)table;
      outTable = database.getDriver().getAtManager().create(database, excelTable, metaData);// new ExcelFileTable().init(new File(excelTable.getFile()),
    }
    else if (table instanceof SIMPLE_TABLE) {
      final SIMPLE_TABLE memTable = (SIMPLE_TABLE)table;
      final TableMetaData newmetaData = new TableMetaData();
      final HashSet<String> columnNames = new HashSet<String>();
      for (int i = 1, n = metaData.getColumnCount(); i <= n; i++) {
        final Column mI = metaData.getColumn(i);
        final String description = mI.getDescription();
        final String finalName = !columnNames.contains(description)
          ? description
          : mI.getName();
        newmetaData.add(Column.getAndInit(finalName, description, mI.getType()));
      }
      final MemoryTable memOutTable = new MemoryTable(memTable.getTable(), newmetaData, null);
      database.add(memTable.getCatalog(), memOutTable);
      outTable = memOutTable;// /AtManagerController.create(excelTable, metaData);//new ExcelFileTable().init(new File(excelTable.getFile()),
                              // excelTable.getName());
      // database.add(decoder.getDatabase().catalog, fileTable);
    }
    else if (table instanceof BASE_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else if (table instanceof JDBC_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else if (table instanceof TEMP_TABLE) {
      throw new UnsupportedOperationException("Not Implemented Yet");
    }
    else {
      return 0;
    }
    final InsertTableAccessor insert = outTable.getInsertAccessor();
    int insertCount = 0;
    try {
      final int n = metaData.getColumnCount();
      while (result.hasNext()) {
        final Row row = result.getNext();
        final DatabaseValue[] values = new DatabaseValue[n];
        for (int i = 1; i <= n; i++) {
          values[i - 1] = row.getDatabaseValue(i);
        }
        insert.insert(values);
        insertCount++;
      }
    }
    finally {
      insert.close();
      result.close();
    }
    return insertCount;
  }

  public Class<CREATE_TABLE_AS> getImplClass() {
    return CREATE_TABLE_AS.class;
  }
}
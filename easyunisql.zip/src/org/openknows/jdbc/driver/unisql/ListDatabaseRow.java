package org.openknows.jdbc.driver.unisql;

import java.util.List;

public class ListDatabaseRow extends AbstractDatabaseRow {
  
  public Row init(final MetaData metadata, final List<DatabaseValue> values) {
    super.init(metadata);
    this.values = values.toArray(new DatabaseValue[values.size()]);
    return this;
  }
  
	public Row init(final MetaData metadata, final DatabaseValue[] values) {
		super.init(metadata);
    final int n = values.length;
		this.values = new DatabaseValue[n];
    System.arraycopy(values, 0, this.values, 0, n);
    return this;
	}
  
  @Override
  public DatabaseValue getDatabaseValue(final int index) {
    return values[index-1];
  }
  
  private DatabaseValue[] values;
}

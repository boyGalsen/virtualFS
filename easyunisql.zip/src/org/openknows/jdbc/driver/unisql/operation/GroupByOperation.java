package org.openknows.jdbc.driver.unisql.operation;

import org.openknows.jdbc.driver.unisql.*;


public abstract class GroupByOperation extends Operation {
  
  public GroupByOperation(final String name, final ColumnType type) {
    super (name, type);
    this.rowIndex = -1;
  }

  public GroupByOperation(final String name, final ColumnType type, final String rowName, final MetaData metaData) {
    super (name, type);
    this.rowIndex = metaData.getColumnIndex(rowName);
  }
  
  public GroupByOperation(final String name, final ColumnType type, final int rowIndex, final MetaData metaData) {
    super (name, type);
    this.rowIndex = rowIndex;
  }
  
  protected final int rowIndex;
}

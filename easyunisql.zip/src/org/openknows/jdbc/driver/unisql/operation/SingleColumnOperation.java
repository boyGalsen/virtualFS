package org.openknows.jdbc.driver.unisql.operation;

import org.openknows.jdbc.driver.unisql.*;

public abstract class SingleColumnOperation extends Operation {

  public SingleColumnOperation(MetaData metadata, int index, String renamedName, ColumnType type) {
    this(metadata, metadata.getColumn(index), renamedName, type);
  }

  public SingleColumnOperation(MetaData metadata, int index, String renamedName) {
    this(metadata, metadata.getColumn(index), renamedName);
  }

  public SingleColumnOperation(MetaData metadata, int index, ColumnType type) {
    this(metadata, metadata.getColumn(index), type);
  }

  public SingleColumnOperation(MetaData metadata, int index) {
    this(metadata, metadata.getColumn(index));
  }

  public SingleColumnOperation(MetaData metadata, String columnName, String renamedName, ColumnType type) {
    this(metadata, metadata.findColumnByName(columnName), renamedName, type);
  }

  public SingleColumnOperation(MetaData metadata, String columnName, String renamedName) {
    this(metadata, metadata.findColumnByName(columnName), renamedName);
  }

  public SingleColumnOperation(MetaData metadata, String columnName, ColumnType type) {
    this(metadata, metadata.findColumnByName(columnName), type);
  }

  public SingleColumnOperation(MetaData metadata, String columnName) {
    this(metadata, metadata.findColumnByName(columnName));
  }

  public SingleColumnOperation(MetaData metadata, Column column) {
    this(metadata, column, column.getName(), column.getType());
  }

  public SingleColumnOperation(MetaData metadata, Column column, ColumnType type) {
    this(metadata, column, column.getName(), type);
  }

  public SingleColumnOperation(MetaData metadata, Column column, String name) {
    this(metadata, column, name, column.getType());
  }

  public SingleColumnOperation(MetaData metadata, Column column, String name, ColumnType type) {
    super(name, type);
    this.columnIndex = metadata.getColumnIndex(column);
  }

  protected int getColumnIndex() {
    return this.columnIndex;
  }

  private final int columnIndex;
}

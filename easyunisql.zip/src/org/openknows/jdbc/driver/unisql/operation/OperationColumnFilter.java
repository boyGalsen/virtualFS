package org.openknows.jdbc.driver.unisql.operation;

import com.easyrms.util.*;

import java.util.*;

import org.openknows.jdbc.driver.unisql.*;

public class OperationColumnFilter implements Row {

  public OperationColumnFilter(MetaData fromMetaData) {
    this.metaData = new TableMetaData();
  }

  public int getElementCount() {
    return this.metaData.getColumnCount();
  }

  public void add(final Operation operation) {
    this.metaData.add(Column.getAndInit(StringUtil.NVL(operation.getName(), "COLUMN_" + (this.operations.size() + 1)), operation.getType()));
    this.operations.add(operation);
  }

  private void compute() {
    if (this.values == null) {
      final int n = metaData.getColumnCount();
      this.values = new DatabaseValue[n];
      int i = 0;
      for (int j = 0, m = operations.size(); j < m; i++) {
        final Operation operation = operations.get(j);
        this.values[i++] = operation.process(row, null);
      }
    }
  }

  public Row setRow(Row row) {
    this.row = row;
    this.values = null;
    return this;
  }

  public DatabaseValue getDatabaseValue(int index) {
    compute();
    return values[index - 1];
  }

  public DatabaseValue getDatabaseValue(String columnName) {
    return getDatabaseValue(metaData.getColumnIndex(columnName));
  }

  public Object getValue(int index) {
    compute();
    return values[index - 1].getOriginalValue();
  }

  public Object getValue(String columnName) {
    return getValue(metaData.getColumnIndex(columnName));
  }

  public boolean isNull(int index) {
    compute();
    return values[index - 1].isNull();
  }

  public boolean isNull(String columnName) {
    return isNull(metaData.getColumnIndex(columnName));
  }

  public String getAsString(int index) {
    compute();
    return values[index - 1].getStringValue();
  }

  public String getAsString(String columnName) {
    return getAsString(metaData.getColumnIndex(columnName));
  }

  public Long getAsInteger(int index) {
    compute();
    return values[index - 1].getIntegerValue();
  }

  public Long getAsInteger(String columnName) {
    return getAsInteger(metaData.getColumnIndex(columnName));
  }

  public Double getAsDouble(int index) {
    compute();
    return values[index - 1].getDoubleValue();
  }

  public Double getAsDouble(String columnName) {
    return getAsDouble(metaData.getColumnIndex(columnName));
  }

  public Boolean getAsBoolean(int index) {
    compute();
    return values[index - 1].getBooleanValue();
  }

  public Boolean getAsBoolean(String columnName) {
    return getAsBoolean(metaData.getColumnIndex(columnName));
  }

  public MetaData getMetaData() {
    return metaData;
  }

  private final TableMetaData metaData;
  private final ArrayList<Operation> operations = new ArrayList<Operation>();
  private Row row;
  private DatabaseValue[] values;
}
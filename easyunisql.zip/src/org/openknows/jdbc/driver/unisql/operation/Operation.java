package org.openknows.jdbc.driver.unisql.operation;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;


public abstract class Operation {
  
  public Operation(final String name, final ColumnType operation_type) {
    this.name = name;
    this.type = operation_type;
  }
  
  public String getName() { return this.name; }
  public ColumnType getType() { return this.type; }

  public abstract DatabaseValue process(final Row originalRow, final DatabaseValue previousValue);
  
  private final String name;
  private final ColumnType type;
  
  public static final String[] getIDs(final int length) {
    final String[] result = new String[length];
    for (int i = 0; i < length; i++) {
      result[i] = ids.getNewID();
    }
    return result;
  }
  public static final IDGenerator ids = new IDGenerator(true);
}

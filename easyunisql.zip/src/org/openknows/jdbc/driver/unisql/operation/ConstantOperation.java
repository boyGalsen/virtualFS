package org.openknows.jdbc.driver.unisql.operation;


import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;

public class ConstantOperation extends Operation {

  public ConstantOperation(final String name, final String value) {
    super(name, ColumnType.STRING);
    this.value = JDBCDatabaseValue.getAndInit(value);
  }

  public ConstantOperation(final String name, final Double value) {
    super(name, ColumnType.DOUBLE);
    this.value = JDBCDatabaseValue.getAndInit(value);
  }

  public ConstantOperation(final String name, final Integer value) {
    super(name, ColumnType.DOUBLE);
    this.value = JDBCDatabaseValue.getAndInit(value);
  }

  public ConstantOperation(final String name, final JDBCDatabaseValue value, ColumnType type) {
    super(name, type);
    this.value = value;
  }

  @Override
  public DatabaseValue process(final Row originalRow, final DatabaseValue previousValue) {
    return value;
  }

  private final DatabaseValue value;
}
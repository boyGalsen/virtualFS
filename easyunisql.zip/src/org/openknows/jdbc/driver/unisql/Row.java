package org.openknows.jdbc.driver.unisql;


public interface Row extends Cloneable {
  
  public MetaData getMetaData();
  
  public int getElementCount();
  
  public DatabaseValue getDatabaseValue(int index);
  public DatabaseValue getDatabaseValue(String columnName);
  
  public Object getValue(int index);
  public Object getValue(String columnName);

  public String getAsString(int index);
  public String getAsString(String columnName);

  public Long getAsInteger(int index);
  public Long getAsInteger(String columnName);

  public Double getAsDouble(int index);
  public Double getAsDouble(String columnName);

  public Boolean getAsBoolean(int index);
  public Boolean getAsBoolean(String columnName);
  
  public boolean isNull(int index);
  public boolean isNull(String columnName);
}

package org.openknows.jdbc.driver.unisql;


public interface InsertTableAccessor {

  public MetaData getMetaData() throws DatabaseException;
  public void insert(String[] column, Object[] values) throws DatabaseException; 
	public void insert(int[] column, Object[] values) throws DatabaseException; 
	public void insert(Object[] values) throws DatabaseException;
	
  public void insert(String[] column, DatabaseValue[] values) throws DatabaseException; 
  public void insert(int[] column, DatabaseValue[] values) throws DatabaseException;
  
  public void insert(DatabaseValue[] values) throws DatabaseException;
  
  public void insert(Row row) throws DatabaseException;
  
  public void close() throws DatabaseException;
 
}

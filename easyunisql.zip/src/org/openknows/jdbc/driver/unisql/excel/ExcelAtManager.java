package org.openknows.jdbc.driver.unisql.excel;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;


public class ExcelAtManager implements AtManager {
  
  public static ExcelAtManager reference = new ExcelAtManager();

  public String getPrefix() {
    return "XLS";
  }
  
  public void init(Parameters properties) {
  }
  
  public boolean dropTable(MemoryDatabase database, String file, String name) throws DatabaseException {
    final ValidatedFile f = StreamUtils.getFile(file);
    if (f.isExists()) {
      return StreamUtils.delete(f);
    }
    return false;
  }

  public Table createTable(final MemoryDatabase database, final String file, final String name, final MetaData metaData) throws DatabaseException {
    new ExcelCreator().create(StreamUtils.getFile(file), metaData, null);
    return getTable(database, file, name);
  }


  public Table getTable(final MemoryDatabase database, final String file, final String name) throws DatabaseException {
    return new ExcelFileTable().init(database, file, name);
  }
}

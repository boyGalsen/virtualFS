package org.openknows.jdbc.driver.unisql.excel;


import java.io.*;
import java.util.HashSet;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import org.openknows.jdbc.driver.unisql.*;

import jxl.Workbook;
import jxl.format.*;
import jxl.write.DateFormat;
import jxl.write.Label;
import jxl.write.NumberFormat;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


public class ExcelWriter {
  
  public static enum ExcelObjectType {
    DEFAULT_QUOTE(true), STRING_QUOTE(true), DECIMAL_QUOTE(true), INTEGER_QUOTE(true),
    DEFAULT(false), STRING(false), DECIMAL(false), INTEGER(false);
    
    ExcelObjectType(boolean isQuoted) {
      this.isQuoted = isQuoted;
    }
    
    public boolean isQUOTE() {
      return this.isQuoted;
    }
    
    private final boolean isQuoted;
  }
  
	public ExcelWriter() {
	}
  
  public void createSheet(final String name) {
    workbook.createSheet(name, 0);
  }
  
  public void write(final MetaData metaData) throws IOException {
    try {
      final WritableSheet sheet = this.workbook.getSheet(0);
      final HashSet<String> columnNames = new HashSet<String>();
      for (int i = 1, n = metaData.getColumnCount(); i <= n ; i++) {
        final Column column = metaData.getColumn(i);
        final String description = column.getDescription();
        final String finalName = !columnNames.contains(description) ? description : column.getName();
        sheet.addCell(new Label(i-1, 0, finalName, titleFormat));
        columnNames.add(finalName);
      }
    }
    catch (Throwable exception) {
      throw new IOException(exception);
    }
  }
  
  public void write(final MetaData metaData, final Row row) throws IOException {
    try {
      final WritableSheet sheet = this.workbook.getSheet(0);
      final int j = sheet.getRows();
      for (int i = 1, n = row.getElementCount(); i <= n ; i++) {
        final ColumnType type = metaData.getColumn(i).getType(); 
        switch(type) {
          case BOOLEAN : {
              final Boolean value = row.getAsBoolean(i);
              if (value == null)  {
                sheet.addCell(new Label(i-1, j, null));
              }
              else {
                sheet.addCell(new jxl.write.Boolean(i-1, j, value.booleanValue()));
              }
            }
            break;
          case LONG : {
              final Long value = row.getAsInteger(i);
              if (value == null)  {
                sheet.addCell(new Label(i-1, j, null));
              }
              else {
                sheet.addCell(new jxl.write.Number(i-1, j, value.intValue(), integerFormat));
              }
            }
            break;
          case DOUBLE : {
              final Double value = row.getAsDouble(i);
              if (value == null)  {
                sheet.addCell(new Label(i-1, j, null));
              }
              else {
                sheet.addCell(new jxl.write.Number(i-1, j, value.doubleValue(), numberFormat));
              }
            } 
            break;
          case STRING :
          default : {
            final String value = row.getAsString(i);
            if (value == null) {
              sheet.addCell(new Label(i-1, j, null, stringFormat));
            }
            else {
              sheet.addCell(new Label(i-1, j, value, stringFormat));
            }
          }
        }
      }
    }
    catch (Throwable exception) {
      throw new IOException(exception);
    }
  }

	
	public ExcelWriter init(final ValidatedFile out) {
    try {
      if (out.isExists()) {
        try (final FileInputStream in = StreamUtils.newFileInputStream(out)) {
          try (final FileOutputStream outs = StreamUtils.newFileOutputStream(out)) {
            this.workbook = Workbook.createWorkbook(outs, Workbook.getWorkbook(in));
          }
        }
      }
      else {
        try (final FileOutputStream outs = StreamUtils.newFileOutputStream(out)) {
  		    this.workbook = Workbook.createWorkbook(outs);
        }
        createSheet("UNISQL");
      }
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
    }
		return this;
	}
	
	public ExcelWriter init(final OutputStream out) {
    try {
      this.workbook = Workbook.createWorkbook(out);
      createSheet("UNISQL");
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
    }
    return this;
  }
  
  public void close() throws IOException {
    try {
      this.workbook.write();
      this.workbook.close();
    }
    catch (Throwable exception) {
      throw new IOException(exception);
    }
  }

  private WritableWorkbook workbook;
  
  
  private static final WritableFont arial10ptBoldNotUnderline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE);
  private static final WritableFont arial8ptNotUnderline = new WritableFont( WritableFont.ARIAL, 8, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE);
  
  private static final WritableCellFormat titleFormat = new WritableCellFormat(arial10ptBoldNotUnderline);
  private static final WritableCellFormat integerFormat = new WritableCellFormat(arial8ptNotUnderline, new NumberFormat("#"));
  private static final WritableCellFormat numberFormat = new WritableCellFormat(arial8ptNotUnderline, new NumberFormat("#.##"));
  private static final WritableCellFormat dateFormat = new WritableCellFormat(arial8ptNotUnderline, new DateFormat("dd MMM yyyy"));
  private static final WritableCellFormat stringFormat = new WritableCellFormat(arial8ptNotUnderline);
  
  static {
    try {
      titleFormat.setWrap(true);
      titleFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      titleFormat.setBackground(Colour.GRAY_25);
      titleFormat.setAlignment(Alignment.CENTRE);
    
      integerFormat.setWrap(false);
      integerFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      integerFormat.setBackground(Colour.WHITE);
      integerFormat.setAlignment(Alignment.CENTRE);
    
      numberFormat.setWrap(false);
      numberFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      numberFormat.setBackground(Colour.WHITE);
      numberFormat.setAlignment(Alignment.CENTRE);
    
      dateFormat.setWrap(false);
      dateFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      dateFormat.setBackground(Colour.WHITE);
      dateFormat.setAlignment(Alignment.CENTRE);
    
      stringFormat.setWrap(false);
      stringFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      stringFormat.setBackground(Colour.WHITE);
      stringFormat.setAlignment(Alignment.CENTRE);
    }
    catch (Throwable ignored) {
    }
  }
}

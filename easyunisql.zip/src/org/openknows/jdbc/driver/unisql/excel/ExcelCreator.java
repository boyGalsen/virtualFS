package org.openknows.jdbc.driver.unisql.excel;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.preferences.*;

import java.io.File;

import org.openknows.jdbc.driver.unisql.DatabaseException;
import org.openknows.jdbc.driver.unisql.MetaData;


public class ExcelCreator {

  public ExcelCreator() { 
  }
  
  public void create(final ValidatedFile file, final MetaData metaData, final Parameters parameters) throws DatabaseException {
  	try {
      if (file.isExists()) {
        StreamUtils.delete(file);
      }
	  	try {
		  	final ExcelWriter w = new ExcelWriter();
        try {
          w.init(file);
  		  	w.write(metaData);
        }
        finally {
          w.close();
        }
	  	}
	  	finally {
	  	}
  	}
  	catch (Throwable e) {
  		throw new DatabaseException(e);
  	}
  }
  /*
  
  public static SimpleRequest.ResultSetListener generate(final OutputStream out) throws Throwable {

    return new SimpleRequest.ResultSetListener() {
    
    private final WritableWorkbook workBook = Workbook.createWorkbook(out);
    private final WritableSheet sheet = workBook.createSheet("SQL Results", 0);
    private final ArrayList types = ObjectArrays.getArrayList();
    private int nbColumns = 0; 
    private int row = 0;

    public void init(ResultSet v) throws SQLException {
      try {
        final ResultSetMetaData metaData = v.getMetaData();
        nbColumns = metaData.getColumnCount();
        for (int i = 0 ; i < nbColumns ; i++) {
          final int iAdd1 = i+1;
          final String name = metaData.getColumnName(iAdd1);
          final Label label = new Label(i, 0, name, titleFormat); 
          sheet.addCell(label);
          final Integer type;
          if (SQLUtils.isDate(iAdd1,metaData)) {
            type = DATE_TYPE;
          }
          else if (SQLUtils.isInteger(iAdd1,metaData)) {
            type = INTEGER_TYPE;
          }
          else if (SQLUtils.isNumber(iAdd1,metaData)) {
            type = NUMBER_TYPE;
          }
          else {
            type = STRING_TYPE;
          }
          types.add(type);
        }
      }
      catch (Throwable exception) {
        throw new SQLException(exception.getMessage());
      }
    }
    
    public void close() throws SQLException {
       try {
          workBook.write();
          workBook.close();
        }
        catch (Throwable exception) {
          throw new SQLException(exception.getMessage());
        }      
      }
    
    public void set(int x, ResultSet v) throws SQLException {
      try {
        row++;
        for (int i = 0 ; i < nbColumns ; i++) {
          final int iAdd1 = i+1;
          final Integer type = (Integer)types.get(i);
          if (type == INTEGER_TYPE) {
            final int value = v.getInt(iAdd1);
            if (!v.wasNull()) {
              final Number number = new Number(i, row, value, integerFormat);
              sheet.addCell(number);
            }
            else {
              sheet.addCell(new Label(i, row, "", stringFormat));
            }
          }
          else if (type == NUMBER_TYPE) {
            final double value = v.getDouble(iAdd1);
            if (!v.wasNull()) {
              final Number number = new Number(i, row, value, numberFormat);
              sheet.addCell(number);
            }
            else {
              sheet.addCell(new Label(i, row, "", stringFormat));
            }
          }
          else if (type == DATE_TYPE) {
            final Timestamp value = v.getTimestamp(iAdd1);
            if (!v.wasNull()) {
              final DateTime dateTime = new DateTime(i, row, value, dateFormat);
              sheet.addCell(dateTime);
            }
            else {
              sheet.addCell(new Label(i, row, "", stringFormat));
            }
          }
          else {
            final String value = v.getString(iAdd1);
            final Label label = new Label(i, row, v.wasNull() ? "" : value, stringFormat); 
            sheet.addCell(label);
          }
        }
      }
      catch (Throwable exception) {
        throw new SQLException(exception.getMessage());
      }
    }
  };
}

  private static final Integer INTEGER_TYPE = LongCache.getInteger(0);
  private static final Integer NUMBER_TYPE = LongCache.getInteger(1);
  private static final Integer DATE_TYPE = LongCache.getInteger(2);
  private static final Integer STRING_TYPE = LongCache.getInteger(3);*/

}

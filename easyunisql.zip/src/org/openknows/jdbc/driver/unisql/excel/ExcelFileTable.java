package org.openknows.jdbc.driver.unisql.excel;


import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;



public class ExcelFileTable implements AtTable {

  public ExcelFileTable init(final MemoryDatabase database, final String file, String name) throws DatabaseException {
    try {
      final int index = file.indexOf("#");
      if (index >= 0) return this.init(EzFSUtil.findEzFsFileDescriptior(file.substring(0, index)), Integer.parseInt(file.substring(index+1)), name, true);
      return this.init(EzFSUtil.findEzFsFileDescriptior(file), name);
    }
    catch (Throwable forwarded) {
      throw new DatabaseException(forwarded);
    }
  }
  	
	public ExcelFileTable init(final EzFSFileDescriptor file) throws DatabaseException {
		return this.init(file, true);
	}
  
  public ExcelFileTable init(final EzFSFileDescriptor file, String name) throws DatabaseException {
    return this.init(file, 1, name, true);
  }
  
  public String getName() { 
    return this.name; 
  }
  public String getType() { 
    return Table.FILE; 
  }
  public String getDescription() { 
    return EzFSUtil.getAbsolutePath(this.file); 
  }

  public ExcelFileTable init(final EzFSFileDescriptor file, final boolean withColumnNameHeader) throws DatabaseException {
    return init(file, 1, EzFSUtil.getAbsolutePath(file), withColumnNameHeader);
  }
  
  public ExcelFileTable init(final EzFSFileDescriptor file, final int sheet, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
      this.sheet = sheet-1;
	  	this.withColumnNameHeader = withColumnNameHeader;
	  	final ExcelParser parser = new ExcelParser();
	  	
	  	final TableMetaData metaData = new TableMetaData();
	  	try (final EzFSConnection connection = EzFS.reference.get().getConnection(file.getConnectionDescriptor())) {
        try (final InputStream in = connection.find(file).getAccess().openInput()) {
        	parser.init(in);
          if (!parser.hasMoreSheet()) throw new DatabaseException("Not Valid File.");
          parser.getNextSheet();
  				if (withColumnNameHeader) {
  					if (!parser.hasMoreRow()) throw new DatabaseException("Not Valid File.");
  					parser.getNextRow();
  					while (parser.hasMoreElement()) {
  						metaData.add(Column.getAndInit(parser.getNextElement(), ColumnType.STRING));
  					}
  				}
  				else {
  					if (!parser.hasMoreRow()) throw new DatabaseException("Not Valid File.");
  					parser.getNextRow();
  					int i = 1;
  					while(parser.hasMoreElement()) {
  						metaData.add(Column.getAndInit(IntegerCache.toString(i++), ColumnType.LONG));
  					}
  				}
        }
	  	}
	  	this.metaData = metaData;
  	}
		catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
			throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
			return new ExcelTableAccessor(file, metaData, sheet, withColumnNameHeader);
  	}
  	catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
  		throw new DatabaseException(ignored);
  	}
  }

  public ExcelTableInsertAccessor getExcelInsertAccessor() throws DatabaseException {
    try {
      return new ExcelTableInsertAccessor().init(file, metaData);
    }
    catch (Throwable ignored) {
      throw new DatabaseException(ignored);
    }
  }

	public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return getExcelInsertAccessor();
	}
  
  private EzFSFileDescriptor file;
  private boolean withColumnNameHeader;
  private MetaData metaData;
  private String name;
  private int sheet;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}

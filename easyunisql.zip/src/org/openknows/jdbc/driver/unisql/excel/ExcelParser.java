package org.openknows.jdbc.driver.unisql.excel;

import java.io.*;
import java.util.*;

import jxl.*;


public class ExcelParser {

  public ExcelParser() {}
  
  public void reset() throws IOException {
    this.in.reset();
    this.currentRow = 0;
    this.sheet = null;
    this.currentColumn = 0;
    this.currentSheet = 0;
    this.header = new Properties();
 }
    
  public ExcelParser init(final InputStream in) throws IOException {
    try {
      this.in = in;
      this.workbook = Workbook.getWorkbook(in);
      this.currentRow = 0;
      this.sheet = null;
      this.currentColumn = 0;
      this.currentSheet = 0;
      this.header = new Properties();
      return this;
    }
    catch (Throwable e) {
      throw new IOException(e);
    }
  }

  public String getNextElement() throws IOException {
    if (!hasMoreElement()) throw new IOException("Has No More Element");
    currentColumn++;
    this.element = sheet.getCell(currentColumn-1, currentRow-1).getContents();
    return element;
  }
  
  public int getNextRow() throws IOException {
    if (!hasMoreRow()) throw new IOException("Has No More Row");
    currentColumn = 0;
    return currentRow++;
  }
  
  public int getSheet(int currentSheet) throws IOException {
    this.currentSheet = currentSheet; 
    if (!hasMoreSheet()) throw new IOException("Has No More Sheet");
    this.sheet = workbook.getSheet(currentSheet);
    currentColumn = 0;
    currentColumn = 0;
    return this.currentSheet++;
  }
  
  public int getNextSheet() throws IOException {
    if (!hasMoreSheet()) throw new IOException("Has No More Sheet");
    this.sheet = workbook.getSheet(currentSheet);
    currentColumn = 0;
    currentColumn = 0;
    return currentSheet++;
  }
  
  public String getCurrentSheetName() { return sheet.getName(); }
  public boolean hasMoreSheet() { return currentSheet < workbook.getNumberOfSheets(); }
  public boolean hasMoreHeader() { return false; }
  public boolean hasMoreRow() throws IOException { return currentRow < sheet.getRows(); }
  public boolean hasMoreElement() throws IOException { return currentColumn < sheet.getColumns(); }
  public Properties getHeader() { return header; }
  
  public void close() {
    in = null;
    element = null;
    sheet = null;
    currentRow = 0;
    currentColumn = 0;
    currentSheet = 0;
    header = null;
  }

  private String element = null;
  private Sheet sheet;
  private Workbook workbook;
  
  private InputStream in = null;
  private int currentRow = 0;
  private int currentSheet = 0;
  private int currentColumn = 0;
  private Properties header = null;
}
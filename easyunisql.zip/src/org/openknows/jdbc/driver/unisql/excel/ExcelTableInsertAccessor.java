package org.openknows.jdbc.driver.unisql.excel;

import com.easyrms.builder.*;
import com.easyrms.io.ezfs.*;

import java.io.*;
import java.util.Arrays;

import org.openknows.jdbc.driver.unisql.*;



public class ExcelTableInsertAccessor extends AbstractInsertTableAccessor implements InsertTableAccessor {
	
	public ExcelTableInsertAccessor init(final EzFSFileDescriptor file, final MetaData metaData) throws DatabaseException {
	  try {
  	  this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
      final OutputStream out = fsConnection.find(file).getAccess().openOutput();
      this.out = new ExcelWriter().init(out);
  		this.metaData = metaData;
      this.types = new ExcelWriter.ExcelObjectType[this.metaData.getColumnCount()];
      this.builders = new Builder[this.metaData.getColumnCount()];
      Arrays.fill(this.types, ExcelWriter.ExcelObjectType.DEFAULT_QUOTE);
  		return this;
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
	}
  
  public void setType(final int index, final ExcelWriter.ExcelObjectType type) {
    this.types[index-1] = (type == null) ? ExcelWriter.ExcelObjectType.DEFAULT_QUOTE : type;
  }
  
  public void set(final int index, final Builder builder) {
    this.builders[index - 1] = builder;
  }
	
	public MetaData getMetaData() throws DatabaseException {
		return metaData;
	}

  @Override
  protected void internalInsert(final Row row) throws DatabaseException {
    try {
      this.out.write(this.metaData, row);
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }
  }

	public void close() throws DatabaseException {
    try {
      try {
        if (out != null) {
          this.out.close();
          out = null;
        }
      }
      finally {
        if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
        }
      }
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }   
  }


  private EzFSConnection fsConnection;
  private MetaData metaData;
  private ExcelWriter.ExcelObjectType[] types;
  private Builder[] builders;
  private ExcelWriter out;
}
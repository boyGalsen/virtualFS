package org.openknows.jdbc.driver.unisql.excel;

import java.io.*;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;


public class ExcelTableAccessor implements TableAccessor {

  public ExcelTableAccessor(EzFSFileDescriptor file, final MetaData metaData, final int sheet, final boolean withColumnNames) throws DatabaseException  { 
		try {
		  this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
      this.reader = fsConnection.find(file).getAccess().openInput();
      this.parser = new ExcelParser();
	    this.metaData = metaData;
			this.parser.init(reader);
      if (!parser.hasMoreSheet()) throw new DatabaseException("Not Valid File.");
      parser.getSheet(sheet);
      if (!parser.hasMoreRow()) throw new DatabaseException("Not Valid File.");
      parser.getNextRow();
      while (parser.hasMoreElement()) { parser.getNextElement();} //ignored
			if (parser.hasMoreRow()) {
				parser.getNextRow();
				hasNext = parser.hasMoreElement();
			}
		}
		catch (Throwable e) {
      EasyRMS.trace.log(e);
			throw new DatabaseException(e);
		}
  }
  
  public void init() throws DatabaseException {
  }

  public MetaData getMetaData()  throws DatabaseException {
    return metaData;
  }

  public boolean hasNext() throws DatabaseException {
  	return hasNext;
  }

  public Row getNext() throws DatabaseException {
		if (!hasNext) throw new DatabaseException("no more value");
		try {
	  	row = new DatabaseRow();
      row.init(this.metaData);
	  	int i = 1;
	  	while (parser.hasMoreElement()) {
	  		row.set(i++, JDBCDatabaseValue.getAndInit(parser.getNextElement()));
	  	}
	  	if (parser.hasMoreRow()) {
				parser.getNextRow();
				hasNext = parser.hasMoreElement();
	  	}
	  	else {
	  		hasNext = false;
	  	}
	    return row;
		}
		catch (Throwable e) {
      EasyRMS.trace.log(e);
			throw new DatabaseException(e);
		}	  	
  }
  
  public void close() throws DatabaseException {
		try {
		  try {
		    hasNext = false;
	      row = null;
	      parser.close();
	      reader.close();
      }
      finally {
        if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
        }
      }
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}	  	
  }
  
  private EzFSConnection fsConnection;
  private final InputStream reader;
	private final ExcelParser parser;
  private final MetaData metaData;

  private DatabaseRow row;
  private boolean hasNext;
}

package org.openknows.jdbc.driver.wrapper;

import org.openknows.common.db.*;

public class SimpleWrapperSQLRequest implements WrapperSQLRequest {
  
  public SimpleWrapperSQLRequest setConnection(WrapperDriverConnection connection) {
    this.connection = connection;
    return this;
  }

  public SimpleStatementResult execute(String request) {
    return null;
  }
  
  private WrapperDriverConnection connection; 
}

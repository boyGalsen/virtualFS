package org.openknows.jdbc.driver.wrapper;

import org.openknows.common.db.*;

public interface WrapperSQLRequest {

  WrapperSQLRequest setConnection(WrapperDriverConnection connection);
  SimpleStatementResult execute(String request);
}

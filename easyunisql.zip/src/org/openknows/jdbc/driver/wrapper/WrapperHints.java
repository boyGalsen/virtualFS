package org.openknows.jdbc.driver.wrapper;

import com.easyrms.util.preferences.*;

public class WrapperHints {
  
  public static WrapperHints compile(String request) {
    return null;
  }

  private WrapperHints(Parameters hints, String cleanRequest) {
    this.hints = hints;
    this.cleanRequest = cleanRequest;
  }
  
  public Parameters getHint() {
    return hints;
  }
  
  public String getSQLRequest() {
    return cleanRequest;
  }
  
  private final Parameters hints;
  private final String cleanRequest;
}

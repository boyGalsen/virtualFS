package org.openknows.jdbc.driver.wrapper;

import java.sql.*;
import java.util.*;
import java.util.logging.*;


public class WrapperDriverConnectionDriver implements Driver {

  public static final String URL_PREFIX = "jdbc:openknows.wrapper:";
  private static final int MAJOR_VERSION = 1;
  private static final int MINOR_VERSION = 0;

  public void close() {
  }

  public Connection connect(String url, Properties props) throws SQLException {
    if (!url.startsWith(URL_PREFIX)) { return null; }
    return null;
  }

  public boolean acceptsURL(String url) {
    return url.startsWith(URL_PREFIX);
  }

  public int getMajorVersion() {
    return MAJOR_VERSION;
  }

  public int getMinorVersion() {
    return MINOR_VERSION;
  }

  public DriverPropertyInfo[] getPropertyInfo(String str, Properties props) {
    return new DriverPropertyInfo[0];
  }

  public boolean jdbcCompliant() {
    return false;
  }
  
  public WrapperSQLRequest getRequestDecoder(WrapperDriverConnection connection) {
    return new SimpleWrapperSQLRequest().setConnection(connection);
  }

  public Logger getParentLogger() throws SQLFeatureNotSupportedException {
    throw new SQLFeatureNotSupportedException("Not Available");
  }
  
  
}
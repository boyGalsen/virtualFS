package org.openknows.jdbc.driver.pool;

import java.sql.*;
import java.util.*;
import java.util.concurrent.locks.*;
import java.util.concurrent.locks.ReentrantReadWriteLock.*;
import java.util.logging.*;

public class PoolDriverConnectionDriver implements Driver {

  public static final String URL_PREFIX = "jdbc:openknows.jdbcpool:";
  private static final int MAJOR_VERSION = 1;
  private static final int MINOR_VERSION = 0;

  private static final HashMap<String, PoolDriverConnectionPool> poolsMap = new HashMap<String, PoolDriverConnectionPool>();
  private static final HashMap<String, String> pooledsUrlMap = new HashMap<String, String>(); 
  public static final PoolDriverConnectionDriver reference = new PoolDriverConnectionDriver();
  private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
  private static final ReadLock rLock = lock.readLock();
  private static final WriteLock wLock = lock.writeLock();
  
  
  public static String getPooledURL(String url) {
    rLock.lock();
    try {
      if (url.startsWith(URL_PREFIX)) return url;
      if (pooledsUrlMap.containsKey(url)) return pooledsUrlMap.get(url);
      return URL_PREFIX+url;
    }
    finally {
      rLock.unlock();
    }
  }
  
  public static void addDataSource(String name, String driver, String url, String user, String password) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
    Class.forName(driver).newInstance();
    wLock.lock();
    try {
      pooledsUrlMap.put(url, name);
      poolsMap.put(name, new PoolDriverConnectionPool(url, user, password));
    }
    finally {
      wLock.unlock();
    }
  }

  public static void removeDataSource(String name) {
    wLock.lock();
    try {
      poolsMap.get(name).closeConnections();
      String findUrl = null;
      for (Map.Entry<String, String> entry : pooledsUrlMap.entrySet()) {
        if (name.equals(entry.getValue())) {
          findUrl = entry.getKey();
          break;
        }
      }
      pooledsUrlMap.remove(findUrl);
      poolsMap.remove(name);
    }
    finally {
      wLock.unlock();
    }
  }

  public static void addDataSource(String name, String driver, String url) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
    Class.forName(driver).newInstance();
    wLock.lock();
    try {
      pooledsUrlMap.put(url, name);
      poolsMap.put(name, new PoolDriverConnectionPool(url));
    }
    finally {
      wLock.unlock();
    }
  }

  public static void addDataSource(String name, String driver, String url, Properties properties) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
    Class.forName(driver).newInstance();
    wLock.lock();
    try {
      pooledsUrlMap.put(url, name);
      poolsMap.put(name, new PoolDriverConnectionPool(url, properties));
    }
    finally {
      wLock.unlock();
    }
  }
  
  private static PoolDriverConnectionPool get(String url) {
    final String pooledValue = url.substring(URL_PREFIX.length());
    rLock.lock();
    try {
      if (!poolsMap.containsKey(pooledValue) && pooledValue.startsWith("jdbc:")) {
        rLock.unlock();
        wLock.lock();
        try {
          if (!poolsMap.containsKey(pooledValue) && pooledValue.startsWith("jdbc:")) {
            pooledsUrlMap.put(pooledValue, pooledValue);
            poolsMap.put(pooledValue, new PoolDriverConnectionPool(pooledValue));
          }
        }
        finally {
          rLock.lock();
          wLock.unlock();
        } 
      }
      return poolsMap.get(pooledValue);
    }
    finally {
      rLock.unlock();
    }
  }
  
  public PoolDriverConnectionDriver() {
    try {
      DriverManager.registerDriver(this);
    }
    catch (Throwable ignored) {
    }
  }

  public Connection connect(String url, Properties props) throws SQLException {
    if (!url.startsWith(URL_PREFIX)) { return null; }
    final PoolDriverConnectionPool pool = get(url);
    return (pool == null) ? null : pool.getConnection();
  }

  public boolean acceptsURL(String url) {
    return url.startsWith(URL_PREFIX);
  }

  public int getMajorVersion() {
    return MAJOR_VERSION;
  }

  public int getMinorVersion() {
    return MINOR_VERSION;
  }

  public DriverPropertyInfo[] getPropertyInfo(String str, Properties props) {
    return new DriverPropertyInfo[0];
  }

  public boolean jdbcCompliant() {
    return false;
  }

  public Logger getParentLogger() throws SQLFeatureNotSupportedException {
    throw new SQLFeatureNotSupportedException("Not Available");
  }
  
  
}
package org.openknows.jdbc.driver.pool;

import com.easyrms.util.*;

import java.sql.*;
import java.util.*;

public class PoolDriverConnectionPool {

  private final Vector connections;
  private final String url, user, password;
  static final private long timeout = 60000;
  private final ConnectionReaper reaper;
  static final private int poolsize = 10;
  private final Properties properties;

  public PoolDriverConnectionPool(String url, String user, String password) {
    this.url = url;
    this.user = user;
    this.password = password;
    this.properties = null;
    connections = new Vector(poolsize);
    reaper = new ConnectionReaper(this);
    reaper.start();
  }

  public PoolDriverConnectionPool(String url) {
    this.url = url;
    this.user = null;
    this.password = null;
    this.properties = null;
    connections = new Vector(poolsize);
    reaper = new ConnectionReaper(this);
    reaper.start();
  }

  public PoolDriverConnectionPool(String url, Properties properties) {
    this.url = url;
    this.user = null;
    this.password = null;
    this.properties = properties;
    connections = new Vector(poolsize);
    reaper = new ConnectionReaper(this);
    reaper.start();
  }

  public synchronized void reapConnections() {
    final long stale = StampUtil.getStampValue() - timeout;
    final Enumeration connlist = connections.elements();
    while ((connlist != null) && (connlist.hasMoreElements())) {
      final PoolDriverConnection conn = (PoolDriverConnection)connlist.nextElement();
      if ((conn.inUse()) && (stale > conn.getLastUse()) && (!conn.validate())) {
        removeConnection(conn);
      }
    }
  }

  public synchronized void closeConnections() {
    final Enumeration connlist = connections.elements();
    while ((connlist != null) && (connlist.hasMoreElements())) {
      final PoolDriverConnection conn = (PoolDriverConnection)connlist.nextElement();
      removeConnection(conn);
    }
  }

  public synchronized Connection getConnection() throws SQLException {
    PoolDriverConnection c;
    for (int i = 0, n = connections.size(); i < n; i++) {
      c = (PoolDriverConnection)connections.elementAt(i);
      if (c.lease()) { return c; }
    }

    final Connection conn = (user == null) ? (properties == null) ? DriverManager.getConnection(url) : DriverManager.getConnection(url, properties)
        : DriverManager.getConnection(url, user, password);
    c = new PoolDriverConnection(conn, this);
    c.lease();
    connections.addElement(c);
    return c;
  }

  public synchronized void returnConnection(PoolDriverConnection conn) {
    conn.expireLease();
  }

  private synchronized void removeConnection(PoolDriverConnection conn) {
    connections.removeElement(conn);
  }

  private class ConnectionReaper extends Thread {
    private PoolDriverConnectionPool pool;
    private final long delay = 300000;

    ConnectionReaper(PoolDriverConnectionPool pool) {
      this.pool = pool;
    }

    @Override
    public void run() {
      while (true) {
        try {
          sleep(delay);
        }
        catch (InterruptedException e) {}
        pool.reapConnections();
      }
    }
  }
}

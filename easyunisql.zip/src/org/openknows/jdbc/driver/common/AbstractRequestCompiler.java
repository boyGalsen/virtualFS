package org.openknows.jdbc.driver.common;

import org.openknows.common.db.*;

import java.sql.*;

public interface AbstractRequestCompiler<C extends SimpleDriverConnection> {

  public SimpleStatementResult compileRequest(String sql, SimpleDriverParameters parameters, C connection) throws SQLException;
  public ResultSetMetaData compileResultSetMetadata(String sql, SimpleDriverParameters parameters, C connection)throws SQLException;
  public ParameterMetaData compileParameterMetadata(String sql, SimpleDriverParameters parameters, C connection)throws SQLException;
}

package org.openknows.jdbc.driver.common;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.io.*;
import java.math.*;
import java.net.*;
import java.sql.*;
import java.sql.Date;
import java.util.*;


public class SimpleDriverParameters {

  public void setArray(int i, Array x) throws SQLException {}

  public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
    parameters.put(parameterIndex, LongCache.get(x.intValue()));
  }

  public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBlob(int i, Blob x) throws SQLException {}

  public void setBoolean(int parameterIndex, boolean x) throws SQLException {
    parameters.put(parameterIndex, Boolean.valueOf(x));
  }

  public void setByte(int parameterIndex, byte x) throws SQLException {
    parameters.put(parameterIndex, new String(new byte[]{x,}));
  }

  public void setBytes(int parameterIndex, byte[] x) throws SQLException {
    parameters.put(parameterIndex, new String(x));
  }

  public void setClob(int i, Clob x) throws SQLException {}

  public void setDate(int parameterIndex, Date x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setDouble(int parameterIndex, double x) throws SQLException {
    parameters.put(parameterIndex, new Double(x));
  }

  public void setFloat(int parameterIndex, float x) throws SQLException {
    parameters.put(parameterIndex, new Double(x));
  }

  public void setInt(int parameterIndex, int x) throws SQLException {
    parameters.put(parameterIndex, IntegerCache.get(x));
  }

  public void setLong(int parameterIndex, long x) throws SQLException {
    parameters.put(parameterIndex, LongCache.get(x));
  }

  public void setNull(int parameterIndex, int sqlType) throws SQLException {
    parameters.put(parameterIndex, null);
  }

  public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
    parameters.put(parameterIndex, null);
  }

  public void setObject(int parameterIndex, Object x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setRef(int i, Ref x) throws SQLException {}

  public void setShort(int parameterIndex, short x) throws SQLException {
    parameters.put(parameterIndex, IntegerCache.get(x));
  }

  public void setString(int parameterIndex, String x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTime(int parameterIndex, Time x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setURL(int parameterIndex, URL x) throws SQLException {
    parameters.put(parameterIndex, x);
  }

  public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, new String(StreamUtils.toByteArray(x)));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {}

  public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {}

  public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setClob(int parameterIndex, Reader reader) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(value));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(value));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNClob(int parameterIndex, NClob value) throws SQLException {}

  public void setNClob(int parameterIndex, Reader reader) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
    try {
      parameters.put(parameterIndex, StreamUtils.toString(reader));
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }

  public void setNString(int parameterIndex, String value) throws SQLException {
    try {
      parameters.put(parameterIndex, value);
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored); 
    }
  }
  
  public void setRowId(int parameterIndex, RowId x) throws SQLException {}

  public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {}

  public IntObjectMap<Object> getParameters() {
    return parameters;
  }
  
  private final IntObjectMap<Object> parameters = new IntObjectMap<Object>();
  
  public void clear() {
    parameters.clear();
  }
}
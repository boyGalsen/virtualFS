package org.openknows.jdbc.driver.common;

import java.sql.*;
import java.util.*;
import java.util.logging.*;


public abstract class AbstractDriverConnectionDriver implements Driver {

  protected AbstractDriverConnectionDriver(String URL_PREFIX) {
    this(URL_PREFIX, 1, 0);
  }
  
  protected AbstractDriverConnectionDriver(String URL_PREFIX, int MAJOR_VERSION, int MINOR_VERSION) {
    this.URL_PREFIX = URL_PREFIX;
    this.MAJOR_VERSION = MAJOR_VERSION;
    this.MINOR_VERSION = MINOR_VERSION;
  }

  public final synchronized Connection connect(String url, Properties props) throws SQLException {
    if (isClosed) {
      throw new SQLException("Closed Driver");
    }
    if (!url.startsWith(URL_PREFIX)) {
      return null;
    }
    return newConnection(url.substring(URL_PREFIX.length()), props);
  }
  
  protected abstract Connection newConnection(String url, Properties props) throws SQLException;

  public final boolean acceptsURL(String url) {
    return url.startsWith(URL_PREFIX);
  }

  public final int getMajorVersion() {
    return MAJOR_VERSION;
  }

  public final int getMinorVersion() {
    return MINOR_VERSION;
  }

  public DriverPropertyInfo[] getPropertyInfo(String str, Properties props) throws SQLException {
    return new DriverPropertyInfo[0];
  }

  public boolean jdbcCompliant() {
    return true;
  }

  public synchronized void close() {
    isClosed = true;
  }
  
  public Logger getParentLogger() throws SQLFeatureNotSupportedException {
    throw new SQLFeatureNotSupportedException("Not Available");
  }



  private boolean isClosed;
  private final String URL_PREFIX;
  private final int MAJOR_VERSION;
  private final int MINOR_VERSION;
}
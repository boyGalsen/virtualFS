package org.openknows.jdbc.ldd;

import com.easyrms.util.*;

public interface LDDDatabase {

  String getName();
  EzArray<? extends Schema> getSchemas();
  Schema findSchema(String name);
  
}

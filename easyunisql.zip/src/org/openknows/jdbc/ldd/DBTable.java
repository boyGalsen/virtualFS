package org.openknows.jdbc.ldd;

import java.util.*;

public class DBTable implements Table {

  public DBTable(DBSchema schema, String name){
    this.schema = schema;
    this.name = name;
  }
  
  public ArrayList<?> getColumnList() {
    return null;
  }

  public String getDescription() {
    return null;
  }

  public String getName() {
    return null;
  }

  public Schema getSchema() {
    return null;
  }

  public String getType() {
    return null;
  }

  DBSchema schema;
  String name;  
}

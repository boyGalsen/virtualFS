package org.openknows.jdbc.ldd;

public interface Function {

  String getName();
  String getType();
  String getBody();
  Schema getSchema();

}

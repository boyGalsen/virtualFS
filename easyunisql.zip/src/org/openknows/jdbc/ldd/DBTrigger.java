package org.openknows.jdbc.ldd;

public class DBTrigger implements Trigger {

  public DBTrigger(DBSchema schema, String name, String definition, String when, String action){
    this.schema = schema;
    this.name = name;
    this.definition = definition;
    this.when = when;
    this.action = action;
  }
  
  public String getDefinition() {
    return null;
  }

  public String getName() {
    return null;
  }

  public Schema getSchema() {
    return null;
  }

  public String getWhen() {
    return null;
  }
  
  public String getAction() {
    return null;
  }  
  
  DBSchema schema;
  String name;
  String definition;
  String when;
  String action;


}

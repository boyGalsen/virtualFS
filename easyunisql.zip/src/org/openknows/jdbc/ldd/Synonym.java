package org.openknows.jdbc.ldd;

public interface Synonym {

  String getName();
  String getTableName();
  Schema getSchema();
  
}

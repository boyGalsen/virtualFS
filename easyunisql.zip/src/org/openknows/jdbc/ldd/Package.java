package org.openknows.jdbc.ldd;

public interface Package {

  String getName();
  String getType();
  String getTable();
  Schema getSchema();
  
}

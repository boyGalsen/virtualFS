package org.openknows.jdbc.ldd;

public class DBFunction implements Function {

  public DBFunction(DBSchema schema, String name){
    this.schema = schema;
    this.name = name;
  }
  
  public String getBody() {
    return null;
  }

  public String getName() {
    return null;
  }

  public Schema getSchema() {
    return null;
  }

  public String getType() {
    return null;
  }

  DBSchema schema;
  String name;  
}

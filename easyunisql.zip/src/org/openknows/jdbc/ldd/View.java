package org.openknows.jdbc.ldd;

public interface View {
  
  String getName();
  String getText();
  int getTextLength();
  Schema getSchema();
}

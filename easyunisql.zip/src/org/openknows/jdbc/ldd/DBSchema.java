package org.openknows.jdbc.ldd;

import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.sql.*;
import java.util.*;

public class DBSchema implements Schema {

  public DBSchema(DBLDDDatabase database, String name) {
    this.database = database;
    this.name = name;
  }

  public DBLDDDatabase getLDDDatabase() {
    return database;
  }

  public String getName() {
    return name;
  }

  public EzArray<Package> getPackages() {
    return packages;
  }

  public EzArray<Procedure> getProcedures() {
    return procedures;
  }

  /**Functions **/
  public DBFunction findFunction(String name) {
    return functions.get().find(name);
  }

  public EzArray<? extends DBFunction> getFunctions() {
    return functions.get().getList();
  }

  private class FunctionCollection {

    public void add(DBFunction function) {
      if (function != null) {
        final String functionName = function.getName();
        if (!functionByName.containsKey(functionName)) {
          if (functions.add(function)) {
            functionByName.put(functionName, function);
          }
        }
      }
    }

    public DBFunction find(String name) {
      return functionByName.get(name);
    }

    public EzArray<DBFunction> getList() {
      return functions.getList();
    }

    private HashMap<String, DBFunction> functionByName = new HashMap<String, DBFunction>();
    private EzArrayCopyOnWriteList<DBFunction> functions = new EzArrayCopyOnWriteList<DBFunction>();
  }

  private ObjectReference<FunctionCollection> functions = new AutoCreateReference<FunctionCollection>() {

    @Override
    protected FunctionCollection create() {
      final FunctionCollection functions = new FunctionCollection();
      final EzDBAccess access = database.getDatabase().openAccess();
      try {
        access.getConnection().query("select OBJECT_NAME from dba_objects where owner not in ('SYS','SYSTEM','PUBLIC') and object_type like('FUNCTION')", new EzDBResultSetListener() {

          @Override
          public void set(int i, ResultSet v) throws SQLException {
            try {
              final String objectName = SQLUtils.getString(v, 1);
              if (StringComparator.isNotNull(objectName)) {
                final DBFunction function = new DBFunction(DBSchema.this, objectName);
                functions.add(function);
              }
            }
            catch (Throwable ignored) {
              EasyRMS.trace.log(ignored);
            }
          }

        });
      }
      finally {
        access.close();
      }
      return functions;
    }

  };

  /**Tables **/
  public DBTable findTable(String name) {
    return tables.get().find(name);
  }

  public EzArray<? extends DBTable> getTables() {
    return tables.get().getList();
  }

  private class TableCollection {

    public void add(DBTable table) {
      if (table != null) {
        final String tableName = table.getName();
        if (!tableByName.containsKey(tableName)) {
          if (tables.add(table)) {
            tableByName.put(tableName, table);
          }
        }
      }
    }

    public DBTable find(String name) {
      return tableByName.get(name);
    }

    public EzArray<DBTable> getList() {
      return tables.getList();
    }

    private HashMap<String, DBTable> tableByName = new HashMap<String, DBTable>();
    private EzArrayCopyOnWriteList<DBTable> tables = new EzArrayCopyOnWriteList<DBTable>();
  }

  private ObjectReference<TableCollection> tables = new AutoCreateReference<TableCollection>() {

    @Override
    protected TableCollection create() {
      final TableCollection tables = new TableCollection();
      final EzDBAccess access = database.getDatabase().openAccess();
      try {
        access.getConnection().query("select * from dba_tables where owner not in ('SYS','SYSTEM','PUBLIC') and IOT_NAME is null", new EzDBResultSetListener() {

          @Override
          public void set(int i, ResultSet v) throws SQLException {
            try {
              final String tableName = SQLUtils.getString(v, 1);
              if (StringComparator.isNotNull(tableName)) {
                final DBTable table = new DBTable(DBSchema.this, tableName);
                tables.add(table);
              }
            }
            catch (Throwable ignored) {
              EasyRMS.trace.log(ignored);
            }
          }

        });
      }
      finally {
        access.close();
      }
      return tables;
    }

  };

  /**Triggers **/
  public DBTrigger findTrigger(String name) {
    return triggers.get().find(name);
  }

  public EzArray<? extends DBTrigger> getTriggers() {
    return triggers.get().getList();
  }

  private class TriggerCollection {

    public void add(DBTrigger trigger) {
      if (trigger != null) {
        final String triggerName = trigger.getName();
        if (!triggerByName.containsKey(triggerName)) {
          if (triggers.add(trigger)) {
            triggerByName.put(triggerName, trigger);
          }
        }
      }
    }

    public DBTrigger find(String name) {
      return triggerByName.get(name);
    }

    public EzArray<DBTrigger> getList() {
      return triggers.getList();
    }

    private HashMap<String, DBTrigger> triggerByName = new HashMap<String, DBTrigger>();
    private EzArrayCopyOnWriteList<DBTrigger> triggers = new EzArrayCopyOnWriteList<DBTrigger>();
  }

  private ObjectReference<TriggerCollection> triggers = new AutoCreateReference<TriggerCollection>() {

    @Override
    protected TriggerCollection create() {
      final TriggerCollection triggers = new TriggerCollection();
      final EzDBAccess access = database.getDatabase().openAccess();
      try {
        access.getConnection().query("select dba_objects.OBJECT_NAME, sys.TRIGGER$.definition, sys.TRIGGER$.whenclause, sys.TRIGGER$.action# from dba_objects, sys.TRIGGER$ where dba_objects.OBJECT_ID = sys.TRIGGER$.obj#  and dba_objects.owner not in ('SYS','PUBLIC','SYSTEM') and dba_objects.object_type='TRIGGER'", new EzDBResultSetListener() {

          @Override
          public void set(int i, ResultSet v) throws SQLException {
            try {
              final String triggerName = SQLUtils.getString(v, 1);
              final String triggerDefinition = SQLUtils.getString(v, 2);
              final String triggerWhen = SQLUtils.getString(v, 3);
              final String triggerAction = SQLUtils.getString(v, 4);
              if (StringComparator.isNotNull(triggerName)) {
                final DBTrigger trigger = new DBTrigger(DBSchema.this, triggerName, triggerDefinition, triggerWhen, triggerAction);
                triggers.add(trigger);
              }
            }
            catch (Throwable ignored) {
              EasyRMS.trace.log(ignored);
            }
          }

        });
      }
      finally {
        access.close();
      }
      return triggers;
    }

  };

  /**Synonym **/
  public DBSynonym findSynonym(String name) {
    return synonyms.get().find(name);
  }

  public EzArray<? extends DBSynonym> getSynonyms() {
    return synonyms.get().getList();
  }

  private class SynonymCollection {

    public void add(DBSynonym synonym) {
      if (synonym != null) {
        final String synonymName = synonym.getName();
        if (!synonymByName.containsKey(synonymName)) {
          if (synonyms.add(synonym)) {
            synonymByName.put(synonymName, synonym);
          }
        }
      }
    }

    public DBSynonym find(String name) {
      return synonymByName.get(name);
    }

    public EzArray<DBSynonym> getList() {
      return synonyms.getList();
    }

    private HashMap<String, DBSynonym> synonymByName = new HashMap<String, DBSynonym>();
    private EzArrayCopyOnWriteList<DBSynonym> synonyms = new EzArrayCopyOnWriteList<DBSynonym>();
  }

  private ObjectReference<SynonymCollection> synonyms = new AutoCreateReference<SynonymCollection>() {

    @Override
    protected SynonymCollection create() {
      final SynonymCollection synonyms = new SynonymCollection();
      final EzDBAccess access = database.getDatabase().openAccess();
      try {
        access.getConnection().query("select  synonym_name,table_name from dba_synonyms where table_owner not in ('SYS','SYSTEM', 'PUBLIC')", 
          new EzDBResultSetListener() {

          @Override
          public void set(int i, ResultSet v) throws SQLException {
            try {
              final String synonymName = SQLUtils.getString(v, 1);
              final String synonymTableName = SQLUtils.getString(v, 2);
              
              if (StringComparator.isNotNull(synonymName)) {
                final DBSynonym synonym = new DBSynonym(DBSchema.this, synonymName, synonymTableName);
                synonyms.add(synonym);
              }
            }
            catch (Throwable ignored) {
              EasyRMS.trace.log(ignored);
            }
          }

        });
      }
      finally {
        access.close();
      }
      return synonyms;
    }

  };
  
  /**View **/
  public DBView findView(String name) {
    return views.get().find(name);
  }

  public EzArray<? extends DBView> getViews() {
    return views.get().getList();
  }

  private class ViewCollection {

    public void add(DBView view) {
      if (view != null) {
        final String viewName = view.getName();
        if (!viewByName.containsKey(viewName)) {
          if (views.add(view)) {
            viewByName.put(viewName, view);
          }
        }
      }
    }

    public DBView find(String name) {
      return viewByName.get(name);
    }

    public EzArray<DBView> getList() {
      return views.getList();
    }

    private HashMap<String, DBView> viewByName = new HashMap<String, DBView>();
    private EzArrayCopyOnWriteList<DBView> views = new EzArrayCopyOnWriteList<DBView>();
  }

  private ObjectReference<ViewCollection> views = new AutoCreateReference<ViewCollection>() {

    @Override
    protected ViewCollection create() {
      final ViewCollection synonyms = new ViewCollection();
      final EzDBAccess access = database.getDatabase().openAccess();
      try {
        access.getConnection().query("select view_name, text from dba_views where owner not in ('SYS', 'SYSTEM')", 
          new EzDBResultSetListener() {

          @Override
          public void set(int i, ResultSet v) throws SQLException {
            try {
              final String viewName = SQLUtils.getString(v, 1);
              final String viewText = SQLUtils.getString(v, 2);
              
              if (StringComparator.isNotNull(viewName)) {
                final DBView view = new DBView(DBSchema.this, viewName, viewText );
                synonyms.add(view);
              }
            }
            catch (Throwable ignored) {
              EasyRMS.trace.log(ignored);
            }
          }

        });
      }
      finally {
        access.close();
      }
      return synonyms;
    }

  };
  
  private DBLDDDatabase database = null;
  private String name = null;
  EzArray<Package> packages = null;
  EzArray<Procedure> procedures = null;
}
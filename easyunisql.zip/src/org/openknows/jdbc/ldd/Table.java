package org.openknows.jdbc.ldd;

import java.util.*;

public interface Table {

  String getName();
  String getType();
  String getDescription();
  ArrayList<?> getColumnList();
  Schema getSchema();
  
}
package org.openknows.jdbc.ldd;

public class DBView implements View {

  public DBView(Schema schema, String name, String text){
    
    this.schema = schema;
    this.name = name;
    this.text = text;
    
  }
  
  public String getName() {
    return null;
  }

  public Schema getSchema() {
    return null;
  }

  public String getText() {
    return null;
  }

  public int getTextLength() {
    return 0;
  }
  
  String name;
  Schema schema;
  String text;
  int textLength;

}

package org.openknows.jdbc.ldd;

public interface Trigger {

  String getName();
  String getDefinition();
  String getWhen();
  String getAction();
  Schema getSchema();
  
}

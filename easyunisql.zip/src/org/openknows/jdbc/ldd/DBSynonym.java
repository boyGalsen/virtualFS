package org.openknows.jdbc.ldd;

public class DBSynonym implements Synonym {

  public DBSynonym(Schema schema, String name, String tableName){
    
    this.schema = schema;
    this.name = name;
    this.tableName = tableName;
    
  }
  
  public String getName() {
    return null;
  }

  public Schema getSchema() {
    return null;
  }

  public String getTableName() {
    return null;
  }

  Schema schema;
  String name;
  String tableName;
}

package org.openknows.jdbc.ldd;

public interface Column {

  String getName();
  String getDataType();
  String getDataLength();
  String getDescription();
  
}
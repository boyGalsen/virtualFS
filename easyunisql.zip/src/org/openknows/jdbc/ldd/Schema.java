package org.openknows.jdbc.ldd;

import com.easyrms.util.*;

public interface Schema {

  String getName();
  LDDDatabase getLDDDatabase();
  EzArray<? extends DBFunction> getFunctions();
  EzArray<Package> getPackages();
  EzArray<Procedure> getProcedures();
  EzArray<? extends DBSynonym> getSynonyms();
  EzArray<? extends DBTable> getTables();
  EzArray<? extends DBTrigger> getTriggers();
  EzArray<? extends DBView> getViews();

}
package org.openknows.jdbc.ldd;

import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.sql.*;
import java.util.*;

public class DBLDDDatabase implements LDDDatabase {

  public DBLDDDatabase(EzJDBCDatabase database) {
    this.database = database; //new EzJDBCDatabase(name, "OracleDB", "jdbc:oracle:thin:???", false, 3, 3);
  }
  
  public String getName() {
    return database.getName()+"-"+database.getDescription();
  }

  public EzJDBCDatabase getDatabase(){
    return database;
  }
  
  public DBSchema findSchema(String name) {
    return schemas.get().find(name);
  }

  public EzArray<? extends DBSchema> getSchemas() {
    return schemas.get().getList();
  }
  
  private class SchemaCollection {
    
    public void add(DBSchema schema) {
      if (schema != null) {
        final String schemaName = schema.getName();
        if (!schemaByName.containsKey(schemaName)) {
          if (schemas.add(schema)) {
            schemaByName.put(schemaName, schema);
          }
        }
      }
    }
    
    public DBSchema find(String name) {
      return schemaByName.get(name);
    }
    
    public EzArray<DBSchema> getList() {
      return schemas.getList();
    }
    
    private HashMap<String, DBSchema> schemaByName = new HashMap<String, DBSchema>(); 
    private EzArrayCopyOnWriteList<DBSchema> schemas = new EzArrayCopyOnWriteList<DBSchema>();
  }

  private ObjectReference<SchemaCollection> schemas = new AutoCreateReference<SchemaCollection>() {

    @Override
    protected SchemaCollection create() {
      final SchemaCollection schemas = new SchemaCollection();
      final EzDBAccess access = database.openAccess();
      try {
        access.getConnection().query(
          "SELECT username FROM all_users ORDER BY username",
          new EzDBResultSetListener() {

            @Override
            public void set(int i, ResultSet v) throws SQLException {
              try {
                final String userName = SQLUtils.getString(v, 1);
                if (StringComparator.isNotNull(userName)) {
                  final DBSchema schema = new DBSchema(DBLDDDatabase.this, userName);
                  schemas.add(schema);
                }
              }
              catch (Throwable ignored) {
                EasyRMS.trace.log(ignored);
              }
            }
            
          });
      }
      finally {
        access.close();
      }
      return schemas;
    }
    
  };
  
  private EzJDBCDatabase database;
  
}
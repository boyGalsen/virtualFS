package org.openknows.jdbc.ldd;

public interface Procedure {

  String getName();
  String getType();
  String getBody();
  Schema getSchema();

}

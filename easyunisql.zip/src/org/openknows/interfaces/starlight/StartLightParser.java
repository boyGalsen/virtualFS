package org.openknows.interfaces.starlight;

import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.text.*;

public class StartLightParser {
  
  public StartLightParser(Reader reader) {
    this.reader = new BoundedBufferedReader(reader);
  }

  public boolean nextEntry() throws ParseException, IOException {
    if (isEnded) {
      return false;
    }
    if (isFirstRow) {
      isFirstRow = false;
      currentLine = this.reader.readLine();
      if (currentLine == null) {
        isEnded = true;
        return false;
      }
      if (currentLine.length() > 15) {
        if (StringComparator.isNumber(currentLine.charAt(0))
          && StringComparator.isNumber(currentLine.charAt(1))
          && StringComparator.isNumber(currentLine.charAt(2))
          && StringComparator.isNumber(currentLine.charAt(3))
          && StringComparator.isNumber(currentLine.charAt(4))
          && StringComparator.isNumber(currentLine.charAt(5))
          && StringComparator.isNumber(currentLine.charAt(6))
          && StringComparator.isNumber(currentLine.charAt(7))
          && ':' == currentLine.charAt(8)
          && StringComparator.isNumber(currentLine.charAt(9))
          && StringComparator.isNumber(currentLine.charAt(10))
          && ':' == currentLine.charAt(11)
          && StringComparator.isNumber(currentLine.charAt(12))
          && StringComparator.isNumber(currentLine.charAt(13))
          && !StringComparator.isNumber(currentLine.charAt(14)))
        {
          currentPrefix = currentLine.substring(0, 14);
          currentEntry = currentLine.substring(14, currentLine.indexOf(" "));
          currentEntryRead = true;
          return true;
        }
        else {
          throw new IOException("Invalid starlight file");
        }
      }
    }
    else {
      if (!currentEntryRead) {
        currentEntryRead = true;
        return currentEntry != null;
      }
      while (nextCurrentEntryRow()) {
      }
      currentEntryRead = true;
      return currentEntry != null;
    }
    isEnded = true;
    return false;
  }
  
  public boolean nextCurrentEntryRow() throws ParseException, IOException {
    if (currentEntry == null) {
      throw new IOException("Cannot read row without read entry");
    }
    currentLine = reader.readLine();
    if (currentLine == null) {
      currentEntry = null;
      currentRowInEntry = 0;
      isEnded = true;
      return false;
    }
    if (currentLine.length() > 15 && currentLine.startsWith(currentPrefix)) {
      currentEntry = currentLine.substring(14, currentLine.indexOf(" "));
      currentRowInEntry = 0;
      return false;
    }
    currentRowInEntry++;
    return true;
  }
  
  public int getCurrentEntryWidth() {
    return 1;
  }
  
  public String getCurrentEntryColumn(int column) {
    return "All";
  }
  
  public String getCurrentEntryRowValue(int column) {
    return currentLine;
  }
  
  public String getCurrentEntryName() {
    return currentEntry;
  }
  
  
  private static class EntryColumn {
    
    public String getName() {
      return null;
    }
    
    public int getSize() {
      return 0;
    }
  }
  
  public void close() {
  }
  
  private static HashMapArrayList<String, EntryColumn> starlightEntryLine = new HashMapArrayList<>();
  private BoundedBufferedReader reader;
  private String currentLine;
  private boolean currentEntryRead;
  private String currentEntry;
  private int currentRowInEntry;
  private boolean isFirstRow = true;
  private boolean isEnded = false;
  private String currentPrefix;
}

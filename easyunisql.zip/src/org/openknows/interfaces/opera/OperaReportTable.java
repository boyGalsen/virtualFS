package org.openknows.interfaces.opera;


import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;

import java.io.*;


public class OperaReportTable implements AtTable {
  
  public OperaReportTable init(final MemoryDatabase database, final String file, String name) throws DatabaseException {
    try {
      return this.init(EzFSUtil.findEzFsFileDescriptior(file), name);
    }
    catch (IOException ioException) {
      throw new DatabaseException(ioException);
    }
  }
	
	public OperaReportTable init(final EzFSFileDescriptor file) throws DatabaseException {
		return this.init(file, true);
	}
  
  public OperaReportTable init(final EzFSFileDescriptor file, String name) throws DatabaseException {
    return this.init(file, name, true);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return EzFSUtil.getAbsolutePath(this.file);
  }
  
  public String getName() {
    return this.name;
  }

  public OperaReportTable init(final EzFSFileDescriptor file, final boolean withColumnNameHeader) throws DatabaseException {
    return init(file, EzFSUtil.getAbsolutePath(file), withColumnNameHeader);
  }
  
  public OperaReportTable init(final EzFSFileDescriptor file, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
      final TableMetaData metaData = new TableMetaData();
      try (final EzFSConnection connection = EzFS.reference.get().getConnection(file.getConnectionDescriptor())) {
        try (final Reader in = connection.find(file).getAccess().openReader()) {
          final SimpleOperaReportRecord record = new SimpleOperaReportRecord(in);
          for (int i = 0, n = record.getWidth(); i < n; i++) {
            metaData.add(Column.getAndInit(record.getColumnName(i), ColumnType.STRING));
          }
        }
      }
	  	this.metaData = metaData;
  	}
		catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
  	  return new OperaReportTableAccessor(file, metaData, withColumnNameHeader);
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return null;
	}
  
  private EzFSFileDescriptor file;
  private boolean withColumnNameHeader;
  private MetaData metaData;
  private String name;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}

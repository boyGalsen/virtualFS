package org.openknows.interfaces.opera;

import com.easyrms.CSV.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.text.*;

public class SimpleOperaReportRecord extends SimpleTSVRecord {

  public SimpleOperaReportRecord(Reader in) {
    super(in);
  }

  @Override
  public boolean next() throws ParseException, IOException {
    if (lineIndex <= 0) {
      return super.next();
    }
    final boolean superNext = super.next();
    if (superNext) {
      return !StringComparator.NVL(getCell(0)).startsWith("S_");
    }
    return false;
  }
}

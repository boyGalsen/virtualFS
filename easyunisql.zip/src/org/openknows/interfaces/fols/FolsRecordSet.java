package org.openknows.interfaces.fols;

import com.easyrms.CSV.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;

import java.io.*;
import java.text.*;
import java.util.*;
import jxl.*;

public class FolsRecordSet implements ExtendedRecordSet {

  public FolsRecordSet(InputStream in) {
    try {
      folsEntries = new FolsStatXMLHandler().parse(new InputStreamReader(in, EzEncoding.UTF_8.getCharset()));
      init();
    }
    catch (Throwable forward) {
      throw ExceptionUtils.newRuntimeException("Error When Parsing Excel File", forward);
    }
  }

  public String getCell(int column) {
    if (!hasMore) throw new IllegalArgumentException("Cannot Access Get Object When Next Is False");  
    final Object o = rowData[column];
    if (o == null) {
      return "";
    }
    if (o instanceof DateAccessor) {
      return ebXMLDateFormat.referenceFormat(o);
    }
    if (o instanceof Double) {
      return DoubleFormat.referenceFormat(o);
    }
    if (o instanceof Integer) {
      return IntegerFormat.referenceFormat(o);
    }
    return o.toString();
  }
  
  public int findColumnIndex(String name) {
    final Integer index = columnsByName.get(name);
    return (index == null) ? -getWidth() : index.intValue();
  }

  public String getColumnName(int column) {
    return columns[column];
  }

  public Object getObject(int column) {
    if (!hasMore) throw new IllegalArgumentException("Cannot Access Get Object When Next Is False");  
    return rowData[column];
  }

  public int getWidth() {
    return columns.length;
  }

  public boolean next() throws ParseException, IOException {
    if (!hasMore) return false;
    final FolsStatEntry folsStatEntry = folsEntries.get(currentRow);
    int i = 0;
    
    rowData[i++] = folsStatEntry.getHOTE_ID();
    rowData[i++] = folsStatEntry.getSTAY_ID();
    rowData[i++] = folsStatEntry.getHOTE_CODE();
    rowData[i++] = folsStatEntry.getSTAY_NUM();
    rowData[i++] = folsStatEntry.getSTAY_BOOK_DATE();
    rowData[i++] = folsStatEntry.getSTAY_DATE_START();
    rowData[i++] = folsStatEntry.getSTAY_DATE_END();
    rowData[i++] = folsStatEntry.getSTAY_TU_ACCOMMODATION_TI();
    rowData[i++] = folsStatEntry.getSTAY_TU_ACCOMMODATION_TE();
    rowData[i++] = folsStatEntry.getSTAY_TU_FOOD_TI();
    rowData[i++] = folsStatEntry.getSTAY_TU_FOOD_TE();
    rowData[i++] = folsStatEntry.getSTAY_TU_OTHER_TI();
    rowData[i++] = folsStatEntry.getSTAY_TU_OTHER_TE();
    rowData[i++] = folsStatEntry.getSTAY_TU_TOTAL_TI();
    rowData[i++] = folsStatEntry.getSTAY_TU_TOTAL_TE();
    rowData[i++] = folsStatEntry.getTAY_TU_NOSHOW_TI();
    rowData[i++] = folsStatEntry.getTAY_TU_NOSHOW_TE();
    rowData[i++] = folsStatEntry.getSTAY_CHANNEL();
    rowData[i++] = folsStatEntry.getSTAY_RATE();
    rowData[i++] = folsStatEntry.getSTAY_ROOM_TYPE();
    rowData[i++] = folsStatEntry.getPRODUCT_TARS_CODE();
    rowData[i++] = folsStatEntry.getSTAY_SEGMENT();
    rowData[i++] = folsStatEntry.getRML();
    rowData[i++] = folsStatEntry.getHOM();
    rowData[i++] = folsStatEntry.getPUR();
    rowData[i++] = folsStatEntry.getGROUPID();
    rowData[i++] = folsStatEntry.getSTAY_ADULTS();
    rowData[i++] = folsStatEntry.getSTAY_CHILDREN();
    
    hasMore = currentRow < folsEntries.getCount();
    currentRow++;
    return hasMore;
  }
  
  private void init() {
    hasMore = currentRow < folsEntries.getCount();
  }
  
  private EzArray<? extends FolsStatEntry> folsEntries;
  private Object[] rowData = new Object[columns.length];
  private int currentRow = 0;
  private boolean hasMore = true;
  
  
  private static final String[] columns = new String[] {
    "HOTE_ID",
    "STAY_ID", 
    "HOTE_CODE", 
    "STAY_NUM", 
    "STAY_BOOK_DATE", 
    "STAY_DATE_START", 
    "STAY_DATE_END", 
    "STAY_TU_ACCOMMODATION_TI", 
    "STAY_TU_ACCOMMODATION_TE", 
    "STAY_TU_FOOD_TI", 
    "STAY_TU_FOOD_TE", 
    "STAY_TU_OTHER_TI", 
    "STAY_TU_OTHER_TE", 
    "STAY_TU_TOTAL_TI", 
    "STAY_TU_TOTAL_TE", 
    "TAY_TU_NOSHOW_TI", 
    "TAY_TU_NOSHOW_TE", 
    "STAY_CHANNEL", 
    "STAY_RATE", 
    "STAY_ROOM_TYPE", 
    "PRODUCT_TARS_CODE", 
    "STAY_SEGMENT", 
    "RML", 
    "HOM", 
    "PUR", 
    "GROUPID", 
    "STAY_ADULTS", 
    "STAY_CHILDREN", 
  };
  private static HashMap<String, Integer> columnsByName = new HashMap<String, Integer>(columns.length);
  static {
    for (int i = 0, n = columns.length; i < n; i++) {
      columnsByName.put(columns[i], IntegerCache.get(i));
    }
  }
}
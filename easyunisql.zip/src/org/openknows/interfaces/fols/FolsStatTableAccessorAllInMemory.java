package org.openknows.interfaces.fols;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;

import java.io.*;


public class FolsStatTableAccessorAllInMemory implements TableAccessor {

  public FolsStatTableAccessorAllInMemory(final EzFSFileDescriptor file, final MetaData metaData, final boolean withColumnNames, final boolean ignoreExtraData) throws DatabaseException  { 
    try {
      this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
      this.parser = new FolsStatXMLHandler();
  		this.metaData = metaData;
      this.ignoreExtraData = ignoreExtraData;
		  try (final Reader in = fsConnection.find(file).getAccess().openReader()) {
        entries = StreamUtils.toString(in);
		  }
      int nextIndex = entries.indexOf("<STATISTICS ", currentFileIndex);
      currentFileIndex = nextIndex;
      hasNext = (nextIndex >= 0);
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}
  }
  
  public void init() throws DatabaseException {
  }

  public MetaData getMetaData()  throws DatabaseException {
    return metaData;
  }

  public boolean hasNext() throws DatabaseException {
  	return hasNext;
  }

  public Row getNext() throws DatabaseException {
		if (!hasNext) throw new DatabaseException("no more value");
		try {
		  int currentIndex = currentFileIndex;
		  int nextIndex = entries.indexOf("<STATISTICS ", currentFileIndex+1);
		  final String toSplit;
 		  if (nextIndex >= 0) {
	     toSplit = entries.substring(currentIndex, nextIndex);	    
		  }
		  else {
		    toSplit = entries.substring(currentIndex, entries.indexOf("</FOLS_STAT>"));
		  }
 		 currentFileIndex = nextIndex;
 		  
 		  
      rowIndex++;
      row = new DatabaseRow();
      row.init(this.metaData);
	  	int i = 1;
	  	currentLine = toSplit;
	  	currentLineIndex = 12;
	  	
	  	while (hasNextEntry()) {
	  	  switch (key) {
  	  	  case "HOTE_ID" : folsEntry.setHOTE_ID(value); break;
          case "STAY_ID" : folsEntry.setSTAY_ID(value); break;
          case "HOTE_CODE" : folsEntry.setHOTE_CODE(value); break;
          case "STAY_NUM" : folsEntry.setSTAY_NUM(value); break;
          case "STAY_BOOK_DATE" : folsEntry.setSTAY_BOOK_DATE(ebXMLDateFormat.referenceWithTime0Parse(value)); break;
          case "STAY_DATE_START" : folsEntry.setSTAY_DATE_START(ebXMLDateFormat.referenceWithTime0Parse(value)); break;
          case "STAY_DATE_END" : folsEntry.setSTAY_DATE_END(ebXMLDateFormat.referenceWithTime0Parse(value)); break;
          case "STAY_TU_ACCOMMODATION_TI" : folsEntry.setSTAY_TU_ACCOMMODATION_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_ACCOMMODATION_TE" : folsEntry.setSTAY_TU_ACCOMMODATION_TE(StringComparator.getDouble(value)); break;
          case "STAY_TU_FOOD_TI" : folsEntry.setSTAY_TU_FOOD_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_FOOD_TE" : folsEntry.setSTAY_TU_FOOD_TE(StringComparator.getDouble(value)); break;
          case "STAY_TU_OTHER_TI" : folsEntry.setSTAY_TU_OTHER_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_OTHER_TE" : folsEntry.setSTAY_TU_OTHER_TE(StringComparator.getDouble(value)); break;
          case "STAY_TU_TOTAL_TI" : folsEntry.setSTAY_TU_TOTAL_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_TOTAL_TE" : folsEntry.setSTAY_TU_TOTAL_TE(StringComparator.getDouble(value)); break;
          case "TAY_TU_NOSHOW_TI" : folsEntry.setTAY_TU_NOSHOW_TI(StringComparator.getDouble(value)); break;
          case "TAY_TU_NOSHOW_TE" : folsEntry.setTAY_TU_NOSHOW_TE(StringComparator.getDouble(value)); break;
          case "STAY_CHANNEL" : folsEntry.setSTAY_CHANNEL(value); break;
          case "STAY_RATE" : folsEntry.setSTAY_RATE(value); break;
          case "STAY_ROOM_TYPE" : folsEntry.setSTAY_ROOM_TYPE(value); break;
          case "PRODUCT_TARS_CODE" : folsEntry.setPRODUCT_TARS_CODE(value); break;
          case "STAY_SEGMENT" : folsEntry.setSTAY_SEGMENT(value); break;
          case "RML" : folsEntry.setRML(value); break;
          case "HOM" : folsEntry.setHOM(value); break;
          case "PUR" : folsEntry.setPUR(value); break;
          case "GROUPID" : folsEntry.setGROUPID(value); break;
          case "STAY_ADULTS" : folsEntry.setSTAY_ADULTS(StringComparator.getInteger(value)); break;
          case "STAY_CHILDREN" : folsEntry.setSTAY_CHILDREN(StringComparator.getInteger(value)); break;
	  	  }
	  	}
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getHOTE_ID()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_ID()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getHOTE_CODE()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_NUM()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_BOOK_DATE()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_DATE_START()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_DATE_END()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_ACCOMMODATION_TI()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_ACCOMMODATION_TE()));
  	  	row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_FOOD_TI()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_FOOD_TE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_OTHER_TI()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_OTHER_TE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_TOTAL_TI()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_TU_TOTAL_TE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getTAY_TU_NOSHOW_TI()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getTAY_TU_NOSHOW_TE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_CHANNEL()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_RATE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_ROOM_TYPE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getPRODUCT_TARS_CODE()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_SEGMENT()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getRML()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getHOM()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getPUR()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getGROUPID()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_ADULTS()));
        row.set(i++, JDBCDatabaseValue.getAndInit(folsEntry.getSTAY_CHILDREN()));
        folsEntry.clear();
	  	hasNext = (nextIndex >= 0);
	  	return row;
		}
		catch (Throwable e) {
      EasyRMS.trace.log(e);
			throw new DatabaseException("on row "+rowIndex+":"+ExceptionUtils.getMessage(e));
		}	  	
  }
  
  private boolean hasNextEntry() {
    int state = INSTART;
    final StringBuilder builder = StreamUtils.getStringBuilder();
    try {
      for (int i = currentLineIndex, n = currentLine.length(); i < n; i++) {
        final char c = currentLine.charAt(i);
        if (state == INSTART) {
          if (c == '\t' || c == '\r' || c == '\n' || c == ' ') {
            
          }
          else if (c == '/') {
            state = INEND;
          }
          else {
            state = INREADKEY;
            builder.append(c);
          }
        }
        else if (state == INSTARTVALUE) {
          if (c == '\t' || c == '\r' || c == '\n' || c == ' ') {
            
          }
          else if (c == '"') {
            state = INREADVALUE;
          }
          else {
            throw new IllegalArgumentException("Invalid entry:"+currentLine);
          }
        }
        else if (state == INSTARTVALUE) {
          if (c == '\t' || c == '\r' || c == '\n' || c == ' ') {
            
          }
          else if (c == '=') {
            state = INSTARTVALUE;
          }
          else {
            throw new IllegalArgumentException("Invalid entry:"+currentLine);
          }
        }
        else if (state == INREADKEY) {
          if (c == '\t' || c == '\r' || c == '\n' || c == ' ') {
            key = builder.toString();
            StreamUtils.reset(builder);
            state = INAFTERKEY;
          }
          else if (c == '=') {
            key = builder.toString();
            StreamUtils.reset(builder);
            state = INSTARTVALUE;
          }
          else {
            builder.append(c);
          }
        }
        else if (state == INREADVALUE) {
          if (c == '"') {
            value = builder.toString();
            StreamUtils.reset(builder);
            currentLineIndex = i+1;
            return true;
          }
          else {
            builder.append(c);
          }
        }
        else if (state == INEND) {
          if (c == '>') {
            return false;
          }
        }
      }
    }
    finally {
      StreamUtils.free(builder);
    }
    return false;
  }
  
  public void close() throws DatabaseException {
    try {
      try {
        hasNext = false;
        row = null;
        entries = null;
      }
      finally {
        if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
        }
      }
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }  
  }
  
  private EzFSConnection fsConnection;
  private static final int INSTART = 0;
  private static final int INREADKEY = 1;
  private static final int INAFTERKEY = 2;
  private static final int INSTARTVALUE = 3;
  private static final int INREADVALUE = 4;
  private static final int INEND = 5;
  
  private final FolsStatXMLHandler parser;
  private final MetaData metaData;

  private String currentLine = "";
  private String key = null;
  private String value = null;
  private int currentLineIndex = 0;
  
  private int rowCount;
  private int rowIndex;
  private DatabaseRow row;
  private boolean hasNext;
  private String entries;
  private int currentFileIndex = 0;
  private final boolean ignoreExtraData; 
  private FolsStatEntry folsEntry = new FolsStatEntry();
}

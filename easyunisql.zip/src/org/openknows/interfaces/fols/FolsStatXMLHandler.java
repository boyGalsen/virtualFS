package org.openknows.interfaces.fols;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.xml.*;

import java.io.*;
import org.xml.sax.*;

public class FolsStatXMLHandler extends SimpleXMLHandler {


  public FolsStatXMLHandler() {
    super();
    setWithNamespaces(false);
    setAutoValueReset(true);
    setIgnoreWhitespace(true);
  }

  public EzArray<? extends FolsStatEntry> parse(Reader reader) throws Exception {
    return parse(reader, false);
  }
  
  public synchronized EzArray<? extends FolsStatEntry> parse(Reader reader,  boolean closeReader) throws Exception {
    try {
      list = new EzArrayList<FolsStatEntry>();
      load(reader);
      return list;
    }
    finally {
      list = null;
      if (closeReader) {
        StreamUtils.closeNotCatch(reader);
      }
    }
  }
  
  @Override
  public void extendEndElement(String namespaceURI, String localName, String qName, String value) throws Exception {
    super.extendEndElement(namespaceURI, localName, qName, value);
  }

  @Override
  public void extendStartElement(String namespaceURI, String localName, String qName, Attributes atts) throws Exception {
    localName = StringComparator.NVL(localName, qName);
    if ("STATISTICS".equals(localName)) {
      final FolsStatEntry entry = new FolsStatEntry();
      for (int i = 0, n = atts.getLength(); i < n; i++) {
        final String att = StringComparator.NVL(atts.getLocalName(i), atts.getQName(i));
        final String value = atts.getValue(i);
        switch (att) {
          case "HOTE_ID" : entry.setHOTE_ID(value); break;
          case "STAY_ID" : entry.setSTAY_ID(value); break;
          case "HOTE_CODE" : entry.setHOTE_CODE(value); break;
          case "STAY_NUM" : entry.setSTAY_NUM(value); break;
          case "STAY_BOOK_DATE" : entry.setSTAY_BOOK_DATE(ebXMLDateFormat.referenceWithTime0Parse(value)); break;
          case "STAY_DATE_START" : entry.setSTAY_DATE_START(ebXMLDateFormat.referenceWithTime0Parse(value)); break;
          case "STAY_DATE_END" : entry.setSTAY_DATE_END(ebXMLDateFormat.referenceWithTime0Parse(value)); break;
          case "STAY_TU_ACCOMMODATION_TI" : entry.setSTAY_TU_ACCOMMODATION_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_ACCOMMODATION_TE" : entry.setSTAY_TU_ACCOMMODATION_TE(StringComparator.getDouble(value)); break;
          case "STAY_TU_FOOD_TI" : entry.setSTAY_TU_FOOD_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_FOOD_TE" : entry.setSTAY_TU_FOOD_TE(StringComparator.getDouble(value)); break;
          case "STAY_TU_OTHER_TI" : entry.setSTAY_TU_OTHER_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_OTHER_TE" : entry.setSTAY_TU_OTHER_TE(StringComparator.getDouble(value)); break;
          case "STAY_TU_TOTAL_TI" : entry.setSTAY_TU_TOTAL_TI(StringComparator.getDouble(value)); break;
          case "STAY_TU_TOTAL_TE" : entry.setSTAY_TU_TOTAL_TE(StringComparator.getDouble(value)); break;
          case "TAY_TU_NOSHOW_TI" : entry.setTAY_TU_NOSHOW_TI(StringComparator.getDouble(value)); break;
          case "TAY_TU_NOSHOW_TE" : entry.setTAY_TU_NOSHOW_TE(StringComparator.getDouble(value)); break;
          case "STAY_CHANNEL" : entry.setSTAY_CHANNEL(value); break;
          case "STAY_RATE" : entry.setSTAY_RATE(value); break;
          case "STAY_ROOM_TYPE" : entry.setSTAY_ROOM_TYPE(value); break;
          case "PRODUCT_TARS_CODE" : entry.setPRODUCT_TARS_CODE(value); break;
          case "STAY_SEGMENT" : entry.setSTAY_SEGMENT(value); break;
          case "RML" : entry.setRML(value); break;
          case "HOM" : entry.setHOM(value); break;
          case "PUR" : entry.setPUR(value); break;
          case "GROUPID" : entry.setGROUPID(value); break;
          case "STAY_ADULTS" : entry.setSTAY_ADULTS(StringComparator.getInteger(value)); break;
          case "STAY_CHILDREN" : entry.setSTAY_CHILDREN(StringComparator.getInteger(value)); break;
          default : 
        }
      }
      list.add(entry);
    }
    else {
      super.extendStartElement(namespaceURI, localName, qName, atts);
    }
  }

  private EzArrayList<FolsStatEntry> list = null;
}

package org.openknows.interfaces.fols;

import com.easyrms.date.*;

import org.openknows.jdbc.driver.unisql.*;

import java.util.*;

public class FolsStatEntry {
  
  
  
  public String getHOTE_ID() {
    return HOTE_ID;
  }
  public void setHOTE_ID(String hOTE_ID) {
    HOTE_ID = hOTE_ID;
  }
  public String getSTAY_ID() {
    return STAY_ID;
  }
  public void setSTAY_ID(String sTAY_ID) {
    STAY_ID = sTAY_ID;
  }
  public String getHOTE_CODE() {
    return HOTE_CODE;
  }
  public void setHOTE_CODE(String hOTE_CODE) {
    HOTE_CODE = hOTE_CODE;
  }
  public String getSTAY_NUM() {
    return STAY_NUM;
  }
  public void setSTAY_NUM(String sTAY_NUM) {
    STAY_NUM = sTAY_NUM;
  }
  public DateAccessor getSTAY_BOOK_DATE() {
    return STAY_BOOK_DATE;
  }
  public void setSTAY_BOOK_DATE(DateAccessor sTAY_BOOK_DATE) {
    STAY_BOOK_DATE = sTAY_BOOK_DATE;
  }
  public DateAccessor getSTAY_DATE_START() {
    return STAY_DATE_START;
  }
  public void setSTAY_DATE_START(DateAccessor sTAY_DATE_START) {
    STAY_DATE_START = sTAY_DATE_START;
  }
  public DateAccessor getSTAY_DATE_END() {
    return STAY_DATE_END;
  }
  public void setSTAY_DATE_END(DateAccessor sTAY_DATE_END) {
    STAY_DATE_END = sTAY_DATE_END;
  }
  public Double getSTAY_TU_ACCOMMODATION_TI() {
    return STAY_TU_ACCOMMODATION_TI;
  }
  public void setSTAY_TU_ACCOMMODATION_TI(Double sTAY_TU_ACCOMMODATION_TI) {
    STAY_TU_ACCOMMODATION_TI = sTAY_TU_ACCOMMODATION_TI;
  }
  public Double getSTAY_TU_ACCOMMODATION_TE() {
    return STAY_TU_ACCOMMODATION_TE;
  }
  public void setSTAY_TU_ACCOMMODATION_TE(Double sTAY_TU_ACCOMMODATION_TE) {
    STAY_TU_ACCOMMODATION_TE = sTAY_TU_ACCOMMODATION_TE;
  }
  public Double getSTAY_TU_FOOD_TI() {
    return STAY_TU_FOOD_TI;
  }
  public void setSTAY_TU_FOOD_TI(Double sTAY_TU_FOOD_TI) {
    STAY_TU_FOOD_TI = sTAY_TU_FOOD_TI;
  }
  public Double getSTAY_TU_FOOD_TE() {
    return STAY_TU_FOOD_TE;
  }
  public void setSTAY_TU_FOOD_TE(Double sTAY_TU_FOOD_TE) {
    STAY_TU_FOOD_TE = sTAY_TU_FOOD_TE;
  }
  public Double getSTAY_TU_OTHER_TI() {
    return STAY_TU_OTHER_TI;
  }
  public void setSTAY_TU_OTHER_TI(Double sTAY_TU_OTHER_TI) {
    STAY_TU_OTHER_TI = sTAY_TU_OTHER_TI;
  }
  public Double getSTAY_TU_OTHER_TE() {
    return STAY_TU_OTHER_TE;
  }
  public void setSTAY_TU_OTHER_TE(Double sTAY_TU_OTHER_TE) {
    STAY_TU_OTHER_TE = sTAY_TU_OTHER_TE;
  }
  public Double getSTAY_TU_TOTAL_TI() {
    return STAY_TU_TOTAL_TI;
  }
  public void setSTAY_TU_TOTAL_TI(Double sTAY_TU_TOTAL_TI) {
    STAY_TU_TOTAL_TI = sTAY_TU_TOTAL_TI;
  }
  public Double getSTAY_TU_TOTAL_TE() {
    return STAY_TU_TOTAL_TE;
  }
  public void setSTAY_TU_TOTAL_TE(Double sTAY_TU_TOTAL_TE) {
    STAY_TU_TOTAL_TE = sTAY_TU_TOTAL_TE;
  }
  public Double getTAY_TU_NOSHOW_TI() {
    return TAY_TU_NOSHOW_TI;
  }
  public void setTAY_TU_NOSHOW_TI(Double tAY_TU_NOSHOW_TI) {
    TAY_TU_NOSHOW_TI = tAY_TU_NOSHOW_TI;
  }
  public Double getTAY_TU_NOSHOW_TE() {
    return TAY_TU_NOSHOW_TE;
  }
  public void setTAY_TU_NOSHOW_TE(Double tAY_TU_NOSHOW_TE) {
    TAY_TU_NOSHOW_TE = tAY_TU_NOSHOW_TE;
  }
  public String getSTAY_CHANNEL() {
    return STAY_CHANNEL;
  }
  public void setSTAY_CHANNEL(String sTAY_CHANNEL) {
    STAY_CHANNEL = sTAY_CHANNEL;
  }
  public String getSTAY_RATE() {
    return STAY_RATE;
  }
  public void setSTAY_RATE(String sTAY_RATE) {
    STAY_RATE = sTAY_RATE;
  }
  public String getSTAY_ROOM_TYPE() {
    return STAY_ROOM_TYPE;
  }
  public void setSTAY_ROOM_TYPE(String sTAY_ROOM_TYPE) {
    STAY_ROOM_TYPE = sTAY_ROOM_TYPE;
  }
  public String getPRODUCT_TARS_CODE() {
    return PRODUCT_TARS_CODE;
  }
  public void setPRODUCT_TARS_CODE(String pRODUCT_TARS_CODE) {
    PRODUCT_TARS_CODE = pRODUCT_TARS_CODE;
  }
  public String getSTAY_SEGMENT() {
    return STAY_SEGMENT;
  }
  public void setSTAY_SEGMENT(String sTAY_SEGMENT) {
    STAY_SEGMENT = sTAY_SEGMENT;
  }
  public String getRML() {
    return RML;
  }
  public void setRML(String rML) {
    RML = rML;
  }
  public String getHOM() {
    return HOM;
  }
  public void setHOM(String hOM) {
    HOM = hOM;
  }
  public String getPUR() {
    return PUR;
  }
  public void setPUR(String pUR) {
    PUR = pUR;
  }
  public String getGROUPID() {
    return GROUPID;
  }
  public void setGROUPID(String gROUPID) {
    GROUPID = gROUPID;
  }
  public Integer getSTAY_ADULTS() {
    return STAY_ADULTS;
  }
  public void setSTAY_ADULTS(Integer sTAY_ADULTS) {
    STAY_ADULTS = sTAY_ADULTS;
  }
  public Integer getSTAY_CHILDREN() {
    return STAY_CHILDREN;
  }
  public void setSTAY_CHILDREN(Integer sTAY_CHILDREN) {
    STAY_CHILDREN = sTAY_CHILDREN;
  }
  public void clear() {
    HOTE_ID = null;
     STAY_ID = null;
     HOTE_CODE = null;
     STAY_NUM = null;
    STAY_BOOK_DATE = null;
    STAY_DATE_START = null;
    STAY_DATE_END = null;
    STAY_TU_ACCOMMODATION_TI = null;
    STAY_TU_ACCOMMODATION_TE = null;
    STAY_TU_FOOD_TI = null;
    STAY_TU_FOOD_TE = null;
    STAY_TU_OTHER_TI = null;
    STAY_TU_OTHER_TE = null;
    STAY_TU_TOTAL_TI = null;
    STAY_TU_TOTAL_TE = null;
    TAY_TU_NOSHOW_TI = null;
    TAY_TU_NOSHOW_TE = null;
     STAY_CHANNEL = null;
     STAY_RATE = null;
     STAY_ROOM_TYPE = null;
     PRODUCT_TARS_CODE = null;
     STAY_SEGMENT = null;
     RML = null;
     HOM = null;
     PUR = null;
    GROUPID = null;
    STAY_ADULTS = null;
    STAY_CHILDREN = null;
  }

  private String HOTE_ID;
  private String STAY_ID;
  private String HOTE_CODE;
  private String STAY_NUM;
  private DateAccessor STAY_BOOK_DATE;
  private DateAccessor STAY_DATE_START;
  private DateAccessor STAY_DATE_END;
  private Double STAY_TU_ACCOMMODATION_TI;
  private Double STAY_TU_ACCOMMODATION_TE;
  private Double STAY_TU_FOOD_TI;
  private Double STAY_TU_FOOD_TE;
  private Double STAY_TU_OTHER_TI;
  private Double STAY_TU_OTHER_TE;
  private Double STAY_TU_TOTAL_TI;
  private Double STAY_TU_TOTAL_TE;
  private Double TAY_TU_NOSHOW_TI;
  private Double TAY_TU_NOSHOW_TE;
  private String STAY_CHANNEL;
  private String STAY_RATE;
  private String STAY_ROOM_TYPE;
  private String PRODUCT_TARS_CODE;
  private String STAY_SEGMENT;
  private String RML;
  private String HOM;
  private String PUR;
  private String GROUPID;
  private Integer STAY_ADULTS;
  private Integer STAY_CHILDREN;

}

package org.openknows.interfaces.fols;


import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.net.content.*;
import com.easyrms.util.xml.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.MemoryDatabase;


public class FolsStatTable implements AtTable {
  
  public FolsStatTable init(final MemoryDatabase database, final String file, String name) throws DatabaseException {
    try {
      return this.init(EzFSUtil.findEzFsFileDescriptior(file), name);
    }
    catch (IOException ioException) {
      throw new DatabaseException(ioException);
    }
  }
	
	public FolsStatTable init(final EzFSFileDescriptor file) throws DatabaseException {
		return this.init(file, true);
	}
  
  public FolsStatTable init(final EzFSFileDescriptor file, String name) throws DatabaseException {
    return this.init(file, name, true);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return EzFSUtil.getAbsolutePath(this.file);
  }
  
  public String getName() {
    return this.name;
  }

  public FolsStatTable init(final EzFSFileDescriptor file, final boolean withColumnNameHeader) throws DatabaseException {
    return init(file, EzFSUtil.getAbsolutePath(file), withColumnNameHeader);
  }
  
  public FolsStatTable init(final EzFSFileDescriptor file, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
	  	final TableMetaData metaData = new TableMetaData();
	  	metaData.add(Column.getAndInit("HOTE_ID", ColumnType.STRING));
	  	metaData.add(Column.getAndInit("STAY_ID", ColumnType.STRING));
	  	metaData.add(Column.getAndInit("HOTE_CODE", ColumnType.STRING));
	  	metaData.add(Column.getAndInit("STAY_NUM", ColumnType.STRING));
      metaData.add(Column.getAndInit("STAY_BOOK_DATE", ColumnType.DATE));
      metaData.add(Column.getAndInit("STAY_DATE_START", ColumnType.DATE));
      metaData.add(Column.getAndInit("STAY_DATE_END", ColumnType.DATE));
	  	metaData.add(Column.getAndInit("STAY_TU_ACCOMMODATION_TI", ColumnType.DOUBLE));
	  	metaData.add(Column.getAndInit("STAY_TU_ACCOMMODATION_TE", ColumnType.DOUBLE));
	  	metaData.add(Column.getAndInit("STAY_TU_FOOD_TI", ColumnType.DOUBLE));
	  	metaData.add(Column.getAndInit("STAY_TU_FOOD_TE", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("STAY_TU_OTHER_TI", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("STAY_TU_OTHER_TE", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("STAY_TU_TOTAL_TI", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("STAY_TU_TOTAL_TE", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("TAY_TU_NOSHOW_TI", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("TAY_TU_NOSHOW_TE", ColumnType.DOUBLE));
      metaData.add(Column.getAndInit("STAY_CHANNEL", ColumnType.STRING));
      metaData.add(Column.getAndInit("STAY_RATE", ColumnType.STRING));
      metaData.add(Column.getAndInit("STAY_ROOM_TYPE", ColumnType.STRING));
      metaData.add(Column.getAndInit("PRODUCT_TARS_CODE", ColumnType.STRING));
      metaData.add(Column.getAndInit("STAY_SEGMENT", ColumnType.STRING));
      metaData.add(Column.getAndInit("RML", ColumnType.STRING));
      metaData.add(Column.getAndInit("HOM", ColumnType.STRING));
      metaData.add(Column.getAndInit("PUR", ColumnType.STRING));
      metaData.add(Column.getAndInit("GROUPID", ColumnType.STRING));
      metaData.add(Column.getAndInit("STAY_ADULTS", ColumnType.LONG));
      metaData.add(Column.getAndInit("STAY_CHILDREN", ColumnType.LONG));
	  	this.metaData = metaData;
  	}
		catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
  	  if (true) {
        return new FolsStatTableAccessorAllInMemory(file, metaData, withColumnNameHeader, false);
  	  }
  	  return new FolsStatTableAccessor(file, metaData, withColumnNameHeader, false);
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return null;
	}
  
  private EzFSFileDescriptor file;
  private boolean withColumnNameHeader;
  private MetaData metaData;
  private String name;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}

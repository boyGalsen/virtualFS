package org.openknows.interfaces.fols;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.net.content.*;
import com.easyrms.util.xml.*;

import java.io.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;


public class FolsStatTableAccessor implements TableAccessor {

  public FolsStatTableAccessor(final EzFSFileDescriptor file, final MetaData metaData, final boolean withColumnNames, final boolean ignoreExtraData) throws DatabaseException  { 
    try {
      this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
      is = fsConnection.find(file).getAccess().openInput();
      final XMLInputStream in = new XMLInputStream(is);
      this.parser = new FolsStatXMLHandler();
      this.metaData = metaData;
      this.ignoreExtraData = ignoreExtraData;
	    entries = parser.parse(new InputStreamReader(in, EzEncoding.UTF_8.getCharset()));
      rowCount = entries.getCount();
  		hasNext = rowCount > rowIndex;
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}
  }
  
  public void init() throws DatabaseException {
  }

  public MetaData getMetaData()  throws DatabaseException {
    return metaData;
  }

  public boolean hasNext() throws DatabaseException {
  	return hasNext;
  }

  public Row getNext() throws DatabaseException {
		if (!hasNext) throw new DatabaseException("no more value");
		try {
		  final FolsStatEntry entry = entries.get(rowIndex);
      rowIndex++;
      row = new DatabaseRow();
      row.init(this.metaData);
	  	int i = 1;
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getHOTE_ID()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_ID()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getHOTE_CODE()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_NUM()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_BOOK_DATE()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_DATE_START()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_DATE_END()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_ACCOMMODATION_TI()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_ACCOMMODATION_TE()));
	  	row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_FOOD_TI()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_FOOD_TE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_OTHER_TI()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_OTHER_TE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_TOTAL_TI()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_TU_TOTAL_TE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getTAY_TU_NOSHOW_TI()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getTAY_TU_NOSHOW_TE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_CHANNEL()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_RATE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_ROOM_TYPE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getPRODUCT_TARS_CODE()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_SEGMENT()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getRML()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getHOM()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getPUR()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getGROUPID()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_ADULTS()));
      row.set(i++, JDBCDatabaseValue.getAndInit(entry.getSTAY_CHILDREN()));
	  	hasNext = rowIndex < rowCount;
	  	return row;
		}
		catch (Throwable e) {
      EasyRMS.trace.log(e);
			throw new DatabaseException("on row "+rowIndex+":"+ExceptionUtils.getMessage(e));
		}	  	
  }
  
  public void close() throws DatabaseException {
    try {
      try {
        hasNext = false;
        row = null;
        entries = null;
        if (is != null) {
          is.close();
          is = null;
        }
      }
      finally {
        if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
        }
      }
    }
    catch (Throwable e) {
      throw new DatabaseException(e);
    }  
  }
  
  private EzFSConnection fsConnection;
  private final FolsStatXMLHandler parser;
  private final MetaData metaData;
  private InputStream is;
  private int rowCount;
  private int rowIndex;
  private DatabaseRow row;
  private boolean hasNext;
  private EzArray<? extends FolsStatEntry> entries;
  
  private final boolean ignoreExtraData; 
}

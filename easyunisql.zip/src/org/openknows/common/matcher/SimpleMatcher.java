package org.openknows.common.matcher;

import com.easyrms.util.*;

import java.util.*;


public class SimpleMatcher {

  public SimpleMatcher addEquals(final String value, final int id) {
    equals.add(value);
    equalIDs.add(IntegerCache.get(id));
    return this;
  }

  public SimpleMatcher addStartWith(final String value, final int id) {
    startwiths.add(value);
    startwithIDs.add(IntegerCache.get(id));
    return this;
  }

  public SimpleMatcher addStartEndWith(final String start, final String end, final int id) {
    startendStartwiths.add(start);
    startendEndwiths.add(end);
    startendwithIDs.add(IntegerCache.get(id));
    return this;
  }

  public SimpleMatcher addEndWith(final String value, final int id) {
    endwiths.add(value);
    endwithIDs.add(IntegerCache.get(id));
    return this;
  }

  public IDRule compile() {
    return new IDRule() {

      public int match(final String value) {
        for (int i = 0, n = equals.size(); i < n ; i++) {
          final String s = equals.get(i);
          if (value == s || value.equals(s)) return equalIDs.get(i).intValue(); 
        }
        if (value == null) return -1;
        for (int i = 0, n = startendStartwiths.size(); i < n ; i++) {
          final String s = startendStartwiths.get(i);
          final String e = startendStartwiths.get(i);
          if (value.startsWith(s) && value.endsWith(e)) return startendwithIDs.get(i).intValue(); 
        }
        for (int i = 0, n = startwiths.size(); i < n ; i++) {
          final String s = startwiths.get(i);
          if (value.startsWith(s)) return startwithIDs.get(i).intValue(); 
        }
        for (int i = 0, n = endwiths.size(); i < n ; i++) {
          final String s = endwiths.get(i);
          if (value.endsWith(s)) return endwithIDs.get(i).intValue(); 
        }
        return -1;
      }
      
    };
  }
  
  public void clear() {
    equals.clear();
    equalIDs.clear();
    startwiths.clear();
    startwithIDs.clear();
    endwiths.clear();
    endwithIDs.clear();
  }
  
  private ArrayList<String> equals = new ArrayList<String>();
  private ArrayList<Integer> equalIDs = new ArrayList<Integer>();
  private ArrayList<String> startwiths = new ArrayList<String>();
  private ArrayList<Integer> startwithIDs = new ArrayList<Integer>();
  
  private ArrayList<String> startendStartwiths = new ArrayList<String>();
  private ArrayList<String> startendEndwiths = new ArrayList<String>();
  private ArrayList<Integer> startendwithIDs = new ArrayList<Integer>();
  
  private ArrayList<String> endwiths = new ArrayList<String>();
  private ArrayList<Integer> endwithIDs = new ArrayList<Integer>();
}
package org.openknows.common.matcher;

public interface ObjectRule<T> {

	public T match(final String value);
}

package org.openknows.common.matcher;
public interface IDRule {

	public int match(final String value);
}

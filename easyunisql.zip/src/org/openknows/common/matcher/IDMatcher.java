package org.openknows.common.matcher;

import com.easyrms.util.*;

import java.io.*;
import java.util.*;

import org.codehaus.janino.*;


public class IDMatcher {
	
	public void addEquals(final String value, final int id) {
		equals.add(value);
    equalIDs.add(IntegerCache.get(id));
	}

	public void addStartWith(final String value, final int id) {
		startwiths.add(value);
    startwithIDs.add(IntegerCache.get(id));
	}

  public void addEndWith(final String value, final int id) {
    endwiths.add(value);
    endwithIDs.add(IntegerCache.get(id));
  }

  public IDRule compile() {
  	final Atom firstAtom = new Atom();
    final boolean isEvery = endwiths.size() > 0;
    if (isEvery) firstAtom.setEvery();
    int i = 0;
  	for (final String value : equals) {
      final int m = value.length();
      Atom currentAtom = firstAtom;
      currentAtom.setMin(m);
      currentAtom.setMax(m);
  		for (int j = 0 ; j < m; j++) {
  			final char c = value.charAt(j);
  			currentAtom = currentAtom.add(c);
        if (isEvery) {
          currentAtom.setEvery();
        }
        currentAtom.setMin(m);
        currentAtom.setMax(m);
  		}
			currentAtom.setTerminal();
      currentAtom.setReturnValue(equalIDs.get(i++).intValue());
  	}
    i = 0;
		for (final String value : startwiths) {
      final int m = value.length();
      Atom currentAtom = firstAtom;
      currentAtom.setMin(m);
      currentAtom.setMax(Integer.MAX_VALUE);
			for (int j = 0 ; j < m; j++) {
				final char c = value.charAt(j);
				currentAtom = currentAtom.add(c);
        if (isEvery) {
          currentAtom.setEvery();
        }
        currentAtom.setMin(m);
        currentAtom.setMax(Integer.MAX_VALUE);
			}
			currentAtom.setAllMatch();
			currentAtom.setTerminal();
      currentAtom.setReturnValue(startwithIDs.get(i++).intValue());
		}
    i = 0;
    final Atom every = firstAtom.getEvery();
    if (isEvery) {
      for (final String value : endwiths) {
        final int m = value.length();
        Atom currentAtom = firstAtom; 
        currentAtom.setMin(m);
        currentAtom.setMax(Integer.MAX_VALUE);
        currentAtom.setEvery();
        currentAtom = every; 
        currentAtom.setMin(m);
        currentAtom.setMax(Integer.MAX_VALUE);
        currentAtom.activate();
        for (int j = 0 ; j < m; j++) {
          final char c = value.charAt(j);
          currentAtom = currentAtom.add(c);
          if (isEvery) currentAtom.setEvery();
          currentAtom.setMin(m);
          currentAtom.setMax(Integer.MAX_VALUE);
        }
        currentAtom.setTerminal();
        currentAtom.setReturnValue(endwithIDs.get(i++).intValue());
      }
    }
    return firstAtom.buildRule();
  }


	public static class Atom {

    public Atom() {	
      this.parent = null;
    	this.ids = new IDGenerator();
    	this.id = (int)ids.getNewValue();
      this.everyAtom = new Atom(this);
      this.isallmatch = false;
    }
    
    public Atom getEvery() {
      return this.everyAtom;
    }
      
    private Atom(final Atom parent) {
      this.parent = parent;
      this.ids = parent.ids;
      this.isevery = false;
      this.id = (int)ids.getNewValue();
      this.everyAtom = this;
    }
    
		private Atom(final char c, final Atom parent) {
			this.c = c;
      this.parent = parent;
      this.ids = parent.ids;
			this.id = (int)ids.getNewValue();
      this.everyAtom = parent.everyAtom;
		}
		
		Atom add(final char c) {
			final Character C = new Character(c);
			Atom a = map.get(C);
			if (a == null) {
				a = new Atom(c, this);
				map.put(C, a);
			}
			return a;
		}
    
    private boolean isEveryAtom() {
      return this == this.everyAtom;
    }
    
    private boolean isAllMatch() {
      if (parent == null) return isallmatch;
      if (isallmatch) return true;
      return parent.isAllMatch();
    }
		
    private int getAllMatchValue() {
      if (parent == null) return -1;
      if (isallmatch) return returnValue;
      return parent.getAllMatchValue();
    }
    
		void setTerminal() {
			this.isterminal = true;
		}
		
		void setAllMatch() {
			this.isallmatch = true;
      //this.allMatchValue = returnValue;
		}
		
		public boolean isTerminal() {
			return isterminal;
		}
		
		public boolean match(final String v) {
			return match(v.toCharArray(), 0, v.length()); 
		}
		
		public boolean match(final char[] value, final int index, final int endIndex) {
       if (endIndex <= index) return isterminal;
       if (isallmatch) return true;
       final Atom a = map.get(new Character(value[index]));
       return (a == null) ? false : a.match(value, index+1, endIndex);
		}

    public IDRule buildRule() {
      final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
			final StringBuilder buffer = bufferPool.get();
      try {
        final String name = "IDRule_"+StampUtil.getStampValue()+"_"+LongCache.toString(keys.getNewValue());
        buffer.append("package org.openknows.common.matcher;\r\n"
                     +"public class ").append(name).append(" implements org.openknows.common.matcher.IDRule {\r\n\r\n"
  			             +"  public int match(final String value) {\r\n");
      if (this.min == Integer.MAX_VALUE) {
          buffer.append("    return -1; \r\n");
      }
      else {
        buffer.append("    int state = ").append(id).append("; \r\n"
                     +"    final int n = value.length();\r\n");
       if (this.min > 0) {
         buffer.append("    if (n < ").append(LongCache.toString(this.min));
         if (this.max < Integer.MAX_VALUE) buffer.append(" || n > ").append(LongCache.toString(this.max));
         buffer.append(") return -1;\r\n");
       }
       else if (this.max < Integer.MAX_VALUE) {
         buffer.append("    if (n > ").append(LongCache.toString(this.max)).append(") return -1;\r\n");
       }
                     buffer.append("    for (int i = 0; i < n ; i++) {\r\n"
                     +"      final char c = value.charAt(i);\r\n"
                     //+" System.out.println(\"i=\"+i+\";c=\"+c+\";state=\"+state);\r\n"
                     +"      switch (state) {\r\n");
       if (everyAtom.isactivate) {
         buffer.append("//every\r\n");
         everyAtom.appendSwitch1(buffer);
       }
       appendSwitch1(buffer);
       buffer.append("        default : throw new IllegalStateException();\r\n"
  			             +"      }\r\n"
  			             +"    }\r\n"
  			             +"    switch (state) {\r\n");
        if (everyAtom.isactivate) {
          buffer.append("//every\r\n");
          everyAtom.appendSwitch2(buffer);
        }
        appendSwitch2(buffer);
  			buffer.append("      default : throw new IllegalStateException();\r\n"
  			             +"    }\r\n");
      }
        buffer.append("  }\r\n"
                     +"}\r\n");
        //System.out.println(buffer.toString());
        final SimpleCompiler compiler = new SimpleCompiler(null, new StringReader(buffer.toString()));
        return (IDRule)compiler.getClassLoader().loadClass("org.openknows.common.matcher."+name).newInstance();
			}
      catch (Throwable exception) {
        Trace.reference.log(exception);
        return null;
      }
			finally {
			  bufferPool.free(buffer);
			}
		}
		
		private void appendSwitch1(final StringBuilder buffer) {
      buffer.append("        case ").append(LongCache.toString(id)).append(" : \r\n");
			if (map.size() == 0) {
        if (isAllMatch()) {
          buffer.append("          return ").append(LongCache.toString(getAllMatchValue())).append(";\r\n");
        }
        else if (isEveryAtom()) {
          buffer.append("return -1;");
        }
        else if (isevery) {
          buffer.append("state = ").append(LongCache.toString(getEvery().id)).append("; --i; break;\r\n");
        }
        else {
				  buffer.append("           return -1;\r\n");
        }
			}
			else {
        buffer.append("          switch(c) {\r\n");
        for (final Atom a : map.values()) {
					buffer.append("            case ").append(LongCache.toString(a.c)).append(" : state = ").append(LongCache.toString(a.id)).append("; break;\r\n");
				}
				buffer.append("            default : ");
        if (isAllMatch()) {
          buffer.append("          return ").append(LongCache.toString(getAllMatchValue())).append(";\r\n");
        }
        else if (isEveryAtom()) {
          buffer.append("break;");
        }
        else if (!isevery) {
          buffer.append("return -1;");
        }
        else {
          buffer.append("state = ").append(LongCache.toString(getEvery().id)).append("; --i; break;");
        }
        buffer.append("\r\n"
				             +"          }\r\n"
				             +"        break;\r\n");
        for (final Atom a : map.values()) {
          a.appendSwitch1(buffer);
        }
			}
		}

		private void appendSwitch2(final StringBuilder buffer) {
			buffer.append("      case ").append(LongCache.toString(id)).append(" : return ").append(isterminal ? LongCache.toString(returnValue) : "-1").append(";\r\n");
      if (map.size() > 0) {
        for (final Atom a : map.values()) {
          a.appendSwitch2(buffer);
        }
      }
		}
    
    public void setMin(final int min) {
      this.min = Math.min(min, this.min);
    }

    public void setMax(final int max) {
      this.max = Math.max(max, this.max);
    }
    
    public void setReturnValue(final int returnValue) {
      if (this.returnValue != 0) throw new IllegalArgumentException();
      this.returnValue = returnValue;
    }
    
    public void setEvery() {
      this.isevery = true;
    }
    
    public boolean isEvery() {
      return this.isevery;
    }
    
    public void activate() {
      this.isactivate = true;
    }

		private HashMap<Character, Atom> map = new HashMap<Character, Atom>();
		private char c;
		private boolean isterminal = false;
		private boolean isallmatch = false;
    //private int allMatchValue = -1;
    private int min = Integer.MAX_VALUE;
    private int max = 0;
    private int returnValue = 0;
    private boolean isevery = false;
    private boolean isactivate = false;
    private final int id;
		private final IDGenerator ids;
    private final Atom parent;
    private final Atom everyAtom;
	}
  
  public void clear() {
    equals.clear();
    equalIDs.clear();
    startwiths.clear();
    startwithIDs.clear();
    endwiths.clear();
    endwithIDs.clear();
  }
	
	private ArrayList<String> equals = new ArrayList<String>();
  private ArrayList<Integer> equalIDs = new ArrayList<Integer>();
	private ArrayList<String> startwiths = new ArrayList<String>();
  private ArrayList<Integer> startwithIDs = new ArrayList<Integer>();
  private ArrayList<String> endwiths = new ArrayList<String>();
  private ArrayList<Integer> endwithIDs = new ArrayList<Integer>();
	
	/*
	private static final void match(Rule a, String value) {
		System.out.println(value+":"+a.match(value));
	}*/

  private static final IDGenerator keys = new IDGenerator();
}
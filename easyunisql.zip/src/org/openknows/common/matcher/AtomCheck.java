package org.openknows.common.matcher;

import com.easyrms.util.*;

import java.util.*;


public class AtomCheck {

  public void addEquals(final String value, final int id) {
    equals.add(value);
    equalIDs.add(IntegerCache.get(id));
  }

  public void addStartWith(final String value, final int id) {
    startwiths.add(value);
    startwithIDs.add(IntegerCache.get(id));
  }

  public void addStartEndWith(final String start, final String end, final int id) {
    startendStartwiths.add(start);
    startendEndwiths.add(end);
    startendwithIDs.add(IntegerCache.get(id));
  }

  public void addEndWith(final String value, final int id) {
    endwiths.add(value);
    endwithIDs.add(IntegerCache.get(id));
  }
  
  
  public Atom compile() {
    final boolean isEvery = endwiths.size() > 0;
    final Atom firstAtom = new Atom(isEvery);
    {
      int i = 0;
      for (int k = 0, l = equals.size(); k < l; k++) {
        final String value = equals.get(k);
        Atom currentAtom = firstAtom;
        for (int j = 0, m = value.length(); j < m; j++) {
          currentAtom = currentAtom.add(value.charAt(j));
          final Atom tmpAtom = currentAtom;
          int endI = 0;
          for (int endwithsI = 0, endwithsN = endwiths.size(); endwithsI < endwithsN; endwithsI++) {
            final String endValue = endwiths.get(endwithsI);
            for (int endJ = 0 , endM = endValue.length(); endJ < endM; endJ++) {
              currentAtom = currentAtom.add(endValue.charAt(endJ));
            }
            currentAtom.terminalID = endwithIDs.get(endI++).intValue();
          }
          currentAtom = tmpAtom;
        }
        currentAtom.terminalID = equalIDs.get(i++).intValue();
      }
    }
    {
      int i = 0;
      for (int k = 0, l = startwiths.size(); k < l; k++) {
        final String value = startwiths.get(k);
        Atom currentAtom = firstAtom;
        for (int j = 0, m = value.length() ; j < m; j++) {
          currentAtom = currentAtom.add(value.charAt(j));
          final Atom tmpAtom = currentAtom;
          int endI = 0;
          for (int endwithsI = 0, endwithsN = endwiths.size(); endwithsI < endwithsN; endwithsI++) {
            final String endValue = endwiths.get(endwithsI);
            for (int endJ = 0 , endM = endValue.length(); endJ < endM; endJ++) {
              currentAtom = currentAtom.add(endValue.charAt(endJ));
            }
            currentAtom.terminalID = endwithIDs.get(endI++).intValue();
          }
          currentAtom = tmpAtom;
        }
        currentAtom.terminalID = startwithIDs.get(i++).intValue();
        currentAtom.allMatchID = currentAtom.terminalID;
      }
    }
    {
      int i = 0;
      final Atom every = firstAtom.every;
      if (isEvery) {
        for (int k = 0, l = endwiths.size(); k < l; k++) {
          final String value = endwiths.get(k);
          Atom currentAtom = every; 
          for (int j = 0 , m = value.length(); j < m; j++) {
            currentAtom = currentAtom.add(value.charAt(j));
          }
          currentAtom.terminalID = endwithIDs.get(i++).intValue();
        }
      }
    }
    return firstAtom;
  }

  private ArrayList<String> equals = new ArrayList<String>();
  private ArrayList<Integer> equalIDs = new ArrayList<Integer>();
  private ArrayList<String> startwiths = new ArrayList<String>();
  private ArrayList<Integer> startwithIDs = new ArrayList<Integer>();
  
  private ArrayList<String> startendStartwiths = new ArrayList<String>();
  private ArrayList<String> startendEndwiths = new ArrayList<String>();
  private ArrayList<Integer> startendwithIDs = new ArrayList<Integer>();
  
  private ArrayList<String> endwiths = new ArrayList<String>();
  private ArrayList<Integer> endwithIDs = new ArrayList<Integer>();
  
  
  public class Atom {
    
    public Atom(boolean withEvery) { 
      this.parent = null;
      ids = new IDGenerator();
      id = ids.getNewValue(); 
      this.every = withEvery ? new Atom(this) : null;
    }

    private Atom(final Atom parent) {
      this.parent = parent;
      this.ids = parent.ids;
      this.id = ids.getNewValue();
      this.every = this;
    }
    
    private Atom(final char c, Atom parent) {
      this.parent = parent;
      this.c = c;
      this.ids = parent.ids;
      this.id = ids.getNewValue();
      this.every = parent.every;
    }
    
    Atom add(final char c) {
      final Character C = new Character(c);
      Atom a = map.get(C);
      if (a == null) {
        a = new Atom(c, this);
        map.put(C, a);
      }
      return a;
    }
    
    public int match(final String v) {
      return match(v.toCharArray(), 0, v.length()); 
    }
    
    public int match(final char[] value, final int index, final int endIndex) {
      if (endIndex <= index) return terminalID;
      final Atom a = map.get(new Character(value[index]));
      return (a == null) ? (every == null) ? allMatchID : checkAll(every.match(value, index+1, endIndex), allMatchID) : checkAll(a.match(value, index+1, endIndex), allMatchID) ;
    }
    
    private HashMap<Character, Atom> map = new HashMap<Character, Atom>();
    private char c;
    private final int id;
    private final IDGenerator ids;
    private Atom every;
    private Atom parent;
    
    private int terminalID = -1;
    private int allMatchID = -1;
  }

  
  private static final int checkAll(int result, int all) {
    return result < 0 ? all : result;
  }
}
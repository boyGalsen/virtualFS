package org.openknows.common.matcher;

import com.easyrms.util.*;

import org.codehaus.janino.*;

import java.io.*;
import java.util.*;



public class Matcher {
	
	public Matcher addEquals(final String value) {
		equals.add(value);
    return this;
	}

	public Matcher addStartWith(final String value) {
		startwiths.add(value);
    return this;
	}
  
  public Matcher addEndWidth(final String value) {
    endwiths.add(value);
    return this;
  }

  public Rule compile() {
  	final Atom firstAtom = new Atom();
  	for (final String value : equals) {
      final int m = value.length();
      Atom currentAtom = firstAtom;
      currentAtom.setMin(m);
      currentAtom.setMax(m);
  		for (int j = 0 ; j < m; j++) {
  			final char c = value.charAt(j);
  			currentAtom = currentAtom.add(c);
        currentAtom.setMin(m);
        currentAtom.setMax(m);
  		}
			currentAtom.setTerminal();
  	}
		for (final String value : startwiths) {
      final int m = value.length();
      Atom currentAtom = firstAtom;
      currentAtom.setMin(m);
      currentAtom.setMax(Integer.MAX_VALUE);
			for (int j = 0 ; j < m; j++) {
				final char c = value.charAt(j);
				currentAtom = currentAtom.add(c);
        currentAtom.setMin(m);
        currentAtom.setMax(Integer.MAX_VALUE);
			}
			currentAtom.setAllMatch();
			currentAtom.setTerminal();
		}
    if (endwiths.size() > 0) {
      firstAtom.setIsEverything();
      for (final String value : endwiths) {
        final int m = value.length();
        Atom currentAtom = firstAtom;
        currentAtom.setMin(m);
        currentAtom.setMax(Integer.MAX_VALUE);
        for (int j = 0 ; j < m; j++) {
          final char c = value.charAt(j);
          currentAtom = currentAtom.add(c);
          currentAtom.setMin(m);
          currentAtom.setMax(Integer.MAX_VALUE);
        }
        currentAtom.setTerminal();
      }
    }
		return firstAtom.buildRule();
  }


	public static class Atom {

    public Atom() {	
    	ids = new IDGenerator();
    	id = (int)ids.getNewValue();	
    }
		
		private Atom(final char c, final IDGenerator ids) {
			this.c = c;
			this.ids = ids;
			this.id = (int)ids.getNewValue();
		}
		
		Atom add(final char c) {
			final Character C = new Character(c);
			Atom a = map.get(C);
			if (a == null) {
				a = new Atom(c, ids);
				map.put(C, a);
			}
			return a;
		}
		
		void setTerminal() {
			this.isterminal = true;
		}
		
		void setAllMatch() {
			this.isallmatch = true;
		}
		
		public boolean isTerminal() {
			return isterminal;
		}
		
		public boolean match(final String v) {
			return match(v.toCharArray(), 0, v.length()); 
		}
    
    public boolean isEverything() {
      return isEverything();
    }
		
		public boolean match(final char[] value, final int index, final int endIndex) {
       if (endIndex <= index) return isterminal;
       if (isallmatch) return true;
       final Atom a = map.get(new Character(value[index]));
       return (a == null) ? iseverything ? match(value, index+1, endIndex) : false : a.match(value, index+1, endIndex);
		}

    public Rule buildRule() {
			final StringBuilder buffer = StreamUtils.getStringBuilder();
      try {
        final String name = "Rule_"+StampUtil.getStampValue()+"_"+LongCache.toString(keys.getNewValue());
        buffer.append("package org.openknows.common.matcher;\r\n"
                     +"public class ").append(name).append(" implements org.openknows.common.matcher.Rule {\r\n\r\n"
  			             +"  public boolean match(final String value) {\r\n"
                     +"    int state = ").append(id).append("; \r\n"
                     +"    final int n = value.length();\r\n" 
                     +"    if (n < ").append(LongCache.toString(this.min)).append(" && n > ").append(LongCache.toString(this.max)).append(") return false;\r\n"
                     +"    for (int i = 0; i < n ; i++) {\r\n"
  			             +"      final char c = value.charAt(i);\r\n"
  			             +"      switch (state) {\r\n");
  			appendSwitch1(buffer);
  			buffer.append("        default : throw new IllegalStateException();\r\n"
  			             +"      }\r\n"
  			             +"    }\r\n"
  			             +"    switch (state) {\r\n");
  			appendSwitch2(buffer);
  			buffer.append("      default : throw new IllegalStateException();\r\n"
  			             +"    }\r\n"
  			             +"  }\r\n"
  			             +"}\r\n");
				final SimpleCompiler compiler = new SimpleCompiler(null, new StringReader(buffer.toString()));
        return (Rule)compiler.getClassLoader().loadClass("org.openknows.common.matcher."+name).newInstance();
			}
      catch (Throwable exception) {
        return new Rule() {

          public boolean match(final String value) {
            return this.match(value);
          }
        };
      }
			finally {
				StreamUtils.free(buffer);
			}
		}
		
		private void appendSwitch1(final StringBuilder buffer) {
      buffer.append("        case ").append(LongCache.toString(id)).append(" : \r\n");
			if (isallmatch) {
				buffer.append("          return true;\r\n");
        for (final Atom a : map.values()) a.appendSwitch1(buffer);
			}
			else if (map.size() == 0) {
				buffer.append("          return false;\r\n");
			}
			else {
        buffer.append("          switch(c) {\r\n");
        for (final Atom a : map.values()) {
					buffer.append("            case ").append(LongCache.toString(a.c)).append(" : state = ").append(LongCache.toString(a.id)).append("; break;\r\n");
				}
				buffer.append("            default : ").append(iseverything ? "break;" : "return false;").append("\r\n"
				             +"          }\r\n"
				             +"        break;\r\n");
        for (final Atom a : map.values()) a.appendSwitch1(buffer);
			}
		}

		private void appendSwitch2(final StringBuilder buffer) {
			buffer.append("      case ").append(IntegerCache.toString(id)).append(" : return ").append(isterminal ? "true" : "false").append(";\r\n");
      if (map.size() > 0) {
        for (final Atom a : map.values()) {
          a.appendSwitch2(buffer);
        }
      }
		}
    
    public void setMin(int min) {
      this.min = Math.min(min, this.min);
    }

    public void setMax(int max) {
      this.max = Math.max(max, this.max);
    }
    
    public void setIsEverything() {
      this.iseverything = true;
    }

		private HashMap<Character, Atom> map = new HashMap<Character, Atom>();
		private char c;
		private boolean isterminal = false;
		private boolean isallmatch = false;
    private boolean iseverything = false;
    private int min = Integer.MAX_VALUE;
    private int max = 0;
		private final int id;
		private final IDGenerator ids;
	}
	
	private ArrayList<String> equals = new ArrayList<String>();
	private ArrayList<String> startwiths = new ArrayList<String>();
  private ArrayList<String> endwiths = new ArrayList<String>();
  
	
/*	private static final void match(Rule a, String value) {
		System.out.println(value+":"+a.match(value));
	}*/

  private static final IDGenerator keys = new IDGenerator();
}

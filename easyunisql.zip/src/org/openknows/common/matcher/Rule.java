


package org.openknows.common.matcher;
public interface Rule {

	public boolean match(final String value);
}

package org.openknows.common.matcher;

import java.util.ArrayList;

public class ObjectMatcher<T> {

  public ObjectMatcher<T> addEquals(final String value, final T o) {
    final int findIndex = objectList.indexOf(o);
    idMatcher.addEquals(value, (findIndex >= 0) ? findIndex : objectList.size());
    objectList.add(o);
    return this;
  }

  public ObjectMatcher<T> addEqualsIgnoreCase(final String value, final T o) {
    final int findIndex = objectList.indexOf(o);
    idMatcher.addEquals(value, (findIndex >= 0) ? findIndex : objectList.size());
    objectList.add(o);
    return this;
  }

  public ObjectMatcher<T> addStartWith(final String value, final T o) {
    final int findIndex = objectList.indexOf(o);
    idMatcher.addStartWith(value, (findIndex >= 0) ? findIndex : objectList.size());
    objectList.add(o);
    return this;
  }

  public ObjectMatcher<T> addEndWith(final String value, final T o) {
    final int findIndex = objectList.indexOf(o);
    idMatcher.addEndWith(value, (findIndex >= 0) ? findIndex : objectList.size());
    objectList.add(o);
    return this;
  }

  //markov
  public ObjectRule<T> compile() {
    final IDRule idRule = idMatcher.compile();
    return new ObjectRule<T>() {
      
      private final ArrayList<T> objectList = ObjectMatcher.this.objectList;
      private final T defaultValue = ObjectMatcher.this.defaultValue;

      public T match(final String value) {
        final int id = idRule.match(value);
        if (id < 0) return defaultValue;
        return objectList.get(id);
      }
    };
  }
  
  public ObjectMatcher<T> setDefaultValue(final T defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }
  
  public void clear() {
    objectList.clear();
    idMatcher.clear();
  }
  
  private T defaultValue = null;
  private final IDMatcher idMatcher = new IDMatcher();
  private final ArrayList<T> objectList = new ArrayList<T>();
}

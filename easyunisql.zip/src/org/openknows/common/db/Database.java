package org.openknows.common.db;

import java.sql.*;
import javax.sql.*;


public class Database {

  public Connection getConnection() {
    if (defaultPool == null) throw new IllegalStateException();
    try {
      return defaultPool.getConnection();
    }
    catch (Exception ignored) {
      throw new RuntimeException(ignored);
    }
  }

  public DataSource getDefaultDataSource() {
    return defaultPool;
  }
  protected void setDefaultDataSource(DataSource pool) {
    defaultPool = pool;
  }

  private DataSource defaultPool;
}
package org.openknows.common.db;

import java.sql.*;

public class SimpleRequest {

  public static SimpleStatementResult execute(Statement statement, String request) throws SQLException {
    statement.execute(request);
    final int updateCount = statement.getUpdateCount();
    final ResultSet resultSet = statement.getResultSet();
    return new SimpleStatementResult(request, updateCount < 0, updateCount, new ResultSet[] {resultSet}, -1);
  }
}

package org.openknows.common.db;

import java.sql.*;

public class SimpleStatementResult {

  public SimpleStatementResult(String sqlrequest, boolean isResultSet, int updateCount, ResultSet[] resultSet, int rowCount) {
    this.sqlrequest = sqlrequest;
    this.isResultSet = isResultSet;
    this.updateCount = updateCount;
    this.resultSet = (resultSet == null) ? new ResultSet[0] : resultSet;
    this.rowCount = rowCount;
  }
  
  public String getSQLRequest() {
    return sqlrequest;
  }
  
  public ResultSet getCurrentResultSet() {
    return (this.resultSet.length == 0) ? null : this.resultSet[0];
  }

  public ResultSet[] getResultSet() {
    return this.resultSet.clone();
  }

  public boolean isResultSet() {
    return this.isResultSet;
  }

  public int getUpdateCount() {
    return this.updateCount;
  }

  public SQLWarning getWarning() {
    return warning;
  }

  public SimpleStatementResult setWarning(SQLWarning warning) {
    this.warning = warning;
    return this;
  }

  public int getRowCount() {
    return rowCount;
  }
  
  public void close() {
  }

  private final boolean isResultSet;
  private final int updateCount;
  private final ResultSet[] resultSet;
  private final int rowCount;

  private final String sqlrequest;
  private SQLWarning warning = null;
}
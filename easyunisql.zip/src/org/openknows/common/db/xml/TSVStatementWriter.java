package org.openknows.common.db.xml;

import com.easyrms.builder.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.xml.*;

import java.io.*;
import java.sql.*;

import org.openknows.common.db.*;

public class TSVStatementWriter implements XMLStatementProtocol {
  
  public TSVStatementWriter(Writer out) {
    this.out = out;
  }
  
  public SimpleStatementResult execute(Statement statement, String request) throws SQLException {
    final TSVResponse xmlResponse = internalExecute(statement, request);
    try {
      final StringWriter sout = new StringWriter();
      write(xmlResponse, sout);
      sout.close();
      out.write(sout.toString());
      out.flush();
      return XMLStatementHandler.getStatement(new StringReader(sout.toString()));
    }
    catch (IOException exception) {
      throw new SQLException(exception);
    }
  }
  
  public void throwException(SQLException sqlException, String request) throws SQLException {
    write(new TSVResponse(request, StampUtil.getStampValue(), true, ExceptionUtils.getMessage(sqlException), false, 0, 0, 0), out);
  }
  
  private TSVStatementWriter writeHeader(Writer out, String property, String value) throws IOException {
    out.write(property);
    out.write("\t");
    out.write(StringComparator.NVL(value));
    out.write("\r\n");
    return this;
  }
  
  private void writeText(Writer out, String value) throws IOException {
    if (value != null) {
      final int result = checkSpecialChar(value);
      if ((result&WIDTHTILD) != 0) {
        value = value.replace("~", "~~");
      }
      if ((result&WIDTHSLASHR) != 0) {
        value = value.replace("\r", "~r");
      }
      if ((result&WIDTHSLASHN) != 0) {
        value = value.replace("\n", "~n");
      }
      if ((result&WIDTHTAB) != 0) {
        value = value.replace("\t", "~t");
      }
      if ((result&WIDTZERO) != 0) {
        value = value.replace("�", "~�");
      }
      out.write(value);
    }
  }
  
  private String readText(String value) {
    final int result = checkSpecialChar(value);
    if ((result&WIDTHTILD) != 0) {
      value = value.replace("~~", "~");
    }
    if ((result&WIDTHSLASHR) != 0) {
      value = value.replace("~r", "\r");
    }
    if ((result&WIDTHSLASHN) != 0) {
      value = value.replace("~n", "\n");
    }
    if ((result&WIDTHTAB) != 0) {
      value = value.replace("~t", "\t");
    }
    if ((result&WIDTZERO) != 0) {
      value = value.replace("~�", "�");
    }
    return value;
    
  }
  
  private int checkSpecialChar(String value) {
    int result = 0;
    for (int i = 0, n = value.length(); i < n; i++) {
      switch (value.charAt(i)) {
        case '~' : result = result|WIDTHTILD; break;
        case '\r' : result = result|WIDTHSLASHR; break;
        case '\n' : result = result|WIDTHSLASHN; break;
        case '\t' : result = result|WIDTHTAB; break;
        case '�' : result = result|WIDTZERO; break;
      }
    }
    return result;
  }
  
  private static final int WIDTHTILD = 1;
  private static final int WIDTHSLASHR = 2;
  private static final int WIDTHSLASHN = 4;
  private static final int WIDTHTAB = 8;
  private static final int WIDTZERO = 16;
  
  private void write(TSVResponse xmlResponse, Writer out) throws SQLException {
    try {
      final boolean withError = xmlResponse.isError();
      writeHeader(out, SQLResponseAttrID, null);
      writeHeader(out, SQLResponseAttrWithError, withError ? TRUEValue : FALSEValue);
      writeHeader(out, SQLResponseAttrStartTime, dateFormat(new java.util.Date(xmlResponse.start)));
      writeHeader(out, SQLResponseAttrExecutionDuration, LongCache.toString(StampUtil.getStampValue() - xmlResponse.start));
      writeHeader(out, SQLResponseAttrColCount, LongCache.toString(xmlResponse.getColCount()));
      writeHeader(out, SQLResponseAttrRowCount, LongCache.toString(xmlResponse.getRowCount()));
      writeHeader(out, SQLResponseAttrUpdateCount, LongCache.toString(xmlResponse.getUpdateCount()));
      out.write("~.~.~.~.~.Request~.~.~.~.~.\r\n");
      writeText(out, xmlResponse.getSQLRequest());
      out.write("\r\n");
      if (withError) {
        out.write("~.~.~.~.~.Error~.~.~.~.~.\r\n");
        writeText(out, xmlResponse.getXMLSQLResponse());
      }
      else {
        out.write("~.~.~.~.~.Result~.~.~.~.~.\r\n");
        out.write(xmlResponse.getXMLSQLResponse());
      }
    }
    catch (IOException exception) {
      throw new SQLException(exception);
    }
  }
  
  private TSVResponse internalExecute(Statement statement, String request) {
    final long startExecution = StampUtil.getStampValue();
    try {
      final boolean isResultSet = statement.execute(request);
      final int updateCount = statement.getUpdateCount();
      final ResultSet resultSet = statement.getResultSet();
      final StringWriter out = new StringWriter();
      int columnCount = 0;
      int rowCount = 0;
      if (isResultSet) {
          out.write("~.~.~.~.~.Metadata~.~.~.~.~.\r\n");
          final ResultSetMetaData meta = resultSet.getMetaData();
          columnCount = meta.getColumnCount();
          out.write("ColAttrType");
          out.write("\tColAttrPrecision");
          out.write("\tColAttrScale");
          out.write("\tColAttrName");
          out.write("\tColAttrDisplaySize");
          out.write("\r\n");
          for (int i = 1; i <= columnCount; i++) {
            out.write(IntegerCache.toString(meta.getColumnType(i)));
            out.write("\t");
            out.write(IntegerCache.toString(meta.getPrecision(i)));
            out.write("\t");
            out.write(IntegerCache.toString(meta.getScale(i)));
            out.write("\t");
            out.write(meta.getColumnName(i));
            out.write("\t");
            out.write(IntegerCache.toString(meta.getColumnDisplaySize(i)));
            out.write("\r\n");
          }
          final ebXMLDateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
          out.write("~.~.~.~.~.Rows~.~.~.~.~.\r\n");
          while (resultSet.next()) {
            rowCount++;
            for (int i = 1; i <= columnCount; i++) {
              if (i > 0) {
                out.write("\t");
              }
              final Object object = resultSet.getObject(i);
              if (object != null && !resultSet.wasNull()) {
                if (object instanceof Number) {
                  if (meta.getScale(i) > 0 || meta.getPrecision(i) == 0){
                    writeText(out, ""+((Number)object).doubleValue());
                  }
                  else {
                    writeText(out, Long.toString(((Number)object).longValue()));
                  }
                }
                else if (object instanceof java.util.Date) {
                  writeText(out, dateFormat.format(object));
                }
                else if (object instanceof byte[]) {
                  writeText(out, StreamUtils.base64encode((byte[])object));
                }
                else {
                  writeText(out, object.toString());
                }
              }
              else {
                writeText(out, "�");
              }                     
            }
          }
      }
      out.close();
      return new TSVResponse(request, startExecution, false, out.toString(), isResultSet, updateCount, columnCount, rowCount);
    }
    catch (Throwable exception) {
      return new TSVResponse(request, startExecution, true, exception.toString(), false, 0, 0, 0);
    }
  }
  
  protected static class TSVResponse {

    public TSVResponse(String sqlRequest, long start, boolean isError, String message, boolean isResultSet, int updateCount, int colCount, int rowCount) {
      this.sqlRequest = sqlRequest;
      this.start = start;
      this.message = message;
      this.updateCount = updateCount;
      this.colCount = colCount;
      this.rowCount = rowCount;
      this.isResultSet = isResultSet;
      this.isError = isError;
    }
    
    public boolean isResultSet() {
      return isResultSet;
    }

    public int getColCount() {
      return colCount;
    }

    public int getRowCount() {
      return rowCount;
    }

    public String getXMLSQLResponse() {
      if (isError) return "";
      return message;
    }
    
    public String getErrorMessage() {
      if (!isError) return "";
      return message;
    }

    public int getUpdateCount() {
      return updateCount;
    }
    
    public boolean isError() {
      return isError;
    }
    
    public String getSQLRequest() {
      return sqlRequest;
    }
    
    private final long start;
    private final int updateCount;
    private final int rowCount;
    private final int colCount;
    private final boolean isResultSet;
    private final String message;
    private final boolean isError;
    private final String sqlRequest;
  }
  
  private Writer out;
  
  private static String dateFormat(java.util.Date date) {
    synchronized (dateFormat) {
      return dateFormat.format(date);
    }
  }
  
  private static final DateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
}
package org.openknows.common.db.xml;


import com.easyrms.date.*;
import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.xml.*;

import java.io.*;
import java.sql.*;

import org.openknows.common.db.*;

import org.xml.sax.*;


public class XMLStatementHandler extends SimpleXMLHandler implements XMLStatementProtocol {
  
  private static final SynchronizedSimplePool<XMLStatementHandler> pool = new SynchronizedSimplePool<XMLStatementHandler>(XMLStatementHandler.class, 3);
  public static final SimpleStatementResult getStatement(String reader) throws SQLException {
    return getStatement(new StringReader(reader));
  }

  public static final SimpleStatementResult getStatement(Reader reader) throws SQLException {
    final XMLStatementHandler handler = pool.getNew();
    try {
      return handler.getInternalStatement(reader);
    }
    finally {
      pool.free(handler);
    }
  }

  public XMLStatementHandler() {
    this.setAutoValueReset(true);
    this.setIgnoreWhitespace(true);
  }

	private synchronized final SimpleStatementResult getInternalStatement(Reader reader) throws SQLException {
		try {
			load(reader);
			return getXMLStatement();		
		}
    catch (SQLException sqlException) {
      throw sqlException;
    }
		catch (Throwable ignored) {
			throw new SQLException(ignored);
		}
		finally {
			reset();
		}
	}

  private SimpleStatementResult getXMLStatement() throws SQLException {
    if (withError) throw sqlException;
    return statement;
  }

  @Override
  public void extendStartElement(String namespaceURI, String localName, String qName, Attributes atts) throws Exception {
    localName = StringUtil.NVL(localName, qName).intern();
    if (SQLResponse == localName) {
      isInMetaData = false;
      isInData = false;
      resultSet = null;
      metaData = null;
      sqlRequest = null;
      executionTime = ebXMLDateBuilder.referenceParse(atts.getValue(SQLResponseAttrStartTime)).getTime();
      withError = TRUEValue.equals(atts.getValue(SQLResponseAttrWithError));
      sqlException = new SQLException("WITH ERROR QUERY");
      colCount = MathUtils.parseInt(atts.getValue(SQLResponseAttrColCount));
      rowCount = MathUtils.parseInt(atts.getValue(SQLResponseAttrRowCount));
      updateCount = MathUtils.parseInt(atts.getValue(SQLResponseAttrUpdateCount));
    }
		else if (SQLRequest == localName) {
		}
    else if (Request == localName) {
		}
    else if (SQLError == localName) {
    }
    else if (SQLMetadata == localName) {
      this.metaData = new OpenknowsResultSetMetadata(colCount);
      isInMetaData = true;
      currentCol = 0;
    }
    else if (SQLData == localName) {
      this.resultSet = new OpenknowsResultSet(metaData, updateCount, rowCount);
      this.resultSet.setRequest(sqlRequest);
      this.resultSet.setExecutionTime(executionTime);
      isInData = true;
      currentRow = 0;
      currentCol = 0;
    }
		else if (SQLResultSet == localName) {
		}
    else if (SQLRow == localName) {
      currentRow ++;
      currentCol = 0;
    }
    else if (SQLCol == localName) {
      currentCol++;
      if (isInMetaData) {
        final String name = atts.getValue(SQLColAttrName);
        final int type = Integer.parseInt(atts.getValue(SQLColAttrType));
        final int scale = Integer.parseInt(atts.getValue(SQLColAttrScale));
        final int displaySize = Integer.parseInt(atts.getValue(SQLColAttrDisplaySize));
        final int precision = Integer.parseInt(atts.getValue(SQLColAttrPrecision));
        metaData.set(currentCol, name, name, type,precision, scale, displaySize);
      }
      else if (isInData) {
        wasNull = TRUEValue.equals(atts.getValue(SQLColAttrNull));
      }
      else {
        throw new SQLException("Not valid response");
      }
    }
    else {
      super.extendStartElement(namespaceURI, localName, qName, atts);
    }
  }

  @Override
  public void extendEndElement(String namespaceURI, String localName, String qName, String value) throws Exception {
    localName = StringUtil.NVL(localName, qName).intern();
    if (SQLResponse == localName) {
      statement = new SimpleStatementResult(
        sqlRequest,
        isResultSet,
        updateCount, 
        new ResultSet[] {resultSet,}, 
        rowCount);
    }
		else if (SQLRequest == localName) {
      sqlRequest = getValue();
    }
		else if (Request == localName) {
			sqlRequest = getValue();
		}
    else if (SQLError == localName) {
    }
    else if (SQLMetadata == localName) {
      isInMetaData = false;
    }
    else if (SQLData == localName) {
      isInData = false;
    }
    else if (SQLResultSet == localName) {
    }
    else if (SQLRow == localName) {
    }    
    else if (SQLCol == localName) {
      if (isInMetaData) {
      }
      else if (isInData) {
        resultSet.set(wasNull ? null : SQLUtils.getSQLObjectValue(this.getValue(), metaData.getColumnType(currentCol), metaData.getScale(currentCol), metaData.getPrecision(currentCol)), currentRow, currentCol);
      }
      else {
        sqlException = new SQLException("Not valid response");
        withError = true;
        throw sqlException;
      }
    }
    else {
      super.extendEndElement(namespaceURI, localName, qName, value);
    }
  }
  
  @Override
  public void reset() {
		super.reset();
    isResultSet = false;
  	withError = false;
		colCount = 0;
		rowCount = 0;
		resultSet = null;
    statement = null;
		metaData = null;
		currentRow = 0;
		currentCol = 0;
    updateCount = 0;
		wasNull = false;
		sqlRequest = null;
		isInMetaData = false;
		isInData = false;
    withError = false;
    sqlException = null;
		setAutoValueReset(true);
		setIgnoreWhitespace(true);
  }
  
  private SQLException sqlException;
  private boolean isResultSet = false;
  private boolean withError = false;
  private int colCount = 0;
  private int updateCount = 0;
  private int rowCount = 0;
  private OpenknowsResultSet resultSet = null;
  private SimpleStatementResult statement = null;
  private OpenknowsResultSetMetadata metaData = null;
  private int currentRow = 0;
  private int currentCol = 0;
  private boolean wasNull = false;
  private long executionTime = -1;
  private String sqlRequest = null;
  
  private boolean isInMetaData = false;
  private boolean isInData = false;
}
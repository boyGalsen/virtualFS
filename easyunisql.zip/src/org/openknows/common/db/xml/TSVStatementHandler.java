package org.openknows.common.db.xml;

import com.easyrms.util.*;

import org.openknows.common.db.*;

import java.io.*;
import java.sql.*;

public class TSVStatementHandler {

  private static final SynchronizedSimplePool<TSVStatementHandler> pool = new SynchronizedSimplePool<TSVStatementHandler>(TSVStatementHandler.class, 3);
  
  public static final SimpleStatementResult getStatement(Reader reader) throws SQLException {
    final TSVStatementHandler handler = pool.getNew();
    try {
      return handler.getInternalStatement(reader);
    }
    finally {
      pool.free(handler);
    }
  }
  
  private synchronized final SimpleStatementResult getInternalStatement(Reader reader) throws SQLException {
    try {
      //load(reader);
      return getXMLStatement();   
    }
    catch (SQLException sqlException) {
      throw sqlException;
    }
    catch (Throwable ignored) {
      throw new SQLException(ignored);
    }
    finally {
      reset();
    }
  }

  private SimpleStatementResult getXMLStatement() throws SQLException {
    if (withError) throw sqlException;
    return statement;
  }
    public void reset() {
      isResultSet = false;
      withError = false;
      colCount = 0;
      rowCount = 0;
      resultSet = null;
      statement = null;
      metaData = null;
      currentRow = 0;
      currentCol = 0;
      updateCount = 0;
      wasNull = false;
      sqlRequest = null;
      isInMetaData = false;
      isInData = false;
      withError = false;
      sqlException = null;
    }
    
    private SQLException sqlException;
    private boolean isResultSet = false;
    private boolean withError = false;
    private int colCount = 0;
    private int updateCount = 0;
    private int rowCount = 0;
    private OpenknowsResultSet resultSet = null;
    private SimpleStatementResult statement = null;
    private OpenknowsResultSetMetadata metaData = null;
    private int currentRow = 0;
    private int currentCol = 0;
    private boolean wasNull = false;
    private long executionTime = -1;
    private String sqlRequest = null;
    
    private boolean isInMetaData = false;
    private boolean isInData = false; 
}

package org.openknows.common.db.xml;

import com.easyrms.builder.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.xml.*;

import java.io.*;
import java.sql.*;

import org.openknows.common.db.*;

public class XMLStatementWriter implements XMLStatementProtocol {
  
  public XMLStatementWriter(Writer out) {
    this.out = out;
  }
  
  public SimpleStatementResult execute(Statement statement, String request) throws SQLException {
    final XMLResponse xmlResponse = internalExecute(statement, request);
    try {
      final StringWriter sout = new StringWriter();
      write(xmlResponse, sout);
      sout.close();
      out.write(sout.toString());
      out.flush();
      return XMLStatementHandler.getStatement(new StringReader(sout.toString()));
    }
    catch (IOException exception) {
      throw new SQLException(exception);
    }
  }
  
  public void throwException(SQLException sqlException, String request) throws SQLException {
    write(new XMLResponse(request, StampUtil.getStampValue(), true, ExceptionUtils.getMessage(sqlException), false, 0, 0, 0), out);
  }
  
  private void write(XMLResponse xmlResponse, Writer out) throws SQLException {
    try {
      final XMLWriter xout = new XMLWriter(out);
      final boolean withError = xmlResponse.isError();
      xout
        .writeTag(SQLResponse)
        .writeAttribute(SQLResponseAttrID, StringUtil.NVL(null))
        .writeAttribute(SQLResponseAttrWithError, withError ? TRUEValue : FALSEValue)
        .writeAttribute(SQLResponseAttrStartTime, dateFormat(new java.util.Date(xmlResponse.start)))
        .writeAttribute(SQLResponseAttrExecutionDuration, LongCache.toString(StampUtil.getStampValue() - xmlResponse.start))
        .writeAttribute(SQLResponseAttrColCount, LongCache.toString(xmlResponse.getColCount()))
        .writeAttribute(SQLResponseAttrRowCount, LongCache.toString(xmlResponse.getRowCount()))
        .writeAttribute(SQLResponseAttrUpdateCount, LongCache.toString(xmlResponse.getUpdateCount()));
      xout.writeTag(SQLRequest);
      xout.writeText(xmlResponse.getSQLRequest(), true);
      xout.closeTag(SQLRequest);
      if (withError) {
        xout.writeTag(SQLError);
        xout.writeText(xmlResponse.getXMLSQLResponse(), true);
        xout.closeTag(SQLError);
      }
      else {
        xout.writeText(xmlResponse.getXMLSQLResponse(), false);
      }
      xout.closeTag(SQLResponse);
      xout.close();
    }
    catch (IOException exception) {
      throw new SQLException(exception);
    }
  }
  
  private XMLResponse internalExecute(Statement statement, String request) {
    final long startExecution = StampUtil.getStampValue();
    try {
      final boolean isResultSet = statement.execute(request);
      final int updateCount = statement.getUpdateCount();
      final ResultSet resultSet = statement.getResultSet();
      final StringWriter out = new StringWriter();
      final XMLWriter xout = new XMLWriter(out);
      int columnCount = 0;
      int rowCount = 0;
      if (isResultSet) {
        xout.writeTag(SQLResultSet);
          xout.writeTag(SQLMetadata);
          final ResultSetMetaData meta = resultSet.getMetaData();
          columnCount = meta.getColumnCount();
          for (int i = 1; i <= columnCount; i++) {
            xout
              .writeTag(SQLCol)
              .writeAttribute(SQLColAttrType, IntegerCache.toString(meta.getColumnType(i)))
              .writeAttribute(SQLColAttrPrecision, IntegerCache.toString(meta.getPrecision(i)))
              .writeAttribute(SQLColAttrScale, IntegerCache.toString(meta.getScale(i)))
              .writeAttribute(SQLColAttrName, meta.getColumnName(i))
              .writeAttribute(SQLColAttrDisplaySize, IntegerCache.toString(meta.getColumnDisplaySize(i)))
              .closeTag();
          }
          xout.closeTag(SQLMetadata);
          final ebXMLDateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
          xout.writeTag(SQLData);
          while (resultSet.next()) {
            rowCount++;
            xout.writeTag(SQLRow);
            for (int i = 1; i <= columnCount; i++) {
              xout.writeTag(SQLCol);
              final Object object = resultSet.getObject(i);
              if (object != null && !resultSet.wasNull()) {
                if (object instanceof Number) {
                  if (meta.getScale(i) > 0 || meta.getPrecision(i) == 0){
                    xout.writeText(""+((Number)object).doubleValue());
                  }
                  else {
                    xout.writeText(Long.toString(((Number)object).longValue()));
                  }
                }
                else if (object instanceof java.util.Date) {
                  xout.writeText(dateFormat.format(object));
                }
                else if (object instanceof byte[]) {
                  xout.writeCData(StreamUtils.base64encode((byte[])object));
                }
                else {
                  xout.writeCData(object.toString());
                }
              }
              else {
                xout.writeAttribute(SQLColAttrNull, TRUEValue);
              }                     
              xout.closeTag(SQLCol);
            }
            xout.closeTag(SQLRow);
          }
          xout.closeTag(SQLData);
        xout.closeTag(SQLResultSet);
      }
      xout.close();
      out.close();
      return new XMLResponse(request, startExecution, false, out.toString(), isResultSet, updateCount, columnCount, rowCount);
    }
    catch (Throwable exception) {
      return new XMLResponse(request, startExecution, true, exception.toString(), false, 0, 0, 0);
    }
  }
  
  protected static class XMLResponse {

    public XMLResponse(String sqlRequest, long start, boolean isError, String message, boolean isResultSet, int updateCount, int colCount, int rowCount) {
      this.sqlRequest = sqlRequest;
      this.start = start;
      this.message = message;
      this.updateCount = updateCount;
      this.colCount = colCount;
      this.rowCount = rowCount;
      this.isResultSet = isResultSet;
      this.isError = isError;
    }
    
    public boolean isResultSet() {
      return isResultSet;
    }

    public int getColCount() {
      return colCount;
    }

    public int getRowCount() {
      return rowCount;
    }

    public String getXMLSQLResponse() {
      if (isError) return "";
      return message;
    }
    
    public String getErrorMessage() {
      if (!isError) return "";
      return message;
    }

    public int getUpdateCount() {
      return updateCount;
    }
    
    public boolean isError() {
      return isError;
    }
    
    public String getSQLRequest() {
      return sqlRequest;
    }
    
    private final long start;
    private final int updateCount;
    private final int rowCount;
    private final int colCount;
    private final boolean isResultSet;
    private final String message;
    private final boolean isError;
    private final String sqlRequest;
  }
  
  private Writer out;
  
  private static String dateFormat(java.util.Date date) {
    synchronized (dateFormat) {
      return dateFormat.format(date);
    }
  }
  
  private static final DateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
}
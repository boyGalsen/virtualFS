package org.openknows.common.db.xml;

import com.easyrms.db.*;
import com.easyrms.util.*;

import java.util.*;
import java.sql.*;

class OpenknowsResultSetMetadata implements ResultSetMetaData {

  public OpenknowsResultSetMetadata(int size) {
    this.size = size;
    this.labels = new String[size];
    this.names = new String[size];
    this.scale = new int[size];
    this.precision = new int[size];
    this.type = new int[size];
    this.displaySize = new int[size];
  }

  public String getCatalogName(int column) throws SQLException {
    return null;
  }

  public Class<?> getColumnClass(int column) throws SQLException {
    return SQLUtils.getSQLClass(getColumnType(column), getScale(column), getPrecision(column));
  }

  public String getColumnClassName(int column) throws SQLException {
    return SQLUtils.getSQLClassName(getColumnType(column), getScale(column), getPrecision(column));
  }

  public int getColumnCount() throws SQLException {
    return size;
  }

  public int getColumnDisplaySize(int column) throws SQLException {
    return displaySize[column - 1];
  }

  public String getColumnLabel(int column) throws SQLException {
    return labels[column - 1];
  }

  public String getColumnName(int column) throws SQLException {
    return names[column - 1];
  }

  public int getColumnType(int column) throws SQLException {
    return type[column - 1];
  }

  public String getColumnTypeName(int column) throws SQLException {
    return null;
  }

  public int getPrecision(int column) throws SQLException {
    return precision[column - 1];
  }

  public int getScale(int column) throws SQLException {
    return scale[column - 1];
  }

  public String getSchemaName(int column) throws SQLException {
    return null;
  }

  public String getTableName(int column) throws SQLException {
    return null;
  }

  public boolean isAutoIncrement(int column) throws SQLException {
    return false;
  }

  public boolean isCaseSensitive(int column) throws SQLException {
    return false;
  }

  public boolean isCurrency(int column) throws SQLException {
    return false;
  }

  public boolean isDefinitelyWritable(int column) throws SQLException {
    return false;
  }

  public int isNullable(int column) throws SQLException {
    return 0;
  }

  public boolean isReadOnly(int column) throws SQLException {
    return true;
  }

  public boolean isSearchable(int column) throws SQLException {
    return false;
  }

  public boolean isSigned(int column) throws SQLException {
    return false;
  }

  public boolean isWritable(int column) throws SQLException {
    return false;
  }

  public void set(int column, String name, String label, int type, int precision, int scale, int displaySize) {
    column = column - 1;
    this.type[column] = type;
    this.names[column] = name;
    this.labels[column] = label;
    this.precision[column] = precision;
    this.scale[column] = scale;
    this.displaySize[column] = displaySize;
    this.nameIndex.put(name, IntegerCache.get(column));
  }

  public int getColumnIndex(String name) {
    final Integer value = nameIndex.get(name);
    if (value == null) return -1;
    return value.intValue();
  }

  private final int size;
  private final int[] type;
  private final String[] labels;
  private final String[] names;
  private final int[] precision;
  private final int[] scale;
  private final int[] displaySize;
  private final HashMap<String, Integer> nameIndex = new HashMap<String, Integer>();

  public boolean isWrapperFor(Class<?> iface) throws SQLException {
    return false;
  }

  public <T> T unwrap(Class<T> iface) throws SQLException {
    return null;
  }
}
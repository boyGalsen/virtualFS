package org.openknows.common.db.xml;

interface XMLStatementProtocol {
  
  static final String TRUEValue = "YES";
  static final String FALSEValue = "NO";

  static final String Request = "REQUEST";
  static final String SQLRequest = "SQLREQUEST";
  static final String SQLResponse = "SQLRESPONSE";
  static final String SQLResponseAttrID = "ID";
  static final String SQLResponseAttrStartTime = "STARTTIME";
  static final String SQLResponseAttrExecutionDuration = "EXECUTIONDURATION";
  static final String SQLResponseAttrWithError = "WITHERROR";
  static final String SQLResponseAttrColCount = "COLCOUNT";
  static final String SQLResponseAttrRowCount = "ROWCOUNT";
  static final String SQLResponseAttrUpdateCount = "UPDATECOUNT";
  static final String SQLError = "SQLERROR";
  static final String SQLMetadata = "METADATA";
  static final String SQLStamment = "STMT";
  static final String SQLResultSet = "RSET";
  static final String SQLData = "DATA";
  static final String SQLRow = "ROW";
  static final String SQLCol = "COL";
  static final String SQLColAttrNull = "NULL";
  static final String SQLColAttrType = "TYPE";
  static final String SQLColAttrPrecision = "PRECISION";
  static final String SQLColAttrScale = "SCALE";
  static final String SQLColAttrName = "NAME";
  static final String SQLColAttrDisplaySize = "DISPLAYSIZE";
}

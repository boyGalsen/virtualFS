package org.openknows.common.db;

import com.easyrms.db.*;
import com.easyrms.util.array.*;

import java.sql.*;

public class SimpleConnectedStatementResult extends SimpleStatementResult {
  
  private static final ResultSet[] noResultSet = new ResultSet[0];

  public static SimpleConnectedStatementResult execute(EzJDBCDatabase jdbcDatabase, String request) throws SQLException {
    final EzDBTransaction connection = jdbcDatabase.openTransaction();
    final EzJDBCPhysicalConnection physicalConnection = connection.asJDBCConnection();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(jdbcDatabase.getName(), jdbcDatabase.getDescription(), connection.getUID(), physicalConnection.getUID(), false, true, request, ObjectArrays.emptyObjectArray);
    try {
      final Connection jdbcConnection = physicalConnection.getConnection();
      try {
        final Statement statement = jdbcConnection.createStatement();
        try {
          perfRequest.fireEndPreparation(statement);
          if (statement.execute(request)) {
            perfRequest.fireEndExecution();
            final SimpleConnectedStatementResult result = new SimpleConnectedStatementResult(jdbcConnection, request, true, statement.getUpdateCount(), new ResultSet[] { statement.getResultSet()}, -1);
            perfRequest.fireEnd(Math.max(result.getUpdateCount(), result.getRowCount()), "Unknown");
            return result;
          }
          perfRequest.fireEndExecution();
          final SimpleConnectedStatementResult result =  new SimpleConnectedStatementResult(jdbcConnection, request, true, statement.getUpdateCount(), noResultSet, -1);   
          perfRequest.fireEnd(Math.max(result.getUpdateCount(), result.getRowCount()), "Unknown");
          return result;
        }
        finally {
          statement.close();
        }
      }
      catch (Throwable ignored) {
        perfRequest.fireError(ignored);
        perfRequest.fireEnd(0, null);
        SimplePooledConnections.log(connection, ignored, request, ObjectArrays.emptyObjectArray);
        throw new SQLException(ignored);
      }
      finally {
        SQLUtils.close(jdbcConnection);
      }
    }
    finally {
      SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
  }
  
  
  
  private SimpleConnectedStatementResult(Connection connection, String sqlrequest, boolean isResultSet, int updateCount, ResultSet[] resultSet, int rowCount) {
    super(sqlrequest, isResultSet, updateCount, resultSet, rowCount);
  }



  @Override
  public void close() {
    super.close();
  }

}

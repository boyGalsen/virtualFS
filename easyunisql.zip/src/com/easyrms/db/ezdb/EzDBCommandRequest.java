package com.easyrms.db.ezdb;

import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.sql.*;

import org.openknows.common.db.*;
import org.openknows.jdbc.driver.common.*;
import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;


public class EzDBCommandRequest extends AbstractEzDBRequest {
  
  protected EzDBCommandRequest() {
    super(false, prefix);
  }

  @Override
  public SimpleStatementResult compileRequest(String sql, SimpleDriverParameters parameters) throws SQLException {
    //final Tuple2<String, String> databaseNameRealRequest = decode(sql);
    final String command = removePrefix(sql);
    final TableMetaData metaData = new TableMetaData();
    metaData.add(Column.getAndInit("CMDRESPONSE", ColumnType.STRING));
    final MemoryTable memoryTable = new MemoryTable("commandResult", metaData, null);
    try {
      final InsertTableAccessor is = memoryTable.getInsertAccessor();
      try {
        try {
            final Process process = Runtime.getRuntime().exec(command);
            final BoundedBufferedReader in = new BoundedBufferedReader(new InputStreamReader(process.getInputStream()));
            String line = null;
            while((line = in.readLine()) != null) {
              final DatabaseRow row = new DatabaseRow();
              row.init(metaData);
              row.set(1, JDBCDatabaseValue.getAndInit(StringComparator.NVL(line)));
              is.insert(row);
            }
        }
        catch (Throwable ignored) {
          final DatabaseRow row = new DatabaseRow();
          row.init(metaData);
          row.set(1, JDBCDatabaseValue.getAndInit("Error ["+ExceptionUtils.getMessage(ignored)+"]"));
          is.insert(row);
        }
      }
      finally {
        is.close();
      }
      return new SimpleStatementResult(command, true, 0, new ResultSet[] { DirectExecute.toResultSet(memoryTable.getAccessor()) } , memoryTable.getRowCount());
    }
    catch (DatabaseException databaseException) {
      throw new SQLException(databaseException); 
    }
    
    
    
    //final EzJDBCDatabase jdbcDatabase = EzDBDatabaseManager.reference.find(databaseName);
    //if (jdbcDatabase == null) throw new SQLException("Unknown shema "+databaseName);
  }
  
  private static final String prefix = "command";

}

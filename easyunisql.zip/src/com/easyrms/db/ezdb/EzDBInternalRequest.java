package com.easyrms.db.ezdb;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.sql.*;

import org.openknows.common.db.*;
import org.openknows.jdbc.driver.common.*;
import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.*;
import org.openknows.jdbc.driver.unisql.memory.*;

public class EzDBInternalRequest extends AbstractEzDBRequest {
  
  protected EzDBInternalRequest(EzDBConnectionDriver driver) {
    super(false, prefix);
    this.driver = driver;
  }
  
  @Override
  public SimpleStatementResult compileRequest(String sql, SimpleDriverParameters parameters) throws SQLException {
    final String command = removePrefix(sql);
    return getHelp(sql, parameters);
  }
  
  private SimpleStatementResult getHelp(String sql, SimpleDriverParameters parameters) throws SQLException {
    final TableMetaData metaData = new TableMetaData();
    metaData.add(Column.getAndInit("COMMAND", ColumnType.STRING));
    metaData.add(Column.getAndInit("DESCRIPTION", ColumnType.STRING));
    final MemoryTable zipFiles = new MemoryTable("EZDB_HELP", metaData, null);
    try {
      final InsertTableAccessor is = zipFiles.getInsertAccessor();
      try {
        try {
          final DatabaseRow row = new DatabaseRow();
          row.init(metaData);
          row.set(1, JDBCDatabaseValue.getAndInit(StringComparator.NVL("help")));
          row.set(2, JDBCDatabaseValue.getAndInit(StringComparator.NVL("give the available commands")));
          is.insert(row);
        }
        catch (Throwable ignored) {
          final DatabaseRow row = new DatabaseRow();
          row.init(metaData);
          row.set(1, JDBCDatabaseValue.getAndInit("Error ["+ExceptionUtils.getMessage(ignored)+"]"));
          is.insert(row);
        }
      }
      finally {
        is.close();
      }
      return new SimpleStatementResult(sql, true, 0, new ResultSet[] { DirectExecute.toResultSet(zipFiles.getAccessor()) } , zipFiles.getRowCount());
    }
    catch (DatabaseException databaseException) {
      throw new SQLException(databaseException); 
    }
    
    
    
    //final EzJDBCDatabase jdbcDatabase = EzDBDatabaseManager.reference.find(databaseName);
    //if (jdbcDatabase == null) throw new SQLException("Unknown shema "+databaseName);
  }
  
  private final EzDBConnectionDriver driver;
  private static final String prefix = "help";

}

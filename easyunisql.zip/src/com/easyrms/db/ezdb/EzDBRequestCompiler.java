package com.easyrms.db.ezdb;

import com.easyrms.util.*;

import java.sql.*;

import org.openknows.common.db.*;
import org.openknows.jdbc.driver.common.*;

public class EzDBRequestCompiler implements AbstractRequestCompiler<EzDBConnection> {
  
  public EzDBRequestCompiler(EzDBConnectionDriver driver) {
    this.driver = driver;
  }

  public ParameterMetaData compileParameterMetadata(String sql, SimpleDriverParameters parameters, EzDBConnection connection) throws SQLException {
    final String originalSQL = sql;
    sql = driverNormalize(originalSQL);
    if (sql != null) {
      
    }
    sql = sqlNormalize(originalSQL);
    if (sql != null) { 
      final AbstractEzDBRequest requestType = findSQLRequestType(sql);
      if (requestType == null) throw new SQLException("Invalid Request");
      return requestType.compileParameterMetadata(sql, parameters);
    }
    throw new SQLException("Invalid Request");
  }

  public SimpleStatementResult compileRequest(String sql, SimpleDriverParameters parameters, EzDBConnection connection) throws SQLException {
    sql = sqlNormalize(sql);
    final AbstractEzDBRequest requestType = findSQLRequestType(sql);
    if (requestType == null) throw new SQLException("Invalid Request");
    return requestType.compileRequest(sql, parameters);
  }

  public ResultSetMetaData compileResultSetMetadata(String sql, SimpleDriverParameters parameters, EzDBConnection connection) throws SQLException {
    sql = sqlNormalize(sql);
    final AbstractEzDBRequest requestType = findSQLRequestType(sql);
    if (requestType == null) throw new SQLException("Invalid Request");
    return requestType.compileResultSetMetadata(sql, parameters);
  }
  
  private AbstractEzDBRequest findSQLRequestType(String sql) {
    final EzArray<? extends AbstractEzDBRequest> requestTypes = driver.getRequestType();
    for (int i = 0, n = requestTypes.getCount(); i < n; i++) {
      final AbstractEzDBRequest requestType = requestTypes.get(i);
      if (!requestType.isDriver() && sql.startsWith(requestType.getSQLPrefixForCheck())) {
        return requestType;
      }
    }
    return null;
  }
  
  private AbstractEzDBRequest findDriverRequestType(String sql) {
    final EzArray<? extends AbstractEzDBRequest> requestTypes = driver.getRequestType();
    for (int i = 0, n = requestTypes.getCount(); i < n; i++) {
      final AbstractEzDBRequest requestType = requestTypes.get(i);
      if (requestType.isDriver() && sql.startsWith(requestType.getDriverPrefixForCheck())) {
        return requestType;
      }
    }
    return null;
  }

  
  private String driverNormalize(String sql) throws SQLException {
    sql = StringUtil.trim(sql);
    sql = sql.replaceFirst("[ \r\n\t\f]+", " ");
    if (sql.startsWith("driver ")) {
      return sql.substring(7).replaceFirst("[ \r\n\t\f]+", " ");
    }
    return sql;
  }
  
  private String sqlNormalize(String sql) throws SQLException {
    sql = StringUtil.trim(sql);
    sql = sql.replaceFirst("[ \r\n\t\f]+", " ");
    if (sql.startsWith("execute ")) {
      return sql.substring(8).replaceFirst("[ \r\n\t\f]+", " ");
    }
    else if (sql.startsWith("exec ")) {
      return sql.substring(5).replaceFirst("[ \r\n\t\f]+", " ");
    }
    return "sql "+sql;
  }


  private final EzDBConnectionDriver driver;
}

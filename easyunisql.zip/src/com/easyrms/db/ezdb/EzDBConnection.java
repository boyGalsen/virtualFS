package com.easyrms.db.ezdb;

import org.openknows.jdbc.driver.common.*;

import java.util.*;

public class EzDBConnection extends SimpleDriverConnection {

  public EzDBConnection() {
    super();
  }

  public EzDBConnection(AbstractRequestCompiler compiler, Properties properties) {
    super(compiler, properties);
  }

  public EzDBConnection(AbstractRequestCompiler compiler) {
    super(compiler);
  }

  public EzDBConnection(Properties properties) {
    super(properties);
  }

}

package com.easyrms.db.ezdb;

import com.easyrms.util.*;

import org.openknows.jdbc.driver.common.*;
import org.openknows.jdbc.driver.unisql.jdbc.*;

import java.sql.*;
import java.util.*;

/**
 * use this url to connect to an HTTP SQL service with Encrypt SQL
 * jdbc:proxyget:[user/password@]127.0.0.1[:port]/servicepath!encryptkey
 * 
 * use this url to connect to an HTTP SQL service without Encrypt SQL
 * if ($encryptKey is Present) it use an encrypt user password option
 * jdbc:proxyget:[user/password@]127.0.0.1[:port]/servicepath[$encryptkey]
 */
public class EzDBConnectionDriver extends AbstractDriverConnectionDriver {
  
  public static void register() {
    getReference();
  }
  
  public static synchronized EzDBConnectionDriver getReference() {
    if (reference == null) reference = new EzDBConnectionDriver();
    return reference;
  }
  
  private static EzDBConnectionDriver reference;
  
  
  public EzDBConnectionDriver() {
    super("jdbc:ezrms.ezdb:");
    register(new EzDBInternalRequest(this));
    register(new EzDBSQLRequest());
    register(new EzDBCommandRequest());
  }
  
  @Override
  protected Connection newConnection(String url, Properties props) throws SQLException {
    return new EzDBConnection(new EzDBRequestCompiler(this));
  }
  
  public void register(AbstractEzDBRequest requestType) {
    requestTypes.add(requestType);
  }
  
  public EzArray<? extends AbstractEzDBRequest> getRequestType() {
    return requestTypes.getList();
  }
  
  private EzArrayCopyOnWriteList<AbstractEzDBRequest> requestTypes = new EzArrayCopyOnWriteList<AbstractEzDBRequest>();
}

package com.easyrms.db.ezdb;

import com.easyrms.db.*;
import com.easyrms.util.*;

import java.util.*;
import java.util.concurrent.locks.*;
import java.util.concurrent.locks.ReentrantReadWriteLock.*;

public class EzDBDatabaseManager {
  
  public static final EzDBDatabaseManager reference = new EzDBDatabaseManager();

  
  public void register(EzJDBCDatabase database) {
    register(database.getName(), database);
  }
  
  public void register(String shemaName, EzJDBCDatabase database) {
    final WriteLock writeLock = lock.writeLock();
    writeLock.lock();
    try {
      if (url.add(database.getURL()) && !databaseByShema.containsKey(shemas)) {
        shemas.add(shemaName);
        databaseByShema.put(shemaName, database);
      }
    }
    finally {
      writeLock.unlock();
    }
  }
  
  public EzArray<String> getShemas() {
    final ReadLock readLock = lock.readLock();
    readLock.lock();
    try {
      return shemas.getList();
    }
    finally {
      readLock.unlock();
    }
  }
  
  public EzJDBCDatabase find(String shemaName) {
    final ReadLock readLock = lock.readLock();
    readLock.lock();
    try {
      return databaseByShema.get(shemaName);
    }
    finally {
      readLock.unlock();
    }  
  }
  
  private final HashSet<String> url = new HashSet<String>();
  private final EzArrayCopyOnWriteList<String> shemas = new EzArrayCopyOnWriteList<String>();
  private final HashMap<String, EzJDBCDatabase> databaseByShema = new HashMap<String, EzJDBCDatabase>();
  private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
}

package com.easyrms.db.ezdb;

import com.easyrms.util.*;

import java.sql.*;

import org.openknows.common.db.*;
import org.openknows.jdbc.driver.common.*;

public abstract class AbstractEzDBRequest {
  
  protected AbstractEzDBRequest(boolean isDriver, String prefix) {
    this.prefix = prefix;
    this.prefixforcheck = prefix+" ";
    this.isDriver = isDriver;
  }
  
  public String getPrefix() {
    return prefix;
  }
  
  public boolean isDriver() {
    return isDriver;
  }

  public String getSQLPrefixForCheck() {
    return isDriver ? null : prefixforcheck;
  }
  
  public String getDriverPrefixForCheck() {
    return isDriver ? prefixforcheck : null;
  }
  
  protected final String removePrefix(String sql) {
    return StringUtil.trim(sql.substring(prefixforcheck.length()));
  }

  public ParameterMetaData compileParameterMetadata(String sql, SimpleDriverParameters parameters) throws SQLException {
    return null;
  }

  public abstract SimpleStatementResult compileRequest(String sql, SimpleDriverParameters parameters) throws SQLException;

  public ResultSetMetaData compileResultSetMetadata(String sql, SimpleDriverParameters parameters) throws SQLException {
    return null;
  }
  
  private final String prefix;
  private final String prefixforcheck;
  private final boolean isDriver;
}

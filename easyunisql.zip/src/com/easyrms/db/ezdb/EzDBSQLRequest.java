package com.easyrms.db.ezdb;

import com.easyrms.db.*;
import com.easyrms.util.*;

import java.sql.*;

import org.openknows.common.db.*;
import org.openknows.jdbc.driver.common.*;

public class EzDBSQLRequest extends AbstractEzDBRequest {
  
  protected EzDBSQLRequest() {
    super(false, prefix);
  }
  
  private Tuple2<String, String> decodeSQL(String sql) {
    final String decodedSQL = removePrefix(sql);
    int i = 0;
    for (int n = decodedSQL.length(); i < n; i++) {
      final char c = decodedSQL.charAt(i);
      if (c == ' ' || c == '\t') {
        break;
      }
    }
    if (i >= decodedSQL.length()) {
      return new Tuple2<String, String>("", StringUtil.trim(decodedSQL));
    }
    return new Tuple2<String, String>(decodedSQL.substring(0, i), StringUtil.trim(decodedSQL.substring(i)));
  }

  @Override
  public SimpleStatementResult compileRequest(String sql, SimpleDriverParameters parameters) throws SQLException {
    final Tuple2<String, String> databaseNameRealRequest = decodeSQL(sql);
    final String databaseName = databaseNameRealRequest.get0();
    final EzJDBCDatabase jdbcDatabase = EzDBDatabaseManager.reference.find(databaseName);
    if (jdbcDatabase == null) throw new SQLException("Unknown shema "+databaseName);
    return SimpleConnectedStatementResult.execute(jdbcDatabase, databaseNameRealRequest.get1());
  }
  
  private static final String prefix = "sql";

}

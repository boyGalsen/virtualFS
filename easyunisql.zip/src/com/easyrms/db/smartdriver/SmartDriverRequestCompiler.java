package com.easyrms.db.smartdriver;

import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.executor.*;

import org.openknows.common.db.*;
import org.openknows.common.db.SimpleRequest;
import org.openknows.common.db.xml.*;
import org.openknows.jdbc.driver.common.*;

import java.sql.*;
import java.util.*;


public class SmartDriverRequestCompiler implements AbstractRequestCompiler<SimpleDriverConnection> {
  
  public SmartDriverRequestCompiler(ValidatedDirectory cacheDirectory, EzJDBCDatabase database) {
    this.cacheDirectory = cacheDirectory;
    this.database = database;
  }
  
  public ParameterMetaData compileParameterMetadata(String sql, SimpleDriverParameters parameters, SimpleDriverConnection connection) {
    return null;
  }

  public SimpleStatementResult compileRequest(String sqlRequest, SimpleDriverParameters parameters, SimpleDriverConnection connection) throws SQLException {
    final SmartDriverHints hints = SmartDriverHints.compile(sqlRequest);
    final com.easyrms.util.preferences.Parameters hintParameters = hints.getHint();
    final String[] cache = hintParameters.getParameterValues("cache");
    if (cache != null && cache.length >= 1) {
      final boolean refresh = ParametersUtil.getBoolean(hintParameters, "refresh", false);
      final int background = ParametersUtil.getInt(hintParameters, "backgroundrefresh", 0)*60*1000;
      try {
        final ValidatedFile cacheFile = StreamUtils.getChildFile(cacheDirectory, cache[0]);
        StreamUtils.mkParentDirs(cacheFile);
        try {
          if (!refresh && cacheFile.isExists()) {
            final SimpleStatementResult statement = XMLStatementHandler.getStatement(StreamUtils.newFileReader(cacheFile));
            if (hints.getSQLRequest().equalsIgnoreCase(statement.getSQLRequest())) {
              //if (cache)
              return statement;
            }
          }
        }
        catch (Throwable ignored) {
        }
        //Connection connection = SimpleConnections.getConnection(database.getURL(), true);
        try {
          final Statement statement = connection.createStatement();
          return new XMLStatementWriter(StreamUtils.newFileWriter(cacheFile)).execute(statement, hints.getSQLRequest());
        }
        catch (Throwable exception) {
          throw new SQLException(exception);
        }
        finally {
        //  SQLUtils.close(connection);
        }
      }
      finally {
        if (background > 0) {
          addForBackgroundRefresh(cache[0], background, hints.getSQLRequest());
        }
      }
    }
    //Connection connection = SimpleConnections.getConnection(database.getURL(), true);
    try {
      final Statement statement = connection.createStatement();
      return SimpleRequest.execute(statement, hints.getSQLRequest());
    }
    catch (Throwable exception) {
      throw new SQLException(exception);
    }
    finally {
    //  SQLUtils.close(connection);
    }
  }

  public ResultSetMetaData compileResultSetMetadata(String sql, SimpleDriverParameters parameters, SimpleDriverConnection connection) {
    return null;
  } 
  
  private final ValidatedDirectory cacheDirectory;
  private final EzJDBCDatabase database;
  
  private final void addForBackgroundRefresh(final String key, int delay, final String sql) {
    synchronized (backGroundRequests) {
      if (!backGroundRequests.containsKey(key)) {
        final PeriodicManager manager = PeriodicManager.getAlonePeriodicManager(PeriodicContextType.DEFAULT, delay, "SmartDriver/"+key);
        manager.add(new EzRunnableTask("SmarDriverBackgroundRequest", new Runnable() {
          
          public synchronized void run() {
            try {
              final Connection connection = SimpleConnections.getConnection(database.getName(), database.getDescription(), database.getURL(), true, database.isSoftDatabase());
              try {
                final Statement statement = connection.createStatement();
                final ValidatedFile cacheFile = StreamUtils.getChildFile(cacheDirectory, key);
                new XMLStatementWriter(StreamUtils.newFileWriter(cacheFile)).execute(statement, sql);
              }
              finally {
                SQLUtils.close(connection);
              }
            }
            catch (Throwable ignored) {
              
            }
          }
        }));
        backGroundRequests.put(key, manager);
      }
    }
  }
  private final HashMap<String, PeriodicManager> backGroundRequests = new HashMap<String, PeriodicManager>(); 
}
package com.easyrms.db.smartdriver;

import com.easyrms.cache.*;
import com.easyrms.db.*;
import com.easyrms.util.*;

import org.openknows.jdbc.driver.common.*;

import java.sql.*;
import java.util.*;


public class SmartDriverConnectionDriver extends AbstractDriverConnectionDriver {
  
  public SmartDriverConnectionDriver() {
    super("jdbc:ezrms.smart:");
  }
  
  @Override
  protected Connection newConnection(String url, Properties props) throws SQLException {
    return new SimpleDriverConnection(compilers.get(url));
  }

  private final Cache<String, SmartDriverRequestCompiler> compilers = Caches.newCacheInstance(new Creator<String, SmartDriverRequestCompiler>() {

    public SmartDriverRequestCompiler create(String key) throws Exception {
      return new SmartDriverRequestCompiler(StreamUtils.getChildDirectory(StreamUtils.getDirectory(materialiseDirectory), "smartdriverrequest"), new EzJDBCDatabase(key, "smartDriver", key));
    }
  });  
  
  private static final String materialiseDirectory = PropertiesUtil.getString("com.easyrms.db.proxydb.materialiseDirectory", "C:/temp/");

}
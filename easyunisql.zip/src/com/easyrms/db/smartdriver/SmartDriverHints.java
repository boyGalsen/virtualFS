package com.easyrms.db.smartdriver;

import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.preferences.*;

public class SmartDriverHints {
  
  public static SmartDriverHints compile(String request) {
    final SimpleParameters hints = new SimpleParameters();
    final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
    final StringBuilder realRequest = bufferPool.get();
    final StringBuilder parameterName = bufferPool.get();
    final StringBuilder parameterValue = bufferPool.get();
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<String> parameterValues = arrayPool.get();
    try {
      int state  = START;
      for (int i = 0, n = request.length(); i < n; i++) {
        final char c = request.charAt(i);
        switch (state) {
          case START : {
            switch (c) {
              case '/' : {
                state = READFIRSTSTART;
                break;
              }
              default : {
                realRequest.append(c);
                break;
              }
            }
            break;
          }
          case READFIRSTSTART : {
            switch (c) {
              case '*' : {
                state = READSECONDSTART;
                break;
              }
              case '/' : {
                realRequest.append('/');
                state = READFIRSTSTART;
                break;
              }
              default : {
                state = START;
                realRequest.append('/').append(c);
                break;
              }
            }
            break;
          }
          case READSECONDSTART : {
            switch (c) {
              case '-' : {
                state = READNAME;
                break;
              }
              case '/' : {
                realRequest.append('/').append('*');
                state = READFIRSTSTART;
                break;
              }
              default : {
                state = START;
                realRequest.append('/').append('*').append(c);
                break;
              }
            }
            break;
          }
          case READNAME : {
            switch (c) {
              case ' ' : case '\r': case '\n': case '\f': case '\t': {
                if (parameterName.length() > 0) {
                  hints.add(new SimpleParametersTuple(parameterName.toString(), StringArrays.emptyStringArray));
                  parameterName.setLength(0);
                }
                break;
              }
              case '*' : {
                state = READFIRSTEND;
                break;
              }
              case '(' : {
                parameterValue.setLength(0);
                parameterValues.clear();
                if (parameterName.length() == 0) throw new IllegalArgumentException("Invalid Request");
                state = READPARAMETER;
                break;
              }
              default : {
                parameterName.append(c);
                break;
              }
            }
            break;
          }
          case 4 : {
            switch (c) {
              case ' ' : case '\r': case '\n': case '\f': case '\t': {
                if (parameterValue.length() > 0) {
                  parameterValues.add(parameterValue.toString());
                  parameterValue.setLength(0);
                }
                break;
              }
              case ')' : {
                if (parameterValue.length() > 0) {
                  parameterValues.add(parameterValue.toString());
                  parameterValue.setLength(0);
                }
                hints.add(new SimpleParametersTuple(parameterName.toString().toLowerCase(), parameterValues.toArray(new String[parameterValues.size()])));
                parameterName.setLength(0);
                parameterValues.add(parameterValue.toString());
                state = READNAME;
                break;
              }
              default : {
                parameterValue.append(c);
                break;
              }
            }
            break;
          }
          case READFIRSTEND : {
            switch (c) {
              case '/' : {
                state = START;
                break;
              }
              case ' ' : case '\r': case '\n': case '\f': case '\t': {
                parameterName.append('*');
                if (parameterName.length() > 0) {
                  hints.add(new SimpleParametersTuple(parameterName.toString().toLowerCase(), StringArrays.emptyStringArray));
                  parameterName.setLength(0);
                }
                break;
              }
              case '*' : {
                parameterName.append('*');
                state = READFIRSTEND;
                break;
              }
              case '(' : {
                parameterName.append('*');
                parameterValue.setLength(0);
                parameterValues.clear();
                state = READPARAMETER;
                break;
              }
              default : {
                parameterName.append('*');
                parameterName.append(c);
                state = READNAME;
                break;
              }
            }
            break;
          }
          
        }
      }
      return new SmartDriverHints(hints, realRequest.toString());
    }
    finally {
      arrayPool.free(parameterValues);
      bufferPool.free(parameterName);
      bufferPool.free(parameterValue);
      bufferPool.free(realRequest);
    }
  }

  private SmartDriverHints(Parameters hints, String cleanRequest) {
    this.hints = hints;
    this.cleanRequest = cleanRequest;
  }
  
  public Parameters getHint() {
    return hints;
  }
  
  public String getSQLRequest() {
    return cleanRequest;
  }
  
  private final Parameters hints;
  private final String cleanRequest;
  
  private static final int START = 0;
  private static final int READFIRSTSTART = 1;
  private static final int READSECONDSTART = 2;
  private static final int READNAME = 3;
  private static final int READPARAMETER = 4;
  private static final int READFIRSTEND = 5;
  
  
}
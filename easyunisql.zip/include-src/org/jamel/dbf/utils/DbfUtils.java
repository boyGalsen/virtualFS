package org.jamel.dbf.utils;

import java.io.DataInput;
import java.io.IOException;

/**
 * @author Sergey Polovko
 */
public final class DbfUtils {

    private DbfUtils() {
    }

    public static int readLittleEndianInt(DataInput in) throws IOException {
        int bigEndian = 0;
        for (int shiftBy = 0; shiftBy < 32; shiftBy += 8) {
          bigEndian |= (in.readUnsignedByte() & 0xff) << shiftBy;
        }
        return bigEndian;
    }

    public static short readLittleEndianShort(DataInput in) throws IOException {
        int low = in.readUnsignedByte() & 0xff;
        int high = in.readUnsignedByte();
        return (short) (high << 8 | low);
    }

    public static int trimLeftSpacesIndex(byte[] arr) {
      int i = arr.length;
      while (--i >= 0 && arr[i] == ' ') {
      }
      return i == 0 ? 0 : ++i;
  }

    
    public static byte[] trimLeftSpaces(byte[] arr) {
        int i = arr.length;
        while (--i >= 0 && arr[i] == ' ') {
        }
        if (i == 0) {
          return noByte;
        }
        ++i;
        if (i == arr.length) {
          return arr;
        }
        byte[] result = new byte[i];
        if (i > 0) {
          System.arraycopy(arr, 0, result, 0, i);
        }
        return result;
    }

    public static boolean contains(byte[] arr, byte value) {
        for (int i = 0, n = arr.length; i < n; i++) {
          if (arr[i] == value) return true;
        }
        return false;
    }
    
    public static boolean contains(byte[] arr, byte value, int from, int to) {
      for (int i = from, n = Math.min(to, arr.length); i < n; i++) {
        if (arr[i] == value) return true;
      }
      return false;
  }

    /**
     * parses only positive numbers
     *
     * @param bytes   bytes of string value
     * @return integer value
     */
    public static int parseInt(byte[] bytes) {
        int result = 0;
        for (int i = 0, n = bytes.length; i < n; i++) {
          final byte aByte = bytes[i];
            if (aByte == ' ') {
              return result;
            }

            result *= 10;
            result += (aByte - (byte) '0');
        }

        return result;
    }

    /**
     * parses only positive numbers
     *
     * @param bytes   bytes of string value
     * @param from    index to start from
     * @param to      index to end at
     * @return integer value
     */
    public static int parseInt(byte[] bytes, int from, int to) {
        int result = 0;
        for (int i = from, n = bytes.length; i < to && i < n; i++) {
            result *= 10;
            result += (bytes[i] - (byte) '0');
        }
        return result;
    }

    /**
     * parses only positive numbers
     *
     * @param bytes   bytes of string value
     * @return long value
     */
    public static long parseLong(byte[] bytes) {
        long result = 0;
        for (int i = 0, n = bytes.length; i < n; i++) {
          final byte aByte = bytes[i];
            if (aByte == ' ') return result;

            result *= 10;
            result += (aByte - (byte) '0');
        }

        return result;
    }

    /**
     * parses only positive numbers
     *
     * @param bytes   bytes of string value
     * @param from    index to start from
     * @param to      index to end at
     * @return integer value
     */
    public static long parseLong(byte[] bytes, int from, int to) {
        long result = 0;
        for (int i = from, n = bytes.length; i < to && i < n; i++) {
            result *= 10;
            result += (bytes[i] - (byte) '0');
        }
        return result;
    }
    
    private static final byte[] noByte = new byte[0];
}

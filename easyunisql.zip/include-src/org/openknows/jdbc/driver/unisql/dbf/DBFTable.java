package org.openknows.jdbc.driver.unisql.dbf;


import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.memory.*;

import java.io.*;
import org.jamel.dbf.*;
import org.jamel.dbf.structure.*;


public class DBFTable implements AtTable {
  
  public DBFTable init(final MemoryDatabase database, final String file, String name) throws DatabaseException {
    try {
      return this.init(EzFSUtil.findEzFsFileDescriptior(file), name);
    }
    catch (IOException ioException) {
      throw new DatabaseException(ioException);
    }
  }
	
	public DBFTable init(final EzFSFileDescriptor file) throws DatabaseException {
		return this.init(file, true);
	}
  
  public DBFTable init(final EzFSFileDescriptor file, String name) throws DatabaseException {
    return this.init(file, name, true);
  }
  
  public String getType() {
    return Table.FILE;
  }
  
  public String getDescription() {
    return EzFSUtil.getAbsolutePath(this.file);
  }
  
  public String getName() {
    return this.name;
  }

  public DBFTable init(final EzFSFileDescriptor file, final boolean withColumnNameHeader) throws DatabaseException {
    return init(file, EzFSUtil.getAbsolutePath(file), withColumnNameHeader);
  }
  
  public DBFTable init(final EzFSFileDescriptor file, final String name, final boolean withColumnNameHeader) throws DatabaseException {
  	try {
	  	this.file = file;
      this.name = name;
      final TableMetaData metaData = new TableMetaData();
      try (final EzFSConnection connection = EzFS.reference.get().getConnection(file.getConnectionDescriptor())) {
        try (final InputStream in = connection.find(file).getAccess().openInput()) {
          final DbfReader record = new DbfReader(in);
          final DbfHeader header = record.getHeader();
          for (int i = 0, n = header.getFieldsCount(); i < n; i++) {
            final DbfField field = header.getField(i);
            switch (field.getDataType()) {
              case DATE : {
                metaData.add(Column.getAndInit(field.getName(), ColumnType.DATE));
              }
              break;
              case LOGICAL : {
                metaData.add(Column.getAndInit(field.getName(), ColumnType.BOOLEAN));
              }
              break;
              case FLOAT : {
                metaData.add(Column.getAndInit(field.getName(), ColumnType.DOUBLE));
              }
              break;
              case NUMERIC : {
                if (field.getDecimalCount() > 0) {
                  metaData.add(Column.getAndInit(field.getName(), ColumnType.DOUBLE));
                }
                else {
                  metaData.add(Column.getAndInit(field.getName(), ColumnType.LONG));
                }
              }
              break;
              case CHAR : {
                metaData.add(Column.getAndInit(field.getName(), ColumnType.STRING));
              }
              break;
            }
          }
        }
      }
	  	this.metaData = metaData;
  	}
		catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      throw new DatabaseException(ignored);
		}  
    return this;
	}
  
  public TableAccessor getAccessor() throws DatabaseException {
  	try {
  	  return new DBFTableAccessor(file, metaData, withColumnNameHeader);
  	}
  	catch (Throwable ignored) {
      throw new DatabaseException(ignored);
  	}
  }

  public InsertTableAccessor getInsertAccessor() throws DatabaseException {
		return null;
	}
  
  private EzFSFileDescriptor file;
  private boolean withColumnNameHeader;
  private MetaData metaData;
  private String name;
  
  public MetaData getMetaData() throws DatabaseException {
    return metaData;
  }
}

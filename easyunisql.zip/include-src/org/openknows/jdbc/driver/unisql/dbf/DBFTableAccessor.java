package org.openknows.jdbc.driver.unisql.dbf;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;
import java.nio.charset.*;
import java.util.*;
import org.jamel.dbf.*;
import org.jamel.dbf.structure.*;

import org.openknows.jdbc.driver.unisql.*;
import org.openknows.jdbc.driver.unisql.jdbcmap.JDBCDatabaseValue;


public class DBFTableAccessor implements TableAccessor {

  public DBFTableAccessor(EzFSFileDescriptor file, final MetaData metaData, final boolean withColumnNames) throws DatabaseException  { 
    try {
      this.fsConnection = EzFS.reference.get().getConnection(file.getConnectionDescriptor());
      this.reader = fsConnection.find(file).getAccess().openInput();
      record = new DbfReader(this.reader);
      header = record.getHeader();
      charset = record.getCharset();
  		this.metaData = metaData;
   		currentRow = new Object[header.getFieldsCount()];
   		currentRow = record.nextRecord(currentRow);
  		hasNext = currentRow != null;
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}
  }
  
  public void init() throws DatabaseException {
  }

  public MetaData getMetaData()  throws DatabaseException {
    return metaData;
  }

  public boolean hasNext() throws DatabaseException {
  	return hasNext;
  }

  public Row getNext() throws DatabaseException {
		if (!hasNext) throw new DatabaseException("no more value");
		try {
      rowIndex++;
      row = new DatabaseRow();
      row.init(this.metaData);
      for (int i = 0, n = currentRow.length; i < n; i++) {
        final DbfField field = header.getField(i);
        final Object value = currentRow[i]; 
        //final String fieldName = field.getName();
        switch (field.getDataType()) {
          case DATE : {
            row.set(i+1, JDBCDatabaseValue.getAndInit(toDate(value)));
          }
          break;
          case LOGICAL : {
            row.set(i+1, JDBCDatabaseValue.getAndInit(toBoolean(value)));
          }
          break;
          case FLOAT : {
            row.set(i+1, JDBCDatabaseValue.getAndInit(toDouble(value)));
          }
          break;
          case NUMERIC : {
            if (field.getDecimalCount() > 0) {
              row.set(i+1, JDBCDatabaseValue.getAndInit(toDouble(value)));
            }
            else {
              row.set(i+1, JDBCDatabaseValue.getAndInit(toLong(value)));
            }
          }
          break;
          case CHAR : {
            row.set(i+1, JDBCDatabaseValue.getAndInit(toString(value)));
          }
          break;
        }
      }
      currentRow = record.nextRecord();
      hasNext = currentRow != null;
	  	return row;
		}
		catch (Throwable e) {
      throw new DatabaseException("on row "+rowIndex+":"+ExceptionUtils.getMessage(e));
		}	  	
  }
  
  private String toString(Object value) {
    return value == null ? null : new String((byte[])value, charset);
  }
  
  private Double toDouble(Object value) {
    return value == null ? null : (Double)value;
  }
  
  private Long toLong(Object value) {
    return value == null ? null : (Long)value;
  }

  private Date toDate(Object value) {
    return value == null ? null : (Date)value;
  }

  
  private Boolean toBoolean(Object value) {
    return value == null ? null : (Boolean)value;
  }
  
  public void close() throws DatabaseException {
    try {
      try {
        hasNext = false;
        row = null;
        StreamUtils.closeNotCatch(reader);
        reader = null;
        record = null;
        header = null;
      }
      finally {
        if (fsConnection != null) {
          fsConnection.close();
          fsConnection = null;
        }
      }
		}
		catch (Throwable e) {
			throw new DatabaseException(e);
		}	 
  }
  
  private EzFSConnection fsConnection;
  private final MetaData metaData;

  private int rowIndex;
  private DatabaseRow row;
  private boolean hasNext;
  private Object[] currentRow;
  private DbfReader record;
  private DbfHeader header;
  private Charset charset;
  
  private InputStream reader;
}

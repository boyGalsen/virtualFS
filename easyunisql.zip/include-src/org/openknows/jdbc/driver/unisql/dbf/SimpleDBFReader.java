package org.openknows.jdbc.driver.unisql.dbf;

import java.io.*;
import org.jamel.dbf.*;
import org.jamel.dbf.structure.*;

public class SimpleDBFReader {

  public static void main(String... args) {
    
    DbfReader reader = new DbfReader(new File("D:\\OpenKnowsPlugin\\EC_W\\easyunisql\\include-src\\org\\openknows\\jdbc\\unisql\\dbf\\COMPANY.DBF"));
    final DbfHeader header = reader.getHeader();
    for (int i = 0, n = header.getFieldsCount(); i < n; i++) {
      if (i > 0) {
        System.out.print("\t");
      }
      System.out.print(header.getField(i).getName());
    }
    System.out.print("\r\n");
    DbfRow row = null;
    while ((row = reader.nextRow()) != null) {
      for (int i = 0, n = header.getFieldsCount(); i < n; i++) {
        if (i > 0) {
          System.out.print("\t");
        }
        DbfField field = header.getField(i);
        switch (field.getDataType()) {
          case LOGICAL : System.out.print(row.getBoolean(field.getName())); break;
          case DATE : System.out.print(row.getDate(field.getName())); break;
          case FLOAT : System.out.print(row.getFloat(field.getName())); break;
          case NUMERIC : System.out.print(row.getInt(field.getName())); break;
          case CHAR : System.out.print(row.getString(field.getName())); break;
        }
        
      }
      System.out.print("\r\n");
        
    }
  }
}

import com.easyrms.db.*;
import com.easyrms.util.array.*;

import java.io.*;
import java.sql.*;

public class checklogin {

  private static final String database = "jdbc:oracle:thin:yield/yieldboss@(DESCRIPTION= (LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.248.167)(PORT=1525)) (CONNECT_DATA=(SERVICE_NAME=RMSPE4)))";
  
  
  public static void main(String... args) throws Throwable {
    final EzDBTransaction totransaction = new EzJDBCDatabase("to", "to", database).openTransaction();
    try (final FileWriter out = new FileWriter("d:/loginsezrms.txt")) {
      try {
        out.append("login");
        out.append("\t");
        out.append("password");
        out.append("\r\n");
      }
      catch (IOException forward) {
        throw new RuntimeException(forward);
      }
      SimpleRequest.query(totransaction, "select email, password from hotel.users", ObjectArrays.emptyObjectArray, new EzDBResultSetListener() {

        @Override
        public void set(int i, ResultSet v) throws SQLException {
          // TODO Auto-generated method stub
          try {
            System.out.println(SQLUtils.getString(v, 1));
            out.append(SQLUtils.getString(v, 1));
            out.append("\t");
            out.append(SQLUtils.getString(v, 2));
            out.append("\r\n");
          }
          catch (IOException forward) {
            throw new SQLException(forward);
          }
        }
        
      });
    }
    finally {
      totransaction.rollback();
      totransaction.close();
    }
    System.out.print("Done!");
  }

}

package org.openknows.jdbc.ldd2;

// ALL_ARGUMENTS for PROCEDURES object type PACKAGE 
public interface CMAProcedureArg {
  public String getOwner();
  public String getProcFuncName();
  public long getProcFuncId();
  public String getPackageName();
  public long getSubId();   // 0 for Package itself
  public String getNumOverload();
  public String getName();
  
}

package org.openknows.jdbc.ldd2;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.io.*;
import java.sql.*;
import java.util.*;

import com.easyrms.date.*;
import com.easyrms.db.*;

// ================================================================================================================================================ *
//                                                                                                                                                  *
// First, we need a list of Database Server with name (in key) and connection string (in value)                                                     *
//                                                                                                                                                  *
// Then we can access to others methods                                                                                                             *
// checkOwner(listOfDatabaseServer) : Compare Owner                                                                                                 *
// checkObjectTypeCountByOwner(listOfDatabaseServer, ownerCode) : Compare the number of Objects by type for one Owner                               *
// checkObjectByOwner(listOfDatabaseServer, owner, typeObject) : Compare Object for one Owner and one Object Type                                   *
// checkProcedureByOwner(listOfDatabaseServer, owner, typeObject) : Compare Procedure Or Function Or Trigger Or Package for one Owner               *
// checkIndexByOwner(listOfDatabaseServer, owner) : Compare Index for one Owner                                                                     *
// checkColumnForTable(listOfDatabaseServer, owner, tableName) : Compare Column for one Owner and one Table                                         *
// checkColumnForIndex(listOfDatabaseServer, owner, indexName) : Compare Column for one Owner and one Index                                         *
//                                                                                                                                                  *
// An HashMap "statistic" have the element to be compare in key and the list of DataBaseServer in value (each name is separate by "�")              *
// Exception : For counting process, the statistic contain count in value (one value is required for each DataBaseServer, zero if not)              *
// The DataBaseServer name is the header of column                                                                                                  *
// An ArrayList "keys" contain the keys of statistic sorted, this is the header of row                                                              *
// In cell we have a green disc or a red disc to say Ok or not                                                                                      *
// Exception : For counting process, we have the number of element                                                                                  *
// In additionnal, when the key need other informations, we have an HashMap "reference" to list complementaries parameters                          *
//                                                                                                                                                  *
// For presenting in HTML format                                                                                                                    *
// boolean GenerateResultHTMLHeader() : Create the Output Stream HTML file and generate header's HTML, return true if succesfully                   *
// GenerateResultHTMLManageView(lineHtml, idTable, title) : Generate the script management of block view (Stream, Icremental Id, title)             *
// GenerateResultHTMLInitView(lineHtml, idTable) : Generate the script launch for initialize the block view                                         *
// GenerateResultHTMLTable(title, keys, statistic) : Generate a table with key as row and a split "�" statistic value for DataBase Server list      *
// GenerateResultHTMLTableProc(title, keys, statistic, reference) : Same with parameter's list for the first DataBase Server (Proc/Func/Trig/Pack)  *
// GenerateResultHTMLTableIndex(title, keys, statistic, reference) : Same with parameter's list for the first DataBase Server (Index)               *
// GenerateResultHTMLTableCol(title, keys, statistic, reference) : Same with parameter's list for the first DataBase Server (column's table)        *
// GenerateResultHTMLIndexCol(title, keys, statistic, reference) : Same with parameter's list for the first DataBase Server (column's index)        *
// GenerateResultHTMLTableCount(title, keys, statistic) : Generate a table with key as row and a counter by cell and DataBase Server name as column *
// GenerateResultHTMLFooter() : Generate the footer's HTML and close the Output Stream HTML file                                                    *
//                                                                                                                                                  *
// In additionnal, the .png files must be copied in generate HTML file directory                                                                    *
//                                                                                                                                                  *
// ------------------------------------------------------------------------------------------------------------------------------------------------ *

public class TestCMA {
  
  // Compare contain of all database server
  public static void main(String[] args) throws Throwable {
    final TestCMA testCMA = new TestCMA();
    try {
      // Extract list of database server (key:name, value:url)
      HashMap<String, String>listOfDatabaseServer = testCMA.listOfDatabaseServer();
      if (listOfDatabaseServer.size() < 2) return;
      System.out.println(" 1 - Database Server list Ok ");
      
      if (! testCMA.GenerateResultHTMLHeader()) return;
      System.out.println(" 2 - Header HTML Ok ");
      
      // check processes for Oracle
      testCMA.checkOwner(listOfDatabaseServer);
      System.out.println(" 3 - Check Owner Ok ");      
      testCMA.checkColumnForIndex(listOfDatabaseServer, "CONFIG", "CALENDAR_INDEX2");
      System.out.println(" 4.1 - Check Column Index completed ");

      testCMA.GenerateResultHTMLFooter();
      System.out.println(" 5 - Footer HTML Ok ");
    }
    catch  (Throwable exception) {    
    }
  }

  // =============================================================*
  // Extract list of Database Server from XML file (name and url) *
  // -------------------------------------------------------------*
  
  final String nameOfXml = "D:\\DAM\\workspace\\3.1\\ezrms\\webapp\\WEB-INF\\ezrmsconfig.xml";
  final String tagDatabaseServer = "EZRMSDatabaseServer";
  final String attrNameInTagDatabaseServer = "name";
  final String attrUrlInTagDatabaseServer = "url";
  
  public HashMap<String, String>listOfDatabaseServer() {
    final HashMap<String, String> databaseServer = new HashMap<String, String>();
    try {
      final FileReader fileReader = StreamUtils.newFileReader(StreamUtils.getFile(nameOfXml));
      final BufferedReader lineXml = new BufferedReader(fileReader);
      try {
        String name;
        String url;
        int pos;
        boolean comment = false;
  
        while (true) {
          final String oneLine = lineXml.readLine();
          if (oneLine == null) break;
  
          final String line = oneLine.trim();
          if (line.startsWith("<!--")) {
            comment = true;
          }        
          if (!comment && (line.startsWith("<" + tagDatabaseServer) || line.startsWith("< " + tagDatabaseServer))) {
            pos = line.indexOf(attrNameInTagDatabaseServer + "=", tagDatabaseServer.length());
            if (pos > tagDatabaseServer.length()) {
              name = line.substring(line.indexOf("\"", pos)+1, line.indexOf("\"", pos+attrNameInTagDatabaseServer.length()+3));
            }
            else {
              name = " ";
            }
            pos = line.indexOf(attrUrlInTagDatabaseServer + "=", tagDatabaseServer.length());
            if (pos > tagDatabaseServer.length()) {
              url = line.substring(line.indexOf("\"", pos)+1, line.indexOf("\"", pos+attrUrlInTagDatabaseServer.length()+3));
            }
            else {
              url = " ";
            }
            if (!name.trim().isEmpty() && !url.trim().isEmpty()) {
              System.out.println(name + " | " + url);
              databaseServer.put(name, url);      
            }
          }
          if (line.contains("-->")) {
            comment = false;
          }
        }
      }
      catch  (Throwable exception) {    
      }
      finally {
        try {lineXml.close();} catch (Throwable exception) {}
        try {StreamUtils.close(fileReader);} catch (Throwable exception) {}
      }
    }
    catch  (Throwable exception) {    
    }

    return databaseServer;
  }

  // =============================================================*
  // Check process                                                *
  // -------------------------------------------------------------*
  
  final String[] listOfSchemaEz={"BOOKING", "BUDGET", "CHECKPOINT", "COMPETE", "CONFIG", "DEAL", "HOTEL", "LOAD", "OPERA", "YIELD"};
  final String[] listOfObjectType={"CLUSTER", "FUNCTION", "INDEX", "JOB", "PACKAGE", "PACKAGE BODY", "PROCEDURE", "SEQUENCE", "SYNONYM", "TABLE", "TRIGGER", "VIEW"}; 

  public void checkLookup(HashMap<String, String>listOfDatabaseServer) {
    try {
      for (String oneSchema : listOfSchemaEz) {      
        checkObjectTypeCountByOwner(listOfDatabaseServer, oneSchema);      
        System.out.println("Check Object Type Count For Owner " + oneSchema + " Ok ");
        
        for (String oneType : listOfObjectType) { 
          checkObjectByOwner(listOfDatabaseServer, oneSchema, oneType);
          System.out.println("Check Object Type " + oneType + " For Owner " + oneSchema + " Ok ");
        }
        
        final ArrayList<String> listOfTables = extractListOfObjet(listOfDatabaseServer, oneSchema, "TABLE");
        for (String oneTable : listOfTables) {
          checkColumnForTable(listOfDatabaseServer, oneSchema, oneTable);
          System.out.println("Check Columns Table " + oneTable + " For Owner " + oneSchema + " Ok ");
        }
      }
    }
    catch  (Throwable exception) {
      System.out.println("Lookup schema failed");
    }
  }

  final String requestListOfObjectForOwner = "select object_name from sys.all_objects where owner='";
  final String requestListOfObjectForOwner2 = " and object_type='";
  final String requestListOfObjectForOwner3 = " and object_name not like 'SYS_IOT_%'";
  final String requestListOfObjectForOwner4 = " and temporary='N' ";
 
  public ArrayList<String> extractListOfObjet(HashMap<String, String>listOfDatabaseServer, String owner, String typeObject) {
    final ArrayList<String> listOfObject = new ArrayList<String>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("List Of object For one Type : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestListOfObjectForOwner + owner + "'" + requestListOfObjectForOwner2 + typeObject + "'" + requestListOfObjectForOwner3 + requestListOfObjectForOwner4, 
          new EzDBResultSetListener() {
            
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final String Object_name = SQLUtils.getString(v, 1);
              if (! listOfObject.contains(Object_name)) {
                listOfObject.add(Object_name);
              }
            }
          },
          ObjectArrays.emptyObjectArray);
        databaseAccess.close();
      }
    }
    catch  (Throwable exception) {
      System.out.println("Extract List failed");
    }    
    return listOfObject;
  }
  
  final String requestOwner = "select distinct owner from sys.all_objects";
  final String titleOwner = "Compare Owner List";
  
  public void checkOwner(HashMap<String, String>listOfDatabaseServer) {
    final HashMap<String, String> ownerStatistic = new HashMap<String, String>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Owner : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestOwner,
          new EzDBResultSetListener() {
            
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final String owner = SQLUtils.getString(v, 1);
              final CMAOwner cMAOwner = new CMAOwner() {
      
                public String getOwner() {
                  return owner;
                }
              };
              final String databaseList;
              if (ownerStatistic.containsKey(cMAOwner.getOwner())) {
                databaseList = ownerStatistic.get(cMAOwner.getOwner()) + "�" + databaseName;
              }
              else {
                databaseList = databaseName;
              }
              ownerStatistic.put(cMAOwner.getOwner(), databaseList);
            }
          },
          ObjectArrays.emptyObjectArray);
        
        databaseAccess.close();
      }
      GenerateResultHTMLTable(titleOwner, keys, ownerStatistic);
    }
    catch  (Throwable exception) {    
    }
  }
  
  final String requestObjectType = "select object_type, count(*) from sys.all_objects where owner='";
  final String requestObjectType2 = " and object_name not like 'SYS_IOT_%'";
  final String requestObjectType3 = " group by object_type";
  final String titleObjectType = "Count Object type for Owner : ";
  
  public void checkObjectTypeCountByOwner(HashMap<String, String>listOfDatabaseServer, String ownerCode) {
    final HashMap<String, String> objectTypeStatistic = new HashMap<String, String>();
    for (String oneType : listOfObjectType) {
      objectTypeStatistic.put(oneType, "");
    }
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    String separatorSign = "";
    try {
      for (String oneDb : keys) {
        final HashMap<String, String> typeAndCount = new HashMap<String, String>();
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Object By Owner : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestObjectType + ownerCode + "'" + requestObjectType2 + requestObjectType3,
          new EzDBResultSetListener() {
            
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final String objectType = SQLUtils.getString(v, 1);
              final int objectCount = SQLUtils.getInt(v, 2);
              typeAndCount.put(objectType, Integer.toString(objectCount));
            }
          },
          ObjectArrays.emptyObjectArray);
        
        databaseAccess.close();
        for (String oneType : listOfObjectType) {
          final String MemorizedListOfCount = objectTypeStatistic.get(oneType);
          if (typeAndCount.containsKey(oneType)) {
            objectTypeStatistic.put(oneType, MemorizedListOfCount + separatorSign + typeAndCount.get(oneType));
          }
          else {
            objectTypeStatistic.put(oneType, MemorizedListOfCount + separatorSign + "0");            
          }
        }
        separatorSign = "�";
      }
      GenerateResultHTMLTableCount(titleObjectType + ownerCode, keys, objectTypeStatistic);
    }
    catch  (Throwable exception) {    
    }
  }

  final String requestObjectByOwner = "select owner, object_id, object_name, object_type, temporary, created, last_ddl_time from sys.all_objects where owner='";
  final String requestObjectByOwner2 = " and object_type='";
  final String requestObjectByOwner3 = " and object_name not like 'SYS_IOT_%' and temporary='N' ";
  final String titleObjectByOwner = "Compare ";
  final String titleObjectByOwner2 = " List for Owner : ";
  
  public void checkObjectByOwner(HashMap<String, String>listOfDatabaseServer, String owner, String typeObject) {
    final HashMap<String, String> objectStatistic = new HashMap<String, String>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Object By Owner : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestObjectByOwner + owner + "'" + requestObjectByOwner2 + typeObject + "'" + requestObjectByOwner3, 
          new EzDBResultSetListener() {
            
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final String owner = SQLUtils.getString(v, 1);
              final long object_id = SQLUtils.getLong(v, 2);
              final String object_name = SQLUtils.getString(v, 3);
              final String object_type = SQLUtils.getString(v, 4);
              final String temporary = SQLUtils.getString(v, 5);
              final DateAccessor created = SQLUtils.getDate(v, 6);
              final DateAccessor last_ddl_time = SQLUtils.getDate(v, 7);
              final CMAObject cMAObject = new CMAObject() {
                
                public String getOwner() {
                  return owner;
                }                
                public long getId() {
                  return object_id;
                }                
                public String getName() {
                  return object_name;
                }                
                public String getType() {
                  return object_type;
                }                
                public boolean isTemporary() {
                  return ("Y".compareTo(temporary) == 0) ? true : false;
                }
                public DateAccessor getCreatedTime() {
                  return created;
                }                
                public DateAccessor getLastDdlTime() {
                  return last_ddl_time;
                }
              };
              final String databaseList;
              if (objectStatistic.containsKey(cMAObject.getName())) {
                databaseList = objectStatistic.get(cMAObject.getName()) + "�" + databaseName;
              }
              else {
                databaseList = databaseName;
              }
              objectStatistic.put(cMAObject.getName(), databaseList);
            }
          },
          ObjectArrays.emptyObjectArray);
        
        databaseAccess.close();
      }
      GenerateResultHTMLTable(titleObjectByOwner + typeObject + titleObjectByOwner2 + owner, keys, objectStatistic);
    }
    catch  (Throwable exception) {    
    }
  }

  final String requestProcedureByOwner = "select owner, object_id, object_name, object_type, procedure_name, subprogram_id, overload," +
      " aggregate, pipelined, parallel, interface, deterministic, authid from sys.all_procedures where owner='";
  final String requestProcedureByOwner2 = " and object_type='";
  final String titleProcedureByOwner = "Compare ";
  final String titleProcedureByOwner2 = " List for Owner : ";

  public void checkProcedureByOwner(HashMap<String, String>listOfDatabaseServer, String owner, String typeObject) {
    final HashMap<String, String> procedureStatistic = new HashMap<String, String>();
    final HashMap<String, CMAProcedure> procedureReference = new HashMap<String, CMAProcedure>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Proc./Funct. By Owner : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestProcedureByOwner + owner + "'" + requestProcedureByOwner2 + typeObject + "'", 
          new EzDBResultSetListener() {
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final String owner = SQLUtils.getString(v, 1);
              final long object_id = SQLUtils.getLong(v, 2);
              final String object_name = SQLUtils.getString(v, 3);
              final String object_type = SQLUtils.getString(v, 4);
              final String name = SQLUtils.getString(v, 5);
              final long sub_id = SQLUtils.getLong(v, 6);
              final String numOverload = SQLUtils.getString(v, 7);
              final String aggregate = SQLUtils.getString(v, 8);              
              final String pipeLined = SQLUtils.getString(v, 9);
              final String parallel = SQLUtils.getString(v, 10);
              final String interfaceYN = SQLUtils.getString(v, 11);
              final String deterministic = SQLUtils.getString(v, 12);
              final String executeAs = SQLUtils.getString(v, 13);             
              final CMAProcedure cMAProcedure = new CMAProcedure() {
                
                public String getOwner() {
                  return owner;
                }                
                public String getObjectName() {
                  return object_name;
                }
                public long getObjectId() {
                  return object_id;
                }
                public String getObjectType() {
                  return object_type;
                }                
                public String getName() {
                  return (name == null) ? "" : name;
                }                
                public long getSubId() {
                  return sub_id;
                }
                public String getNumOverload() {
                  return (numOverload == null) ? "" : numOverload;
                }
                public boolean isAggregate() {
                  return ("YES".compareTo(aggregate) == 0) ? true : false;
                }
                public boolean isPipeLined() {
                  return ("YES".compareTo(pipeLined) == 0) ? true : false;
                }
                public boolean isParallel() {
                  return ("YES".compareTo(parallel) == 0) ? true : false;
                }
                public boolean isInterface() {
                  return ("YES".compareTo(interfaceYN) == 0) ? true : false;
                }
                public boolean isDeterministic() {
                  return ("YES".compareTo(deterministic) == 0) ? true : false;
                }
                public String getExecuteAs() {
                  return (executeAs == null) ? "" : executeAs;
                }
              };
              
              if (! procedureReference.containsKey(cMAProcedure.getObjectName())) {
                procedureReference.put(cMAProcedure.getObjectName(), cMAProcedure);
              }
              
              // If attributs of procedure are not the same, consider that the procedure is in error and don't memorize this server name
              final CMAProcedure cMAProcedureReference = procedureReference.get(cMAProcedure.getObjectName());
              if (cMAProcedureReference.getName().compareTo(cMAProcedure.getName()) == 0
               && cMAProcedureReference.getSubId() == cMAProcedure.getSubId()
               && cMAProcedureReference.getNumOverload().compareTo(cMAProcedure.getNumOverload()) == 0
               && cMAProcedureReference.isAggregate() == cMAProcedure.isAggregate()
               && cMAProcedureReference.isPipeLined() == cMAProcedure.isPipeLined()
               && cMAProcedureReference.isParallel() == cMAProcedure.isParallel()
               && cMAProcedureReference.isInterface() == cMAProcedure.isInterface()
               && cMAProcedureReference.isDeterministic() == cMAProcedure.isDeterministic()
               && cMAProcedureReference.getExecuteAs().compareTo(cMAProcedure.getExecuteAs()) == 0
              ) {
                final String databaseList;
                if (procedureStatistic.containsKey(cMAProcedure.getObjectName())) {
                  databaseList = procedureStatistic.get(cMAProcedure.getObjectName()) + "�" + databaseName;
                }
                else {
                  databaseList = databaseName;
                }
                procedureStatistic.put(cMAProcedure.getObjectName(), databaseList);
              }
            }
          },
          ObjectArrays.emptyObjectArray);
        databaseAccess.close();
      }
      GenerateResultHTMLTableProc(titleProcedureByOwner + typeObject + titleProcedureByOwner2 + owner, keys, procedureStatistic, procedureReference);
    }
    catch  (Throwable exception) {    
    }
  }

  final String requestIndexByOwner = "select owner, index_name, index_type, table_owner, table_name, table_type, num_rows, uniqueness, compression," +
      " partitioned, temporary, generated, join_index, dropped from sys.all_indexes where owner='";
  final String titleIndexByOwner = "Compare ";
  final String titleIndexByOwner2 = " List for Owner : ";

  public void checkIndexByOwner(HashMap<String, String>listOfDatabaseServer, String owner) {
    final HashMap<String, String> indexStatistic = new HashMap<String, String>();
    final HashMap<String, CMAIndex> indexReference = new HashMap<String, CMAIndex>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Index By Owner : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestIndexByOwner + owner + "'", 
          new EzDBResultSetListener() {
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final String owner = SQLUtils.getString(v, 1);
              final String name = SQLUtils.getString(v, 2);
              final String type = SQLUtils.getString(v, 3);
              final String table_owner = SQLUtils.getString(v, 4);
              final String table_name = SQLUtils.getString(v, 5);
              final String table_type = SQLUtils.getString(v, 6);
              final long num_rows = SQLUtils.getLong(v, 7);
              final String uniqueness = SQLUtils.getString(v, 8);
              final String compression = SQLUtils.getString(v, 9);              
              final String partitioned = SQLUtils.getString(v, 10);
              final String temporary = SQLUtils.getString(v, 11);
              final String generated = SQLUtils.getString(v, 12);
              final String join_index = SQLUtils.getString(v, 13);
              final String inRecycleBin = SQLUtils.getString(v, 14);             
              final CMAIndex cMAIndex = new CMAIndex() {
               
                public String getOwner() {
                  return owner;
                }                
                public String getName() {
                  return name;
                }
                public String getType() {
                  return (type == null) ? "" : type;
                }
                public String getTableOwner() {
                  return table_owner;
                }
                public String getTableName() {
                  return table_name;
                } 
                public String getTableType() {
                  return (table_type == null) ? "" : table_type;
                }                
                public long getNumberOfRow() {
                  return num_rows;
                }
                public boolean isUnique() {
                  return ("UNIQUE".compareTo(uniqueness) == 0) ? true : false;
                }
                public boolean isCompressed() {
                  return ("ENABLED".compareTo(compression) == 0) ? true : false;
                }
                public boolean isPartitioned() {
                  return ("YES".compareTo(partitioned) == 0) ? true : false;
                }
                public boolean isTemporary() {
                  return ("Y".compareTo(temporary) == 0) ? true : false;
                }
                public boolean isSystemGenerated() {
                  return ("Y".compareTo(generated) == 0) ? true : false;
                }
                public boolean isJoinIndex() {
                  return ("YES".compareTo(join_index) == 0) ? true : false;
                }
                public boolean isInRecycleBin() {
                  return ("YES".compareTo(inRecycleBin) == 0) ? true : false;
                }
              };
              
              if (! indexReference.containsKey(cMAIndex.getName())) {
                indexReference.put(cMAIndex.getName(), cMAIndex);
              }
              
              // If attributs of index are not the same, consider that the index is in error and don't memorize this server name
              final CMAIndex cMAIndexReference = indexReference.get(cMAIndex.getName());
              if (cMAIndexReference.getType().compareTo(cMAIndex.getType()) == 0
               && cMAIndexReference.getTableOwner().compareTo(cMAIndex.getTableOwner()) == 0
               && cMAIndexReference.getTableName().compareTo(cMAIndex.getTableName()) == 0
               && cMAIndexReference.getTableType().compareTo(cMAIndex.getTableType()) == 0
               && cMAIndexReference.isUnique() == cMAIndex.isUnique()
               && cMAIndexReference.isCompressed() == cMAIndex.isCompressed()
               && cMAIndexReference.isPartitioned() == cMAIndex.isPartitioned()
               && cMAIndexReference.isTemporary() == cMAIndex.isTemporary()
               && cMAIndexReference.isSystemGenerated() == cMAIndex.isSystemGenerated()
               && cMAIndexReference.isJoinIndex() == cMAIndex.isTemporary()
               && cMAIndexReference.isInRecycleBin() == cMAIndex.isTemporary()
              ) {
                final String databaseList;
                if (indexStatistic.containsKey(cMAIndex.getName())) {
                  databaseList = indexStatistic.get(cMAIndex.getName()) + "�" + databaseName;
                }
                else {
                  databaseList = databaseName;
                }
                indexStatistic.put(cMAIndex.getName(), databaseList);
              }
            }
          },
          ObjectArrays.emptyObjectArray);
        databaseAccess.close();
      }
      GenerateResultHTMLTableIndex(titleIndexByOwner + "INDEX" + titleIndexByOwner2 + owner, keys, indexStatistic, indexReference);
    }
    catch  (Throwable exception) {    
    }
  }
  
  final String requestTableForOwner = "select count(*) from sys.all_objects where owner='";
  final String requestTableForOwner2 = " and object_name='";
  final String requestTableForOwner3 = " and object_type='TABLE'";
  final String requestTableForOwner4 = " and temporary='N' ";
  final String requestColumnForTable = "select owner, table_name, column_id, column_name, data_type, data_type_mod, " +
      "data_length, data_precision, data_scale, nullable, character_set_name, char_length, char_used from sys.all_tab_columns where owner='";
  final String requestColumnForTable2 = " and table_name='";
  final String titleColumnByTable = "Compare Column List for Table : ";
  final String titleColumnByTable2 = " and Owner : ";
  
  public void checkColumnForTable(HashMap<String, String>listOfDatabaseServer, String owner, String tableName) {
    final HashMap<String, String> columnStatistic = new HashMap<String, String>();
    final HashMap<String, CMATableCol> columnReference = new HashMap<String, CMATableCol>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    final ArrayList<Long> existTable = new ArrayList<Long>();
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Column By Table : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestTableForOwner + owner + "'" + requestTableForOwner2 + tableName + "'" + requestTableForOwner3 + requestTableForOwner4, 
          new EzDBResultSetListener() {
            
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final int exist = SQLUtils.getInt(v, 1);
              if (exist == 1) {
                if (existTable.size() == 0) existTable.add(Long.getLong("1"));
              }
            }
          },
          ObjectArrays.emptyObjectArray);
          
        if (existTable.size() > 0) {
          databaseAccess.query(
            requestColumnForTable + owner + "'" + requestColumnForTable2 + tableName + "'", 
            new EzDBResultSetListener() {
              
              @Override
              public void set(int i, ResultSet v) throws SQLException  {
                final String col_TableOwner = SQLUtils.getString(v, 1);
                final String col_TableName = SQLUtils.getString(v, 2);
                final int col_Num = SQLUtils.getInt(v, 3);
                final String col_Name = SQLUtils.getString(v, 4);
                final String col_Type = SQLUtils.getString(v, 5);
                final String col_TypeMod = SQLUtils.getString(v, 6);                
                final long col_Length = SQLUtils.getLong(v, 7);
                final long col_Precision = SQLUtils.getLong(v, 8);
                final long col_Decimal = SQLUtils.getLong(v, 9);
                final String col_Nullable = SQLUtils.getString(v, 10);
                final String col_CharSet = SQLUtils.getString(v, 11);
                final long col_LengthInByte = SQLUtils.getLong(v, 12);
                final String col_CharUsed = SQLUtils.getString(v, 13); 
                final CMATableCol cMAColTable = new CMATableCol() {
                   
                  public String getTableOwner() {
                    return col_TableOwner;
                  }
                  public String getTableName() {
                    return col_TableName;
                  }
                  public int getNumCol() {
                    return col_Num;
                  }                
                  public String getName() {
                    return col_Name;
                  }                
                  public String getType() {
                    return col_Type;
                  }
                  public String getTypeMod() {
                    return (col_TypeMod == null) ? "" : col_TypeMod;
                  }
                  public long getLength() {
                    return col_Length;
                  }
                  public long getPrecision() {
                    return col_Precision;
                  }
                  public long getDecimal() {
                    return col_Decimal;
                  }
                  public boolean isNullable() {
                    return ("Y".compareTo(col_Nullable) == 0) ? true : false;
                  }
                  public String getCharSet() {
                    return (col_CharSet == null) ? "" : col_CharSet;
                  }
                  public long getLengthInByte() {
                    return col_LengthInByte;
                  }
                  public String getCharUsed() {
                    return (col_CharUsed == null) ? "" : col_CharUsed;
                  }
                };
                
                if (! columnReference.containsKey(cMAColTable.getName())) {
                  columnReference.put(cMAColTable.getName(), cMAColTable);
                }
                
                // If attributs of column are not the same, consider that the column is in error and don't memorize this server name
                final CMATableCol cMAColReference = columnReference.get(cMAColTable.getName());
                if (cMAColReference.getType().compareTo(cMAColTable.getType()) == 0
                 && cMAColReference.getTypeMod().compareTo(cMAColTable.getTypeMod()) == 0
                 && cMAColReference.getLength() == cMAColTable.getLength()
                 && cMAColReference.getPrecision() == cMAColTable.getPrecision()
                 && cMAColReference.getDecimal() == cMAColTable.getDecimal()
                 && cMAColReference.getLengthInByte() == cMAColTable.getLengthInByte()
                 && cMAColReference.isNullable() == cMAColTable.isNullable()
                 && cMAColReference.getCharSet().compareTo(cMAColTable.getCharSet()) == 0
                 && cMAColReference.getCharUsed().compareTo(cMAColTable.getCharUsed()) == 0
                ) {
                  final String databaseList;
                  if (columnStatistic.containsKey(cMAColTable.getName())) {
                    databaseList = columnStatistic.get(cMAColTable.getName()) + "�" + databaseName;
                  }
                  else {
                    databaseList = databaseName;
                  }
                  columnStatistic.put(cMAColTable.getName(), databaseList);
                }
              }
            },
            ObjectArrays.emptyObjectArray);
        }
        databaseAccess.close();
      }
      GenerateResultHTMLTableCol(titleColumnByTable + tableName + titleColumnByTable2 + owner, keys, columnStatistic, columnReference);
    }
    catch  (Throwable exception) {    
    }
  }
  
  final String requestIndexForOwner = "select count(*) from sys.all_indexes where owner='";
  final String requestIndexForOwner2 = " and index_name='";
  final String requestColumnForIndex = "select index_owner, index_name, table_owner, table_name, column_name, column_position," +
      " column_length, descend from sys.all_ind_columns where index_owner='";
  final String requestColumnForIndex2 = " and index_name='";
  final String titleColumnByIndex = "Compare Column List for Index : ";
  final String titleColumnByIndex2 = " and Owner : "; 
  
  public void checkColumnForIndex(HashMap<String, String>listOfDatabaseServer, String owner, String indexName) {
    final HashMap<String, String> columnStatistic = new HashMap<String, String>();
    final HashMap<String, CMAIndexCol> columnReference = new HashMap<String, CMAIndexCol>();
    final ArrayList<String> keys = new ArrayList<String>(listOfDatabaseServer.keySet());
    Collections.sort(keys);
    final ArrayList<Long> existIndex = new ArrayList<Long>();
    try {
      for (String oneDb : keys) {
        final String databaseName = oneDb;
        final String databaseUrl = listOfDatabaseServer.get(databaseName);
        System.out.println("Column By Index : " + databaseName + " | " + databaseUrl);
        final EzJDBCDatabase databaseLink = new EzJDBCDatabase(databaseName, databaseName, databaseUrl);
        final EzJDBCConnection databaseAccess = databaseLink.openAccess();

        databaseAccess.query(
          requestIndexForOwner + owner + "'" + requestIndexForOwner2 + indexName + "'", 
          new EzDBResultSetListener() {
            
            @Override
            public void set(int i, ResultSet v) throws SQLException  {
              final int exist = SQLUtils.getInt(v, 1);
              if (exist == 1) {
                if (existIndex.size() == 0) existIndex.add(Long.getLong("1"));
              }
            }
          },
          ObjectArrays.emptyObjectArray);
          
        if (existIndex.size() > 0) {
          databaseAccess.query(
            requestColumnForIndex + owner + "'" + requestColumnForIndex2 + indexName + "'", 
            new EzDBResultSetListener() {
              
              @Override
              public void set(int i, ResultSet v) throws SQLException  {
                final String col_IndexOwner = SQLUtils.getString(v, 1);
                final String col_IndexName = SQLUtils.getString(v, 2);
                final String col_TableOwner = SQLUtils.getString(v, 3);
                final String col_TableName = SQLUtils.getString(v, 4);
                final String col_Name = SQLUtils.getString(v, 5);
                final long col_Position = SQLUtils.getLong(v, 6);
                final long col_Length = SQLUtils.getLong(v, 7);
                final String col_Descend = SQLUtils.getString(v, 8);
                final CMAIndexCol cMAColIndex = new CMAIndexCol() {
                  
                  public String getIndexOwner() {
                    return col_IndexOwner;
                  }
                  public String getIndexName() {
                    return col_IndexName;
                  }                  
                  public String getTableOwner() {
                    return col_TableOwner;
                  }
                  public String getTableName() {
                    return col_TableName;
                  }                
                  public String getName() {
                    return (col_Name == null) ? "" : col_Name;
                  }
                  public long getPosition() {
                    return col_Position;
                  }                  
                  public long getLength() {
                    return col_Length;
                  }
                  public boolean isDescend() {
                    return ("DESC".compareTo(col_Descend) == 0) ? true : false;
                  }
                };
                
                if (! columnReference.containsKey(Long.toString(cMAColIndex.getPosition()))) {
                  columnReference.put(Long.toString(cMAColIndex.getPosition()), cMAColIndex);
                }
                
                // If attributs of column are not the same, consider that the column is in error and don't memorize this server name
                final CMAIndexCol cMAColReference = columnReference.get(Long.toString(cMAColIndex.getPosition()));
                if (cMAColReference.getTableOwner().compareTo(cMAColIndex.getTableOwner()) == 0
                 && cMAColReference.getTableName().compareTo(cMAColIndex.getTableName()) == 0
                 && cMAColReference.getName().compareTo(cMAColIndex.getName()) == 0
                 && cMAColReference.getLength() == cMAColReference.getLength()
                 && cMAColReference.isDescend() == cMAColIndex.isDescend()
                ) {
                  final String databaseList;
                  if (columnStatistic.containsKey(Long.toString(cMAColIndex.getPosition()))) {
                    databaseList = columnStatistic.get(Long.toString(cMAColIndex.getPosition())) + "�" + databaseName;
                  }
                  else {
                    databaseList = databaseName;
                  }
                  columnStatistic.put(Long.toString(cMAColIndex.getPosition()), databaseList);
                }
              }
            },
            ObjectArrays.emptyObjectArray);
        }
        databaseAccess.close();
      }
      GenerateResultHTMLTableIndexCol(titleColumnByIndex + indexName + titleColumnByIndex2 + owner, keys, columnStatistic, columnReference);
    }
    catch  (Throwable exception) {    
    }
  }
  
  // =============================================================*
  // Out Html file : Generate Header, Array, Footer               *
  // -------------------------------------------------------------*
  
  final String monTitre = "Test CMA";
  final java.util.Date now = new java.util.Date();
  final String dateString = String.format("%tY%tm%td_%tH%tM%tS", now, now, now, now, now, now);
  final String nameHtml = "C:\\temp\\Cma_" + dateString + ".html";
  
  public boolean GenerateResultHTMLHeader() {    
    try {
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), false);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("<!DOCTYPE html>\n");
      lineHtml.write("<html>\n");
      lineHtml.write("<head>\n");
      lineHtml.write("<title>" + monTitre + "</title>\n");
      lineHtml.write("<link rel='stylesheet' type='text/css' href='D:\\DAM\\workspace\\3.1\\session\\src\\com\\ezrms\\www\\ezcss.css' >\n");
      lineHtml.write("</head>\n");
      lineHtml.write("<body style='overflow:scroll;'>\n");
      lineHtml.flush();
      lineHtml.close();
      return true;
    }
    catch  (Throwable exception) {
      System.out.println("Header failed");
      return false;
    }
  }
  
  static int idTable = 0;
  public void GenerateResultHTMLManageView(BufferedWriter lineHtml, int idTable, String title) {
    try {      
      lineHtml.write("<script language='JavaScript'>\n");
      lineHtml.write("function changeView" + idTable + "(pChoice) {\n");
      lineHtml.write("var vViewDiv=document.getElementById('view" + idTable + "');\n");
      lineHtml.write("if (vViewDiv != null) {\n");
      lineHtml.write("var vExtend=document.getElementById('extend" + idTable + "');\n");
      lineHtml.write("var vReduce=document.getElementById('reduce" + idTable + "');\n");
      lineHtml.write("if (pChoice == 'E') {\n");
      lineHtml.write("vViewDiv.style.display = 'none';\n");
      lineHtml.write("vExtend.style.display = '';\n");
      lineHtml.write("vReduce.style.display = 'none';\n");
      lineHtml.write("}\n");
      lineHtml.write("if (pChoice == 'R') {\n");
      lineHtml.write("vViewDiv.style.display = '';\n");
      lineHtml.write("vExtend.style.display = 'none';\n");
      lineHtml.write("vReduce.style.display = '';\n");
      lineHtml.write("}\n");
      lineHtml.write("}\n");
      lineHtml.write("}\n");
      lineHtml.write("</script>\n");
      
      lineHtml.write("<label class='ezTitle'>");
      lineHtml.write(title);
      lineHtml.write("</label>\n");
      lineHtml.write("<img id='extend" + idTable + "' src='extend.png' title='extend' alt='extend' height='16px' width='16px' onclick='changeView" + idTable + "(\"R\");'/>\n");
      lineHtml.write("<img id='reduce" + idTable + "' src='reduce.png' title='reduce' alt='reduce' height='16px' width='16px' onclick='changeView" + idTable + "(\"E\");'/>\n");
      lineHtml.write("</div>\n");
      
      lineHtml.write("<div class='ezhiddenblockclicktitle' id='view" + idTable + "'>\n");

      lineHtml.write("<script language='JavaScript'>\n");
      lineHtml.write("function changeFilter" + idTable + "() {\n");
        lineHtml.write("var vSelect=document.getElementById('sel" + idTable + "');\n");
        lineHtml.write("var vValueSelect=vSelect.value;\n");
        lineHtml.write("var vIdCount=0;\n");
        lineHtml.write("var vIdError;\n");
        lineHtml.write("var vIdLine;\n");
        lineHtml.write("var vElError;\n");
        lineHtml.write("var vElLine;\n");
        
        lineHtml.write("while (1) {\n");
          lineHtml.write("vIdCount+=1;\n");
          lineHtml.write("vIdError='hid" + idTable + "er_' + vIdCount" + ";\n");
          lineHtml.write("vElError = document.getElementById(vIdError);\n");
          
          lineHtml.write("if (vElError == null) break;\n");
          
          lineHtml.write("vIdLine='tbl" + idTable + "tr_' + vIdCount" + ";\n");
          lineHtml.write("vElLine = document.getElementById(vIdLine);\n");
          lineHtml.write("vElLine.style.display = '';\n");         
          lineHtml.write("if (vElError.value == 'N' && vValueSelect == '2') {\n");
            lineHtml.write("vElLine.style.display = 'none';\n");  
          lineHtml.write("}\n");
        lineHtml.write("}\n");
      lineHtml.write("}\n");
      lineHtml.write("</script>\n");
  
      lineHtml.write("<label>");
      lineHtml.write("Filter : ");
      lineHtml.write("</label>\n");
      lineHtml.write("<select id='sel" + idTable + "' onchange='changeFilter" + idTable + "();'>\n");
      lineHtml.write("<option value='1'>All</option>\n");
      lineHtml.write("<option value='2' selected>Alert</option>\n");
      lineHtml.write("</select>\n");
      lineHtml.flush();
    }
    catch  (Throwable exception) {
      System.out.println("View Manager failed");
    } 
  }
  
  public void GenerateResultHTMLInitView(BufferedWriter lineHtml, int idTable) {
    try {
      lineHtml.write("<script language='JavaScript'>\n");
      lineHtml.write("changeView" + idTable + "(\"E\");\n");
      lineHtml.write("changeFilter" + idTable + "();\n");
      lineHtml.write("</script>\n");
      lineHtml.flush();
    }
    catch  (Throwable exception) {
      System.out.println("View Init failed");
    } 
  }
  
  public void GenerateResultHTMLTable(String title, ArrayList<String>keys, HashMap<String, String>statistic) {
    try {
      idTable += 1;
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);    
      lineHtml.write("<div style='color:silver; border-bottom-style:solid; border-bottom-width:3px; border-bottom-color:grey;'>\n");
      GenerateResultHTMLManageView(lineHtml, idTable, title);

      lineHtml.write("<table>\n");      
      lineHtml.write("<tr>\n");
      lineHtml.write("<th class='eztth'> </th>\n");
      for (String oneDb : keys) {
        lineHtml.write("<th class='eztth'>" + oneDb + "</th>\n");
      }
      lineHtml.write("</tr>\n");
      
      int indexTd = 0;
      final ArrayList<String> statSet = new ArrayList<String>(statistic.keySet());
      Collections.sort(statSet);
      for (String oneStat : statSet) {
        indexTd += 1;
        lineHtml.write("<tr id='tbl" + idTable + "tr_" + Integer.toString(indexTd) + "'>\n");
        boolean error = false;
        System.out.println("Exist in => " + oneStat + " - " + statistic.get(oneStat));
        lineHtml.write("<td class='ezttd'>" + oneStat + "</td>\n");
        final ArrayList<String> listdb = new ArrayList<String>(Arrays.asList(statistic.get(oneStat).split("�")));
        for (int i=0, n=keys.size() ; i<n ; i++) {
          lineHtml.write("<td class='ezttd'>");
          if (listdb.contains(keys.get(i))) {
            lineHtml.write("<img src='green.png' title='Ok' alt='Ok' height='16px' width='16px' />");
          }
          else { 
            lineHtml.write("<img src='red.png' title='Ko' alt='Ko' height='16px' width='16px' />");
            error = true;
          }
          lineHtml.write("</td>\n");
        }
        lineHtml.write("<input type='hidden' id='hid" + idTable + "er_" + Integer.toString(indexTd) + "' value='" + (error ? "Y" : "N") + "'/>\n");        
        lineHtml.write("</tr>\n");
      }      

      lineHtml.write("</table>\n");
      lineHtml.write("</div>\n");      
      GenerateResultHTMLInitView(lineHtml, idTable);
      lineHtml.write("</div>\n");
      lineHtml.flush();
      lineHtml.close();
    }
    catch  (Throwable exception) {
      System.out.println("Table failed");
    }    
  }

  public void GenerateResultHTMLTableProc(String title, ArrayList<String>keys, HashMap<String, String>statistic, HashMap<String, CMAProcedure>reference) {
    try {
      idTable += 1;
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("<div style='color:silver; border-bottom-style:solid; border-bottom-width:3px; border-bottom-color:grey'>\n");     
      GenerateResultHTMLManageView(lineHtml, idTable, title);
            
      lineHtml.write("<table>\n");
      lineHtml.write("<tr>\n");

      final String[] headCol = {"Object Name", "Proc. Name", "Sub Id", "Num. Overload", "Aggregate", "PipeLined", "Parallel", "Interface", "Deterministic", "Execute As", "Object Name"};
      for (String oneCol : headCol) {
        lineHtml.write("<th class='eztth'>" + oneCol + "</th>\n");
      }
      for (String oneDb : keys) {
        lineHtml.write("<th class='eztth'>" + oneDb + "</th>\n");
      }
      lineHtml.write("</tr>\n");
      
      int indexTd = 0;
      final ArrayList<String> statSet = new ArrayList<String>(statistic.keySet());
      Collections.sort(statSet);
      for (String oneStat : statSet) {
        indexTd += 1;
        lineHtml.write("<tr id='tbl" + idTable + "tr_" + Integer.toString(indexTd) + "'>\n");
        boolean error = false;
        System.out.println("Object Name => " + oneStat + " - " + statistic.get(oneStat));
        final CMAProcedure cMAProcedure = reference.get(oneStat);       
        lineHtml.write("<td class='ezttd'>" + cMAProcedure.getObjectName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAProcedure.getName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAProcedure.getSubId() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAProcedure.getNumOverload() + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAProcedure.isAggregate())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAProcedure.isPipeLined())
            ? "<img src='green.png' title='yes' alt='no' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAProcedure.isParallel())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAProcedure.isInterface())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAProcedure.isDeterministic())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAProcedure.getExecuteAs() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAProcedure.getObjectName() + "</td>\n");
        final ArrayList<String> listdb = new ArrayList<String>(Arrays.asList(statistic.get(oneStat).split("�")));
        for (int i=0, n=keys.size() ; i<n ; i++) {
          lineHtml.write("<td class='ezttd'>");
          if (listdb.contains(keys.get(i))) {
            lineHtml.write("<img src='green.png' title='Ok' alt='Ok' height='16px' width='16px' />");
          }
          else { 
            lineHtml.write("<img src='red.png' title='Ko' alt='Ko' height='16px' width='16px' />");
            error = true;
          }
          lineHtml.write("</td>\n");
        }
        lineHtml.write("<input type='hidden' id='hid" + idTable + "er_" + Integer.toString(indexTd) + "' value='" + (error ? "Y" : "N") + "'/>\n");        
        lineHtml.write("</tr>\n");
      }      

      lineHtml.write("</table>\n");
      lineHtml.write("</div>\n");      
      GenerateResultHTMLInitView(lineHtml, idTable);
      lineHtml.write("</div>\n");
      lineHtml.flush();
      lineHtml.close();
    }
    catch  (Throwable exception) {
      System.out.println("Procedure List failed");
    }    
  }

  public void GenerateResultHTMLTableIndex(String title, ArrayList<String>keys, HashMap<String, String>statistic, HashMap<String, CMAIndex>reference) {
    try {
      idTable += 1;
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("<div style='color:silver; border-bottom-style:solid; border-bottom-width:3px; border-bottom-color:grey'>\n");     
      GenerateResultHTMLManageView(lineHtml, idTable, title);
            
      lineHtml.write("<table>\n");
      lineHtml.write("<tr>\n");
      
      final String[] headCol = {"Name", "Type", "Table Owner", "Table Name", "Table Type", "Unique", "Compressed", "Partitioned", "Temporary", "System Generated", "Join Index", "In Recycle Bin", "Name"};
      for (String oneCol : headCol) {
        lineHtml.write("<th class='eztth'>" + oneCol + "</th>\n");
      }
      for (String oneDb : keys) {
        lineHtml.write("<th class='eztth'>" + oneDb + "</th>\n");
      }
      lineHtml.write("</tr>\n");
      
      int indexTd = 0;
      final ArrayList<String> statSet = new ArrayList<String>(statistic.keySet());
      Collections.sort(statSet);
      for (String oneStat : statSet) {
        indexTd += 1;
        lineHtml.write("<tr id='tbl" + idTable + "tr_" + Integer.toString(indexTd) + "'>\n");
        boolean error = false;
        System.out.println("Index Name => " + oneStat + " - " + statistic.get(oneStat));
        final CMAIndex cMAIndex = reference.get(oneStat);       
        lineHtml.write("<td class='ezttd'>" + cMAIndex.getName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAIndex.getType() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAIndex.getTableOwner() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAIndex.getTableName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAIndex.getTableType() + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isUnique())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isCompressed())
            ? "<img src='green.png' title='yes' alt='no' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isPartitioned())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isTemporary())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isSystemGenerated())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isJoinIndex())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cMAIndex.isInRecycleBin())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cMAIndex.getName() + "</td>\n");
        final ArrayList<String> listdb = new ArrayList<String>(Arrays.asList(statistic.get(oneStat).split("�")));
        for (int i=0, n=keys.size() ; i<n ; i++) {
          lineHtml.write("<td class='ezttd'>");
          if (listdb.contains(keys.get(i))) {
            lineHtml.write("<img src='green.png' title='Ok' alt='Ok' height='16px' width='16px' />");
          }
          else { 
            lineHtml.write("<img src='red.png' title='Ko' alt='Ko' height='16px' width='16px' />");
            error = true;
          }
          lineHtml.write("</td>\n");
        }
        lineHtml.write("<input type='hidden' id='hid" + idTable + "er_" + Integer.toString(indexTd) + "' value='" + (error ? "Y" : "N") + "'/>\n");        
        lineHtml.write("</tr>\n");
      }      

      lineHtml.write("</table>\n");
      lineHtml.write("</div>\n");      
      GenerateResultHTMLInitView(lineHtml, idTable);
      lineHtml.write("</div>\n");
      lineHtml.flush();
      lineHtml.close();
    }
    catch  (Throwable exception) {
      System.out.println("Index List failed");
    }    
  }

  public void GenerateResultHTMLTableCol(String title, ArrayList<String>keys, HashMap<String, String>statistic, HashMap<String, CMATableCol>reference) {
    try {
      idTable += 1;
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("<div style='color:silver; border-bottom-style:solid; border-bottom-width:3px; border-bottom-color:grey;'>\n");     
      GenerateResultHTMLManageView(lineHtml, idTable, title);
            
      lineHtml.write("<table>\n");
      lineHtml.write("<tr>\n");
      final String[] headCol = {"Name", "Order", "Type", "Type Mod", "Length", "Precision", "Decimal", "Nullable", "CharSet", "CharLength", "CharUsed", "Name"};
      for (String oneCol : headCol) {
        lineHtml.write("<th class='eztth'>" + oneCol + "</th>\n");
      }
      for (String oneDb : keys) {
        lineHtml.write("<th class='eztth'>" + oneDb + "</th>\n");
      }
      lineHtml.write("</tr>\n");
      
      int indexTd = 0;
      final ArrayList<String> statSet = new ArrayList<String>(statistic.keySet());
      Collections.sort(statSet);
      for (String oneStat : statSet) {
        indexTd += 1;
        lineHtml.write("<tr id='tbl" + idTable + "tr_" + Integer.toString(indexTd) + "'>\n");
        boolean error = false;
        System.out.println("Col. Name => " + oneStat + " - " + statistic.get(oneStat));
        CMATableCol cmaColTable = reference.get(oneStat);       
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getNumCol() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getType() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getTypeMod() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getLength() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getPrecision() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getDecimal() + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cmaColTable.isNullable())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getCharSet() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getLengthInByte() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getCharUsed() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColTable.getName() + "</td>\n");
        final ArrayList<String> listdb = new ArrayList<String>(Arrays.asList(statistic.get(oneStat).split("�")));
        for (int i=0, n=keys.size() ; i<n ; i++) {
          lineHtml.write("<td class='ezttd'>");
          if (listdb.contains(keys.get(i))) {
            lineHtml.write("<img src='green.png' title='Ok' alt='Ok' height='16px' width='16px' />");
          }
          else { 
            lineHtml.write("<img src='red.png' title='Ko' alt='Ko' height='16px' width='16px' />");
            error = true;
          }
          lineHtml.write("</td>\n");
        }
        lineHtml.write("<input type='hidden' id='hid" + idTable + "er_" + Integer.toString(indexTd) + "' value='" + (error ? "Y" : "N") + "'/>\n");        
        lineHtml.write("</tr>\n");
      }      

      lineHtml.write("</table>\n");
      lineHtml.write("</div>\n");      
      GenerateResultHTMLInitView(lineHtml, idTable);
      lineHtml.write("</div>\n");
      lineHtml.flush();
      lineHtml.close();
    }
    catch  (Throwable exception) {
      System.out.println("Column By Table failed");
    }    
  }

  public void GenerateResultHTMLTableIndexCol(String title, ArrayList<String>keys, HashMap<String, String>statistic, HashMap<String, CMAIndexCol>reference) {
    try {
      idTable += 1;
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("<div style='color:silver; border-bottom-style:solid; border-bottom-width:3px; border-bottom-color:grey;'>\n");     
      GenerateResultHTMLManageView(lineHtml, idTable, title);
            
      lineHtml.write("<table>\n");
      lineHtml.write("<tr>\n");      
      final String[] headCol = {"Table Owner", "Table Name", "Name", "Position", "Length", "Descend", "Table Name", "Name"};
      for (String oneCol : headCol) {
        lineHtml.write("<th class='eztth'>" + oneCol + "</th>\n");
      }
      for (String oneDb : keys) {
        lineHtml.write("<th class='eztth'>" + oneDb + "</th>\n");
      }
      lineHtml.write("</tr>\n");
      
      int indexTd = 0;
      final ArrayList<String> statSet = new ArrayList<String>(statistic.keySet());
      Collections.sort(statSet);
      for (String oneStat : statSet) {
        indexTd += 1;
        lineHtml.write("<tr id='tbl" + idTable + "tr_" + Integer.toString(indexTd) + "'>\n");
        boolean error = false;
        System.out.println("Col. Name => " + oneStat + " - " + statistic.get(oneStat));
        CMAIndexCol cmaColIndex = reference.get(oneStat); 
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getTableOwner() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getTableName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getPosition() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getLength() + "</td>\n");
        lineHtml.write("<td class='ezttd'>"
          + ((cmaColIndex.isDescend())
            ? "<img src='green.png' title='yes' alt='yes' height='16px' width='16px' />"
            : "<img src='orange.png' title='no' alt='no' height='16px' width='16px' />")
          + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getTableName() + "</td>\n");
        lineHtml.write("<td class='ezttd'>" + cmaColIndex.getName() + "</td>\n");
        final ArrayList<String> listdb = new ArrayList<String>(Arrays.asList(statistic.get(oneStat).split("�")));
        for (int i=0, n=keys.size() ; i<n ; i++) {
          lineHtml.write("<td class='ezttd'>");
          if (listdb.contains(keys.get(i))) {
            lineHtml.write("<img src='green.png' title='Ok' alt='Ok' height='16px' width='16px' />");
          }
          else { 
            lineHtml.write("<img src='red.png' title='Ko' alt='Ko' height='16px' width='16px' />");
            error = true;
          }
          lineHtml.write("</td>\n");
        }
        lineHtml.write("<input type='hidden' id='hid" + idTable + "er_" + Integer.toString(indexTd) + "' value='" + (error ? "Y" : "N") + "'/>\n");        
        lineHtml.write("</tr>\n");
      }      

      lineHtml.write("</table>\n");
      lineHtml.write("</div>\n");      
      GenerateResultHTMLInitView(lineHtml, idTable);
      lineHtml.write("</div>\n");
      lineHtml.flush();
      lineHtml.close();
    }
    catch  (Throwable exception) {
      System.out.println("Column By Index failed");
    }    
  }

  public void GenerateResultHTMLTableCount(String title, ArrayList<String>keys, HashMap<String, String>statistic) {
    try {
      idTable += 1;
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("<div style='color:silver; border-bottom-style:solid; border-bottom-width:3px; border-bottom-color:grey;'>\n");     
      GenerateResultHTMLManageView(lineHtml, idTable, title);
      
      lineHtml.write("<table>\n");
      lineHtml.write("<tr>\n");
      lineHtml.write("<th class='eztth'> </th>\n");
      for (String oneDb : keys) {
        lineHtml.write("<th class='eztth'>" + oneDb + "</th>\n");
      }
      lineHtml.write("</tr>\n");
      
      int indexTd = 0;
      final ArrayList<String> statSet = new ArrayList<String>(statistic.keySet());
      Collections.sort(statSet);
      for (String oneStat : statSet) {
        indexTd += 1;
        lineHtml.write("<tr id='tbl" + idTable + "tr_" + Integer.toString(indexTd) + "'>\n");
        boolean error = false;
        System.out.println("Object Type => " + oneStat + " - " + statistic.get(oneStat));
        lineHtml.write("<td class='ezttd'>" + oneStat + "</td>\n");
        final ArrayList<String> countdb = new ArrayList<String>(Arrays.asList(statistic.get(oneStat).split("�")));
        for (int i=0, n=keys.size() ; i<n ; i++) {
          lineHtml.write("<td class='eztth' ");
          if (countdb.get(0).compareTo(countdb.get(i)) != 0) {
            error = true;
            lineHtml.write(" style='background-color:red;'>");
          }
          else {
            lineHtml.write(" style='background-color:green;'>");
          }
          lineHtml.write(countdb.get(i));
          lineHtml.write("</td>\n");
        }
        lineHtml.write("<input type='hidden' id='hid" + idTable + "er_" + Integer.toString(indexTd) + "' value='" + (error ? "Y" : "N") + "'/>\n");        
        lineHtml.write("</tr>\n");
      }      

      lineHtml.write("</table>\n");
      lineHtml.write("</div>\n");      
      GenerateResultHTMLInitView(lineHtml, idTable);
      lineHtml.write("</div>\n");
      lineHtml.flush();
      lineHtml.close();
    }
    catch  (Throwable exception) {
      System.out.println("Table failed");
    }    
  }
  
  public void GenerateResultHTMLFooter() {
    try {
      final FileWriter fileWriter = StreamUtils.newFileWriter(StreamUtils.getFile(nameHtml), true);
      final BufferedWriter lineHtml = new BufferedWriter(fileWriter);
      lineHtml.write("</body>\n");
      lineHtml.write("</html>\n");
      lineHtml.flush();
      lineHtml.close();
      try {StreamUtils.close(fileWriter);} catch (Throwable exception) {}
    }
    catch  (Throwable exception) {
      System.out.println("Footer failed");
    }
  }
}

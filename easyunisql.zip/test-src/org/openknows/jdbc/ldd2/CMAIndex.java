package org.openknows.jdbc.ldd2;

// ALL_INDEXES
public interface CMAIndex {

  public String getOwner();
  public String getName();
  public String getType();
  public String getTableOwner();
  public String getTableName();
  public String getTableType();
  public long getNumberOfRow();
  public boolean isUnique();
  public boolean isCompressed();
  public boolean isPartitioned();
  public boolean isTemporary();
  public boolean isSystemGenerated();
  public boolean isJoinIndex();
  public boolean isInRecycleBin();
}

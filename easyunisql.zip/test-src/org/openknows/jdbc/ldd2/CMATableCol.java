package org.openknows.jdbc.ldd2;

// ALL_TAB_COLUMNS
public interface CMATableCol {
  
  public String getTableOwner();
  public String getTableName();
  public int getNumCol();
  public String getName();
  public String getType();
  public String getTypeMod();
  public long getLength();
  public long getPrecision();
  public long getDecimal();
  public boolean isNullable();
  public String getCharSet();
  public long getLengthInByte();
  public String getCharUsed();
}

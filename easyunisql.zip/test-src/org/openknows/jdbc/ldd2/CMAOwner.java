package org.openknows.jdbc.ldd2;

// ALL_OBJECTS (Distinct Owner)
public interface CMAOwner {

  public String getOwner();
}

package org.openknows.jdbc.ldd2;

// ALL_PROCEDURES contain PROCEDURE, FUNCTION, TRIGGER
public interface CMAProcedure {

  public String getOwner();
  public String getObjectName();
  public long getObjectId();
  public String getObjectType();
  public String getName();
  public long getSubId();   // 0 for Package itself
  public String getNumOverload();
  public boolean isAggregate();
  public boolean isPipeLined();
  public boolean isParallel();
  public boolean isInterface();
  public boolean isDeterministic();  
  public String getExecuteAs();
}

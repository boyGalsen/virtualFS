package org.openknows.jdbc.ldd2;

// ALL_TRIGGER_COLS
public interface CMATriggerCol {
  public String getTriggerOwner();
  public String getTriggerName();
  public String getTableOwner();
  public String getTableName();
  public String getDirection();
  public String getName();  // if getDataLevel = 0 ; Name = null for returning argument ; if getDataLevel > 0 see documentation
  public long getPosition(); // if getDataLevel = 0 ; Position = 0 for returning argument ; if getDataLevel > 0 see documentation
  public long getOrder();
  public long getDataLevel();  
  public String getType();
  public long getLehgth();
  public long getPrecision();
  public long getDecimal();
  public long getRadix();
  public boolean hasDefault();
  public String getCharSet();
  public long getLengthInByte();
  public String getCharUsed();
  
}

package org.openknows.jdbc.ldd2;

// ALL_IND_COLUMNS
public interface CMAIndexCol {
  
  public String getIndexOwner();
  public String getIndexName();
  public String getTableOwner();
  public String getTableName();
  public String getName();
  public long getPosition();
  public long getLength();
  public boolean isDescend();
}

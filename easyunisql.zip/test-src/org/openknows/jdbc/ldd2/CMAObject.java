package org.openknows.jdbc.ldd2;

import com.easyrms.date.*;

// ALL_OBJECTS
public interface CMAObject {

  String getOwner();
  long getId();
  String getName();
  String getType();
  boolean isTemporary();
  DateAccessor getCreatedTime();
  DateAccessor getLastDdlTime();
}

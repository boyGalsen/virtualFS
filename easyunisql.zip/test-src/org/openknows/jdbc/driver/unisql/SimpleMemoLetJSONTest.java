package org.openknows.jdbc.driver.unisql;

import com.easyrms.util.io.*;

import org.openknows.jdbc.driver.unisql.json.*;
import org.openknows.jdbc.driver.unisql.memo.*;

import java.io.*;

public class SimpleMemoLetJSONTest {

  public static void main(String... args) throws Throwable {
    final SimpleMemoLet memoLet = new SimpleMemoLet();
    memoLet.init(null);
    final AtTable table = memoLet.onGet(null);
    final StringWriter sout = new StringWriter();
    final JSONWriter jout = new JSONWriter(sout);
    JSONMemoryTable.writeTo(jout, table);
    System.out.println(sout.toString());
    new JSONMemoryTable(sout.toString());
  }
}

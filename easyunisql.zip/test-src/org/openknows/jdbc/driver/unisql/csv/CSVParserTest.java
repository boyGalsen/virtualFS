package org.openknows.jdbc.driver.unisql.csv;

import java.io.*;

public class CSVParserTest {
  
  public static final void main(String[] args) throws IOException {
    final CSVParser parser = new CSVParser();
    final FileReader input = new FileReader("C:\\temp\\iris.txt");
    try {
      parser.init(input);
      while (parser.hasMoreRow()) {
        System.out.print(parser.getNextRow()+":");
        while (parser.hasMoreElement()) {
          System.out.print('\''+parser.getNextElement()+'\''+"\t");
        }
        System.out.println("");
      }
    }
    finally {
      input.close();
    }
  }
}

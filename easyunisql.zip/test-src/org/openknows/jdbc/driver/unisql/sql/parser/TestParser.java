package org.openknows.jdbc.driver.unisql.sql.parser;

import org.openknows.jdbc.driver.unisql.jdbc.*;

import java.io.StringBufferInputStream;
import java.util.Stack;

public class TestParser {

 public static void main(String[] args) throws Throwable {
 	 /*check("select backup.t, xls.t, machin from " +
      "@CSV:T:/test/backup.txt as backup, " +
      "@XLS:T:/test/test/xls.xls as xls, " +
      "@JDBC:postgres(select * from toto where a in ('t')) as jdbc where backup.t1 EQUALS 3 ");
  check("select p.HTML, p.POSTDATE, p.POSTCODE, p.PASSANT, p.SEG, p.RAT, p.COMPANY, p.GROUP, p.ALLOT, p.SOURCE, p.MODATE, p.UPDATE, p.UNKNOWN, count(*) from @csv:c:/temp/passant.txt p group by p.HTML, p.POSTDATE, p.POSTCODE, p.PASSANT, p.SEG, p.RAT, p.COMPANY, p.GROUP, p.ALLOT, p.SOURCE, p.MODATE, p.UPDATE, p.UNKNOWN");
  */
   final JDBCConnectionDriver driver = JDBCConnectionDriver.getReference();
   //check(driver, "select a1+1 from toto");
   //check(driver, "select count(*) from toto");
   //check(driver, "select min(a) from toto");
   //check("select mafunctionvide() from toto");
   check(driver, "select sum(a.b+a.c) from @:c:/temp/x1.xls a");
   
   Stack a = new Stack();
   //check("select * from (select * from @:c:/temp/x1.xls b) a");
  //check("drop table @mem:tt");
  //check("create table @CSV:T:/test/b.csv as (select * from  @CSV:T:/test/backup.txt)");
   //check("select * from toto");
   //check("set A on @CSV:T:/test/backup.txt");
   //check("register jdbc:postgresql:postgres with driver = 'org.postgresql.Driver' and user = 'postgres' and password = 'wxcvbn'");
 }
 
 public static void check(JDBCConnectionDriver driver, String request) throws Throwable {
   final Object select = parser.compute(driver, new StringBufferInputStream(request));
   if (select != null) System.out.println("OK"); else System.out.println("ERROR");  
 }
 
}

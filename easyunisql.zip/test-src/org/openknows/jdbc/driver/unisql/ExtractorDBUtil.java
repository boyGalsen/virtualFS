/**
 * Created on May 13, 2003
 *
 * To change this generated comment edit the template variable "filecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of file comments go to
 * Window>Preferences>Java>Code Generation.
 */
package org.openknows.jdbc.driver.unisql;

import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;
import java.sql.*;


public class ExtractorDBUtil {

	public static void main (String[] args) {
	  try {
	    connect();
	  }
	  catch(SQLException exception) {
      EasyRMS.trace.log(exception);
	  }
	  
	}
	
	public static void connect() throws SQLException{
	  try {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	  }
	  catch(Exception e) {
	  }
		Connection conn = SimpleConnections.getConnection(null, null, "jdbc:oracle:thin:yield/yieldboss@(DESCRIPTION= (LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=10.21.226.45)(PORT=1525)) (CONNECT_DATA=(SERVICE_NAME=OXI)))", true, false);
		final ValidatedDirectory root = StreamUtils.getDirectory("d:/openknows/database/oxi");
	  Statement stmt = conn.createStatement();
	 	
		extractTables(root, stmt, conn);
		extractViews(root, stmt, conn);
		extractPackage(root, stmt, conn);
		extractTriggers(root, stmt, conn);
		extractFunctions(root, stmt, conn);
		extractSynonym(root, stmt, conn);
    extractIndexes(root, stmt, conn);
    
		stmt.close();
		conn.close();
		System.out.println("Done!");
    
	}

	public static void extractSynonym(ValidatedDirectory root, Statement stmt, Connection conn) throws SQLException  {
	  	final ResultSet rset = stmt.executeQuery("select owner, synonym_name,table_owner, table_name from dba_synonyms where table_owner not in ('SYS','SYSTEM', 'PUBLIC') ");
			while(rset.next()) {
				final String owner = toString(rset, 1, "");
				final String name = toString(rset, 2, "");
				final String table_owner = toString(rset, 3, "");
				final String table_name = toString(rset, 4, "");
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "synonyms"));
				final ValidatedFile file = StreamUtils.getChildFile(directory,name.toLowerCase()+".sql");
		    System.out.println("Synonym "+file.getFullName());
				try (final FileWriter writer = StreamUtils.newFileWriter(file)) {
					writer.write("create ");
					writer.write(owner.toLowerCase());
					writer.write(" synonym ");
					writer.write(name.toLowerCase());
					writer.write(" for ");
					writer.write(table_owner.toLowerCase());
					writer.write(".");
					writer.write(table_name.toLowerCase());
					writer.write(";\r\n");
					writer.flush();
					writer.close();
					EasyRMS.trace.log(file.getFullName()+ " created");
				}
				catch(Exception e) {
				  EasyRMS.trace.log("error with "+file.getFullName(), e);
				}
			}
			rset.close();
		 }

	public static void extractViews(ValidatedDirectory root, Statement stmt, Connection conn) throws SQLException  {
		final ResultSet rset = stmt.executeQuery("select owner, view_name, text from dba_views where owner not in ('SYS', 'SYSTEM')");
		while(rset.next()) {
			final String owner = toString(rset, 1, "");
			final String name = toString(rset, 2, "");
			final ValidatedDirectory directory = StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "views");
			StreamUtils.controlExistDirectory(directory);
			final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase()+".sql");
      System.out.println("View "+file.getFullName());
			try (final FileWriter writer = StreamUtils.newFileWriter(file)){
				writer.write("create or replace view ");
				writer.write(name.toLowerCase());
				writer.write(" as \r\n");
				writer.write(toString(rset, 3, "").replaceAll("\r?\n","\r\n"));
				writer.write(";\r\n");
				writer.flush();
				writer.close();
				EasyRMS.trace.log(file.getFullName()+ " created");
			}
			catch(Exception e) {
			  EasyRMS.trace.log("error with "+file.getFullName(), e);
			}
		}
		rset.close();
	 }


	public static void extractPackage(ValidatedDirectory root, Statement stmt, Connection conn) throws SQLException  {
		final PreparedStatement preparedStatement = conn.prepareStatement("SELECT LINE,TEXT FROM sys.all_source where owner=? and name=? and type=? order by line");
		final ResultSet rset = stmt.executeQuery("select OWNER, OBJECT_NAME from dba_objects where owner not in ('SYS','SYSTEM','PUBLIC') and object_type like('PACKAGE')");
		while(rset.next()) {
			final String owner = rset.getString(1);
			final String name = rset.getString(2);
			final String type = "PACKAGE";
			preparedStatement.setString(1, owner );
			preparedStatement.setString(2, name );
			preparedStatement.setString(3, type );
			final ResultSet rset2 = preparedStatement.executeQuery();
			try {
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "packages"));
				final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase() + ".sql");
        System.out.println("Package "+file.getFullName());
        try (final FileWriter writer = StreamUtils.newFileWriter(file)) {
	        writer.write("create or replace ");
					while(rset2.next()) {
						writer.write(toString(rset2, 2, "").replaceAll("\r?\n","\r\n"));
						writer.flush();
					}
				}
				catch(Exception e) {
				  EasyRMS.trace.log("error with " + file.getFullName(), e);
				}
				rset2.close();
				EasyRMS.trace.log(file.getFullName() + " created");
			}
			catch(Exception e) {
        EasyRMS.trace.log(e);
			}
		}
		rset.close();
	
		final ResultSet rset3 = stmt.executeQuery("select OWNER, OBJECT_NAME from dba_objects where owner not in ('SYS','SYSTEM','PUBLIC') and object_type like('PACKAGE BODY')");
		while(rset3.next()) {
			final String owner = rset3.getString(1);
			final String name = rset3.getString(2);
			final String type = "PACKAGE BODY";
			preparedStatement.setString( 1 , owner );
			preparedStatement.setString( 2 , name );
			preparedStatement.setString( 3 , type );
			final ResultSet rset4 = preparedStatement.executeQuery();
			try {
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "packagebodys"));
				final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase() + ".sql");
        System.out.println("Package Body "+file.getFullName());
				try (final FileWriter writer = StreamUtils.newFileWriter(file)){
				  writer.write("create or replace ");
	        while (rset4.next()) {
						writer.write(toString(rset4, 2, "").replaceAll("\r?\n","\r\n"));
						writer.flush();
					}
				}
				catch(Exception e) {
				  EasyRMS.trace.log("error with " + file.getFullName(), e);
				}
				rset4.close();
				EasyRMS.trace.log(file.getFullName() + " created");
			}
			catch(Exception e) {
        EasyRMS.trace.log(e);
			}
		}
		rset3.close();
		preparedStatement.close();
	}

	public static void extractTriggers(ValidatedDirectory root, Statement stmt, Connection conn) throws SQLException {
		final ResultSet rset = stmt.executeQuery("select dba_objects.OWNER, dba_objects.OBJECT_NAME, sys.TRIGGER$.definition, sys.TRIGGER$.whenclause, sys.TRIGGER$.action#  from dba_objects, sys.TRIGGER$ where dba_objects.OBJECT_ID = sys.TRIGGER$.obj#  and dba_objects.owner not in ('SYS','PUBLIC','SYSTEM') and dba_objects.object_type='TRIGGER'");
		while(rset.next()) {
			final String owner = toString(rset, 1);
			final String name = toString(rset, 2);
			final String definition = toString(rset, 3, "");
			final String when = toString(rset, 4, "");
			final String action = toString(rset, 5, "");
			try {
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "triggers"));
				final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase() + ".sql");
        System.out.println("Triggers "+file.getFullName());
				try (final FileWriter writer = StreamUtils.newFileWriter(file)) {
  				writer.write("create or replace trigger ");
  				writer.write(name.toLowerCase());
  				writer.write("\r\n");
  				writer.write(definition);
  				writer.write("\r\n");
  				writer.write(when);
  				writer.write("\r\n");
  				writer.write(action);
  				writer.write(";\r\n");
				}				
				EasyRMS.trace.log(file.getFullName() + " created");
			}
			catch(Exception e) {
        EasyRMS.trace.log(e);
			}
		}
		rset.close();
	}

	public static void extractIndexes(ValidatedDirectory root, Statement stmt, Connection conn) throws SQLException {
		final ResultSet rset = stmt.executeQuery("select owner, index_name, index_type, table_name, uniqueness, compression from DBA_INDEXES where owner not in ('SYS','SYSTEM','PUBLIC') and (index_name  not in (select DBA_CONSTRAINTS.CONSTRAINT_NAME from DBA_CONSTRAINTS where DBA_CONSTRAINTS.owner= DBA_INDEXES.owner))");
		final PreparedStatement preparedStatement = conn.prepareStatement("select COLUMN_NAME,COLUMN_POSITION from DBA_IND_COLUMNS where index_owner=? and index_name=? order by column_position");
		while(rset.next()) {
			final String owner = rset.getString(1);
			final String name = rset.getString(2);
			final String type = toString(rset, 3);
			final String table_name = toString(rset, 4);
			final String unique = toString(rset, 5);
			final String compression = toString(rset, 6);
			preparedStatement.setString(1, owner);
			preparedStatement.setString(2, name);
			final ResultSet rset2 = preparedStatement.executeQuery();
			try {
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "indexes"));
				final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase() + ".sql");
		    System.out.println("Index "+file.getFullName());
				try (final FileWriter writer = StreamUtils.newFileWriter(file)){
					writer.write("create index ");
					writer.write(name.toLowerCase());
					writer.write("\r\n  on ");
					writer.write(table_name.toLowerCase());
					writer.write(" ");
					int nbCols = 0;
					while (rset2.next()) {
						if (nbCols > 0) writer.write(",");
						else writer.write("(");
						nbCols++;
						writer.write(toString(rset2, 1, "").toLowerCase());
						writer.flush();
					}
					if (nbCols > 0) writer.write(")");
					if ("ENABLED".equals(compression)) {
						writer.write("\r\n  compress ");
					}
					writer.write(";\r\n");
	      }
				catch (final Exception e) {
				  EasyRMS.trace.log("error with " + file.getFullName(), e);
				}
				rset2.close();
				EasyRMS.trace.log(file.getFullName()+ " created");
			}
			catch (final Exception e) {
        EasyRMS.trace.log(e);
			}
		}
		rset.close();	
		preparedStatement.close();

		}
	
	public static void extractFunctions(final ValidatedDirectory root, final Statement stmt, final Connection conn) throws SQLException {
		final PreparedStatement preparedStatement = conn.prepareStatement("SELECT LINE,TEXT FROM sys.all_source where owner=? and name=? and type=? order by line");
		final ResultSet rset = stmt.executeQuery("select OWNER, OBJECT_NAME from dba_objects where owner not in ('SYS','SYSTEM','PUBLIC') and object_type like('FUNCTION')");
		while (rset.next()) {
			final String owner = rset.getString(1);
			final String name = rset.getString(2);
			final String type = "FUNCTION";
			preparedStatement.setString(1, owner);
			preparedStatement.setString(2, name);
			preparedStatement.setString(3, type);
			final ResultSet rset2 = preparedStatement.executeQuery();
			try {
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "functions"));
				final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase() + ".sql");
        System.out.println("Function "+file.getFullName());
				try (final FileWriter writer = StreamUtils.newFileWriter(file)) {
				  writer.write("create or replace ");
	        while (rset2.next()) {
						writer.write(toString(rset2, 2, "").replaceAll("\r?\n","\r\n"));
						writer.flush();
					}
				}
				catch (final Throwable e) {
				  EasyRMS.trace.log("error with " + file.getFullName(), e);
				}
				finally {
				  rset2.close();
				}
				EasyRMS.trace.log(file.getFullName()+ " created");
			}
			catch(Exception e) {
        EasyRMS.trace.log(e);
			}
		}
		rset.close();	
		preparedStatement.close();
	}

	public static void extractTables(ValidatedDirectory root, Statement stmt, Connection conn) throws SQLException {
		final PreparedStatement preparedStatement = conn.prepareStatement("select column_name, data_type, data_length, data_precision, data_scale, nullable, data_default from DBA_TAB_COLUMNS where owner=? and table_name=? order by table_name, column_id asc");
		final PreparedStatement preparedStatement2 = conn.prepareStatement("select constraint_name, constraint_type, search_condition, delete_rule, r_owner, r_constraint_name from DBA_CONSTRAINTS where constraint_type=? and owner=? and table_name=? and generated='USER NAME'");
		final PreparedStatement preparedStatement3 = conn.prepareStatement("select table_name from DBA_CONSTRAINTS where owner=? and constraint_name=? ");
		final PreparedStatement preparedStatement4 = conn.prepareStatement("select column_name, position from DBA_CONS_COLUMNS where owner=? and constraint_name=? and position is not null order by constraint_name, position");
		final PreparedStatement preparedStatement5 = conn.prepareStatement("select index_name from DBA_INDEXES where owner=? and index_name=?");
		final PreparedStatement preparedStatement6 = conn.prepareStatement("select grantee,privilege,grantable from DBA_TAB_PRIVS where owner=? and table_name=?");
		final ResultSet rset = stmt.executeQuery("select owner,table_name from dba_tables where owner not in ('SYS','SYSTEM','PUBLIC') and IOT_NAME is null");
		while(rset.next()) {
			final String owner = rset.getString(1);
			final String name = rset.getString(2);
			preparedStatement.setString(1, owner);
			preparedStatement.setString(2, name);
			final ResultSet rset2 = preparedStatement.executeQuery();

			try {
				final ValidatedDirectory directory = StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(root, owner.toLowerCase()), "tables"));
				final ValidatedFile file = StreamUtils.getChildFile(directory, name.toLowerCase() + ".sql");
        System.out.println("Tables "+file.getFullName());
        try (final FileWriter writer = StreamUtils.newFileWriter(file)){
					writer.write("create table ");
					writer.write(name.toLowerCase());
					writer.write(" (\r\n");
					int nbCol = 0;
					while (rset2.next()) {
						if (nbCol > 0) writer.write(",\r\n");
						nbCol++;
						
						final String columnName = toString(rset2, 1);
						final String data_type = toString(rset2, 2);
						final String data_length = toString(rset2, 3, "1");
						final String data_precision = toString(rset2, 4, "1");
						final String data_scale = toString(rset2, 5);
						final String nullable = toString(rset2, 6);
						final String defaultData = toString(rset2, 7);
						
						writer.write("  ");
						writer.write(columnName.toLowerCase());
						writer.write(" ");
						writer.write(data_type);
						if ("NUMBER".equals(data_type)) {
							writer.write("(");
							writer.write(data_precision);
							if (data_scale != null && !"0".equals(data_scale)) {
								writer.write(",");
								writer.write(data_scale);
							}
							writer.write(") ");
						}
						else {						
							writer.write("(");
							writer.write(data_length);
							writer.write(") ");
						}
						if (defaultData != null) {
							writer.write("default ");
							writer.write(defaultData);
							writer.write(" ");
						}
						if (nullable.charAt(0) == 'N') {
							writer.write("not null ");
						}
						writer.flush();
					}
					extractConstraint(writer, "P", owner, name, preparedStatement2, preparedStatement3, preparedStatement4, preparedStatement5);
					extractConstraint(writer, "U", owner, name, preparedStatement2, preparedStatement3, preparedStatement4, preparedStatement5);
					extractConstraint(writer, "R", owner, name, preparedStatement2, preparedStatement3, preparedStatement4, preparedStatement5);
					extractConstraint(writer, "C", owner, name, preparedStatement2, preparedStatement3, preparedStatement4, preparedStatement5);
					writer.write("\r\n)\r\n");
					extractGrant(writer,owner,name, preparedStatement6);
				}
				catch(Exception e) {
				  EasyRMS.trace.log("error with " + file.getFullName(), e);
				}
				rset2.close();
				EasyRMS.trace.log(file.getFullName()+ " created");
			}
			catch(Exception e) {
        EasyRMS.trace.log(e);
			}
		}
		rset.close();	
		preparedStatement6.close();
		preparedStatement5.close();
		preparedStatement4.close();
		preparedStatement3.close();
		preparedStatement2.close();
		preparedStatement.close();
	}

	private static String toString(ResultSet rset, int index) throws SQLException {
		return toString(rset,index, null);
	}
	private static String toString(ResultSet rset, int index, String defaultValue) throws SQLException {
		final String result = rset.getString(index);
		return rset.wasNull() ? defaultValue : result;
	}

	private static void extractGrant(Writer writer, String owner, String table_name, PreparedStatement preparedStatement) throws SQLException {
		preparedStatement.setString(1, owner);
		preparedStatement.setString(2, table_name);
		final ResultSet rset = preparedStatement.executeQuery();
		try  {
			while (rset.next()) {
				final String grantee = toString(rset, 1, ""); 
				final String privilege = toString(rset, 2, ""); 
				final String grantable = toString(rset, 3, ""); 
				writer.write("\r\n");
				writer.write("grant ");
				writer.write( privilege.toLowerCase());
				writer.write(" on ");
				writer.write(table_name.toLowerCase());
				writer.write(" to ");
				writer.write(grantee.toLowerCase());
				if ("YES".equals(grantable)) writer.write("  with grant option ");
				writer.write(";");
			}
		}
		catch(Exception e) {
      EasyRMS.trace.log(e);
		}
	}
	
	private static void extractConstraint(Writer writer, String type, String owner, String table_name, PreparedStatement preparedStatement2, PreparedStatement preparedStatement3, PreparedStatement preparedStatement4, PreparedStatement preparedStatement5) throws SQLException {
		int nbConstraint = 0;
		preparedStatement2.setString(1, type);
		preparedStatement2.setString(2, owner);
		preparedStatement2.setString(3, table_name);
		final ResultSet rset3 = preparedStatement2.executeQuery();
		try  {
			while (rset3.next()) {
				writer.write(",\r\n");
				nbConstraint++;
				final String constraint_name = toString(rset3, 1);
				final String constraint_type = toString(rset3, 2);
				final String seach_condition = toString(rset3, 3);
				final String delete_rule = toString(rset3, 4);
				final String reference_owner = toString(rset3, 5);
				final String reference_constraint = toString(rset3, 6);
				writer.write("  constraint ");
				writer.write(constraint_name.toLowerCase());
				writer.write("\r\n    ");
				if ("P".equals(constraint_type)) {
					writer.write("primary key ");
				}
				else if ("R".equals(constraint_type)) {
					writer.write("foreign key ");
				}
				else if ("C".equals(constraint_type)) {
					writer.write("check ");
				}
				else if ("U".equals(constraint_type)) {
					writer.write("unique ");
				}
							
				if (seach_condition!= null) {
					writer.write(" (");
					writer.write(seach_condition);
					writer.write(") ");
				}
							
				preparedStatement4.setString(1, owner);
				preparedStatement4.setString(2, constraint_name);
				final ResultSet rset5 = preparedStatement4.executeQuery();
				try {
					int nbConstraintColumn = 0;
					while(rset5.next()) {
						final String column_name = toString(rset5, 1);
						if (column_name != null) {
							if (nbConstraintColumn == 0) {
								writer.write("(");
							}
							else {
								writer.write(",");
							}
							nbConstraintColumn++;
							writer.write(column_name.toLowerCase());
						}
					}
					if (nbConstraintColumn > 0) {
						writer.write(")");
					}
				}
				catch(Exception e2) {
          EasyRMS.trace.log(e2);
				}
				rset5.close();
							
				if (reference_owner != null && reference_constraint != null) {
					preparedStatement3.setString(1, owner);
					preparedStatement3.setString(2, constraint_name);
					final ResultSet rset4 = preparedStatement3.executeQuery();
					try {
						if (rset4.next()) {
							final String reference = toString(rset4, 1);
							if (reference != null) {
								writer.write(" references ");
								writer.write(owner.toLowerCase());
								writer.write(".");
								writer.write(reference.toLowerCase());
								writer.write(" ");
							}
						}
					}
					catch(Exception e2) {
	          EasyRMS.trace.log(e2);
					}
					rset4.close();
				}
				if (delete_rule != null && !"NO ACTION".equals(delete_rule)) {
					writer.write(" on delete ");
					writer.write(delete_rule.toLowerCase());
				}
				
				preparedStatement5.setString(1, owner);
				preparedStatement5.setString(2, constraint_name);
				final ResultSet rset6 = preparedStatement5.executeQuery();
				try {
					if (rset6.next()) {
						final String indexName = toString(rset6, 1);
						if (indexName != null) {
							writer.write("\r\n    using index ");
						}
					}
				}
				catch(Exception e2) {
          EasyRMS.trace.log(e2);
				}
				rset6.close();
			}
		}
		catch(Exception e1) {
      EasyRMS.trace.log(e1);
		}
		rset3.close();
	}
}

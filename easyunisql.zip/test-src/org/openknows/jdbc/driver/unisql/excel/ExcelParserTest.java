package org.openknows.jdbc.driver.unisql.excel;

import java.io.*;

public class ExcelParserTest {
  
  public static final void main(String[] args) throws IOException {
    final ExcelParser parser = new ExcelParser();
    final FileInputStream input = new FileInputStream("C:\\test\\csv\\050901fidelity.txt");//ezcolumns.model.txt");
    try {
      parser.init(input);
      while (parser.hasMoreRow()) {
        System.out.print(parser.getNextRow()+":");
        while (parser.hasMoreElement()) {
          System.out.print(parser.getNextElement()+"\t");
        }
        System.out.println("");
      }
    }
    finally {
      input.close();
    }
  }
}

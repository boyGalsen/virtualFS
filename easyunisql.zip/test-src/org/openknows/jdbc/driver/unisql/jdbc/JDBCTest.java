package org.openknows.jdbc.driver.unisql.jdbc;


import com.easyrms.db.*;
import com.easyrms.util.*;

import java.sql.*;


public class JDBCTest {

  public static Connection getConnection() throws Throwable {
    JDBCConnectionDriver.register();
    return SimpleConnections.getConnection(null, null, "jdbc:unisql:myserver", false, false);
  }
  
  public static void print(ResultSet rs) throws Throwable {
    if (rs == null) return;
    final ResultSetMetaData metaData = rs.getMetaData();
    final int nbColumn = metaData.getColumnCount();
    for (int i = 1 ; i <= nbColumn; i++) {
      if (i > 1) System.out.print("\t");
      System.out.print(metaData.getColumnName(i));
    }
    System.out.println("");
    while (rs.next()) {
      for (int i = 1 ; i <= nbColumn; i++) {
        if (i > 1) System.out.print("\t");
        System.out.print(rs.getString(i));
      }
      System.out.println("");
    }
  }
  
  public static void printUpdate(Connection conn, String request) throws Throwable {
    final Statement stmt = conn.createStatement();
    int updateCount = stmt.executeUpdate(request);
    System.out.println(updateCount);
    stmt.close();
  }
  
  public static void print(Connection conn, String request) throws Throwable {
    try {
      System.out.println("\r\n"+request);
      final Statement stmt = conn.createStatement();
      //final ResultSet rset = stmt.executeQuery("select tax, htl, update, rev from @csv:c:/temp/passant2.txt");
      final ResultSet rset = stmt.executeQuery(request);
      print(rset);
      rset.close();
      stmt.close();
    }
    catch (Throwable e) {
      EasyRMS.trace.log(e);
    }
  }

  
  public static int getInt(Connection conn, String request) throws Throwable {
    final Statement stmt = conn.createStatement();
    //final ResultSet rset = stmt.executeQuery("select tax, htl, update, rev from @csv:c:/temp/passant2.txt");
    final ResultSet rset = stmt.executeQuery(request);
    int result = 0;
    if (rset.next()) {
     result = MathUtils.parseInt(rset.getString(1));
    }
    rset.close();
    stmt.close();
    return result;
  }

  public static void main(String[] args) {
    try {
      final Connection conn = getConnection();
      final DatabaseMetaData databaseMetaData = conn.getMetaData();
      
      //printUpdate(conn, "register jdbc:postgresql:ezdocs as gac with driver='org.postgresql.Driver' and user='postgres' and password='wxcvbn'");
      //print(conn, "select * from @jdbc:gac(select * from ezdocs_category) a");
      print(databaseMetaData.getCatalogs());
     // print(conn, "select * from @csv:c:/temp/iris.txt a where A.type='Iris-setosa'");
     // printUpdate(conn, "activate manager org.openknows.jdbc.driver.unisql.csv.CSVAtManager");
     // print(conn, "select * from @csv:c:/temp/iris.txt a where A.type='Iris-setosa'");
     // printUpdate(conn, "desactivate manager org.openknows.jdbc.driver.unisql.csv.CSVAtManager");
      //print(conn, "select a.country, count(*) from @EZ:C:/temp/UA3UMF03.ez#booking.txt a group by a.country");
      //print(conn, "select *, a.ooi+a.extra+a.ooo from @EZ:Z:/Production/snapshots/201009/BRQKMB11.ez#invento.txt a where a.ooi+a.extra+a.ooo<= 0");
    
      //print(conn, "select STD(A.sep_length) as aa, Statistics.Std(A.sep_length) as ab from @csv:c:/temp/iris.txt a where A.type not like 'Iris-se%'");
      //print(conn, "select * from @csv:c:/temp/iris.txt a where 1+2>=0");
      print(conn, "select * from @memo:/system a union all select * from @memo:/system b");
      print(conn, "select * from @:d:/ a ");
      print(conn, "select a.ISDIRECTORY, count(*) from @:d:/ a group by a.ISDIRECTORY");
      print(conn, "select * from @tsv:file://d:/a.tsv a ");
      print(conn, "select * from @tsv:d:/a.tsv a ");
      //print(conn, "select * from @folsstat:d:/fols/20170329/Arch_FOLS_5140_20170324/FOLS_5140_20170324.xml a");
      print(conn, "select a.RML, count(*), min(STAY_ADULTS), avg(STAY_ADULTS), max(STAY_ADULTS) from @folsstat:d:/fols/20170329/Arch_FOLS_5140_20170324/FOLS_5140_20170324.xml a group by a.RML");
      print(conn, "select count(*) from @operareport:D:/OpenKnowsPlugin/EC_W/easyunisql/test-src/org/openknows/jdbc/driver/unisql/jdbc/res_forecastnetgah.txt a");
      print(conn, "select * from @dbf:D:/OpenKnowsPlugin/EC_W/easyunisql/include-src/org/openknows/jdbc/driver/unisql/dbf/CURRENC.DBF a");
      print(conn, "select * from @dbf:D:/OpenKnowsPlugin/EC_W/easyunisql/include-src/org/openknows/jdbc/driver/unisql/dbf/GENERAL.DBF a");
      //print(conn, "select * from @cmd:tasklist where cmdresponse not like '%4024%' and cmdrow > 2");
      //print(conn, "select * from @cmd:netstat#-a a where a.CMDRESPONSE like '%2701%'");
      conn.close();
      System.exit(0);
    }
    catch (Throwable e) {
      EasyRMS.trace.log(e);
    }
  }
}

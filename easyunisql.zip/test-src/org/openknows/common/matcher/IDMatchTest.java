package org.openknows.common.matcher;

public class IDMatchTest {

  public static final void main(String[] args) {
    final IDMatcher matcher = new IDMatcher();
    matcher.addEquals("GET", 1);
    matcher.addEquals("POST", 2);
    matcher.addStartWith("POSTE", 4);
    matcher.addEquals("POSTEN", 3);
    matcher.addEndWith(".txt", 5);
    final IDRule idrule = matcher.compile();
    System.out.println(idrule.match("GET"));
    System.out.println(idrule.match("G"));
    System.out.println(idrule.match("POSTENE"));
    System.out.println(idrule.match("POSTEN"));
    System.out.println(idrule.match("POStds.txt"));
    System.out.println(idrule.match("toto.txt"));
    System.out.println(idrule.match("toto.txt.xml"));
  }
}

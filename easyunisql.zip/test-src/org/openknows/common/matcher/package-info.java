/**
 * 
 */
/**
 * 
 */
package org.openknows.common.matcher;
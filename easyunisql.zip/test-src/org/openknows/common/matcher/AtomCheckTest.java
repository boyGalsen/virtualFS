package org.openknows.common.matcher;

import org.openknows.common.matcher.AtomCheck.*;

public class AtomCheckTest {
  
  public static final void main(String[] args) {
    final AtomCheck matcher = new AtomCheck();
    matcher.addEquals("GET", 1);
    matcher.addEquals("POST", 2);
    matcher.addStartWith("POSTE", 4);
    matcher.addEquals("POSTEN", 3);
    //matcher.addEndWith("xts", 6);
    matcher.addEndWith(".txt", 5);
    matcher.addStartWith("PO.txY", 14);
    matcher.addEquals("POST.tx", 15);
    final Atom idrule = matcher.compile();
    System.out.println(idrule.match("GET"));
    System.out.println(idrule.match("G"));
    System.out.println(idrule.match("POSTENE"));
    System.out.println(idrule.match("POSTEN"));
    System.out.println(idrule.match("POStds.txts"));
    System.out.println(idrule.match("PO.txt"));
    System.out.println(idrule.match("POST.txt"));
    System.out.println(idrule.match("toto.txt"));
    System.out.println(idrule.match("toto.txt.xml"));
  }
}

package org.openknows.common.matcher;

import com.easyrms.util.*;

public class MatcherTest {

  public static final void main(String[] args) {
    /*final Matcher m = new Matcher();
    m.addEquals("");
    m.addStartWith("t");
    m.addEquals("toto");
    m.addEquals("totox");
    m.addEquals("titi");
    m.addEquals("gac");
    final Rule a = m.compile();
    match(a, "");
    match(a, "toto");
    match(a, "gac");
    match(a, "ga");
    match(a, "totox");
    match(a, "titix");*/
    {
      final Matcher t = new Matcher();
      t.addEndWidth(".txt");
      final Rule r = t.compile();
      System.out.println("toto.txt.xml.:"+r.match("toto.txt.xml"));
      final String s = g;
      final long t1 = StampUtil.getStampValue();
      boolean test;
      for (int i = 0 ; i < 1000000; i++) {
        test = s.equals(a) 
          || s.equals(b) 
          || s.equals(c)
          || s.equals(d) 
          || s.equals(e) 
          || s.equals(f) 
          || s.equals(g);
        //System.out.println(test);
      }
      final long t2 = StampUtil.getStampValue();
      System.out.println(t2-t1);
    }   
    
    {
      final String s = g;
      final Matcher m = new Matcher();
      m.addEquals(a);
      m.addEquals(b);
      m.addEquals(c);
      m.addEquals(d);
      m.addEquals(e);
      m.addEquals(f);
      m.addEquals(g);
      final Rule r = m.compile();
      final long t1 = StampUtil.getStampValue();
      boolean test;
      for (int i = 0 ; i < 1000000; i++) {
        test = r.match(s); 
      }
      final long t2 = StampUtil.getStampValue();
      System.out.println(t2-t1);
    }   
  }
  
  private static final String a = "cas1";
  private static final String b = "zez e ";
  private static final String c = "cas2";
  private static final String d = " zee ez";
  private static final String e = "dzdzd";
  private static final String f = "ezrfzfezf";
  private static final String g = "cas 3";
}

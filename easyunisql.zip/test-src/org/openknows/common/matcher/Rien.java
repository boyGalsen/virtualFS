package org.openknows.common.matcher;

import java.io.StringReader;

import org.codehaus.janino.SimpleCompiler;

public class Rien {

  public static void main(String... args) throws Throwable {
    final String s = 
      "package org.matcher;" +
      "public class MyTest implements org.matcher.Rule {" +
      "  public boolean match(final String value) { return true;}" +
      "}";
    
    //Class c = new ClassBodyEvaluator("public boolean match()").evaluate();
    
    final SimpleCompiler compiler = new SimpleCompiler(null, new StringReader(s));
    final Rule r = (Rule)compiler.getClassLoader().loadClass("org.matcher.MyTest").newInstance();
    System.out.println(r.match("rien"));
  }
}

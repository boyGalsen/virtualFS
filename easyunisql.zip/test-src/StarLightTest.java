import org.openknows.interfaces.starlight.*;

import java.io.*;

public class StarLightTest {

  public static void main(String... args) throws Throwable {
    final File toTest = new File("D:/OpenKnowsPlugin/EC_W/easyunisql/test-src/EZ170322.DAT");
    try (final Reader in = new FileReader(toTest)) {
      final StartLightParser parser = new StartLightParser(in);
      while (parser.nextEntry()) {
        System.out.println(parser.getCurrentEntryName());
      }
    }
  }
}

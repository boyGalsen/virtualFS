package com.ezrms.db.tests;

import com.easyrms.util.*;

public class TestJavaRun {

  public static void main(String... args) throws Throwable {
    final Process process = Runtime.getRuntime().exec("Tasklist");
    StreamUtils.copy(process.getInputStream(), System.out);
  }
}

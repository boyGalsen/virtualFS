package com.ezrms.db.tests;

import com.easyrms.db.*;
import com.easyrms.db.ezdb.*;
import com.easyrms.util.comparator.*;

import java.sql.*;

import org.openknows.jdbc.driver.unisql.jdbc.*;

public class TestXML {

  public static void main(String... args) throws Throwable {
    DriverManager.registerDriver(new JDBCConnectionDriver());
    DriverManager.registerDriver(new EzDBConnectionDriver());
    final EzJDBCDatabase ezdb = new EzJDBCDatabase("ezdb", "ezdb", "jdbc:ezrms.ezdb:test");
    final EzJDBCDatabase db = new EzJDBCDatabase("unisql", "unisql", "jdbc:unisql:test");
    EzDBDatabaseManager.reference.register(db);
    final EzJDBCConnection connection = ezdb.openAccess();
    final XMLRequest xmlRequest = new XMLRequest();
    xmlRequest.setRequest("@command:// netstat ");
    final String request = xmlRequest.getResponse(connection);
    final SimpleResultSet requestSet = SQLResponseXMLParser.reference.parse(request);
    
    //SQLResponseXMLParser.reference.parse(response)
    
    
    SimpleRequest.query(
      -1,
      requestSet, 
      new EzDBResultSetListener() {

        @Override
        public void init(ResultSet v) throws SQLException {
          super.init(v);
          final ResultSetMetaData metaData = v.getMetaData();
          for (int j = 1, m = metaData.getColumnCount(); j <= m; j++) { 
            if (j > 1) System.out.print("\t");
            System.out.print(StringComparator.NVL(metaData.getColumnName(j)));
          }
          System.out.println("\t");
        }

        @Override
        public void set(int i, ResultSet v) throws SQLException {
          for (int j = 1, m = v.getMetaData().getColumnCount(); j <= m; j++) { 
            if (j > 1) System.out.print("\t");
            System.out.print(StringComparator.NVL(SQLUtils.getString(v, j)));
          }
          System.out.println("\t");
        }
      });
    connection.close();
  }
}

package com.easyrms.ws.uniws;

import com.easyrms.db.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestUniWSGetConnectionDriver {

	public static void main (String[] args) {
	  try {
	    connect();
	  }
	  catch (SQLException exception) {
      UniWSGetConnectionDriver.trace.log(exception);
	  }
	}
	
	public static void connect() throws SQLException{
	  try {
      DriverManager.registerDriver(new UniWSGetConnectionDriver());
    }
	  catch (Throwable e) {
      UniWSGetConnectionDriver.trace.log(e);
	  }
    Connection conn = SimpleConnections.getConnection(null, null, "jdbc:uniwsget:gcherief@easyrms.com/ga7si0ve8@UniversalQuery#127.0.0.1/services/uniws", false, false);
    Statement stmt2 = conn.createStatement();
    ResultSet rset2 = stmt2.executeQuery("select * from @memo:/system a");
    if (rset2 != null) {
      final int columnCount = rset2.getMetaData().getColumnCount();
      for (int i = 1; i <= columnCount; i++) {
        if (i > 0) System.out.println("\t");
        System.out.print(rset2.getMetaData().getColumnName(i));
      }
      System.out.println();
      while (rset2.next()) { 
        for (int i = 1; i <= columnCount; i++) {
          if (i > 0) System.out.println("\t");
          System.out.print(rset2.getString(i));
        }
        System.out.println();
      }
      rset2.close();
    }
    stmt2.close();    
    Statement stmt = conn.createStatement();
    ResultSet rset = stmt.executeQuery("select * from @memo:/ezrms/ezrmscheck a where a.property like '%ount%'");
  	if (rset != null) {
      final int columnCount = rset.getMetaData().getColumnCount();
      for (int i = 1; i <= columnCount; i++) {
        if (i > 0) System.out.println("\t");
        System.out.print(rset.getMetaData().getColumnName(i));
      }
      System.out.println();
  	  while (rset.next()) { 
        for (int i = 1; i <= columnCount; i++) {
          if (i > 0) System.out.println("\t");
          System.out.print(rset.getString(i));
        }
        System.out.println();
      }
  	  rset.close();
    }
  	stmt.close();
  	conn.close();
	}
}
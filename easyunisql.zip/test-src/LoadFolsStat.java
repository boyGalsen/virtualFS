import com.easyrms.date.*;
import com.easyrms.db.*;
import com.easyrms.util.*;
import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;
import com.easyrms.util.xml.*;

import org.openknows.interfaces.fols.*;

import java.io.*;

public class LoadFolsStat {

  private static final String database = "jdbc:oracle:thin:yield/yieldboss@(DESCRIPTION= (LOAD_BALANCE=on)(ADDRESS=(PROTOCOL=TCP)(HOST=172.17.248.167)(PORT=1525)) (CONNECT_DATA=(SERVICE_NAME=RMSPE4)))";
  
  
  public static void main(String... args) throws Throwable {
    final EzArray<? extends FolsStatEntry> folsEntries = new FolsStatXMLHandler().parse(new InputStreamReader(new XMLInputStream(new FileInputStream("d:/Arch_FOLS_1404_20170803_3/FOLS_1404_20170803_3.xml")), EzEncoding.UTF_8.getCharset()));
    final EzDate snapshot = EzYYYYMMDDDateFormat.referenceParse("20170803").add(-1);
    final EzDBTransaction totransaction = new EzJDBCDatabase("to", "to", database).openTransaction();
    try {
      for (int i = 0, n = folsEntries.getCount(); i < n; i++) {
        final FolsStatEntry entry = folsEntries.get(i);
        if (SimpleModify.modify(
          totransaction, 
          "insert into checkpoint.folsbookings values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,null,null,null,null,null,null,null,null,null)",
          new Object[] {
            IntegerCache.zero,
            snapshot.getID(),
            StringUtil.trunc(entry.getHOTE_ID(), 50),
            StringUtil.trunc(entry.getSTAY_ID(), 50),
            StringUtil.trunc(entry.getHOTE_CODE(), 50),
            StringUtil.trunc(entry.getSTAY_NUM(), 50),
            SQLUtils.toSQLDate(entry.getSTAY_BOOK_DATE()),
            SQLUtils.toSQLDate(entry.getSTAY_DATE_START()),
            SQLUtils.toSQLDate(entry.getSTAY_DATE_END()),
            entry.getSTAY_TU_ACCOMMODATION_TI(),
            entry.getSTAY_TU_ACCOMMODATION_TE(),
            entry.getSTAY_TU_FOOD_TI(),
            entry.getSTAY_TU_FOOD_TE(),
            entry.getSTAY_TU_OTHER_TI(),
            entry.getSTAY_TU_OTHER_TE(),
            entry.getSTAY_TU_TOTAL_TI(),
            entry.getSTAY_TU_TOTAL_TE(),
            entry.getTAY_TU_NOSHOW_TI(),
            entry.getTAY_TU_NOSHOW_TE(),
            StringUtil.trunc(entry.getSTAY_CHANNEL(), 50),
            StringUtil.trunc(entry.getSTAY_RATE(), 50),
            StringUtil.trunc(entry.getSTAY_ROOM_TYPE(), 50),
            StringUtil.trunc(entry.getPRODUCT_TARS_CODE(), 50),
            StringUtil.trunc(entry.getSTAY_SEGMENT(), 50),
            StringUtil.trunc(entry.getRML(), 50),
            StringUtil.trunc(entry.getHOM(), 50),
            StringUtil.trunc(entry.getPUR(), 50),
            StringUtil.trunc(entry.getGROUPID(), 50),
            entry.getSTAY_ADULTS(),
            entry.getSTAY_CHILDREN(),
            
          }) != 1) 
        {
          System.out.println("Error!");
          return;
        }
        System.out.println("insert "+i+"/"+n+" ("+DoubleFormat.referenceFormat((i*100.0/n))+"%)");

      }
      totransaction.commit();
    }
    finally {
      totransaction.rollback();
      totransaction.close();
    }
    System.out.print("Done!");
  }

}

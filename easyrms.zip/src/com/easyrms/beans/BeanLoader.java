package com.easyrms.beans;

public interface BeanLoader {

}
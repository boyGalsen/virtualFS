package com.easyrms.beans;

import com.easyrms.util.*;

public class BeanLoaderException extends Exception {

  public BeanLoaderException(String message) {
    this.message = message;
    this.exception = null;
  }
  public BeanLoaderException(Exception exception) {
    this.message = ExceptionUtils.getMessage(exception);
    this.exception = exception;
  }
  
  @Override
  public final String getMessage() { return this.message; }
  public final Exception getException() { return this.exception; }

  private final String message;
  private final Exception exception;
}
package com.easyrms.builder;

/**
 * DontCareFieldPosition defines no-op FieldDelegate. Its singleton is used for
 * the format methods that don't take a FieldPosition.
 */
class DontCareFieldPosition extends FieldPosition {
  // The singleton of DontCareFieldPosition.
  static final FieldPosition INSTANCE = new DontCareFieldPosition();

  private final Builder.FieldDelegate noDelegate = new Builder.FieldDelegate() {
    public void formatted(Builder.Field attr, Object value, int start, int end, StringBuilder buffer) {}

    public void formatted(int fieldID, Builder.Field attr, Object value, int start, int end, StringBuilder buffer) {}
  };

  private DontCareFieldPosition() {
    super(0);
  }

  @Override
  Builder.FieldDelegate getFieldDelegate() {
    return noDelegate;
  }
}

package com.easyrms.builder;

import com.easyrms.util.*;

public class FieldPositonThreadPool {

  private FieldPositonThreadPool() {
    //HashSetThreadPoolManager.reference.add(this);
    counter.inc();
  }
  
  public static final ThreadLocal<FieldPositonThreadPool> threadPools = new ThreadLocal<FieldPositonThreadPool>() {

    @Override
    protected FieldPositonThreadPool initialValue() {
      return new FieldPositonThreadPool();
    }
  };
  
  public int getMaxSize() {
    return maxPool+1;
  }
  
  public FieldPosition get() {
    getCount.inc();
    if (index >= 0) {
      final FieldPosition result = pools[index];
      pools[index] = null;
      index--;
      return result;
    }
    return fieldPositionPool.getNew();
  }
  
  public void free(FieldPosition position) {
    if (position != null) {
      if (index < maxPool) {
        if (fieldPositionDeleter.delete(position)) {
          pools[++index] = position;
        }
        else {
          fieldPositionDeleter.finalize(position);
        }
      }
      else {
        fieldPositionPool.free(position);
      }
    }
  }
  private static final int maxPool = ThreadUtil.poolSizeDefault-1;//3
  private FieldPosition[] pools = new FieldPosition[maxPool+1];
  private int index = -1;
  
  @Override
  protected void finalize() throws Throwable {
    super.finalize();
    counter.dec();
  }
  
  static final ObjectDeleter<FieldPosition> fieldPositionDeleter = new ObjectDeleter<FieldPosition>() {
    
    public boolean delete(FieldPosition o) {
      o.setBeginIndex(0);
      o.setEndIndex(0);
      return true;
    }
    public void finalize(FieldPosition o) {
      o.setBeginIndex(0);
      o.setEndIndex(0);
    }
  };
  private static final com.easyrms.util.Pool<FieldPosition> fieldPositionPool = new SynchronizedSimplePool<FieldPosition>(
    Builder.class.getName()+".fieldPositionPool",
    new AbstractCreator<FieldPosition>() {
  
      @Override
      public FieldPosition create() {
        return new FieldPosition(0);
      }
    }, 
    fieldPositionDeleter);

  private static final Counter counter = new Counter("FieldPosition ThreadLocal Pool");
  private static final Counter getCount = new Counter("FieldPosition ThreadLocal Total Get");
}

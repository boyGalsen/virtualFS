package com.easyrms.builder;

public abstract class AbstractBuilder extends Builder {


  @Override
  public final Object parseObject(String source, ParsePosition pos) {
    throw new UnsupportedOperationException();
  }

}

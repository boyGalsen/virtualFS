package com.easyrms.builder;

import com.easyrms.date.*;

public final class DateBuilders {

  private DateBuilders() {
  }
  
  public static final String fileTimeStampFormat(Object obj) {
    synchronized (fileTimeStamp) {
      if (obj instanceof DateAccessor) {
        return fileTimeStamp.format(((DateAccessor)obj).toDate());
      }
      return fileTimeStamp.format(obj);
    }
  }
  public static final StringBuilder fileTimeStampFormat(Object obj, StringBuilder buff) {
    synchronized (fileTimeStamp) {
      if (obj instanceof DateAccessor) {
        return fileTimeStamp.format(((DateAccessor)obj).toDate(), buff);
      }
      return fileTimeStamp.format(obj, buff);
    }
  }
  private static final DateBuilder fileTimeStamp = new SimpleDateBuilder("yyyyMMdd HHmmss ");

  public static final String timeStampFormat(Object obj) {
    synchronized (timeStamp) {
      if (obj instanceof DateAccessor) {
        return timeStamp.format(((DateAccessor)obj).toDate());
      }
      return timeStamp.format(obj);
    }
  }
  public static final StringBuilder timeStampFormat(Object obj, StringBuilder buff) {
    synchronized (timeStamp) {
      if (obj instanceof DateAccessor) {
        return timeStamp.format(((DateAccessor)obj).toDate(), buff);
      }
      return timeStamp.format(obj, buff);
    }
  }
  private static final DateBuilder timeStamp = new SimpleDateBuilder("yyyyMMdd HH:mm:ss ");
  
  public static final String dayFormatFormat(Object obj) {
    synchronized (dayFormat) {
      if (obj instanceof DateAccessor) {
        return dayFormat.format(((DateAccessor)obj).toDate());
      }
      return dayFormat.format(obj);
    }
  }
  public static final StringBuilder dayFormatFormat(Object obj, StringBuilder buff) {
    synchronized (dayFormat) {
      if (obj instanceof DateAccessor) {
        return dayFormat.format(((DateAccessor)obj).toDate(), buff);
      }
      return dayFormat.format(obj, buff);
    }
  }
  private static final DateBuilder dayFormat = new SimpleDateBuilder("yyyyMMdd");
  
  public static final String dayHoursFormatFormat(Object obj) {
    synchronized (dayHoursFormat) {
      if (obj instanceof DateAccessor) {
        return dayHoursFormat.format(((DateAccessor)obj).toDate());
      }
      return dayHoursFormat.format(obj);
    }
  }
  public static final StringBuilder dayHoursFormatFormat(Object obj, StringBuilder buff) {
    synchronized (dayHoursFormat) {
      if (obj instanceof DateAccessor) {
        return dayHoursFormat.format(((DateAccessor)obj).toDate(), buff);
      }
      return dayHoursFormat.format(obj, buff);
    }
  }
  private static final DateBuilder dayHoursFormat = new SimpleDateBuilder("yyyyMMddHH");

}

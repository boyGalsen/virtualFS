package com.easyrms.io.ezfs.s3;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.comparator.*;

import java.io.*;


public class S3EzFSConnectionDescriptor extends SimpleEzFSConnectionDescriptor {

  S3EzFSConnectionDescriptor(String bucket, String region, String accesKey, String secretKey, String path) {
    super(
      "s3://"+accesKey+":"+secretKey+"@"+bucket+".s3."+region+".amazonaws.com"+StringComparator.NVL(path),
      "s3://"+accesKey+"@"+bucket+".s3."+region+".amazonaws.com"+StringComparator.NVL(path));
    this.bucket = bucket;
    this.region = region;
    this.accesKey = accesKey;
    this.secretKey = secretKey;
    this.path = path;
  }
    
  public S3EzFSConnection createConnection() throws IOException {
    return new S3EzFSConnection(this);
  }

  public String getRegion() {
    return region;
  }

  public String getBucket() {
    return bucket;
  }

  public String getAccesKey() {
    return accesKey;
  }
    
  public String getSecretKey() {
    return secretKey;
  }
    
  public String getPath() {
    return path;
  }

  private final String region;
  private final String bucket;
  private final String accesKey;
  private final String secretKey;
  private final String path;
}

package com.easyrms.io.ezfs.s3;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.net.aws.*;

import java.io.*;

public class S3EzFSDriver implements EzFSDriver {

    @Override
    public EzArray<String> getEzFSPrefix() {
      return prefixes;
    }

    @Override
    public S3EzFSConnection getConnection(String prefix, String url) throws IOException {
      return getConnectionDescriptor(prefix, url).createConnection();
    }

    @Override
    public S3EzFSConnectionDescriptor getConnectionDescriptor(String prefix, String url) {
      final int indexOfAt = url.indexOf("@");
      if (indexOfAt < 0) {
        throw new IllegalArgumentException("Invalid url"+url);
      }
      final String credentialPart = url.substring(0, indexOfAt);
      final int credentialPartSepIndex = credentialPart.indexOf(":");
      if (credentialPartSepIndex < 0) {
        throw new IllegalArgumentException("Invalid url"+url);
      }
      final String accesKey = credentialPart.substring(0, credentialPartSepIndex);
      final String secretKey = credentialPart.substring(credentialPartSepIndex+1);

      final String uri = url.substring(indexOfAt+1);
      final int s3index = uri.indexOf(".s3.");
      if (s3index < 0) {
        throw new IllegalArgumentException("Invalid url"+url);
      }
      final String bucket = uri.substring(0, s3index);

      final int regionStart = s3index + 4;
      final int amazonIndex = uri.indexOf(".amazonaws.com", regionStart);
      if (amazonIndex < 0) {
        throw new IllegalArgumentException("Invalid url"+url);
      }
      final String region = uri.substring(regionStart, amazonIndex);
      final AWSRegion awsRegion = AWSRegion.findByName(region);
      if (awsRegion == null) {
        throw new IllegalArgumentException("Invalid url"+url+" unknow region "+region);
      }
      
      final String path;
      if (uri.length() > amazonIndex+14) {
        path = uri.substring(amazonIndex+14);
      }
      else {
        path = null;
      }
      return new S3EzFSConnectionDescriptor(bucket, region, accesKey, secretKey, path);
    }

    private static final String prefix = "S3";
    static final EzArray<String> prefixes = new EzArray.AsArray<>(prefix);

}

package com.easyrms.io.ezfs.s3;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.net.aws.*;

import java.io.*;


public class S3EzFSConnection extends AbstractEzFSConnection<S3EzFSFile> {

    public S3EzFSConnection(S3EzFSConnectionDescriptor descriptor) {
      this.descriptor = descriptor;
      this.s3bucket = new AWSS3Bucket(new AWSCredentials(descriptor.getAccesKey(), descriptor.getSecretKey()), AWSRegion.findByName(descriptor.getRegion()), descriptor.getBucket());
      final String path = descriptor.getPath();
      this.root = StringComparator.isNull(path) ? "" : path.startsWith("/") ? path.substring(1) : path;
    }

    @Override
    public S3EzFSConnectionDescriptor getDescriptor() {
        return descriptor;
    }

    @Override
    public S3EzFSFile getRoot() throws IOException {
        return new S3EzFSFile(this);
    }
    
    AWSS3Bucket getS3Bucket() {
      return s3bucket;
    }
    
    
    String getObjectKey(String... path) {
      if (path.length == 0) {
        return root;
      }
      final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
      final StringBuilder buffer = bufferPool.get();
      try {
        buffer.append(root);
        for (int i = 0, n = path.length; i < n; i++) {
          if (buffer.length() > 0) {
            buffer.append("/");
          }
          buffer.append(path[i]);
        }
        return buffer.toString();
      }
      finally {
        bufferPool.free(buffer);
      }
    }

    private final String root;
    private final S3EzFSConnectionDescriptor descriptor;
    private final AWSS3Bucket s3bucket;
    

}

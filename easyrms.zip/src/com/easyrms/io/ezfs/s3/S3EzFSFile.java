package com.easyrms.io.ezfs.s3;

import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.net.aws.*;

import java.io.*;
import java.util.*;


public class S3EzFSFile extends AbstractRemoteEzFSFile<S3EzFSFile> {

  S3EzFSFile(S3EzFSConnection connection) {
    super(ids);
    this.connection = connection;
    this.parent = null;
    this.path = new String[0];
    this.objectKey = connection.getObjectKey(path);
    this.name = null;
    this.isDirectory = true;
    this.isExist = true;
    this.descriptor = new SimpleEzFileDescriptor(connection.getDescriptor(), null, "/", true, false, true);
    this.filter = new S3Filter();
  }

  S3EzFSFile(S3EzFSFile parent, AWSS3BucketObject object, String name) {
    super(ids);
    this.parent = parent;
    this.connection = parent.connection;
    this.name = name;
    this.path = StringArrays.merge(parent.path, name);
    this.objectKey = connection.getObjectKey(path);
    this.isDirectory = false;
    this.length = object.getLength();
    this.isExist = true;
    this.lastModification = object.getLastModification();
    final String parentPath = parent.descriptor.getPath();
    this.descriptor = new SimpleEzFileDescriptor(connection.getDescriptor(), null, parentPath + (parentPath.endsWith("/") ? "" : "/")+name, false, true, false);
    this.filter = new S3Filter();
  }
  
  S3EzFSFile(S3EzFSFile parent, String name, boolean isDirectory) {
    super(ids);
    this.parent = parent;
    this.connection = parent.connection;
    this.name = name;
    this.path = StringArrays.merge(parent.path, name);
    this.objectKey = connection.getObjectKey(path);
    this.isDirectory = isDirectory;
    final String parentPath = parent.descriptor.getPath();
    this.descriptor = new SimpleEzFileDescriptor(connection.getDescriptor(), null, parent.descriptor.getPath() +  (parentPath.endsWith("/") ? "" : "/")+ name + (isDirectory ? "/" : ""), isDirectory, !isDirectory, false);
    this.filter = new S3Filter();
    if (this.isDirectory) {
      this.isExist = true;
      this.lastModification = StampUtil.getNow();
      this.length = 0;
    }
    else {
      this.markAsChange();
      this.synchStatus();
    }
  }
  
  @Override
  protected void internalSynchStatus() {
    if (!isDirectory) {
      try {
        final EzArray<AWSS3BucketObject> objects = connection.getS3Bucket().list(filter);
        boolean isFound = false;
        for (int i = 0, n = objects.getCount(); i < n; i++) {
          final AWSS3BucketObject object = objects.get(i);
          if (StringComparator.equals(name, object.getKey())) {
            isFound = true;
            this.isExist = true;
            this.lastModification = object.getLastModification();
            this.length = object.getLength();
            break;
          }
        }
        if (!isFound) {
          this.isExist = false;
          this.lastModification = null;
          this.length = 0;
        }
      }
      catch (IOException forward) {
        ExceptionUtils.newRuntimeException(forward);
      }
    }
  }

  @Override
  public EzFSFileDescriptor getDescriptor() {
    return descriptor;
  }

  public EzFSFile getDirectory(String name) throws IOException {
    return connection.findDirectory(this, name);
  }

  public EzFSFile getFile(String name) throws IOException {
    return connection.findFile(this, name);
  }

  @Override
  public boolean create() throws IOException {
    if (!isDirectory && !isExist()) {
      return getS3Bucket().write(getObjectKey(), new byte[0]);
    }
    return false;
  }

  @Override
  public EzFSFile getParent() throws IOException {
    return parent;
  }

  @Override
  public EzFSConnection getSystem() throws IOException {
    return connection;
  }

  @Override
  public EzFSFileAccess getAccess() throws IOException {
    if (!isDirectory) {
      return new S3EzFSFileAccess(this);
    }
    throw new IOException("Cannot provide access to a folder.");
  }

  @Override
  public boolean delete() throws IOException {
    final boolean result = connection.getS3Bucket().delete(getObjectKey());
    markAsChange();
    return result;
  }
  
  private void checkIsADirectory() throws IOException {
    if (!descriptor.isDirectory()) {
      throw new IOException("Not A Directroy");
    }
  }

  @Override
  public EzArray<? extends EzFSFile> list() throws IOException {
    checkIsADirectory();
    final EzArray<AWSS3BucketObject> list = connection.getS3Bucket().list(filter);
    final EzArrayList<S3EzFSFile> result = new EzArrayList<>();
    final HashSetThreadPool hashPool = HashSetThreadPool.threadPools.get();
    final HashSet<String> existingFiles = hashPool.get();
    try {
      for (int i = 0, n = list.getCount(); i < n; i++) {
        final AWSS3BucketObject object = list.get(i);
        final String[] paths = StringArrays.toStringArray(object.getKey(), "/");
        if (paths.length <= path.length) {
          throw new IOException("Invalid Bucket Name");
        }
        else if (paths.length == path.length+1) {
          result.add(new S3EzFSFile(this, object, paths[path.length]));
        }
        else {
          final String directoryName = paths[path.length];
          if (!existingFiles.contains(directoryName)) {
            result.add(new S3EzFSFile(this, directoryName, true));
            existingFiles.add(directoryName);
          }
        }
      }
      return result;
    }
    finally {
      hashPool.free(existingFiles);
    }
  }

  @Override
  protected S3EzFSFile newChild(String name, boolean isDirectory) throws IOException {
    checkIsADirectory();
    return new S3EzFSFile(this, name, isDirectory);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final S3EzFSFile that = (S3EzFSFile)o;
    if ((objectKey != null) ? !objectKey.equals(that.objectKey) : that.objectKey != null) {
      return false;
    }
    return (connection.getDescriptor() != null) ? connection.getDescriptor().equals(that.connection.getDescriptor()) : that.connection.getDescriptor() == null;
  }

  @Override
  public int hashCode() {
    int result = (objectKey != null) ? objectKey.hashCode() : 0;
    result = 31 * result + (connection.getS3Bucket().hashCode());
    return result;
  }

  private class S3Filter implements AWSS3BucketObjectFilter {

    public S3Filter() {
      String filterPath = null;
      if (isDirectory) {
        filterPath = objectKey + "/";
      } 
      else {
        int parentEnding = objectKey.lastIndexOf("/");
        filterPath = (parentEnding != -1) ? objectKey.substring(0, parentEnding) + "/" : "";
      }
      /*if (!filterPath.startsWith("/")) {
        filterPath = "/"+filterPath;
      }*/
      this.filterPath = filterPath;
    }

    @Override
    public String getPrefix() {
      return filterPath;
    }

    @Override
    public boolean accept(AWSS3Bucket bucket, String key) {
      return key.startsWith(filterPath);
    }

    private final String filterPath;
  }
  
  AWSS3Bucket getS3Bucket() {
    return connection.getS3Bucket();
  }
  
  String getObjectKey() {
    return objectKey;
  }

  private final String[] path;
  private final String objectKey;
  private final String name;
  private final boolean isDirectory;
  private final S3EzFSFile parent;
  private final SimpleEzFileDescriptor descriptor;
  private final S3EzFSConnection connection;
  private final AWSS3BucketObjectFilter filter;

  private static final IDGenerator ids = new IDGenerator("S3EzFSFile." + System.nanoTime());

}

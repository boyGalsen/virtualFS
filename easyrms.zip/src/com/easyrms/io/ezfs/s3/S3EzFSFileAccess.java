package com.easyrms.io.ezfs.s3;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;

public class S3EzFSFileAccess extends AbstractRemoteEzFSFileAccess<S3EzFSFile>  {

    public S3EzFSFileAccess(S3EzFSFile s3file) {
      super(s3file);
    }

    @Override
    protected void loadTmpFile(ValidatedFile tmpFile) throws IOException {
      StreamUtils.writeTo(tmpFile, remoteFSFile.getS3Bucket().read(remoteFSFile.getObjectKey()));
    }

    @Override
    protected void saveTmpFile(ValidatedFile tmpFile) throws IOException {
      remoteFSFile.getS3Bucket().write(remoteFSFile.getObjectKey(), StreamUtils.toByteArray(tmpFile));
    }

}


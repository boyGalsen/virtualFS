package com.easyrms.io.ezfs.ftp;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.net.*;


import java.io.*;
import java.util.*;
import org.apache.commons.net.ftp.*;

//ftpClient.enterLocalPassiveMode();

public class FTPEzFSConnection extends AbstractEzFSConnection<FTPEzFSFile> implements RemoteClient {
  
  static enum FTPEzFSConnectionMode {
    
    ACTIVE,
    LOCALPASSIVE,
    REMOTEPASSIVE,
    FULLPASSIVE;
  }
  static enum FTPEzFSFTPSystem {
    
    UNIX,
    NT,
    AUTO
  }

  FTPEzFSConnection(FTPEzFsConnectionDescriptor descriptor) throws IOException {
    this.client = new FTPClient();
    final String host = descriptor.getHost();
    final int port = descriptor.getPort();
    final String login = descriptor.getLogin();
    final String password = descriptor.getPassword();
    final String path = descriptor.getPath();
    final FTPEzFSConnectionMode mode = descriptor.getMode();
    final FTPEzFSFTPSystem system = descriptor.getSystem();
    if (system == FTPEzFSFTPSystem.UNIX) {
      this.client.configure(new FTPClientConfig(FTPClientConfig.SYST_UNIX));
    }
    else if (system == FTPEzFSFTPSystem.NT) {
      this.client.configure(new FTPClientConfig(FTPClientConfig.SYST_NT));
    }
    this.host = login+"@"+host;
    this.port = port;
    this.ezroot = new FTPEzFSFile(this);
    this.descriptor = descriptor;
    RemoteClientManager.reference.register(this);
    if (useConnectTimeout) {
      client.setConnectTimeout(ftpTimeout);
      client.setDataTimeout(ftpTimeout);
    }
    client.connect(host, port);
    if (!FTPReply.isPositiveCompletion(client.getReplyCode())) {
      client.disconnect();
      throw new RuntimeException("Error When Connecting FTP");
    }
    client.setDataTimeout(ftpTimeout);
    client.setSoTimeout(ftpTimeout);
    if (mode == FTPEzFSConnectionMode.FULLPASSIVE ) {
      client.enterLocalPassiveMode();
      client.enterRemotePassiveMode();
    }
    else if (mode == FTPEzFSConnectionMode.LOCALPASSIVE ) {
      client.enterRemotePassiveMode();
    }
    else if (mode == FTPEzFSConnectionMode.REMOTEPASSIVE) {
      client.enterRemotePassiveMode();
    }
    if (StringComparator.isNotNull(login)) {
      client.login(login, password);
    }
    if (StringComparator.isNotNull(path) && ((!FtpUtil.isIgnoredSlashPath && "/".equals(path)) || !"/".equals(path))) {
      FtpUtil.changeWorkingDirectory(client, path);
    }
  }
  
  @Override
  public final FTPEzFSFile getRoot() {
    return ezroot;
  }
  
  /*FTPClient getClient() {
    return client;
  }*/
  
  FTPClient startCommand(String command, String parameter) {
    synchronized (this.commands) {
      this.commands.push(new Tuple3<String, String, DateAccessor>(command, parameter, StampUtil.getNow()));
    }
    return client;
  }
  
  void endCommand() {
    synchronized (this.commands) {
      this.commands.pop();
    }
  }
  
  @Override
  protected void internalClose() throws IOException {
    try {
      try {
        try {
          client.logout();
        } 
        finally {
          client.disconnect();
        }
      }
      finally {
        super.internalClose();
      }
    }
    finally {
      RemoteClientManager.reference.remove(this);
    }
  }
  
  public EzFSConnectionDescriptor getDescriptor() {
    return descriptor;
  }
  
  public RemoteClientState getState() {
    final String id = getID();
    final String host = this.host;
    final int port = this.port;
    final DateAccessor startDate = getStartDate();
    final Tuple3<String, String, DateAccessor> commandValue;
    synchronized (this.commands) {
      commandValue = this.commands.isEmpty() ? null : this.commands.peek();
    }
    final String command = (commandValue == null) ? null : commandValue.get0();
    final String parameter = (commandValue == null) ? null : commandValue.get1();
    final DateAccessor commandStart = (commandValue == null) ? null : commandValue.get2();
    return new RemoteClientState() {

      public String getCommand() {
        return command;
      }

      public String getCommandParameter() {
        return parameter;
      }

      public int getConnectionTimeOut() {
        return 0;
      }

      public String getContext() {
        return null;
      }

      public String getID() {
        return id;
      }

      public int getPort() {
        return port;
      }

      public String getProtocol() {
        return "ftp";
      }

      public String getServer() {
        return host;
      }

      public int getSoTimeOut() {
        return 0;
      }

      public DateAccessor getStartDate() {
        return startDate;
      }

      public DateAccessor getCommandStart() {
        return commandStart;
      }      
    };
  }

  private final FTPClient client;
  private final FTPEzFSFile ezroot;
  private final FTPEzFsConnectionDescriptor descriptor;
  
  private final Stack<Tuple3<String, String, DateAccessor>> commands = new Stack<Tuple3<String, String, DateAccessor>>();
  
  private final String host;
  private final int port;
  
  public static final int ftpTimeout = 
    PropertiesUtil.getInt("com.easyrms.io.ezfs.ftp.ftpTimeout", 5*60*1000);
  public static final boolean useConnectTimeout = 
    PropertiesUtil.getBoolean("com.easyrms.io.ezfs.ftp.useConnectTimeout", true);  
  
}
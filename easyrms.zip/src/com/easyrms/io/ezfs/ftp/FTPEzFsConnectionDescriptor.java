package com.easyrms.io.ezfs.ftp;

import com.easyrms.io.ezfs.ftp.FTPEzFSConnection.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.comparator.*;

import java.io.*;

public class FTPEzFsConnectionDescriptor extends SimpleEzFSConnectionDescriptor {

  FTPEzFsConnectionDescriptor(String host, int port, String login, String password, String path, FTPEzFSConnectionMode mode, FTPEzFSFTPSystem system) {
    super(
      FTPEzFSDriver.getPrefix(mode, system)
      +"://"+StringComparator.NVL(login)
      +":"+StringComparator.NVL(password)
      +"@"+StringComparator.NVL(host)
      +":"+port+StringComparator.NVL(path),
      FTPEzFSDriver.getPrefix(mode, system)
      +"://"+StringComparator.NVL(login)
      +"@"+StringComparator.NVL(host)
      +":"+port+StringComparator.NVL(path));
    this.host = host;
    this.port = port;
    this.login = login;
    this.password = password;
    this.path = path;
    this.mode = mode;
    this.system = system;
  }
  
  public String getHost() {
    return host;
  }
  public String getLogin() {
    return login;
  }
  public FTPEzFSConnectionMode getMode() {
    return mode;
  }
  public String getPassword() {
    return password;
  }
  public String getPath() {
    return path;
  }
  public int getPort() {
    return port;
  }
  public FTPEzFSFTPSystem getSystem() {
    return system;
  }
  
  @Override
  public String getContextName() {
    return login.replace(".", "_")+"_"+host.replace(".", "_")+"_"+port;
  }

  public FTPEzFSConnection createConnection() throws IOException {
    return new FTPEzFSConnection(this);
  }

  private final String host;
  private final int port;
  private final String login;
  private final String password;
  private final String path;
  private final FTPEzFSConnectionMode mode;
  private final FTPEzFSFTPSystem system;
}

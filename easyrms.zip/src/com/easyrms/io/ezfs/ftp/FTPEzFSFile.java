package com.easyrms.io.ezfs.ftp;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.ezjmx.*;
import com.easyrms.util.net.*;

import java.io.*;
import java.util.*;
import org.apache.commons.net.ftp.*;

public class FTPEzFSFile extends AbstractRemoteEzFSFile<FTPEzFSFile> {
  
  FTPEzFSFile(FTPEzFSConnection fs) {
    super(ids);
    this.path = StringArrays.emptyStringArray;
    this.parent = null;
    this.isExist = true;
    this.length = 0;
    this.isExist = true;
    this.descriptor = new SimpleEzFileDescriptor(fs.getDescriptor(), null, "/", true, false, true);
    this.lastModification = null;
    this.fs = fs;
  }
  
  FTPEzFSFile(FTPEzFSFile file, String name, boolean isDirectory) throws IOException {
    super(ids);
    this.parent = file;
    this.fs = file.fs;
    this.path = StringArrays.merge(file.path, name);
    final FTPFile ftpFile = file.isExist() ? getAsFTPFile(name, file.getDescriptor()) : null;
    if (ftpFile != null)  {
      isDirectory = ftpFile.isDirectory();
    }
    this.isExist = true;
    this.descriptor = new SimpleEzFileDescriptor(fs.getDescriptor(), name, file.descriptor.getPath() + name + (isDirectory ? "/" : ""), isDirectory, !isDirectory, false);
    this.length = (ftpFile == null) ? 0 : ftpFile.getSize();
    this.lastModification = (ftpFile == null) 
      ? null 
      : (ftpFile.getTimestamp() == null) 
        ? StampUtil.getNow() 
        : new SimpleDateAccessor(ftpFile.getTimestamp().getTimeInMillis());
    this.isExist = (ftpFile != null);
  }
  
  private FTPFile getAsFTPFile(String name, EzFSFileDescriptor descriptor) throws IOException {
    final FTPClient client = fs.startCommand("Describe", descriptor.getPath()+name);
    synchronized (client) {
      try {
        final int count = goWorkingDirectoryParent(client);
        try {
          final FTPFile[] files = FtpUtil.listFiles(client, false);
          for (int i = 0, n = files.length; i < n; i++) {
            final FTPFile file = files[i];
            if (name.equals(file.getName())) {
              return file;
            }
          }
          return null;
        }
        finally {
          ungoWorkingDirectoryParent(client, count);
        }
      }
      finally {
        fs.endCommand();
      }
    }
  }
  
  FTPEzFSFile(FTPEzFSFile file, FTPFile ftpFile) throws IOException {
    super(ids);
    this.parent = file;
    this.fs = file.fs;
    final String name = ftpFile.getName();
    final boolean isDirectory = ftpFile.isDirectory();
    this.path = StringArrays.merge(file.path, name);
    this.isExist = true;
    this.descriptor = new SimpleEzFileDescriptor(fs.getDescriptor(), name, file.descriptor.getPath() + name + (isDirectory ? "/" : ""), isDirectory, !isDirectory, false);
    this.length = ftpFile.getSize();
    final Calendar timeStamp = ftpFile.getTimestamp();
    if (timeStamp == null) {
      EasyRMS.trace.log(this.descriptor.getConnectionDescriptor().getConnectionURL()+"/"+file.descriptor.getPath() + name + (isDirectory ? "/" : "")+" No Timestamp Use Now Instead");
    }
    this.lastModification = (timeStamp == null) ? StampUtil.getNow() : new SimpleDateAccessor(timeStamp.getTime());
  }

  public boolean delete() throws IOException {
    final FTPClient client = fs.startCommand("Delete", getDescriptor().toString());
    synchronized (client) {
      try {
        final int count = goWorkingDirectoryParent(client);
        try {
          return client.deleteFile(this.descriptor.getName());
        }
        finally {
          ungoWorkingDirectoryParent(client, count);
        }
      }
      finally {
        fs.endCommand();
      }
    }
  }
  
  String[] getPathList() {
    return this.path;
  }

  public EzFSFileAccess getAccess() throws IOException {
    return new FTPEzFSFileAccess(this);
  }

  public EzFSFile getParent() {
    return parent;
  }

  public FTPEzFSConnection getSystem() {
    return fs;
  }

  protected int goWorkingDirectoryParent(FTPClient client) throws IOException {
    return FtpUtil.changeWorkingDirectoryParent(client, path);
  }
  
  protected void ungoWorkingDirectoryParent(FTPClient client, int count) throws IOException {
    FtpUtil.changeToParentDirectory(client, count);
  }
  
  protected int goWorkingDirectory(FTPClient client) throws IOException {
    checkIsADirectory();
    return FtpUtil.changeWorkingDirectory(client, path);
  }

  protected void ungoWorkingDirectory(FTPClient client, int count) throws IOException {
    checkIsADirectory();
    FtpUtil.changeToParentDirectory(client, count);
  }

  private void checkIsADirectory() throws IOException {
    if (!descriptor.isDirectory()) {
      throw new IOException("Not A Directroy");
    }
  }
  
  public EzArray<FTPEzFSFile> list() throws IOException {
    if (descriptor.isFile()) {
      return noFTPEzFSFileArray;
    }
    synchronized (children) {
      final FTPClient client = fs.startCommand("List", getDescriptor().toString());
      synchronized (client) {
        try {
          final int count = goWorkingDirectory(client);
          try {
            final HashSetThreadPool setPool = HashSetThreadPool.threadPools.get();
            final HashSet<String> newChildren = setPool.get();
            try {
              final FTPFile[] files = FtpUtil.listFiles(client, true);
              for (int i = 0, n = files.length; i < n; i++) {
                final FTPFile child = files[i];
                if (child != null) {
                  newChildren.add(child.getName());
                  if (!this.children.containsKey(child.getName())) {
                    this.children.put(child.getName(), new FTPEzFSFile(this, child));
                  }
                }
                else if (ignoredNullFTPFile.isActive()) {
                  EasyRMS.trace.log("Invalid List Files "+descriptor.getName()+" On Connection "+fs.getDescriptor().getConnectionURL());
                }
                else {
                  throw new IOException("Invalid List Files "+descriptor.getName()+" On Connection "+fs.getDescriptor().getConnectionURL());
                }
              }
              if (this.children.isEmpty()) return noFTPEzFSFileArray;
              final HashSet<String> toRemove = setPool.get();
              try {
                for (final String oldChild : this.children.keySet()) {
                  if (!newChildren.contains(oldChild)) {
                    toRemove.add(oldChild); 
                  }
                }
                for (final String removeChild : toRemove) {
                  this.children.remove(removeChild);
                }
                if (this.children.isEmpty()) return noFTPEzFSFileArray;
                return new EzArrayList<FTPEzFSFile>(this.children.values());
              }
              finally {
                setPool.free(toRemove);
              }
            }
            finally {
              setPool.free(newChildren);
            }
          }
          finally {
            ungoWorkingDirectory(client, count);
          }
        }
        finally {
          fs.endCommand();
        }
      }
    }
  }

  public EzFSFileDescriptor getDescriptor() {
    return descriptor;
  }

  private final FTPEzFSConnection fs;
  private final String[] path;
  private final FTPEzFSFile parent;
  private final EzFSFileDescriptor descriptor;
  
  private final HashMap<String, FTPEzFSFile> children = new HashMap<String, FTPEzFSFile>(); 

  public boolean create() throws IOException {
    if (isExist()) return true;
    if (!parent.create()) return false;
    if (descriptor.isDirectory()) {
      final FTPClient client = fs.startCommand("Create Directory", getDescriptor().toString());
      synchronized (client) {
        try {
          final int count = goWorkingDirectoryParent(client);
          try {
            return client.makeDirectory(descriptor.getName());
          }
          finally {
            ungoWorkingDirectoryParent(client, count);
          }
        }
        finally {
          fs.endCommand();
        }
      }
    }
    else if (descriptor.isFile()) {
      final FTPClient client = fs.startCommand("Create File", getDescriptor().toString());
      synchronized (client) {
        try {
          final int count = goWorkingDirectoryParent(client);
          try {
            return client.storeFile(descriptor.getName(), new ByteArrayInputStream(new byte[0]));
          }
          finally {
            ungoWorkingDirectoryParent(client, count);
          }
        }
        finally {
          fs.endCommand();
        }
      }
    }
    return false;
  }

  public EzFSFile getDirectory(String name) throws IOException {
    return fs.findDirectory(this, name);
  }

  public EzFSFile getFile(String name) throws IOException {
    return fs.findFile(this, name);
  }

  @Override
  protected FTPEzFSFile newChild(String name, boolean isDirectory) throws IOException {
    return new FTPEzFSFile(this, name, isDirectory);
  }
  
  @Override
  protected void internalSynchStatus() {
    try {
      final FTPFile ftpFile = getAsFTPFile(descriptor.getName(), parent.getDescriptor());
      if (ftpFile == null) {
        this.isExist = false;
        this.length = 0;
        this.lastModification = null;
      }
      else {
        this.isExist = true;
        this.length = ftpFile.getSize();
        final Calendar timeStamp = ftpFile.getTimestamp();
        if (timeStamp == null) {
          EasyRMS.trace.log(this.descriptor.getConnectionDescriptor().getConnectionURL()+"/"+descriptor.getPath() +" No Timestamp Use Now Instead");
        }
        this.lastModification = (timeStamp == null) ? StampUtil.getNow() : new SimpleDateAccessor(timeStamp.getTime());
      }
    }
    catch (IOException asRuntime) {
      throw ExceptionUtils.newRuntimeException(asRuntime);
    }
    
      
    // TODO Auto-generated method stub
    
  }

  public static final EzArray<FTPEzFSFile> noFTPEzFSFileArray = new EzArray.NoEzArray<FTPEzFSFile>();
  private static final EzFlag ignoredNullFTPFile = new EzFlag("Ignore Null FTP File", PropertiesUtil.getBoolean("com.easyrms.io.ezfs.ftp.FTPEzFSFile.ignoredNullFTPFile", false));
  private static final IDGenerator ids = new IDGenerator("AbstractEzFileFTP."+System.nanoTime());

}
package com.easyrms.io.ezfs.ftp;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.ezjmx.*;
import com.easyrms.util.net.*;

import java.io.*;
import org.apache.commons.net.ftp.*;


public class FTPEzFSFileAccess extends AbstractRemoteEzFSFileAccess<FTPEzFSFile> {

  FTPEzFSFileAccess(FTPEzFSFile ftpFile) throws IOException {
    super(ftpFile);
  }
  
  @Override
  protected void loadTmpFile(ValidatedFile file) throws IOException {
    final FTPEzFSConnection connection = this.remoteFSFile.getSystem();
    final FTPClient client = connection.startCommand("Read File", this.remoteFSFile.getDescriptor().toString());
    synchronized (client) {
      try {
        final int count = this.remoteFSFile.goWorkingDirectoryParent(client);
        try {
          StreamUtils.create(file);
          final String fileName = remoteFSFile.getDescriptor().getName();
          final FTPFile[] files = FtpUtil.listFiles(client, false);
          for (int i = 0, n = files.length; i < n; i++) {
            final FTPFile fileI = files[i];
            if (fileI != null) {
              final String fileIName = fileI.getName();
              if (fileIName.equals(fileName)) {
                client.setFileType(FTPClient.BINARY_FILE_TYPE);
                client.setFileTransferMode(FTPClient.BINARY_FILE_TYPE);
                try (final FileOutputStream fout = StreamUtils.newFileOutputStream(file)) {
                  if (!client.retrieveFile(fileName, fout)) {
                    throw new IOException("Cannot Save File");
                  }
                  fout.flush();
                }
                break;
              }
            }
          }
        }
        finally {
          this.remoteFSFile.ungoWorkingDirectoryParent(client, count);
        }
      }
      finally {
        connection.endCommand();
      }
    }
  }

  @Override
  protected void saveTmpFile(ValidatedFile file) throws IOException {
    final FTPEzFSConnection connection = this.remoteFSFile.getSystem();
    final FTPClient client = connection.startCommand("Read File", this.remoteFSFile.getDescriptor().toString());
    synchronized (client) {
      try {
        final int count = this.remoteFSFile.goWorkingDirectoryParent(client);
        try {
          final String sourceName = this.remoteFSFile.getDescriptor().getName();
          final String sourceNameTmp = sourceName + writingSuffix;
          if (!sourceNameTmp.equals(sourceName)) {
            final FTPFile[] files = FtpUtil.listFiles(client, false);
            for (int i = 0, n = files.length; i < n; i++) {
              final FTPFile fileI = files[i];
              if (fileI != null) {
                final String fileIName = fileI.getName();
                if (sourceNameTmp.equals(fileIName) || sourceName.equals(fileIName)) {
                  if (!client.deleteFile(fileIName)) {
                    throw new IOException("Cannot Save File");
                  }
                }
              }
            }
          }
          final long size = file.getLength();
          client.enterLocalPassiveMode();
          client.setFileType(FTPClient.BINARY_FILE_TYPE);
          client.setFileTransferMode(FTPClient.BINARY_FILE_TYPE);
          final InputStream fis = StreamUtils.newFileInputStream(file);
          try {
            if (!client.storeFile(sourceNameTmp, fis)) {
              throw new IOException("Cannot Save File");
            }
          }
          finally {
            StreamUtils.closeNotCatch(fis);
          }
          if (completePendingCommand.booleanValue()) {
            client.completePendingCommand();
          }
          if (!sourceNameTmp.equals(sourceName)) {
            boolean isFileTmpFound = false;
            final FTPFile[] files = FtpUtil.listFiles(client, true);
            for (int i = 0, n = files.length; i < n; i++) {
              final FTPFile fileI = files[i];
              if (fileI != null && sourceNameTmp.equals(fileI.getName())) {
                isFileTmpFound = true;
                if (fileI.getSize() != size) {
                  throw new IOException("Save File Is Incomplete Bad Size");
                }
                if (!client.rename(sourceNameTmp, sourceName)) {
                  throw new IOException("Save File Is Incomplete Bad Rename");
                }
                break;
              }
            }
            if (!isFileTmpFound) {
              throw new IOException("Save File Is Incomplete");
            }
          }
          if (completePendingCommand.booleanValue()) {
            client.completePendingCommand();
          }
        }
        finally {
          this.remoteFSFile.ungoWorkingDirectoryParent(client, count);
        }
      }
      finally {
        connection.endCommand();
      }
    }
  }

  private final String writingSuffix = ".writing";
  private static final EzFlag completePendingCommand = new EzFlag("Execute completePendingCommand (Test, To Be Removed)", false);
}
package com.easyrms.io.ezfs.ftp;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;

public class FTPEzFSDriver implements EzFSDriver {

  public FTPEzFsConnectionDescriptor getConnectionDescriptor(String prefix, String url) {
    final int slashIndex = url.indexOf("/");
    final String path = (slashIndex >= 0) ? url.substring(slashIndex) : "/";
    url = (slashIndex >= 0) ? url.substring(0, slashIndex) : url;
    final int atIndex = url.lastIndexOf("@");
    final String userPassword = (atIndex <= 0) ? null : url.substring(0, atIndex);
    final String hostPort = (atIndex < 0) ? url : url.substring(atIndex+1);
    final String user;
    final String password;
    if (userPassword == null) {
      user = null;
      password = null;
    }
    else {
      final int colonIndex = userPassword.indexOf(":");
      user = (colonIndex < 0) ? userPassword : userPassword.substring(0, colonIndex);
      password = (colonIndex < 0) ? null : userPassword.substring(colonIndex+1);
    }
    final String host;
    final int port;
    {
      final int colonIndex = hostPort.indexOf(":");
      host = (colonIndex < 0) ? hostPort : hostPort.substring(0, colonIndex);
      port = MathUtils.parseInt((colonIndex < 0) ? null : hostPort.substring(colonIndex+1), 21);
    }
    final FTPEzFSConnection.FTPEzFSFTPSystem system;
    if (prefix.endsWith(unixSuffix)) {
      system = FTPEzFSConnection.FTPEzFSFTPSystem.UNIX;
      prefix = prefix.substring(0, prefix.length()-unixSuffix.length());
    }
    else if (prefix.endsWith(ntSuffix)) {
      system = FTPEzFSConnection.FTPEzFSFTPSystem.NT;
      prefix = prefix.substring(0, prefix.length()-ntSuffix.length());
    }
    else {
      system = FTPEzFSConnection.FTPEzFSFTPSystem.AUTO;
    }
    final FTPEzFSConnection.FTPEzFSConnectionMode mode;
    if (prefix.endsWith(fullpassiveSuffix)) {
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.FULLPASSIVE;
    }
    else if (prefix.endsWith(localpassiveSuffix)) { 
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.LOCALPASSIVE;
    }
    else if (prefix.endsWith(remotepassiveSuffix)) { 
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.REMOTEPASSIVE;
    }
    else {
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.ACTIVE;
    }
    return new FTPEzFsConnectionDescriptor(
      host, 
      port, 
      user, 
      password, 
      path, 
      mode,
      system);
  }
  
  public FTPEzFSConnection getConnection(String prefix, String url) throws IOException {
    try {
      final FTPEzFsConnectionDescriptor connectionDescriptor = getConnectionDescriptor(prefix, url);
      if (connectionDescriptor == null) throw new IllegalArgumentException("Cannot Find Parameter For URL "+url);
      return connectionDescriptor.createConnection();
    }
    catch (IOException forward) {
      throw forward;
    }
    catch (Throwable forward) {
      throw new IOException(forward);
    }
  }

  public EzArray<String> getEzFSPrefix() {
    return prefixes;
  }
  
  static final String unixSuffix = ".unix";
  static final String ntSuffix = ".nt";
  static final String fullpassiveSuffix = ".passive";
  static final String localpassiveSuffix = ".localpassive";
  static final String remotepassiveSuffix = ".remotepassive";
  static final String ftpPrefix = "ftp";
  static final EzArray<String> prefixes;
  static String getPrefix(FTPEzFSConnection.FTPEzFSConnectionMode mode, FTPEzFSConnection.FTPEzFSFTPSystem system) {
    String prefix = ftpPrefix;
    if (mode == FTPEzFSConnection.FTPEzFSConnectionMode.FULLPASSIVE) {
      prefix += fullpassiveSuffix;
    }
    else if (mode == FTPEzFSConnection.FTPEzFSConnectionMode.LOCALPASSIVE) {
      prefix += localpassiveSuffix;
    }
    else if (mode == FTPEzFSConnection.FTPEzFSConnectionMode.REMOTEPASSIVE) {
      prefix += remotepassiveSuffix;
    }
    if (system == FTPEzFSConnection.FTPEzFSFTPSystem.UNIX) {
      prefix += unixSuffix;
    }
    else if (system == FTPEzFSConnection.FTPEzFSFTPSystem.NT) {
      prefix += ntSuffix;
    }
    return prefix;
  }
  static FTPEzFSConnection.FTPEzFSFTPSystem getSystem(String prefix) {
    return (FTPEzFSConnection.FTPEzFSFTPSystem)getSystemOrMode(prefix, true);
  }
  static FTPEzFSConnection.FTPEzFSConnectionMode getMode(String prefix) {
    return (FTPEzFSConnection.FTPEzFSConnectionMode)getSystemOrMode(prefix, false);
  }
  static Object getSystemOrMode(String prefix, boolean isSystem) {
    final FTPEzFSConnection.FTPEzFSFTPSystem system;
    if (prefix.endsWith(unixSuffix)) {
      system = FTPEzFSConnection.FTPEzFSFTPSystem.UNIX;
      prefix = prefix.substring(0, prefix.length()-unixSuffix.length());
    }
    else if (prefix.endsWith(ntSuffix)) {
      system = FTPEzFSConnection.FTPEzFSFTPSystem.NT;
      prefix = prefix.substring(0, prefix.length()-ntSuffix.length());
    }
    else {
      system = FTPEzFSConnection.FTPEzFSFTPSystem.AUTO;
    }
    final FTPEzFSConnection.FTPEzFSConnectionMode mode;
    if (prefix.endsWith(fullpassiveSuffix)) {
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.FULLPASSIVE;
    }
    else if (prefix.endsWith(localpassiveSuffix)) { 
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.LOCALPASSIVE;
    }
    else if (prefix.endsWith(remotepassiveSuffix)) { 
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.REMOTEPASSIVE;
    }
    else {
      mode = FTPEzFSConnection.FTPEzFSConnectionMode.ACTIVE;
    }
    return isSystem ? system : mode;
  }
  static {
    final EzArrayList<String> combinations = new EzArrayList<String>();
    for (FTPEzFSConnection.FTPEzFSConnectionMode mode : FTPEzFSConnection.FTPEzFSConnectionMode.values()) {
      for (FTPEzFSConnection.FTPEzFSFTPSystem system : FTPEzFSConnection.FTPEzFSFTPSystem.values()) {
        combinations.add(getPrefix(mode, system));
      }
    }
    prefixes = combinations;
  }
}

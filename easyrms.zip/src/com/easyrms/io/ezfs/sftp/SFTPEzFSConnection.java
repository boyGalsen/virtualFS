package com.easyrms.io.ezfs.sftp;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.net.*;

import com.jcraft.jsch.*;

import java.io.*;
import java.util.*;


public class SFTPEzFSConnection extends AbstractEzFSConnection<SFTPEzFSFile> implements RemoteClient {
  
  SFTPEzFSConnection(SFTPEzFsConnectionDescriptor descriptor) throws IOException {
    final String host = descriptor.getHost();
    final int port= descriptor.getPort();
    final String login= descriptor.getLogin();
    final String password = descriptor.getPassword();
    final String path = descriptor.getPath();
    final String knownHost= descriptor.getKnownHost();
    final String dsaFile = descriptor.getDsaFile();
    final String dsaPassPhrase = descriptor.getDsaPassPhrase();
    final String tmpWritingPath = descriptor.getTmpWritingPath();
    this.host = login+"@"+host;
    this.port = port;
    sftpEzFileRoot = new SFTPEzFSFile(this);
    this.descriptor = descriptor;
    RemoteClientManager.reference.register(this);
    jsch = new JSch();
    try {
      if (knownHost != null) {
        jsch.setKnownHosts(new ByteArrayInputStream(knownHost.getBytes()));
        if (dsaFile != null) {
          if (StringComparator.isNotNull(dsaPassPhrase)) {
            jsch.addIdentity(dsaFile , dsaPassPhrase.getBytes());
          }
          else {
            jsch.addIdentity(dsaFile);
          }
        }
      }
      session = jsch.getSession(login, host, port);
      if (dsaFile == null) {
        session.setPassword(password);
      }
      session.connect();
      final Channel channel = session.openChannel("sftp");
      channel.connect();
      sftpChannel = (ChannelSftp)channel;
      if (StringComparator.isNotNull(path) && ((!SFTPEzFSDriver.isIgnoredSlashPath && "/".equals(path)) || !"/".equals(path))) {
        sftpChannel.cd(path);
      }
      if (tmpWritingPath == null) {
        this.tmpWritingPath = null;
      }
      else {
        this.tmpWritingPath = StringArrays.toStringArray(tmpWritingPath, "/");
      }
    }
    catch (JSchException e) {
      throw new IOException(e);
    }
    catch (SftpException e) {
      throw new IOException(e);     
    }
  }
  
  @Override
  public final SFTPEzFSFile getRoot() {
    return sftpEzFileRoot;
  }
  
  ChannelSftp startCommand(String command, String parameter) {
    synchronized (this.commands) {
      this.commands.push(new Tuple3<String, String, DateAccessor>(command, parameter, StampUtil.getNow()));
    }
    return sftpChannel;
  }
  
  void endCommand() {
    synchronized (this.commands) {
      this.commands.pop();
    }
  }
  
  @Override
  protected void internalClose() throws IOException {
    try {
      try {
        try {
          sftpChannel.exit();
        }
        finally {
          session.disconnect();
        }
      }
      finally {
        super.internalClose();
      }
    }
    finally {
      RemoteClientManager.reference.remove(this);
    }
  }
  
  public EzFSConnectionDescriptor getDescriptor() {
    return descriptor;
  }
  
  
  public RemoteClientState getState() {
    final String id = getID();
    final String host = this.host;
    final int port = this.port;
    final DateAccessor startDate = getStartDate();
    final Tuple3<String, String, DateAccessor> commandValue;
    synchronized (this.commands) {
      commandValue = this.commands.isEmpty() ? null : this.commands.peek();
    }
    final String command = (commandValue == null) ? null : commandValue.get0();
    final String parameter = (commandValue == null) ? null : commandValue.get1();
    final DateAccessor commandDate = (commandValue == null) ? null : commandValue.get2();
    return new RemoteClientState() {

      public String getCommand() {
        return command;
      }

      public String getCommandParameter() {
        return parameter;
      }

      public int getConnectionTimeOut() {
        return 0;
      }

      public String getContext() {
        return null;
      }

      public String getID() {
        return id;
      }

      public int getPort() {
        return port;
      }

      public String getProtocol() {
        return SFTPEzFSDriver.prefix;
      }

      public String getServer() {
        return host;
      }

      public int getSoTimeOut() {
        return 0;
      }

      public DateAccessor getStartDate() {
        return startDate;
      }
      
      public DateAccessor getCommandStart() {
        return commandDate;
      }
    };
  }

  protected final boolean isWithTmpWritingDirectory() {
    return (tmpWritingPath != null && tmpWritingPath.length > 0);
  }
  
  protected int goTmpWritingDirectory(ChannelSftp client) throws IOException {
    int count = 0;
    try {
      for (int i = 0, n = tmpWritingPath.length; i < n; i++, count++) {
        final String pathI = tmpWritingPath[i];
        if (StringComparator.isNotNull(pathI)) {
          client.cd(pathI);
        }
      }
    }
    catch (SftpException e) {
      throw new IOException(e);
    }
    
    return count;
  }
  protected void ungoDirectory(ChannelSftp client, int count) throws IOException {
    try {
      for (int i = 0; i < count; i++) {
        client.cd("..");
      }
    }
    catch (SftpException e) {
      throw new IOException(e);
    }
  }
  private final JSch jsch;
  private final ChannelSftp sftpChannel;
  private final String[] tmpWritingPath;
  private final Session session;
  private final SFTPEzFSFile sftpEzFileRoot;
  private final SimpleEzFSConnectionDescriptor descriptor;
  private final Stack<Tuple3<String, String, DateAccessor>> commands = new Stack<Tuple3<String, String, DateAccessor>>();
  
  private final String host;
  private final int port;
  
}
package com.easyrms.io.ezfs.sftp;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;

import com.jcraft.jsch.*;
import com.jcraft.jsch.ChannelSftp.*;
import java.io.*;
import java.util.*;

public class SFTPEzFSFile extends AbstractRemoteEzFSFile<SFTPEzFSFile> {
  
  SFTPEzFSFile(SFTPEzFSConnection fs) {
    super(ids);
    this.path = StringArrays.emptyStringArray;
    this.parent = null;
    this.length = 0;
    this.isExist = true;
    this.descriptor = new SimpleEzFileDescriptor(fs.getDescriptor(), null, "/", true, false, true);
    this.lastModification = null;
    this.lastAccess = null;
    this.fs = fs;
  }  
  SFTPEzFSFile(SFTPEzFSFile file, String name, boolean isDirectory) throws IOException {
    super(ids);
    this.parent = file;
    this.fs = file.fs;
    this.path = StringArrays.merge(file.path, name);
    final SftpATTRS ftpFile = file.isExist() ? getAsSFTPFile(name, file.getDescriptor()) : null;
    if (ftpFile != null) {
      isDirectory = ftpFile.isDir();
      this.lastModification = new SimpleDateAccessor(ftpFile.getMTime()*1000);
      this.lastAccess = new SimpleDateAccessor(ftpFile.getATime()*1000);;
      this.length = ftpFile.getSize();
      this.isExist = true;
    }
    this.descriptor = new SimpleEzFileDescriptor(fs.getDescriptor(), name, file.getDescriptor().getPath() + name + (isDirectory ? "/" : ""), isDirectory, !isDirectory, false);
  }
  
  private SftpATTRS getAsSFTPFile(String name, EzFSFileDescriptor descriptor) throws IOException {
    final ChannelSftp client = fs.startCommand("Describe", descriptor.getPath()+name);
    try {
      final int count = goWorkingDirectoryParent(client);
      try {
        final Vector<?> lsEntries = client.ls("*");
        if (lsEntries != null) {
          for (int i=0, n = lsEntries.size(); i < n; i++) {
            final Object obj = lsEntries.elementAt(i);
            if (obj instanceof LsEntry) {
              final LsEntry ls = (LsEntry)obj;
              if (name.equals(ls.getLongname())) {
                return ls.getAttrs();
              }
            }
          }
        }
      }
      catch(SftpException e) {
        throw new IOException(e);
      }
      finally {
        ungoWorkingDirectoryParent(client, count);
      }
      return null;
    }
    finally {
      fs.endCommand();
    }
  }
  
  SFTPEzFSFile(SFTPEzFSFile file, LsEntry ftpFile) {
    super(ids);
    this.parent = file;
    this.fs = file.fs;
    final String name = ftpFile.getFilename();
    final SftpATTRS ftpFileAttributs = ftpFile.getAttrs();
    final boolean isDirectory = ftpFileAttributs.isDir();
    this.path = StringArrays.merge(file.path, name);
    this.isExist = true;
    this.descriptor = new SimpleEzFileDescriptor(fs.getDescriptor(), name, file.descriptor.getPath() + name + (isDirectory ? "/" : ""), isDirectory, !isDirectory, false);
    this.length = ftpFileAttributs.getSize();
    final long modificationTimeInselec = ftpFileAttributs.getMTime();
    this.lastModification = new SimpleDateAccessor(modificationTimeInselec*1000);
    final long accessTimeInselec = ftpFileAttributs.getATime();
    this.lastAccess = new SimpleDateAccessor(accessTimeInselec*1000);
  }
  
  public boolean delete() throws IOException {
    final ChannelSftp client = fs.startCommand("Delete", getDescriptor().toString());
    try {
      final int count = goWorkingDirectoryParent(client);
      try {
        client.rm(this.descriptor.getName());
        return true;
      }
      catch (SftpException e) {
        throw new IOException(e);
      }
      finally {
        ungoWorkingDirectoryParent(client, count);
      }
    }
    finally {
      fs.endCommand();
    }
  }
  
  String[] getPathList() {
    return this.path;
  }
  
  public EzFSFileAccess getAccess() throws IOException {
    return new SFTPEzFSFileAccess(this);
  }
  
  public EzFSFile getParent() {
    return parent;
  }
  
  public SFTPEzFSConnection getSystem() {
    return fs;
  }
  
  protected final boolean isWithTmpWritingDirectory() {
    return fs.isWithTmpWritingDirectory();
  }
  
  protected void ungoDirectory(ChannelSftp client, int count) throws IOException {
    fs.ungoDirectory(client, count);
  }
  
  protected String getInternalFullPathNameForRename() {
    final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
    final StringBuilder internalName = bufferPool.get();
    try {
      for (int i = 0, n = path.length; i < n; i++) {
        internalName.append("/").append(StringComparator.NVL(path[i]));   
      }
      return internalName.toString();
    }
    finally {
      bufferPool.free(internalName);
    }
  }
  
  
  protected int goTmpWritingDirectory(ChannelSftp client) throws IOException {
    return fs.goTmpWritingDirectory(client);
  }
  
  protected int goWorkingDirectoryParent(ChannelSftp client) throws IOException {
    return goWorkingDirectory(client, false);
  }
  
  protected void ungoWorkingDirectoryParent(ChannelSftp client, int count) throws IOException {
    ungoWorkingDirectory(client, false, count);
  }
  
  protected int goWorkingDirectory(ChannelSftp client) throws IOException {
    checkIsADirectory();
    return goWorkingDirectory(client, true);
  }

  protected void ungoWorkingDirectory(ChannelSftp client, int count) throws IOException {
    checkIsADirectory();
    ungoWorkingDirectory(client, true, count);
  }

  private void checkIsADirectory() throws IOException {
    if (!descriptor.isDirectory()) {
      throw new IOException("Not A Directroy");
    }
  }
  
  private void ungoWorkingDirectory(ChannelSftp client, boolean withLastElement, int count) throws IOException {
    fs.ungoDirectory(client, count);
  }  
  private int goWorkingDirectory(ChannelSftp client, boolean withLastElement) throws IOException {
    int count = 0;
    try {
      for (int i = 0, n = path.length-(withLastElement ? 0 : 1); i < n; i++, count++) {
        final String pathI = path[i];
        if (StringComparator.isNotNull(pathI)) {
          client.cd(pathI);
          count++;
        }
      }
    }
    catch (SftpException e) {
      throw new IOException(e);
    }
    return count;
  }

  
  public EzArray<SFTPEzFSFile> list() throws IOException {
    if (descriptor.isFile()) {
      return noSFTPEzFSFileArray;
    }
    synchronized (children) {
      final ChannelSftp client = fs.startCommand("List", getDescriptor().toString());
      try {
        final int count = goWorkingDirectory(client);
        try {
          final HashSetThreadPool setPool = HashSetThreadPool.threadPools.get();
          final HashSet<String> newChilds = setPool.get();
          try {
            final Vector<?> lsEntries = client.ls("*");
            if (lsEntries != null) {
              for (int i = 0, n = lsEntries.size(); i < n; i++) {
                final Object obj = lsEntries.elementAt(i);
                if (obj instanceof LsEntry) {
                  final LsEntry ls = (LsEntry)obj;
                  final String name = ls.getFilename();
                  newChilds.add(name);
                  if (!this.children.containsKey(name)) {
                    this.children.put(name, new SFTPEzFSFile(this, ls));
                  }
                }
              }
            }
            if (this.children.isEmpty()) return noSFTPEzFSFileArray;
            final HashSet<String> toRemove = setPool.get();
            try {
              for (final String oldChild : this.children.keySet()) {
                if (!newChilds.contains(oldChild)) {
                  toRemove.add(oldChild); 
                }
              }
              for (final String removeChild : toRemove) {
                this.children.remove(removeChild);
              }
              if (this.children.isEmpty()) return noSFTPEzFSFileArray;
              return new EzArrayList<SFTPEzFSFile>(this.children.values());
            }
            finally {
              setPool.free(toRemove);
            }
          }
          catch (SftpException e) {
            throw new IOException(e);
          }
          finally {
            setPool.free(newChilds);
          }
        }
        finally {
          ungoWorkingDirectory(client, count);
        }
      }
      finally {
        fs.endCommand();
      }
    }
  }
  
  public DateAccessor getLastAccess() {
    synchStatus();
    return lastAccess;
  }
  
  public EzFSFileDescriptor getDescriptor() {
    return descriptor;
  }
  
  private final SFTPEzFSConnection fs;
  private final String[] path;
  private final SFTPEzFSFile parent;
  private final EzFSFileDescriptor descriptor;
  
  private DateAccessor lastAccess;
  private final HashMap<String, SFTPEzFSFile> children = new HashMap<String, SFTPEzFSFile>(); 
  
  public boolean create() throws IOException {
    final ChannelSftp client = fs.startCommand(getDescriptor().isDirectory() ? "Create Directory" : "Create File", getDescriptor().toString());
    try {
      if (isExist()) return true;
      if (!parent.create()) return false;
      final int count = goWorkingDirectoryParent(client);
      try {
        if (descriptor.isDirectory()) {
          final String name = descriptor.getName();
          final Vector<?> lsEntries = client.ls("*");
          for (int i = 0, n = lsEntries.size(); i <n; i++) {
            final Object obj = lsEntries.elementAt(i);
            if (obj instanceof LsEntry) {
              final LsEntry ls = (LsEntry)obj;
              final String entryName = ls.getFilename();
              if (StringComparator.equals(name, entryName)) {
                return true;
              }
            }
          }
          client.mkdir(name);
          return true;
        }
        else if (descriptor.isFile()) {
          client.put(new ByteArrayInputStream(new byte[0]), descriptor.getName(), ChannelSftp.OVERWRITE);
          return true;
        }
      }
      finally {
        ungoWorkingDirectoryParent(client, count);
      }
    }
    catch (SftpException e) {
      throw new IOException(e);
    }
    finally {
      fs.endCommand();
    }
    return false;
  }
  
  public EzFSFile getDirectory(String name) throws IOException {
    return fs.findDirectory(this, name);
  }
  
  public EzFSFile getFile(String name) throws IOException {
    return fs.findFile(this, name);
  }
  
  @Override
  protected SFTPEzFSFile newChild(String name, boolean isDirectory) throws IOException {
    return new SFTPEzFSFile(this, name, isDirectory);
  }
  
  @Override
  protected void internalSynchStatus() {
    try {
      final SftpATTRS ftpFile = getAsSFTPFile(descriptor.getName(), parent.getDescriptor());
      if (ftpFile == null) {
        this.isExist = false;
        this.length = 0;
        this.lastModification = null;
        this.lastAccess = null;
      }
      else {
        this.isExist = true;
        this.lastModification = new SimpleDateAccessor(ftpFile.getMTime()*1000);
        this.lastAccess = new SimpleDateAccessor(ftpFile.getATime()*1000);;
        this.length = ftpFile.getSize();
      }
    }
    catch (IOException asRuntime) {
      throw ExceptionUtils.newRuntimeException(asRuntime);
    }
    
      
    // TODO Auto-generated method stub
    
  }
  
  private static final IDGenerator ids = new IDGenerator("AbstractEzFileSFTP."+System.nanoTime());
  public static final EzArray<SFTPEzFSFile> noSFTPEzFSFileArray = new EzArray.NoEzArray<SFTPEzFSFile>();
}
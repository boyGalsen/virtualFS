package com.easyrms.io.ezfs.sftp;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.comparator.*;

import java.io.*;

public class SFTPEzFsConnectionDescriptor extends SimpleEzFSConnectionDescriptor {

  public SFTPEzFsConnectionDescriptor(
    String host, 
    int port, 
    String login, 
    String password, 
    String path, 
    String knownHost, 
    String tmpWritingPath) 
  {
    this(host, port, login, password, path, knownHost, null, null, tmpWritingPath);
  }
  
  public SFTPEzFsConnectionDescriptor(
    String host, 
    int port, 
    String login, 
    String password, 
    String path, 
    String knownHost, 
    String dsaFile, 
    String dsaPassPhrase,
    String tmpWritingPath)
  {
    super(SFTPEzFSDriver.prefix+"://" + StringComparator.NVL(login) + ":" + StringComparator.NVL(password) + "@" + StringComparator.NVL(host) + ":" + port + StringComparator.NVL(path),
      SFTPEzFSDriver.prefix+"://" + StringComparator.NVL(login) + "@" + StringComparator.NVL(host) + ":" + port + StringComparator.NVL(path));
    this.host = host;
    this.port = port;
    this.login = login;
    this.password = password;
    this.path = path;
    this.knownHost = knownHost;
    this.dsaFile = dsaFile;
    this.dsaPassPhrase = dsaPassPhrase;
    this.tmpWritingPath = tmpWritingPath;
  }
  
  public String getDsaFile() {
    return dsaFile;
  }
  public String getDsaPassPhrase() {
    return dsaPassPhrase;
  }
  public String getHost() {
    return host;
  }
  public String getKnownHost() {
    return knownHost;
  }
  public String getLogin() {
    return login;
  }
  public String getPassword() {
    return password;
  }
  public String getPath() {
    return path;
  }
  public int getPort() {
    return port;
  }
  public String getTmpWritingPath() {
    return tmpWritingPath;
  }
  
  public SFTPEzFSConnection createConnection() throws IOException {
    return new SFTPEzFSConnection(this);
  }

  @Override
  public String getContextName() {
    return login.replace(".", "_")+"_"+host.replace(".", "_")+"_"+port;
  }

  private final String host; 
  private final int port;
  private final String login; 
  private final String password; 
  private final String path;
  private final String knownHost;
  private final String dsaFile;
  private final String dsaPassPhrase;
  private final String tmpWritingPath;
}

package com.easyrms.io.ezfs.sftp;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;
import java.util.*;
import com.jcraft.jsch.*;
import com.jcraft.jsch.ChannelSftp.*;

public class SFTPEzFSFileAccess extends AbstractRemoteEzFSFileAccess<SFTPEzFSFile> {
  
  SFTPEzFSFileAccess(SFTPEzFSFile ftpFile) {
    super(ftpFile);
  }
  
  @Override
  protected void loadTmpFile(ValidatedFile file) throws IOException {
    final SFTPEzFSConnection connection = this.remoteFSFile.getSystem();
    final ChannelSftp client = connection.startCommand("Read File", this.remoteFSFile.getDescriptor().toString());
    try {
      final int count = this.remoteFSFile.goWorkingDirectoryParent(client);
      try {
        final String fileName = remoteFSFile.getDescriptor().getName();
        try {
          final Vector<?> lsEntries = client.ls("*");
          if (lsEntries != null) {
            for (int i=0, n = lsEntries.size(); i < n; i++) {
              final Object obj = lsEntries.elementAt(i);
              if (obj instanceof LsEntry) {
                final LsEntry ls = (LsEntry)obj;
                final String name = ls.getFilename();
                if (fileName.equals(name)) {
                  final FileOutputStream fout = StreamUtils.newFileOutputStream(file);
                  try {
                    client.get(fileName, fout);
                  }
                  finally {
                    StreamUtils.closeNotCatch(fout);
                  }
                  break;
                }
              }
            }
          }
        }
        catch (SftpException e) {
          throw new IOException(e);
        }
      }
      finally {
        this.remoteFSFile.ungoWorkingDirectoryParent(client, count);
      } 
    }
    finally {
      connection.endCommand();
    }
  }
  
  @Override
  protected void saveTmpFile(ValidatedFile file) throws IOException {
    final SFTPEzFSConnection connection = this.remoteFSFile.getSystem();
    final ChannelSftp client = connection.startCommand("Write File", this.remoteFSFile.getDescriptor().toString());
    try {
      final boolean isWithTmpWritingDirectory = this.remoteFSFile.isWithTmpWritingDirectory();
      final int count = isWithTmpWritingDirectory 
        ? this.remoteFSFile.goTmpWritingDirectory(client)
        : this.remoteFSFile.goWorkingDirectoryParent(client);
      try {
        final String sourceName = isWithTmpWritingDirectory 
          ? this.remoteFSFile.getInternalFullPathNameForRename()
          : this.remoteFSFile.getDescriptor().getName();
        final String sourceNameTmp = writingPrefix + this.remoteFSFile.getDescriptor().getName() + writingSuffix;
        if (!sourceNameTmp.equals(sourceName)) {
          try {
            client.rm(sourceNameTmp);
          }
          catch (SftpException ignored) {
          }        
        }
        try (final InputStream fis = StreamUtils.newFileInputStream(file)) {
          client.put(fis, sourceNameTmp, ChannelSftp.OVERWRITE);
        }
        if (!sourceNameTmp.equals(sourceName)) {
          try {
            client.rm(sourceName);
          }
          catch (SftpException ignored) {
          }
          client.rename(sourceNameTmp, sourceName);
        }
      }
      catch (SftpException e) {
        throw new IOException(e);
      }
      finally {
        this.remoteFSFile.ungoDirectory(client, count);
      }
    }
    finally {
      connection.endCommand();
    }
  }
  
  private static final String writingSuffix = ".writing";
  private static final String writingPrefix = "";
}

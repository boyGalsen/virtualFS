package com.easyrms.io.ezfs.sftp;

import com.easyrms.cache.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.util.*;

public class SFTPEzFSDriver implements EzFSDriver {
  
  public EzFSConnection getConnection(String prefix, String url) throws IOException {
    try {
      final SFTPEzFsConnectionDescriptor connectionDescriptor = getConnectionDescriptor(prefix, url);
      if (connectionDescriptor == null) {
        throw new IllegalArgumentException("Cannot Find Parameter For URL "+url);
      }
      return connectionDescriptor.createConnection();
    }
    catch (IOException forward) {
      throw forward;
    }
    catch (Throwable forward) {
      throw new IOException(forward);
    }
  }
  
  public SFTPEzFsConnectionDescriptor getConnectionDescriptor(String prefix, String url) {
    return sftpDescriptors.get(url);
  }

  public EzArray<String> getEzFSPrefix() {
    return prefixs;
  }
  
  private final Cache<String, SFTPEzFsConnectionDescriptor> sftpDescriptors = Caches.newCacheInstance(new Creator<String, SFTPEzFsConnectionDescriptor>() {
    
    public SFTPEzFsConnectionDescriptor create(String url) {
      try {
        final String[] splitted = url.split("[|]");
        String urlFS = splitted[0];
        
        final int slashIndex = urlFS.indexOf("/");
        final String path = (slashIndex >= 0) ? urlFS.substring(slashIndex) : "/";
        urlFS = (slashIndex >= 0) ? urlFS.substring(0, slashIndex) : urlFS;
        final int atIndex = urlFS.lastIndexOf("@");
        final String userPassword = (atIndex <= 0) ? null : urlFS.substring(0, atIndex);
        final String hostPort = (atIndex < 0) ? urlFS : urlFS.substring(atIndex+1);
        
        final String user;
        final String password;
        if (userPassword == null) {
          user = null;
          password = null;
        }
        else {
          final int pointIndex = userPassword.indexOf(":");
          user = (pointIndex < 0) ? userPassword : userPassword.substring(0, pointIndex);
          password = (pointIndex < 0) ? null : userPassword.substring(pointIndex+1);
        }
        
        final int pointIndex = hostPort.indexOf(":");
        final String host = (pointIndex < 0) ? hostPort : hostPort.substring(0, pointIndex);
        final int port = MathUtils.parseInt((pointIndex < 0) ? null : hostPort.substring(pointIndex+1), 22);
        
        final int n = splitted.length;
        if (n == 1 && sftpConfigPath != null) {
          final String prefixFileName = host + "-" + port + (StringComparator.isNull(user) ? "": "-"+user);
          final ValidatedFile propertiesFile = StreamUtils.getChildFile(sftpConfigPath, prefixFileName + ".properties");
          if (propertiesFile.isExists()) {
            final Properties properties = new Properties();
            try (final FileInputStream propertyFile = StreamUtils.newFileInputStream(propertiesFile)) {
              properties.load(propertyFile);
              final String tmpWritingPath = properties.getProperty("tmpWritingPath", null);
              final String sshKnownHost = properties.getProperty("knownhosts", null);
              final ValidatedFile dsaFile = StreamUtils.getChildFile(sftpConfigPath, prefixFileName + ".dsa");
              if (dsaFile.isExists()) {
                final String dsaPassPhrase = properties.getProperty("passphrase", null);
                final String dsaFileName = dsaFile.getFullName().replace('\\', '/');
                return new SFTPEzFsConnectionDescriptor(host, port, user, password, path, sshKnownHost, dsaFileName, dsaPassPhrase, tmpWritingPath);
              }
              return new SFTPEzFsConnectionDescriptor(host, port, user, password, path, sshKnownHost, tmpWritingPath);
            }
          }
        }
        final String sshKnownHost  = (n > 1) ? splitted[1] : null;
        final String dsaFile       = (n > 2) ? splitted[2] : null;
        final String dsaPassPhrase = (n > 3) ? splitted[3] : null;
        return new SFTPEzFsConnectionDescriptor(host, port, user, password, path, sshKnownHost, dsaFile, dsaPassPhrase, null);
      }
      catch (IOException forward) {
        throw ExceptionUtils.newRuntimeException(forward);
      }
    }
  });
  
  private final ValidatedDirectory sftpConfigPath = StreamUtils.NVL(
    StreamUtils.getDirectory(PropertiesUtil.getString("com.easyrms.io.ezfs.sftp.SFTPEzFSDriver.sftpConfigPath", null)),
    StreamUtils.getGlobalConfigDirectory(PropertiesUtil.getString("SFTPCONFIGPATH", "sftp")));

  static final String prefix = "sftp";
  static final EzArray<String> prefixs = new EzArray.AsArray<String>(prefix);
  
  static final boolean isIgnoredSlashPath = PropertiesUtil.getBoolean("com.easyrms.io.ezfs.sftp.isIgnoredSlashPath", true);
  static final boolean isIgnoredSlashPathGoToFile = PropertiesUtil.getBoolean("com.easyrms.io.ezfs.sftp.isIgnoredSlashPathGoToFile", isIgnoredSlashPath);

}
package com.easyrms.io.ezfs;

import java.io.*;

/**
 * 
 * Pointer to a file without real connection to this file (with name, path ...)
 *
 */
public interface EzFSFileDescriptor extends Serializable {

  EzFSConnectionDescriptor getConnectionDescriptor();
  
  String getName();
  String getPath();
  
  boolean isDirectory();
  boolean isFile();
  boolean isRoot();
}

package com.easyrms.io.ezfs;


public interface EzFSFilter {

  public boolean accept(EzFSFile file);
  
  public static final EzFSFilter noFilter = new EzFSFilter() {
    
    public boolean accept(EzFSFile file) {
      return true;
    }
  };
}

package com.easyrms.io.ezfs.status;

import com.easyrms.io.ezfs.status.EzFSFileStatus.*;


public interface EzFSFileMessageListener {

  EzFSFileStatusDetail process(EzFSFileStatus file);
  EzFileStatusComparator getComparator();  
}

package com.easyrms.io.ezfs.status;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.util.*;

public interface EzFileStatusComparator extends Comparator<EzFSFileStatus> {

  
  EzFileStatusComparator nameComparator = new EzFileStatusComparator() {

    public int compare(EzFSFileStatus o1, EzFSFileStatus o2) {
      if (o1 == o2) return 0;
      if (o1 == null) return 1;
      if (o2 == null) return -1;
      final EzFSFile f1 = o1.getFile();
      final EzFSFile f2 = o2.getFile();
      final int nameCompare = StringComparator.compareLowerCase(f1.getDescriptor().getName(), f2.getDescriptor().getName());
      if (nameCompare != 0) return nameCompare;
      final int pathCompare = StringComparator.compareLowerCase(f1.getDescriptor().getPath(), f2.getDescriptor().getPath());
      if (pathCompare != 0) return pathCompare;
      try {
        final DateAccessor o1LastModification = f1.getLastModifiation();
        final DateAccessor o2LastModification = f2.getLastModifiation();
        if (o1LastModification == o2LastModification) return 0;
        if (o1LastModification == null) return 1;
        if (o2LastModification == null) return -1;
        return NumberComparator.compare(o1LastModification.getTime(), o2LastModification.getTime());
      }
      catch (IOException exception) {
        throw ExceptionUtils.newRuntimeException(exception); 
      }
    }
    
  };
  
  EzFileStatusComparator timeComparator = new EzFileStatusComparator() {

    public int compare(EzFSFileStatus o1, EzFSFileStatus o2) {
      if (o1 == o2) return 0;
      if (o1 == null) return 1;
      if (o2 == null) return -1;
      final EzFSFile f1 = o1.getFile();
      final EzFSFile f2 = o2.getFile();
      try {
        final DateAccessor o1LastModification = f1.getLastModifiation();
        final DateAccessor o2LastModification = f2.getLastModifiation();
        if (o1LastModification != o2LastModification) {
          if (o1LastModification == null) return 1;
          if (o2LastModification == null) return -1;
          int timeCompare = NumberComparator.compare(o1LastModification.getTime(), o2LastModification.getTime());
          if (timeCompare != 0) return timeCompare;
        }
      }
      catch (IOException exception) {
        throw ExceptionUtils.newRuntimeException(exception); 
      }
      final int nameCompare = StringComparator.compareLowerCase(f1.getDescriptor().getName(), f2.getDescriptor().getName());
      if (nameCompare != 0) return nameCompare;
      final int pathCompare = StringComparator.compareLowerCase(f1.getDescriptor().getPath(), f2.getDescriptor().getPath());
      return pathCompare;
    }
    
  };
}

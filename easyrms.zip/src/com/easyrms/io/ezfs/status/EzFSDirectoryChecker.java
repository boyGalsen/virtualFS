package com.easyrms.io.ezfs.status;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.status.EzFSFileStatus.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.executor.*;
import com.easyrms.util.ezjmx.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.*;

public class EzFSDirectoryChecker extends AbstractEzProcessPeriodic {
  
  public static final EzFSDirectoryChecker getEzFSDirectoryChecker(String context, EzFSConnectionDescriptor connectionDescriptor, PeriodicContextType periodicContextType, int delay) throws IOException {
    final EzFSFileDescriptor fileDescriptor = EzFS.reference.get().getRoot(connectionDescriptor);
    return getEzFSDirectoryChecker(context, fileDescriptor, periodicContextType, delay);
  } 
  public static final EzFSDirectoryChecker getEzFSDirectoryChecker(String context, EzFSFileDescriptor fileDescriptor, PeriodicContextType periodicContextType, int delay) throws IOException {
    final Tuple4<String, EzFSFileDescriptor, Integer, Integer> key = Tuple.getTuple(
      context, 
      fileDescriptor, 
      IntegerCache.get(periodicContextType.getNbThread()), 
      IntegerCache.get(delay));
    EzFSDirectoryChecker checker = checkers.get(key);
    if (checker == null) {
      checker = new EzFSDirectoryChecker(context, fileDescriptor, periodicContextType, delay);
      EzFS.reference.get().mount(context, fileDescriptor);
      checkers.put(key, checker);
    }
    return checker;
  }
  
  private static final HashMap<Tuple4<String, EzFSFileDescriptor, Integer, Integer>, EzFSDirectoryChecker> checkers = new HashMap<Tuple4<String, EzFSFileDescriptor, Integer, Integer>, EzFSDirectoryChecker>();

  private EzFSDirectoryChecker(String context, EzFSFileDescriptor directory, PeriodicContextType periodicContextType, int delay) throws IOException {
    super(null, "EzFS Check "+directory.getConnectionDescriptor().getDisplayConnectionURL()+(directory.getPath().startsWith("/") ? "" : "/")+directory.getPath(), periodicContextType, delay, true);
    this.context = context;
    if (!directory.isDirectory()) throw new IOException("Invalid Directory");
    this.directory = directory;
    this.childsCache = !isWithEzFSCheckerSerialisation 
      ? null
      : new SerialisableReference<HashMap<String, EzFSDirectoryCheckerStatus>>(StringUtil.computeKeyString("singleDirectoryCheck", getName(), null)) {
  
        @Override
        protected HashMap<String, EzFSDirectoryCheckerStatus> createDefault() {
          return new HashMap<String, EzFSDirectoryCheckerStatus>();
        }        
      };
    this.childs = isWithEzFSCheckerSerialisation ? childsCache.get() : new HashMap<String, EzFSDirectoryCheckerStatus>();
  }
  
  public void addEzFSFileMessageListener(EzFSFileMessageListener listener) {
    synchronized (multiListeners) {
      synchronized (listeners) {
        if (listeners.addIfNotExist(listener)) {
          checkStopStart();
        }
      }
    }
  }
  public void removedEzFSFileMessageListener(EzFSFileMessageListener listener) {
    synchronized (multiListeners) {
      synchronized (listeners) {
        if (listeners.remove(listener)) {
          checkStopStart();
        }
      }
    }
  }
  private final EzArrayCopyOnWriteList<EzFSFileMessageListener> listeners = new EzArrayCopyOnWriteList<EzFSFileMessageListener>();
  private final EzArrayCopyOnWriteList<EzFSFileMultiMessageListener> multiListeners = new EzArrayCopyOnWriteList<EzFSFileMultiMessageListener>();

  
  public void addEzFSFileMultiMessageListener(EzFSFileMultiMessageListener listeners) {
    synchronized (multiListeners) {
      synchronized (listeners) {
        if (multiListeners.addIfNotExist(listeners)) {
          checkStopStart();
        }
      }
    }
  }
  public void removeEzFSFileMultiMessageListener(EzFSFileMultiMessageListener listeners) {
    synchronized (multiListeners) {
      synchronized (listeners) {
        if (multiListeners.remove(listeners)) {
          checkStopStart();
        }
      }
    }
  }
  
  @Override
  public void start() {
    synchronized (multiListeners) {
      synchronized (listeners) {
        isPreviousStart = true;
        checkStopStart();
      }
    }
  }

  @Override
  public void stop() {
    synchronized (multiListeners) {
      synchronized (listeners) {
        super.stop();
        isPreviousStart = false;
      }
    }
  }

  private void checkStopStart() {
    if (multiListeners.getCount() <= 0 && listeners.getCount() <= 0) {
      if (isRunning()) super.stop();
    }
    else {
      if (!isRunning() && isPreviousStart) {
        super.start();
      }
    }
  }
  
  
  public DateAccessor getLastCompleteRun() {
    return lastCompleteRun.get();
  }
  
  public Tuple2<DateAccessor, String> getLastErrorRun() {
    return lastErrorRun.get();
  }
  
  public int getNbRun() {
    return nbRun.intValue();
  }

  public int getNbCompleteRun() {
    return nbCompleteRun.intValue();
  }

  public int getNbErrorRun() {
    return nbErrorRun.intValue();
  }

  private final LongAdder nbRun = new LongAdder();  
  private final LongAdder nbCompleteRun = new LongAdder();  
  private final LongAdder nbErrorRun = new LongAdder();  
  private final AtomicReference<DateAccessor> lastCompleteRun = new AtomicReference<DateAccessor>(null);  
  private final AtomicReference<Tuple2<DateAccessor, String>> lastErrorRun = new AtomicReference<Tuple2<DateAccessor, String>>(null);  
  
  @Override
  protected synchronized void runPeriodicProcess() {
    try {
      final EzArray<? extends EzFSFileMessageListener> listeners = this.listeners.getList();
      final EzArray<? extends EzFSFileMultiMessageListener> multiListeners = this.multiListeners.getList();
      if (multiListeners.getCount() > 0 || listeners.getCount() > 0) {
        final EzFSConnectionDescriptor connectionDescriptor = directory.getConnectionDescriptor();
        final EzFSConnection connection = EzFS.reference.get().getConnection(connectionDescriptor);
        final EzTreeTask<?> currentTask = EzTreeTask.findCurrentTask();
        if (currentTask != null) {
          currentTask.setContextParameter("ezfs.contextName", connectionDescriptor.getContextName());
          currentTask.setContextParameter("ezfs.connectionURL", connectionDescriptor.getConnectionURL());
          currentTask.setContextParameter("ezfs.descriptionURL", connectionDescriptor.getDisplayConnectionURL());
          currentTask.setContextParameter("ezfs.name", directory.getName());
          currentTask.setContextParameter("ezfs.path", directory.getPath());
        }
        try {
          final EzFSFile file = connection.find(directory);
          final EzArray<? extends EzFSFile> listedChilds = file.list();
          final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
          final EzArrayList<EzFSFileStatus> toListenerChilds = arrayPool.get();
          try {
            final boolean isTraceActivate = trace.isActive();
            for (int i = 0, n = listedChilds.getCount(); i < n; i++) {
              final EzFSFile listedChild = listedChilds.get(i);
              final String name = listedChild.getDescriptor().getName();
              EzFSDirectoryCheckerStatus status = childs.get(name);
              if (status == null || ((status.status.getFlag() == EzFSFileStatusFlag.INTERNAL_CHECK_STATE) && (status.size != listedChild.getLength() || status.lastModification.getTime()/1600 != listedChild.getLastModifiation().getTime()/1600))) {
                if (isTraceActivate) {
                  trace.traceln("add check = "+name+";"+listedChild.getLength()+";"+ebXMLDateFormat.referenceFormat(listedChild.getLastModifiation())+"<=>"+(status == null ? "" : ebXMLDateFormat.referenceFormat(status.lastModification))+";"+(listedChild.getLastModifiation().getTime()/1600)+"<=>"+(status == null ? "" : ""+(status.lastModification.getTime()/1600)));
                }
                status = new EzFSDirectoryCheckerStatus(name, listedChild.getLength(), listedChild.getLastModifiation(), EzFSFileStatus.INTERNAL_STATE_DETAIL);
                childs.put(name, status);
              }
              else {
                if (status.status.getFlag() == EzFSFileStatusFlag.INTERNAL_CHECK_STATE) {
                  status.status = EzFSFileStatus.UNKNOWN_STATE_DETAIL;
                }
                if (isTraceActivate) {
                  trace.traceln("add listen = "+name+";"+listedChild.getLength()+";"+ebXMLDateFormat.referenceFormat(listedChild.getLastModifiation()));
                }
                toListenerChilds.add(new EzFSFileStatus(context, listedChild, status.status));
              }
            }
            if (toListenerChilds.size() > 0) {
              final EzFSFileStatus[] statusList = toListenerChilds.toArray(EzFSFileStatus.noStatus);
              {
                final int m = listeners.getCount();
                if (m > 0) {
                  final EzFileStatusComparator statusComparator = listeners.get(0).getComparator();
                  if (statusComparator != null) {
                    Arrays.sort(statusList, statusComparator);
                  }
                  for (int i = 0, n = statusList.length; i < n; i++) {
                    final EzFSFileStatus status = statusList[i];
                    EzFSFileStatusDetail resultStatus = EzFSFileStatus.UNKNOWN_STATE_DETAIL;
                    for (int j = 0; j < m; j++) {
                      final EzFSFileMessageListener listener = listeners.get(j);
                      //??
                      resultStatus = EzFSFileStatus.getMostImportantStatus(resultStatus, listener.process(status));
                    }
                    final EzFSDirectoryCheckerStatus checkStatus = childs.get(status.getFile().getDescriptor().getName());
                    checkStatus.status = resultStatus;
                  }
                }
              }
              {
                final int m = multiListeners.getCount();
                if (m > 0) {
                  final int n = statusList.length;
                  EzFSFileStatusDetail[] resultStatus = new EzFSFileStatusDetail[n];
                  Arrays.fill(resultStatus, EzFSFileStatus.UNKNOWN_STATE_DETAIL);
                  for (int j = 0; j < m; j++) {
                    final EzFSFileMultiMessageListener listener = multiListeners.get(j);
                    //???
                    final EzFSFileStatusDetail[] resultStatusI = listener.process(statusList);
                    for (int i = 0; i < n ; i++) {
                      resultStatus[i] = EzFSFileStatus.getMostImportantStatus(resultStatus[i], resultStatusI[i]);
                    }
                  }
                  for (int i = 0; i < n ; i++) {
                    final EzFSDirectoryCheckerStatus checkStatus = childs.get(statusList[i].getFile().getDescriptor().getName());
                    checkStatus.status = resultStatus[i];
                  }
                }
              }
            }
          }
          finally {
            arrayPool.free(toListenerChilds);
          }
        }
        finally {
          connection.close();
          if (currentTask != null) {
            currentTask.setContextParameter("ezfs.contextName", null);
            currentTask.setContextParameter("ezfs.connectionURL", null);
            currentTask.setContextParameter("ezfs.descriptionURL", null);
            currentTask.setContextParameter("ezfs.name", null);
            currentTask.setContextParameter("ezfs.path", null);
          }

        }
        nbRun.increment();
        nbCompleteRun.increment();
        lastCompleteRun.set(StampUtil.getNow());
        if (isWithEzFSCheckerSerialisation) {
          this.childsCache.saveCurrent();
        }
      }
    }
    catch (RuntimeException ignored) {
      trace.log(ignored);
      nbRun.increment();
      nbErrorRun.increment();
      lastErrorRun.set(new Tuple2<DateAccessor, String>(StampUtil.getNow(), ignored.getCause() == null ? ExceptionUtils.getMessage(ignored) : ExceptionUtils.getMessage(ignored.getCause())));
      throw ignored;
    }
    catch (Throwable throwable) {
      trace.log(throwable, true);
      nbRun.increment();
      nbErrorRun.increment();
      lastErrorRun.set(new Tuple2<DateAccessor, String>(StampUtil.getNow(), ExceptionUtils.getMessage(throwable)));
      throw ExceptionUtils.newRuntimeException(throwable);
    }
  }  

  private final String context;
  private final EzFSFileDescriptor directory;
  private boolean isPreviousStart = false;
  
  private final SerialisableReference<HashMap<String, EzFSDirectoryCheckerStatus>> childsCache;
  private final HashMap<String, EzFSDirectoryCheckerStatus> childs;
  
  private static class EzFSDirectoryCheckerStatus  {
    
    public EzFSDirectoryCheckerStatus(String name, long size, DateAccessor lastModification, EzFSFileStatusDetail status) {
      //this.name = name;
      this.size = size;
      this.lastModification = lastModification;
      this.status = status;
    }
    
    //private final String name;
    private long size; 
    private DateAccessor lastModification; 
    private EzFSFileStatusDetail status;
  }
  
  private static final boolean isWithEzFSCheckerSerialisation = PropertiesUtil.getBoolean("isWithEzFSCheckerSerialisation", true);
}
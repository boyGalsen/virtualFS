package com.easyrms.io.ezfs.status;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.status.EzFSFileStatus.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.ezjmx.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.*;


public class EzFSMultiDirectoryChecker extends AbstractEzProcessPeriodic {

  public static EzFSMultiDirectoryChecker getEzFSDirectoryChecker(String context, EzFSConnectionDescriptor connectionDescriptor, int delayInMilliSeconds) throws IOException {
    return getEzFSDirectoryChecker(context, connectionDescriptor, delayInMilliSeconds, true);
  }  
  public static EzFSMultiDirectoryChecker getEzFSDirectoryChecker(EzJMXGroup parent, String context, EzFSConnectionDescriptor connectionDescriptor, int delayInMilliSeconds) throws IOException {
    return getEzFSDirectoryChecker(parent, context, connectionDescriptor, delayInMilliSeconds, true);
  }
  public static EzFSMultiDirectoryChecker getEzFSDirectoryChecker(String context, EzFSConnectionDescriptor connectionDescriptor, int delayInMilliSeconds, boolean isWithSubDirectory) throws IOException {
    return getEzFSDirectoryChecker(null, context, connectionDescriptor, delayInMilliSeconds, isWithSubDirectory);
  }
  public static EzFSMultiDirectoryChecker getEzFSDirectoryChecker(EzJMXGroup parent, String context, EzFSConnectionDescriptor connectionDescriptor, int delayInMilliSeconds, boolean isWithSubDirectory) throws IOException {
    return getEzFSDirectoryChecker(parent, context, connectionDescriptor, PeriodicContextType.BOXES, delayInMilliSeconds, isWithSubDirectory);
  }
  public static EzFSMultiDirectoryChecker getEzFSDirectoryChecker(EzJMXGroup parent, String context, EzFSConnectionDescriptor connectionDescriptor, PeriodicContextType periodicContextType, int delayInMilliSeconds, boolean isWithSubDirectory) throws IOException {
    final EzFSFileDescriptor fileDescriptor = EzFS.reference.get().getRoot(connectionDescriptor);
    final Tuple5<String, EzFSFileDescriptor, Integer, Integer, Boolean> key = Tuple.getTuple(context, fileDescriptor, IntegerCache.get(periodicContextType.getNbThread()), IntegerCache.get(delayInMilliSeconds), Boolean.valueOf(isWithSubDirectory));
    EzFSMultiDirectoryChecker checker = checkers.get(key);
    if (checker == null) {
      checker = new EzFSMultiDirectoryChecker(parent, context, fileDescriptor, periodicContextType, delayInMilliSeconds, isWithSubDirectory);
      checkers.put(key, checker);
      checkerByName.put(checker.getName(), checker);
      checkerByID.put(IntegerCache.get(checker.getID()), checker);
    }
    return checker;
  }
  
  public static EzFSMultiDirectoryChecker find(String name) {
    return checkerByName.get(name);
  }
  
  public static EzFSMultiDirectoryChecker find(int id) {
    return checkerByID.get(IntegerCache.get(id));
  }
  
  public EzFSMultiDirectoryCheckerSnapshot generateSnapshot() {
    return new EzFSMultiDirectoryCheckerSnapshot(this);
  }

  public static final EzFSMultiDirectoryChecker getEzFSDirectoryChecker(String context, EzFSFileDescriptor fileDescriptor, int delayInMilliSeconds) throws IOException {
    return getEzFSDirectoryChecker(context, fileDescriptor, delayInMilliSeconds, true);
  }  
  public static final EzFSMultiDirectoryChecker getEzFSDirectoryChecker(EzJMXGroup parent, String context, EzFSFileDescriptor fileDescriptor, int delayInMilliSeconds) throws IOException {
    return getEzFSDirectoryChecker(parent, context, fileDescriptor, delayInMilliSeconds, true);
  }
  public static final EzFSMultiDirectoryChecker getEzFSDirectoryChecker(String context, EzFSFileDescriptor fileDescriptor, int delayInMilliSeconds, boolean isWithSubDirectory) throws IOException {
    return getEzFSDirectoryChecker(null, context, fileDescriptor, delayInMilliSeconds, isWithSubDirectory);
  }  
  public static final EzFSMultiDirectoryChecker getEzFSDirectoryChecker(EzJMXGroup parent, String context, EzFSFileDescriptor fileDescriptor, int delayInMilliSeconds, boolean isWithSubDirectory) throws IOException {
    return getEzFSDirectoryChecker(parent, context, fileDescriptor, PeriodicContextType.BOXES, delayInMilliSeconds, isWithSubDirectory);
  }
  public static final EzFSMultiDirectoryChecker getEzFSDirectoryChecker(
    EzJMXGroup parent, 
    String context, 
    EzFSFileDescriptor fileDescriptor, 
    PeriodicContextType periodicContextType, 
    int delayInMilliSeconds, 
    boolean isWithSubDirectory) throws IOException 
  {
    final Tuple5<String, EzFSFileDescriptor, Integer, Integer, Boolean> key = Tuple.getTuple(
      context, 
      fileDescriptor, 
      IntegerCache.get(periodicContextType.getNbThread()), 
      IntegerCache.get(delayInMilliSeconds), 
      Boolean.valueOf(isWithSubDirectory));
    EzFSMultiDirectoryChecker checker = checkers.get(key);
    if (checker == null) {
      checker = new EzFSMultiDirectoryChecker(parent, context, fileDescriptor, periodicContextType, delayInMilliSeconds, isWithSubDirectory);
      checkers.put(key, checker);
      EzFS.reference.get().mount(context, fileDescriptor);
      checkerByName.put(checker.getName(), checker);
      checkerByID.put(IntegerCache.get(checker.getID()), checker);
    }
    return checker;
  }
  
  public static EzArray<? extends EzFSMultiDirectoryChecker> getCheckers() {
    return new EzArrayList<EzFSMultiDirectoryChecker>(checkers.values());
  }
  
  public static EzArray<? extends EzFSMultiDirectoryCheckerSnapshot> getCheckerSnapshots() {
    final EzArrayList<EzFSMultiDirectoryCheckerSnapshot> snapshots = new EzArrayList<EzFSMultiDirectoryCheckerSnapshot>();
    for (final EzFSMultiDirectoryChecker checker : checkers.values()) {
      snapshots.add(new EzFSMultiDirectoryCheckerSnapshot(checker));
    }
    return snapshots;
  }
  
  private static final HashMap<Tuple5<String, EzFSFileDescriptor, Integer, Integer, Boolean>, EzFSMultiDirectoryChecker> checkers = new HashMap<Tuple5<String, EzFSFileDescriptor, Integer, Integer, Boolean>, EzFSMultiDirectoryChecker>();
  private static final HashMap<String, EzFSMultiDirectoryChecker> checkerByName = new HashMap<String, EzFSMultiDirectoryChecker>();
  private static final HashMap<Integer, EzFSMultiDirectoryChecker> checkerByID = new HashMap<Integer, EzFSMultiDirectoryChecker>();
  
  private EzFSMultiDirectoryChecker(EzJMXGroup parent, String context, EzFSFileDescriptor directory, PeriodicContextType periodicContextType, int delay, boolean isWithSubDirectory) throws IOException {
    super(parent, "EzFS Check "+directory.getConnectionDescriptor().getDisplayConnectionURL()+(directory.getPath().startsWith("/") ? "" : "/")+directory.getPath(), periodicContextType, delay, false);
    this.context = context;
    if (!directory.isDirectory()) {
      throw new IOException("Invalid Directory");
    }
    this.directory = directory;
    this.id = ids.getNewValue();
    this.isWithSubDirectory = isWithSubDirectory;
    this.childrenCache = !isWithEzFSCheckerSerialisation 
      ? null
      : new SerialisableReference<HashMap2D<String, String, EzFSFileDescriptorStatus>>(StringUtil.computeKeyString("multiDirectoryCheck", getName(), null)) {
  
          @Override
          protected HashMap2D<String, String, EzFSFileDescriptorStatus> createDefault() {
            return new HashMap2D<String, String, EzFSFileDescriptorStatus>();
          }        
        };
    this.children = isWithEzFSCheckerSerialisation ? childrenCache.get() : new HashMap2D<String, String, EzFSFileDescriptorStatus>();
  }
  
  public String getContext() {
    return context;
  }
  
  public EzFSFileDescriptor getDirectory() {
    return directory;
  }
  
  public void addEzFSFileMessageListener(EzFSFileMessageListener listener) {
    synchronized (listeners) {
      if (listeners.addIfNotExist(listener)) {
        checkStopStart();
      }
    }
  }
  public void removeEzFSFileMessageListener(EzFSFileMessageListener listener) {
    synchronized (listeners) {
      if (listeners.remove(listener)) {
        checkStopStart();
      }
    }
  }
  private final EzArrayCopyOnWriteList<EzFSFileMessageListener> listeners = new EzArrayCopyOnWriteList<EzFSFileMessageListener>(); 
  
  public void addEzFSFileMultiMessageListener(EzFSFileMultiMessageListener listener) {
    synchronized (listeners) {
      if (multiListeners.addIfNotExist(listener)) {
        checkStopStart();
      }
    }
  }
  public void removeEzFSFileMultiMessageListener(EzFSFileMultiMessageListener listener) {
    synchronized (listeners) {
      if (multiListeners.remove(listener)) {
        checkStopStart();
      }
    }
  }
  
  @Override
  public void start() {
    synchronized (listeners) {
      isPreviousStart = true;
      checkStopStart();
    }
  }

  @Override
  public void stop() {
    synchronized (listeners) {
      super.stop();
      isPreviousStart = false;
    }
  }
  
  private void checkStopStart() {
    if (multiListeners.getCount() <= 0 && listeners.getCount() <= 0) {
      super.stop();
    }
    else if (isPreviousStart) {
      super.start();
    }
  }
  private boolean isPreviousStart = false;
  
  private final EzArrayCopyOnWriteList<EzFSFileMultiMessageListener> multiListeners = new EzArrayCopyOnWriteList<EzFSFileMultiMessageListener>(); 
  
  public int getFileCount() {
    return 0;
  }
  public int getUnknownFileCount() {
    return 0;
  }
  public int getOkFileCount() {
    return 0;
  }
  public int getErrorFileCount() {
    return 0;
  }
  public int getWarningFileCount() {
    return 0;
  }
  public int getIgnoredFileCount() {
    return 0;
  }
  
  @Override
  protected synchronized void runPeriodicProcess() {
    try {
      final EzArray<? extends EzFSFileMultiMessageListener> multiListeners;
      final EzArray<? extends EzFSFileMessageListener> listeners;
      synchronized (this.listeners) {
        multiListeners = this.multiListeners.getList();
        listeners = this.listeners.getList();
      }
      if (multiListeners.getCount() > 0 || listeners.getCount() > 0) {
        final EzFSConnection connection = EzFS.reference.get().getConnection(directory.getConnectionDescriptor());
        try {
          final EzFSFile file = connection.find(directory);
          trace.log("start list files "+context+"->"+file.getDescriptor().getPath(), false);
          final EzArray<? extends EzFSFile> listedChilds = file.list();
          trace.log("find "+listedChilds.getCount()+" files "+context+"->"+file.getDescriptor().getPath(), false);
          final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
          final EzArrayList<EzFSFileStatus> toListenerChilds = arrayPool.get();
          try {
            final boolean isTraceActivate = trace.isActive();
            for (int i = 0, n = listedChilds.getCount(); i < n; i++) {
              final EzFSFile listedChild = listedChilds.get(i);
              if (listedChild.getDescriptor().isDirectory()) {
                if (isWithSubDirectory) {
                  final String context = listedChild.getDescriptor().getName(); 
                  trace.log("start list files subdirectory "+context+"->"+listedChild.getDescriptor().getPath(), false);
                  final EzArray<? extends EzFSFile> subListedChilds = listedChild.list();
                  trace.log("find "+listedChilds.getCount()+" files subdirectory "+context+"->"+listedChild.getDescriptor().getPath(), false);
                  for (int j = 0, m = subListedChilds.getCount(); j < m; j++) {
                    final EzFSFile subListedChild = subListedChilds.get(j);
                    if (subListedChild.getDescriptor().isFile()) {
                      final String name = subListedChild.getDescriptor().getName();
                      final EzFSFileDescriptorStatus descriptorStatus = children.get(context, name);
                      EzFSDirectoryCheckerStatus status = (descriptorStatus == null) ? null : descriptorStatus.getStatus();
                      if (status == null || ((status.status.getFlag() == EzFSFileStatusFlag.INTERNAL_CHECK_STATE) && (status.size != subListedChild.getLength() || status.lastModification.getTime()/1600 != subListedChild.getLastModifiation().getTime()/1600))) {
                        if (isTraceActivate) {
                          trace.traceln("add check = "+context+"->"+name+";"+subListedChild.getLength()+";"+ebXMLDateFormat.referenceFormat(subListedChild.getLastModifiation())+"<=>"+(status == null ? "" : ebXMLDateFormat.referenceFormat(status.lastModification))+";"+(subListedChild.getLastModifiation().getTime()/1600)+"<=>"+(status == null ? "" : ""+(status.lastModification.getTime()/1600)));
                        }
                        status = new EzFSDirectoryCheckerStatus(name, subListedChild.getLength(), subListedChild.getLastModifiation(), EzFSFileStatus.INTERNAL_STATE_DETAIL);
                        children.put(context, name, new EzFSFileDescriptorStatus(context, subListedChild.getDescriptor(), status));
                      }
                      else {
                        if (status.status.getFlag() == EzFSFileStatusFlag.INTERNAL_CHECK_STATE) {
                          status.status = EzFSFileStatus.UNKNOWN_STATE_DETAIL;
                        }
                        if (isTraceActivate) {
                          trace.traceln("add listen = "+context+"->"+name+";"+subListedChild.getLength()+";"+ebXMLDateFormat.referenceFormat(subListedChild.getLastModifiation()));
                        }
                        toListenerChilds.add(new EzFSFileStatus(context, subListedChild, status.status));
                      }
                    }
                  }
                }
              }
              else if (listedChild.getDescriptor().isFile()) {
                final String name = listedChild.getDescriptor().getName();
                final EzFSFileDescriptorStatus descriptorStatus = children.get(context, name);
                EzFSDirectoryCheckerStatus status = (descriptorStatus == null) ? null : descriptorStatus.getStatus();
                if (status == null || ((status.status.getFlag() == EzFSFileStatusFlag.INTERNAL_CHECK_STATE) && (status.size != listedChild.getLength() || status.lastModification.getTime()/1600 != listedChild.getLastModifiation().getTime()/1600))) {
                  if (isTraceActivate) {
                    trace.traceln("add check = "+context+"->"+name+";"+listedChild.getLength()+";"+ebXMLDateFormat.referenceFormat(listedChild.getLastModifiation())+"<=>"+(status == null ? "" : ebXMLDateFormat.referenceFormat(status.lastModification))+";"+(listedChild.getLastModifiation().getTime()/1600)+"<=>"+(status == null ? "" : ""+(status.lastModification.getTime()/1600)));
                  }
                  status = new EzFSDirectoryCheckerStatus(name, listedChild.getLength(), listedChild.getLastModifiation(), EzFSFileStatus.INTERNAL_STATE_DETAIL);
                  children.put(context, name, new EzFSFileDescriptorStatus(context, listedChild.getDescriptor(), status));
                }
                else {
                  if (status.status.getFlag() == EzFSFileStatusFlag.INTERNAL_CHECK_STATE) {
                    status.status = EzFSFileStatus.UNKNOWN_STATE_DETAIL;
                  }
                  if (isTraceActivate) {
                    trace.traceln("add listen = "+context+"->"+name+";"+listedChild.getLength()+";"+ebXMLDateFormat.referenceFormat(listedChild.getLastModifiation()));
                  }
                  toListenerChilds.add(new EzFSFileStatus(context, listedChild, status.status));
                }
              }
            }
            if (toListenerChilds.size() > 0) {
              final EzFSFileStatus[] statusList = toListenerChilds.toArray(new EzFSFileStatus[toListenerChilds.size()]);
              {
                final int m = listeners.getCount();
                if (m > 0) {
                  final EzFileStatusComparator statusComparator = listeners.get(0).getComparator();
                  if (statusComparator != null) {
                    Arrays.sort(statusList, statusComparator);
                  }
                  for (int i = 0, n = statusList.length; i < n; i++) {
                    final EzFSFileStatus status = statusList[i];
                    EzFSFileStatusDetail resultStatus = EzFSFileStatus.UNKNOWN_STATE_DETAIL;
                    for (int j = 0; j < m; j++) {
                      final EzFSFileMessageListener listener = listeners.get(j);
                      resultStatus = EzFSFileStatus.getMostImportantStatus(resultStatus, listener.process(status));
                    }
                    final EzFSFileDescriptorStatus descriptorStatus = children.get(status.getContext(), status.getFile().getDescriptor().getName());
                    final EzFSDirectoryCheckerStatus checkStatus = (descriptorStatus == null) ? null : descriptorStatus.getStatus();
                    checkStatus.status = resultStatus;
                    if (resultStatus.getFlag() == EzFSFileStatusFlag.DELETED_STATE) {
                      try {
                        status.getFile().delete();
                      }
                      catch (Throwable ignored) {
                        trace.log(status.getFile().getDescriptor().toString(), ignored);
                      }
                    }
                  }
                }
              }
              {
                final int m = multiListeners.getCount();
                if (m > 0) {
                  EzFSFileStatusDetail[] resultStatus = new EzFSFileStatusDetail[statusList.length];
                  Arrays.fill(resultStatus, EzFSFileStatus.UNKNOWN_STATE_DETAIL);
                  for (int j = 0; j < m; j++) {
                    final EzFSFileMultiMessageListener listener = multiListeners.get(j); 
                    final EzFSFileStatusDetail[] resultStatusI = listener.process(statusList);
                    if (resultStatusI != null) {
                      for (int i = 0, n = resultStatusI.length; i < n ; i++) {
                        resultStatus[i] = EzFSFileStatus.getMostImportantStatus(resultStatus[i], resultStatusI[i]);
                      }
                    }
                  }
                  for (int i = 0, n = statusList.length; i < n ; i++) {
                    final EzFSFileStatus status = statusList[i];
                    final EzFSFileDescriptorStatus descriptorStatus = children.get(status.getContext(), status.getFile().getDescriptor().getName());
                    final EzFSDirectoryCheckerStatus checkStatus = (descriptorStatus == null) ? null : descriptorStatus.getStatus();
                    checkStatus.status = resultStatus[i];
                    if (resultStatus[i].getFlag() == EzFSFileStatusFlag.DELETED_STATE) {
                      status.getFile().delete();
                    }
                  }
                }
              }
            }
          }
          finally {
            arrayPool.free(toListenerChilds);
          }
        }
        finally {
          connection.close();
        }
      }
      nbRun.increment();
      nbCompleteRun.increment();
      lastCompleteRun.set(StampUtil.getNow());
      if (isWithEzFSCheckerSerialisation) {
        this.childrenCache.saveCurrent();
      }
    }
    catch (RuntimeException ignored) {
      trace.log(ignored);
      nbRun.increment();
      nbErrorRun.increment();
      lastErrorRun.set(new Tuple2<DateAccessor, String>(StampUtil.getNow(), ignored.getCause() == null ? ExceptionUtils.getMessage(ignored) : ExceptionUtils.getMessage(ignored.getCause())));
      throw ignored;
    }
    catch (Throwable throwable) {
      trace.log(throwable, true);
      nbRun.increment();
      nbErrorRun.increment();
      lastErrorRun.set(new Tuple2<DateAccessor, String>(StampUtil.getNow(), ExceptionUtils.getMessage(throwable)));
      throw ExceptionUtils.newRuntimeException(throwable);
    }
  }
  
  public int getID() {
    return id;
  }
  
  private final String context;
  private final EzFSFileDescriptor directory;
  private final int id;
  private final boolean isWithSubDirectory;
  private final HashMap2D<String, String, EzFSFileDescriptorStatus> children;
  private final SerialisableReference<HashMap2D<String, String, EzFSFileDescriptorStatus>> childrenCache;
  
  public static class EzFSDirectoryCheckerStatus implements Serializable {
    
    public EzFSDirectoryCheckerStatus(String name, long size, DateAccessor lastModification, EzFSFileStatusDetail status) {
      this.size = size;
      this.lastModification = lastModification;
      this.status = status;
    }
    
    public EzFSFileStatusDetail getStatus() {
      return status;
    }
    
    public long getSize() {
      return size;
    }
    
    public DateAccessor getLastModification() {
      return lastModification;
    }
    
    private long size; 
    private DateAccessor lastModification; 
    private EzFSFileStatusDetail status;
  }
  
  public DateAccessor getLastCompleteRun() {
    return lastCompleteRun.get();
  }
  
  public Tuple2<DateAccessor, String> getLastErrorRun() {
    return lastErrorRun.get();
  }
  
  public int getNbRun() {
    return nbRun.intValue();
  }

  public int getNbCompleteRun() {
    return nbCompleteRun.intValue();
  }

  public int getNbErrorRun() {
    return nbErrorRun.intValue();
  }

  private final LongAdder nbRun = new LongAdder();  
  private final LongAdder nbCompleteRun = new LongAdder();  
  private final LongAdder nbErrorRun = new LongAdder();  
  private final AtomicReference<DateAccessor> lastCompleteRun = new AtomicReference<DateAccessor>(null);  
  private final AtomicReference<Tuple2<DateAccessor, String>> lastErrorRun = new AtomicReference<Tuple2<DateAccessor, String>>(null);  
  
  public static class EzFSMultiDirectoryCheckerSnapshot {
    
    public static Comparator<EzFSMultiDirectoryCheckerSnapshot> contextComparator = new Comparator<EzFSMultiDirectoryCheckerSnapshot>() {

      public int compare(EzFSMultiDirectoryCheckerSnapshot o1, EzFSMultiDirectoryCheckerSnapshot o2) {
        return StringComparator.compare(o1.getContext(), o2.getContext());
      }
    };
    
    public EzFSMultiDirectoryCheckerSnapshot(EzFSMultiDirectoryChecker checker) {
      this.id = checker.getID();
      this.context = checker.getContext();
      this.directory = checker.getDirectory();
      this.name = checker.getName();
      this.lastStartRun = checker.getLastStartRun();
      this.isProcessing = checker.isProcessing();
      this.isRunning = checker.isRunning();
      this.nextStartRun = checker.getNextStartRun();
      this.lastComplete = checker.getLastCompleteRun();
      this.lastError = checker.getLastErrorRun();
      final EzFSFileDescriptorStatus[] status = checker.children.values().toArray(EzFSFileDescriptorStatus.noEzFSFileDescriptorStatus);
      this.files = new EzArrayList<EzFSFileDescriptorStatus>(status.length);
      for (int i = 0, n = status.length; i < n; i++) {
        final EzFSFileDescriptorStatus statusI = status[i];
        this.files.add(statusI);
        final EzFSDirectoryCheckerStatus checkStatus = statusI.getStatus();
        if (checkStatus != null) {
          fileCount++;
          switch (checkStatus.getStatus().getFlag()) {
            case UNKNOWN_STATE : unknownFileCount++;  break;
            case IGNORED_STATE : ignoredFileCount++;  break;
            case OK_STATE : okFileCount++; break;
            case WARNING_STATE : warningFileCount++;  break;
            case ERROR_STATE : errorFileCount++;  break;
            case ERROR_RECHECK_STATE : errorRetryFileCount++;  break;
            case INTERNAL_CHECK_STATE : internalFileCount++;  break;
            case DELETED_STATE : deletedFileCount++; break;
          }
        }
      }
    }
    
    public String getContext() {
      return context;
    }
    
    public EzFSFileDescriptor getDirectory() {
      return directory;
    }
    
    public EzArray<? extends EzFSFileDescriptorStatus> getFiles() {
      return files;
    }
    
    public int getFileCount() {
      return fileCount;
    }
    public int getUnknownFileCount() {
      return unknownFileCount;
    }
    public int getOkFileCount() {
      return okFileCount;
    }
    public int getErrorFileCount() {
      return errorFileCount;
    }
    public int getErrorRetryFileCount() {
      return errorRetryFileCount;
    }
    public int getWarningFileCount() {
      return warningFileCount;
    }
    public int getIgnoredFileCount() {
      return ignoredFileCount;
    }
    public int getInternalFileCount() {
      return internalFileCount;
    }
    public int getDeletedFileCount() {
      return deletedFileCount;
    }
    public String getName() {
      return name;
    }
    public DateAccessor getLastStartRun() {
      return lastStartRun;
    }
    public DateAccessor getNextStartRun() {
      return nextStartRun;
    }
    public boolean isProcessing() {
      return isProcessing;
    }
    public boolean isRunning() {
      return isRunning;
    }
    public int getID() {
      return id;
    }
    public boolean isLastRunError() {
      return (lastError != null 
        && (lastComplete == null || lastComplete.getTime() < lastError.get0().getTime())); 
    }
    public boolean isLastRunComplete() {
      return (lastComplete != null && !isLastRunError());
    }
    public DateAccessor getLastComplete() {
      return lastComplete;
    }
    public Tuple2<DateAccessor, String> getLastError() {
      return lastError;
    }

    private final String name;
    private final DateAccessor lastStartRun;
    private final DateAccessor nextStartRun;
    private final boolean isProcessing;
    private final boolean isRunning;
    private final int id;
    private int fileCount;
    private int unknownFileCount;
    private int okFileCount;
    private int errorFileCount;
    private int errorRetryFileCount;
    private int warningFileCount;
    private int ignoredFileCount;
    private int internalFileCount;
    private int deletedFileCount;
    private final String context;
    private final EzFSFileDescriptor directory;
    private final EzArrayList<EzFSFileDescriptorStatus> files;
    private final DateAccessor lastComplete;
    private final Tuple2<DateAccessor, String> lastError;
  }
  
  private static final IDGenerator ids = new IDGenerator();
  
  public static class EzFSFileDescriptorStatus implements Serializable {
    
    private EzFSFileDescriptorStatus(String context, EzFSFileDescriptor descriptor, EzFSDirectoryCheckerStatus status) {
      this.context = context;
      this.descriptor = descriptor;
      this.status = status; 
    }
    
    public String getContext() {
      return context;
    }
    public EzFSFileDescriptor getDescriptor() {
      return descriptor;
    }
    public EzFSDirectoryCheckerStatus getStatus() {
      return status;
    }
    
    public static EzFSFileDescriptorStatus[] noEzFSFileDescriptorStatus = new EzFSFileDescriptorStatus[0];
    
    private final String context;
    private final EzFSFileDescriptor descriptor;
    private final EzFSDirectoryCheckerStatus status;
  }
  
  private static final boolean isWithEzFSCheckerSerialisation = PropertiesUtil.getBoolean("isWithEzFSCheckerSerialisation", true);
}
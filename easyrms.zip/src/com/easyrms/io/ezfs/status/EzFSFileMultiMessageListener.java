package com.easyrms.io.ezfs.status;

import com.easyrms.io.ezfs.status.EzFSFileStatus.*;

public interface EzFSFileMultiMessageListener {

  public EzFSFileStatusDetail[] process(EzFSFileStatus[] files);
  
}

package com.easyrms.io.ezfs.status;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

public class EzFSFileStatus {
  
  public EzFSFileStatus(String context, EzFSFile file) {
    this(context, file, UNKNOWN_STATE_DETAIL);
  }
  public EzFSFileStatus(String context, EzFSFile file, EzFSFileStatusDetail status) {
    this.file = file;
    this.status = status;
    this.context = context;
  }
  
  public String getContext() {
    return this.context;
  }
  
  public EzFSFile getFile() {
    return this.file;
  }
  
  public EzFSFileStatusDetail getStatus() {
    return status;
  }
  
  private final String context;
  private final EzFSFile file;
  private final EzFSFileStatusDetail status;
  
  public static enum EzFSFileStatusFlag {
    
    UNKNOWN_STATE,
    IGNORED_STATE,
    OK_STATE,
    WARNING_STATE,
    ERROR_STATE,
    ERROR_RECHECK_STATE,
    INTERNAL_CHECK_STATE,
    DELETED_STATE
  }
  
  public static class EzFSFileStatusDetail extends Tuple2<EzFSFileStatusFlag, String> {

    public EzFSFileStatusDetail(EzFSFileStatusFlag a, String b) {
      super(a, b);
    }
    
    public EzFSFileStatusFlag getFlag() {
      return get0();
    }

    public String getMessage() {
      return get1();
    }
  }
  
  public static EzFSFileStatusDetail getMostImportantStatus(EzFSFileStatusDetail detailA, EzFSFileStatusDetail detailB) {
    if (detailA == detailB) {
      return detailB;
    }
    if (detailA == null) {
      return detailB;
    }
    if (detailB == null) {
      return detailA;
    }
    final EzFSFileStatusFlag flagA = detailA.getFlag();
    final EzFSFileStatusFlag flagB = detailB.getFlag();
    if (flagA == flagB) {
      return detailB;
    }
    if (flagA == EzFSFileStatusFlag.UNKNOWN_STATE) {
      return detailB;
    }
    if (flagB == EzFSFileStatusFlag.UNKNOWN_STATE) {
      return detailA;
    }
    if (flagA == EzFSFileStatusFlag.IGNORED_STATE) {
      return detailB;
    }
    if (flagB == EzFSFileStatusFlag.IGNORED_STATE) {
      return detailA;
    }
    if (flagA == EzFSFileStatusFlag.OK_STATE) {
      return detailB;
    }
    if (flagB == EzFSFileStatusFlag.OK_STATE) {
      return detailA;
    }
    return detailB;
  }
  
  public static final EzFSFileStatus[] noStatus = new EzFSFileStatus[0];
  public static final EzFSFileStatusDetail UNKNOWN_STATE_DETAIL = new EzFSFileStatusDetail(EzFSFileStatusFlag.UNKNOWN_STATE, null); 
  public static final EzFSFileStatusDetail INTERNAL_STATE_DETAIL = new EzFSFileStatusDetail(EzFSFileStatusFlag.INTERNAL_CHECK_STATE, null); 
  public static final EzFSFileStatusDetail IGNORED_STATE_DETAIL = new EzFSFileStatusDetail(EzFSFileStatusFlag.IGNORED_STATE, null); 
  public static final EzFSFileStatusDetail OK_STATE_DETAIL = new EzFSFileStatusDetail(EzFSFileStatusFlag.OK_STATE, null); 
}

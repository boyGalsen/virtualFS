package com.easyrms.io.ezfs;

import com.easyrms.date.*;
import com.easyrms.util.*;

import java.io.*;

public interface EzFSFile {
  
  EzFSFileDescriptor getDescriptor();
  
  String getUUID(); 
  EzFSFile getDirectory(String name) throws IOException;
  EzFSFile getFile(String name) throws IOException;
  long getLength() throws IOException;
  boolean isExist() throws IOException;
  boolean create() throws IOException;
  DateAccessor getLastModifiation() throws IOException;
  
  EzFSFile getParent() throws IOException;
  
  EzFSConnection getSystem() throws IOException;
  
  EzFSFileAccess getAccess() throws IOException;
  
  boolean delete() throws IOException;
  
  EzArray<? extends EzFSFile> list() throws IOException;
}

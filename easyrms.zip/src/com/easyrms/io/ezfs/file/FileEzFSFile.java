package com.easyrms.io.ezfs.file;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.array.*;

import java.io.*;
import java.util.*;


public class FileEzFSFile extends AbstractEzFSFile<FileEzFSFile> {
  
  FileEzFSFile(FileEzFSConnection system) throws IOException {
    super(ids);
    this.system = system;
    this.path = StringArrays.emptyStringArray;
    this.descriptor = new SimpleEzFileDescriptor(system.getDescriptor(), null, "/", true, false, true);
    this.parent = null;
    this.file = system.getFile(path);
  }
  
  private FileEzFSFile(FileEzFSFile file, String name, Boolean forceIsDirectory) throws IOException {
    super(ids);
    this.parent = file;
    this.system = file.system;
    this.path = StringArrays.merge(file.path, name);
    this.file = system.getFile(path); 
    final boolean isDirectory = (forceIsDirectory == null) ? !this.file.isFile() : forceIsDirectory.booleanValue();
    this.descriptor = new SimpleEzFileDescriptor(system.getDescriptor(), name, file.descriptor.getPath() + name + (isDirectory ? "/" : ""), isDirectory, !isDirectory, false);
  }
  
  public EzFSFileDescriptor getDescriptor() {
    return descriptor;
  }
  public boolean isExist() throws IOException {
    return file.isExists();
  }
  protected final ValidatedFileOrDirecotry getFile() {
    return this.file;
  }

  public FileEzFSFile getFile(String name) throws IOException {
    return this.system.findFile(this, name);
  }

  public FileEzFSFile getDirectory(String name) throws IOException {
    return this.system.findDirectory(this, name);
  }

  @Override
  public FileEzFSFile newChild(String name, boolean isDirectory) throws IOException {
    if (name.indexOf("/") >= 0) throw new IOException("Invalid Child Name");
    if (this.childs.containsKey(name)) return this.childs.get(name);
    return new FileEzFSFile(this, name, Boolean.valueOf(isDirectory));
  }
  
  public boolean delete() throws IOException {
    if (!file.isExists() || descriptor.isRoot()) return false;
    return StreamUtils.delete(file);
  }
  
  public boolean create() throws IOException {
    if (file.isExists()) return true;
    if (!parent.create()) return false;
    if (descriptor.isDirectory()) {
      return (StreamUtils.controlExistDirectory(file.asDirectory()) != null);
    }
    return StreamUtils.create(file.asFile());
  }
  public FileEzFSFileAccess getAccess() throws IOException {
    if (descriptor.isDirectory()) {
      throw new IOException("Cannot Access To A Directory ["+descriptor.getPath()+"]"); 
    }
    return new FileEzFSFileAccess(this);
  }
  public DateAccessor getLastModifiation() throws IOException {
    return file.getLastModificationDate();
  }
  public long getLength() throws IOException {
    return file.getLength();
  }
  
  public FileEzFSFile getParent() throws IOException {
    return parent;
  }
  public FileEzFSConnection getSystem() throws IOException {
    return system;
  }
  
  public EzArray<FileEzFSFile> list() throws IOException {
    if (descriptor.isFile()) {
      return noFileEzFSFileArray;
    }
    synchronized (childs) {
      final HashSetThreadPool setPool = HashSetThreadPool.threadPools.get();
      final HashSet<String> newChilds = setPool.get();
      try {
        final EzArray<String> children = file.asDirectory().findValidatedNames(null);
        for (int i = 0, n = children.getCount(); i < n; i++) {
          final String child = children.get(i); 
          newChilds.add(child);
          if (!this.childs.containsKey(child)) {
            this.childs.put(child, new FileEzFSFile(this, child, null));
          }
        }
        if (this.childs.isEmpty()) {
          return noFileEzFSFileArray;
        }
        final HashSet<String> toRemove = setPool.get();
        try {
          for (final String oldChild : this.childs.keySet()) {
            if (!newChilds.contains(oldChild)) {
              toRemove.add(oldChild); 
            }
          }
          for (final String removeChild : toRemove) {
            this.childs.remove(removeChild);
          }
          if (this.childs.isEmpty()) return noFileEzFSFileArray;
          return new EzArrayList<FileEzFSFile>(this.childs.values());
        }
        finally {
          setPool.free(toRemove);
        }
      }
      finally {
        setPool.free(newChilds);
      }
    }
  }
  

  private final String[] path;
  private final FileEzFSConnection system;
  private final ValidatedFileOrDirecotry file;
  private final SimpleEzFileDescriptor descriptor;
  private final FileEzFSFile parent;
  private final HashMap<String, FileEzFSFile> childs = new HashMap<String, FileEzFSFile>();

  public static final EzArray<FileEzFSFile> noFileEzFSFileArray = new EzArray.NoEzArray<FileEzFSFile>();
  private static final IDGenerator ids = new IDGenerator("AbstractEzFileFile."+System.nanoTime());

}
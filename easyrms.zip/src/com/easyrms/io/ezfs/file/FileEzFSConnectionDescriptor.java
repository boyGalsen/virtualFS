package com.easyrms.io.ezfs.file;

import com.easyrms.io.ezfs.impl.*;

import java.io.*;

public class FileEzFSConnectionDescriptor extends SimpleEzFSConnectionDescriptor {

  public FileEzFSConnectionDescriptor(String root) {
    super("file://"+root);
    this.root = root;
  }
  
  public String getRoot() {
    return root;
  }
  
  @Override
  public String getContextName() {
    return root.replace("/", "_").replace("\\", "_");
  }

  public FileEzFSConnection createConnection() throws IOException {
    return new FileEzFSConnection(this);
  }
  
  private final String root;
}

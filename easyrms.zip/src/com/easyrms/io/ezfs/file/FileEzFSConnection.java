package com.easyrms.io.ezfs.file;

import com.easyrms.io.ezfs.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;


public class FileEzFSConnection extends AbstractEzFSConnection<FileEzFSFile> {
  
  FileEzFSConnection(FileEzFSConnectionDescriptor descriptor) throws IOException {
    super();
    this.root = StreamUtils.getDirectory(descriptor.getRoot()); 
    this.ezroot = new FileEzFSFile(this);
    if (this.root.isExists() && this.root.isFile()) {
      throw new IOException("Invalid File FS ("+root.getFullName()+")");
    }
    StreamUtils.controlExistDirectory(this.root);
    this.descriptor = descriptor;
  }
  
  public EzFSConnectionDescriptor getDescriptor() {
    return descriptor;
  }

  ValidatedFileOrDirecotry getFile(String... path) throws IOException {
    if (path.length == 0) {
      return root;
    }
    ValidatedFileOrDirecotry file = root;
    for (int i = 0, n = path.length ; i < n; i++) {
      final String name = path[i];
      file = StreamUtils.getChildFileOrDirectory(file.asDirectory(), name);
    }
    return file;
  }
  
  @Override
  public FileEzFSFile getRoot() throws IOException {
    return ezroot;
  }
  
  private ValidatedDirectory root;
  private final FileEzFSFile ezroot;
  private final FileEzFSConnectionDescriptor descriptor;
}
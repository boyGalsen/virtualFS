package com.easyrms.io.ezfs.file;

import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;

public class FileEzFSFileAccess extends AbstractEzFSFileAccess {

  FileEzFSFileAccess(FileEzFSFile file) throws IOException {
    super(file.getUUID());
    this.file = file;
  }
  
  @Override
  protected void loadTmpFile(ValidatedFile file) throws IOException {
  }

  @Override
  protected void saveTmpFile(ValidatedFile file) throws IOException {
  }
  
  @Override
  protected ValidatedFile createTmpFile() throws IOException {
    return file.getFile().asFile();
  }

  @Override
  protected void cleanTmpFile(ValidatedFile file) throws IOException {
  }

  private final FileEzFSFile file;
}

package com.easyrms.io.ezfs.file;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;


public class FileEzFSDriver implements EzFSDriver {

  public FileEzFSConnection getConnection(String prefix, String url) throws IOException {
    try {
      final FileEzFSConnectionDescriptor connectionDescriptor = getConnectionDescriptor(prefix, url);
      if (connectionDescriptor == null) throw new IllegalArgumentException("Cannot Find Parameter For URL "+url);
      return connectionDescriptor.createConnection();
    }
    catch (IOException forward) {
      throw forward;
    }
    catch (Throwable forward) {
      throw new IOException(forward);
    }
  }
  
  public FileEzFSConnectionDescriptor getConnectionDescriptor(String prefix, String url) {
    return new FileEzFSConnectionDescriptor(url);
  }

  public EzArray<String> getEzFSPrefix() {
    return prefixs;
  }
  
  static final String prefix = "file";
  static final EzArray<String> prefixs = new EzArray.AsArray<String>(prefix);
}

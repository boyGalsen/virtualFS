package com.easyrms.io.ezfs;

import com.easyrms.date.*;

public interface EzFSConnectionState {

  String getID();
  DateAccessor getStart();
  EzFSConnectionDescriptor getConnectionDescriptor();  
}

package com.easyrms.io.ezfs;

import java.io.*;

public interface EzFSFileAccess extends Closeable {

  void prepare() throws IOException;
  Reader openReader() throws IOException;
  Writer openWriter() throws IOException;
  Writer openAppendWriter() throws IOException;
  InputStream openInput() throws IOException;
  OutputStream openOutput() throws IOException;
  OutputStream openAppendOutput() throws IOException;
}

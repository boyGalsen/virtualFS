package com.easyrms.io.ezfs;

import com.easyrms.date.*;

public class SimpleEzFSConnectionState implements EzFSConnectionState {
  
  public SimpleEzFSConnectionState(EzFSConnection connection) {
    this.connectionDescriptor = connection.getDescriptor();
    this.start = connection.getStart();
    this.id = connection.getID();
  }

  public EzFSConnectionDescriptor getConnectionDescriptor() {
    return connectionDescriptor;
  }
  
  public DateAccessor getStart() {
    return start;
  }
  
  public String getID() {
    return id;
  }

  private final EzFSConnectionDescriptor connectionDescriptor;
  private final DateAccessor start;
  private final String id;
}

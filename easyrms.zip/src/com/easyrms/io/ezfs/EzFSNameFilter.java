package com.easyrms.io.ezfs;


public interface EzFSNameFilter {

  public boolean accept(EzFSFileDescriptor file);
  
  public static final EzFSNameFilter noFilter = new EzFSNameFilter() {
    
    public boolean accept(EzFSFileDescriptor file) {
      return true;
    }
  };
}

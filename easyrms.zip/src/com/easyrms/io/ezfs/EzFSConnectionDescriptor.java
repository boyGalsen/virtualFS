package com.easyrms.io.ezfs;

import java.io.*;

public interface EzFSConnectionDescriptor extends Serializable {

  String getConnectionURL();
  String getDisplayConnectionURL();
  String getContextName();
}

package com.easyrms.io.ezfs.impl;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.comparator.*;

public final class SimpleEzFileDescriptor implements EzFSFileDescriptor {
  
  public SimpleEzFileDescriptor(EzFSConnectionDescriptor connectionDescriptor, String name, String path, boolean isDirectory, boolean isFile, boolean isRoot) {
    this.connectionDescriptor = connectionDescriptor;
    this.name = StringComparator.NVL(name); 
    this.path = path;
    this.isDirectory = isDirectory;
    this.isFile = isFile;
    this.isRoot = isRoot;
  }

  public EzFSConnectionDescriptor getConnectionDescriptor() {
    return connectionDescriptor;
  }

  public String getName() {
    return name;
  }

  public String getPath() {
    return path;
  }

  public boolean isDirectory() {
    return isDirectory;
  }

  public boolean isFile() {
    return isFile;
  }

  public boolean isRoot() {
    return isRoot;
  }
  
  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof EzFSFileDescriptor)) {
      return false;
    }
    final EzFSFileDescriptor other = (EzFSFileDescriptor)obj;
    return (ObjectComparator.equals(connectionDescriptor, other.getConnectionDescriptor())
      && StringComparator.equals(path, other.getPath())
      && StringComparator.equals(name, other.getName())
      && isRoot() == other.isRoot()
      && isDirectory() == other.isDirectory()
      && isFile() == other.isFile());
  }

  @Override
  public int hashCode() {
    return (connectionDescriptor != null) ? connectionDescriptor.hashCode()+name.hashCode()+path.hashCode() : 0;
  }

  private final EzFSConnectionDescriptor connectionDescriptor;
  private final String name;
  private final String path;
  private final boolean isDirectory;
  private final boolean isFile;
  private final boolean isRoot; 
}

package com.easyrms.io.ezfs.impl;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;

import java.io.*;

abstract public class AbstractEzFSFile<T> implements EzFSFile {
  
  protected AbstractEzFSFile(IDGenerator ids) {
    this(ids.getNewID());
  }
  
  protected AbstractEzFSFile(String uuid) {
    this.uuid = uuid;
  }

  public final String getUUID() {
    return this.uuid;
  }
  
  protected abstract T newChild(String name, boolean isDirecory) throws IOException;
  
  private final String uuid;
}
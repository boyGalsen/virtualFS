package com.easyrms.io.ezfs.impl;

public abstract class AbstractRemoteEzFSFileAccess<T extends AbstractRemoteEzFSFile<T>> extends AbstractEzFSFileAccess {

  protected AbstractRemoteEzFSFileAccess(T remoteFSFile) {
    super(remoteFSFile.getUUID());
    this.remoteFSFile = remoteFSFile;
  }
  
  @Override
  protected void afterSaveTmpFile() {
    super.afterSaveTmpFile();
    remoteFSFile.markAsChange();
  }

  protected final T remoteFSFile;
}

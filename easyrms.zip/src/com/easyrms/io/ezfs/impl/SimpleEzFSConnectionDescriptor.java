package com.easyrms.io.ezfs.impl;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.comparator.*;

public class SimpleEzFSConnectionDescriptor implements EzFSConnectionDescriptor {
  
  protected SimpleEzFSConnectionDescriptor(String connectionURL) {
    this(connectionURL, connectionURL);
  }  
  public SimpleEzFSConnectionDescriptor(String connectionURL, String displayConnectionURL) {
    this.connectionURL = connectionURL;
    this.displayConnectionURL = displayConnectionURL;
    this.contextName = displayConnectionURL.replace("/","_").replace("\\","_").replace(":","_").replace("@","_");
  }

  public final String getConnectionURL() {
    return connectionURL;
  }
  
  public String getDisplayConnectionURL() {
    return displayConnectionURL;
  }
  
  public String getContextName() {
    return contextName;
  }

  @Override
  public int hashCode() {
    return (connectionURL != null) ? connectionURL.hashCode() : 0;
  }
  
  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof EzFSConnectionDescriptor)) {
      return false;
    }
    final EzFSConnectionDescriptor other = (EzFSConnectionDescriptor)obj;
    return (StringComparator.equals(getConnectionURL(), other.getConnectionURL())
      && StringComparator.equals(getDisplayConnectionURL(), other.getDisplayConnectionURL()));
  }

  private final String connectionURL;
  private final String displayConnectionURL;
  private final String contextName;
}

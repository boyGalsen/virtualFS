package com.easyrms.io.ezfs.impl;

import com.easyrms.date.*;
import com.easyrms.util.*;


public abstract class AbstractRemoteEzFSFile<T> extends AbstractEzFSFile<T> {

  protected AbstractRemoteEzFSFile(IDGenerator ids) {
    super(ids);
  }
  
  public final void markAsChange() {
    this.isChange = true;
  }

  public final void synchStatus() {
    if (isChange) {
      internalSynchStatus();
      isChange = false;
    }
  }
  
  public final DateAccessor getLastModifiation() {
    synchStatus();
    return lastModification;
  }

  public final long getLength() {
    synchStatus();
    return length;
  }

  public final boolean isExist() {
    synchStatus();
    return isExist;
  }
  
  protected abstract void internalSynchStatus();
  
  private boolean isChange;
  protected boolean isExist;
  protected DateAccessor lastModification;
  protected long length;
}

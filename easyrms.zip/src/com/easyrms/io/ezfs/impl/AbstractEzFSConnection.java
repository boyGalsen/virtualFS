package com.easyrms.io.ezfs.impl;

import com.easyrms.date.*;
import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.util.*;


abstract public class AbstractEzFSConnection<T extends AbstractEzFSFile<T>> implements EzFSConnection {
  
  protected AbstractEzFSConnection() {
    this.id = ids.getNewID();
    this.startDate = StampUtil.getNow();
    EzFS.reference.get().add(this);
  }

  abstract public T getRoot() throws IOException ;
  
  public DateAccessor getStart() {
    return this.startDate;
  }
  
  public T find(EzFSFileDescriptor descriptor) throws IOException {
    if (descriptor.isDirectory()) return findDirectory(descriptor.getPath());
    return findFile(descriptor.getPath());
  }
  
  public T findDirectory(EzFSFileDescriptor descriptor) throws IOException {
    if (!descriptor.isDirectory()) return null;
    return findDirectory(descriptor.getPath());
  }
  
  public T findFile(EzFSFileDescriptor descriptor) throws IOException {
    if (!descriptor.isFile()) return null;
    return findFile(descriptor.getPath());
  }
  
  public T findFile(String path) throws IOException {
    if (path.length() == 0) return getRoot();
    final StringTokenizer st = new StringTokenizer(path, "/");
    T file = getRoot();
    while (st.hasMoreTokens()) {
      final String token = st.nextToken();
      if (StringComparator.isNotNull(token) && !".".equals(token) && !"..".equals(token)) {
        file = file.newChild(token, st.hasMoreTokens());
      }
    }
    return file;
  }
  
  public T findDirectory(String path) throws IOException {
    if (path.length() == 0) return getRoot();
    final StringTokenizer st = new StringTokenizer(path, "/");
    T file = getRoot();
    while (st.hasMoreTokens()) {
      final String token = st.nextToken();
      if (StringComparator.isNotNull(token) && !".".equals(token) && !"..".equals(token)) {
        file = file.newChild(token, true);
      }
    }
    return file;
  }
  
  public T findFile(T file, String path) throws IOException {
    final String parentPath = file.getDescriptor().getPath();
    if (path.startsWith("/")) {
      if (parentPath.endsWith("/")) {
        return findFile(parentPath+path.substring(1));
      }
      return findFile(parentPath+path);
    }
    if (parentPath.endsWith("/")) {
      return findFile(parentPath+path);
    }
    return findFile(parentPath+"/"+path);  
  }
  
  public T findDirectory(T file, String path) throws IOException {
    final String parentPath = file.getDescriptor().getPath();
    if (path.startsWith("/")) {
      if (parentPath.endsWith("/")) {
        return findDirectory(parentPath+path.substring(1));
      }
      return findDirectory(parentPath+path);
    }
    if (parentPath.endsWith("/")) {
      return findDirectory(parentPath+path);
    }
    return findDirectory(parentPath+"/"+path);
  }
  
  public String getID() {
    return id;
  }
  
  public final void close() throws IOException{
    try {
      internalClose();
    }
    finally {
      EzFS.reference.get().remove(this);
    }
  }
  
  public final DateAccessor getStartDate() {
    return startDate;
  }
  
  protected void internalClose() throws IOException {
  }
  
  private final DateAccessor startDate;
  private final String id;
  private static final IDGenerator ids = new IDGenerator("EZFSC", 0, 1000000000);
}

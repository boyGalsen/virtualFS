package com.easyrms.io.ezfs.impl;

import com.easyrms.io.ezfs.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;

import java.io.*;
import java.util.*;

abstract public class AbstractEzFSFileAccess implements EzFSFileAccess {
  
  protected AbstractEzFSFileAccess(String uid) {
    this.uid = uid;
  }
  
  public Reader openReader() throws IOException {
    final InputStream in = openInput();
    return (in == null) ? null : new InputStreamReader(in);
  }

  public Writer openWriter() throws IOException {
    final OutputStream out = openOutput();
    return (out == null) ? null : new OutputStreamWriter(out);
  }
  
  public Writer openAppendWriter() throws IOException {
    final OutputStream out = openAppendOutput();
    return (out == null) ? null : new OutputStreamWriter(out);
  }
  
  public synchronized InputStream openInput() throws IOException {
    if (out.isNull()) {
      final InputStreamOver in = new InputStreamOver(getTmpFile(true));
      ins.add(in);
      return in;
    }
    return null;
  }

  public synchronized OutputStream openOutput() throws IOException {
    if (ins.size() == 0 && out.isNull()) {
      final OutputStreamOver out = new OutputStreamOver(getTmpFile(false), false);
      isTmpFileSynchronized = true;
      this.out.set(out);
      return out;
    }
    return null;
  }
  
  public synchronized OutputStream openAppendOutput() throws IOException {
    if (ins.size() == 0 && out.isNull()) {
      final OutputStreamOver out = new OutputStreamOver(getTmpFile(false), true);
      isTmpFileSynchronized = true;
      this.out.set(out);
      return out;
    }
    return null;
  }
  
  public synchronized void close() throws IOException {
    if (tmpFile.isDefined()) {
      final ValidatedFile tmpFile = this.tmpFile.get();
      try {
        final int n = this.ins.size();
        if (n > 0) {
          final InputStream[] ins = this.ins.toArray(new InputStream[n]);
          IOException exception = null;
          for (int i = 0; i < n; i++) {
            final InputStream in = ins[i];
            try {
              StreamUtils.closeNotCatch(in);
            }
            catch (IOException e) {
              if (exception == null) {
                exception = e;
              }
            }
          }
          if (exception != null) {
            throw exception;
          }
        }
        final OutputStream out = this.out.get();
        StreamUtils.closeNotCatch(out);
      }
      finally {
        cleanTmpFile(tmpFile);
      }
    }
  }
  
  
  public void prepare() throws IOException {
    getTmpFile(true);
  }
  
  abstract protected void loadTmpFile(ValidatedFile tmpFile) throws IOException;
  abstract protected void saveTmpFile(ValidatedFile tmpFile) throws IOException;
  
  protected void afterSaveTmpFile() {
    
  }
  
  protected void cleanTmpFile(ValidatedFile tmpFile) throws IOException {
    StreamUtils.delete(tmpFile);
  }
  
  protected ValidatedFile createTmpFile() throws IOException {
    return StreamUtils.createTmpFile(uid);
  }
  
  private ValidatedFile getTmpFile(boolean forRead) throws IOException {
    synchronized (tmpFile) {
      if (!tmpFile.isDefined()) {
        final ValidatedFile tmpFile = createTmpFile();
        this.tmpFile.set(tmpFile);
      }
      final ValidatedFile tmpFile = this.tmpFile.get();
      if (forRead && !isTmpFileSynchronized) {
        loadTmpFile(tmpFile);
        isTmpFileSynchronized = true;
      }
      return tmpFile;
    }
  }

  private class OutputStreamOver extends FilterOutputStream {

    public OutputStreamOver(ValidatedFile file, boolean append) throws IOException {
      super(StreamUtils.newFileOutputStream(file, append));
      this.file = file;
    }
    @Override
    public void close() throws IOException {
      synchronized (AbstractEzFSFileAccess.this) {
        flush();
        super.close();
        AbstractEzFSFileAccess.this.out.set(null);
        saveTmpFile(file);
        afterSaveTmpFile();
      }
    }
    
    private final ValidatedFile file;
  }
  
  private class InputStreamOver extends FilterInputStream {

    public InputStreamOver(ValidatedFile file) throws IOException {
      super(StreamUtils.newFileInputStream(file));
    }

    @Override
    public void close() throws IOException {
      synchronized (AbstractEzFSFileAccess.this) {
        super.close();
        if (AbstractEzFSFileAccess.this.ins.contains(this)) {
          AbstractEzFSFileAccess.this.ins.remove(this);
        }
      }
    }
  }
   
  private final SimpleReference<ValidatedFile> tmpFile = new SimpleReference<ValidatedFile>();
  private boolean isTmpFileSynchronized = false;
  private final SimpleReference<OutputStream> out = new SimpleReference<OutputStream>();
  private final HashSet<InputStream> ins = new HashSet<InputStream>();

  private final String uid;
}
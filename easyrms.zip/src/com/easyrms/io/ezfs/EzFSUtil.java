package com.easyrms.io.ezfs;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import javax.activation.*;

public class EzFSUtil {

  private EzFSUtil() {
    
  }
  
  public static EzFSFileDescriptor findEzFsFileDescriptior(String fileName) throws IOException {
    if (fileName.indexOf("://") < 0) {
      fileName = "file://"+fileName;
    }
    final EzFS fs = EzFS.reference.get();
    final int partIndex = fileName.lastIndexOf("/");
    final String directoryPart = fileName.substring(0, partIndex+1);
    final String fileNamePart = fileName.substring(partIndex);
    return fs.getFile(fs.getConnectionDescriptor(directoryPart), fileNamePart);
  }
  
  
  /**
    return numbers of retries;
  */
  public static int send(String url, String path, DataSource dataSource) throws IOException {
    return send(url, path, dataSource, DEFAULT_MAX_NB_RETRY);
  }
  
  public static String getAbsolutePath(EzFSFileDescriptor descriptor) {
    return descriptor.getConnectionDescriptor().getConnectionURL()+descriptor.getPath();
  }
  
  public static String getDisplayAbsolutePath(EzFSFileDescriptor descriptor) {
    return descriptor.getConnectionDescriptor().getDisplayConnectionURL()+descriptor.getPath();
  }
  
  public static String getParentPath(String path) {
    if (path.endsWith("/")) {
      path = path.substring(0, path.length()-1);
    }
    final int index = path.lastIndexOf("/");
    if (index < 0) return "/";
    return path.substring(0, index);
  }
  
  public static boolean isRoot(String path) {
    if (path.endsWith("/")) {
      path = path.substring(0, path.length()-1);
    }
    final int index = path.lastIndexOf("/");
    if (index < 0) return true;
    return false;
  }
  
  public static String createPath(String path, String subPath) {
    if (StringComparator.isNull(subPath)) return path;
    final String descriptorPath = path;
    if (subPath.startsWith("/")) {
      if (descriptorPath.endsWith("/")) {
        return descriptorPath+subPath.substring(1);
      }
      return descriptorPath+subPath;
    }
    if (descriptorPath.endsWith("/")) {
      return descriptorPath+subPath;
    }
    return descriptorPath+"/"+subPath;
  }
  
  public static String createPath(EzFSFileDescriptor descriptor, String subPath) {
    if (StringComparator.isNull(subPath)) return descriptor.getPath();
    final String descriptorPath = descriptor.getPath();
    if (subPath.startsWith("/")) {
      if (descriptorPath.endsWith("/")) {
        return descriptorPath+subPath.substring(1);
      }
      return descriptorPath+subPath;
    }
    if (descriptorPath.endsWith("/")) {
      return descriptorPath+subPath;
    }
    return descriptorPath+"/"+subPath;
  }
  
  /**
    return numbers of retries;
  */
  public static int send(String url, String path, DataSource dataSource, int maxNbRetry) throws IOException {
    int nbTry = 1;
    while (nbTry <= maxNbRetry) {
      try {
        final EzFSConnection fs = EzFS.reference.get().getConnection(url);
        if (fs == null) {
          throw new IOException("Cannot Connect To "+url); 
        }
        try {
          final EzFSFile root = fs.getRoot();
          final EzFSFile directory = root.getDirectory(path);
          final EzFSFile file = directory.getFile(dataSource.getName());
          final InputStream in = dataSource.getInputStream();
          try {
            try (final EzFSFileAccess outAccess = file.getAccess()) {
              StreamUtils.copy(in, true, outAccess.openOutput(), true);
              return nbTry-1;
            }
          }
          finally {
            StreamUtils.closeNotCatch(in);
          }
        }
        finally {
          if (fs != null) {
            fs.close();
          }
        }
      }
      catch (IOException exception) {
        EasyRMS.trace.log("retry send file on exception url="+url+";path="+path+";datasource="+dataSource.getName(), exception);
        if (nbTry >= maxNbRetry) {
          throw exception;
        }
      }
      nbTry++;
      ThreadUtil.sleepSilently(nbTry*DEFAULT_WAIT);
    }
    return nbTry-1;
  }
  
  public static byte[] toByteArray(EzFSFile file) throws IOException {
    try (final EzFSFileAccess accessor = file.getAccess()) {
      try (final InputStream in = accessor.openInput()) {
        return StreamUtils.toByteArray(in);
      }
    }
  }
  
  private static final int DEFAULT_MAX_NB_RETRY = PropertiesUtil.getInt("com.easyrms.io.ezfs.EzFSUtil.defaultMaxNbRetry", 3);
  private static final int DEFAULT_WAIT = PropertiesUtil.getInt("com.easyrms.io.ezfs.EzFSUtil.defaultWait", 15000);
}

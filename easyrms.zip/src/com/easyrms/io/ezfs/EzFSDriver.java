package com.easyrms.io.ezfs;

import com.easyrms.util.*;

import java.io.*;

public interface EzFSDriver {

  EzArray<String> getEzFSPrefix();
  EzFSConnection getConnection(String prefix, String url) throws IOException;
  EzFSConnectionDescriptor getConnectionDescriptor(String prefix, String url);
  
}

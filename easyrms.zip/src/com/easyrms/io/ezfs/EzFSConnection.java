package com.easyrms.io.ezfs;

import com.easyrms.date.*;

import java.io.*;


public interface EzFSConnection extends Closeable {

  String getID();
  DateAccessor getStart();
  EzFSConnectionDescriptor getDescriptor();
  
  EzFSFile getRoot() throws IOException;
  EzFSFile find(EzFSFileDescriptor descriptor) throws IOException;
  EzFSFile findFile(EzFSFileDescriptor descriptor) throws IOException;
  EzFSFile findDirectory(EzFSFileDescriptor descriptor) throws IOException;
  EzFSFile findFile(String path) throws IOException;
  EzFSFile findDirectory(String path) throws IOException;
}

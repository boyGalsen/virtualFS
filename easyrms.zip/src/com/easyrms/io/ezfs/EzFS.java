package com.easyrms.io.ezfs;

import com.easyrms.io.ezfs.file.*;
import com.easyrms.io.ezfs.ftp.*;
import com.easyrms.io.ezfs.s3.*;
import com.easyrms.io.ezfs.sftp.*;
import com.easyrms.io.ezfs.impl.*;
import com.easyrms.util.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.locks.*;


public final class EzFS {
  
  public static final ObjectReference<EzFS> reference = new AutoCreateReference<EzFS>() {

    @Override
    protected EzFS create() {
      final EzFS reference = new EzFS();
      reference.register(new FileEzFSDriver());
      reference.register(new FTPEzFSDriver());
      reference.register(new SFTPEzFSDriver());
      reference.register(new S3EzFSDriver());
      return reference;
    }
  };
  
  public EzFSConnection getConnection(EzFSConnectionDescriptor descriptor) throws IOException {
    return getConnection(descriptor.getConnectionURL());
  }

  public EzFSConnectionDescriptor getConnectionDescriptor(String url) {
    if (url.startsWith("$")) {
      final int index = url.indexOf("/");
      final EzFSMount mount = findMount((index < 0) ? url.substring(1) : url.substring(1, index));
      if (mount == null) {
        return new SimpleEzFSConnectionDescriptor(url, url);
      }
      url = (index < 0) ? EzFSUtil.getAbsolutePath(mount.getFileDescriptor()) : EzFSUtil.getAbsolutePath(mount.getFileDescriptor())+url.substring(index);
    }
    final int index = url.indexOf("://");
    if (index < 0) {
      return new SimpleEzFSConnectionDescriptor(url, url);
    }
    final String prefix = url.substring(0, index);
    final EzFSDriver manager = managers.get(prefix);
    if (manager == null) {
      return new SimpleEzFSConnectionDescriptor(url, url); 
    }
    return manager.getConnectionDescriptor(prefix, url.substring(index+3));
  }

  public EzFSFileDescriptor getRoot(EzFSConnectionDescriptor connection) {
    return new SimpleEzFileDescriptor(connection, "", "/", true, false, true);
  }
  
  public EzFSFileDescriptor getDirectory(EzFSConnectionDescriptor connection, String path) {
    if ("/".equals(path) || path == null) {
      return getRoot(connection);
    }
    if (path.endsWith("/")) {
      path = path.substring(0, path.length()-1);
    }
    final int index = path.lastIndexOf("/");
    return new SimpleEzFileDescriptor(connection, path.substring(index+1), path.startsWith("/") ? path : "/"+path, true, false, false);
  }
  
  public EzFSFileDescriptor getFile(EzFSConnectionDescriptor connection, String path) {
    if ("/".equals(path)) {
      return getRoot(connection);
    }
    if (path.endsWith("/")) {
      return getDirectory(connection, path.substring(0, path.length()-1));
    }
    final int index = path.lastIndexOf("/");
    return new SimpleEzFileDescriptor(connection, path.substring(index+1), path.startsWith("/") ? path : "/"+path, false, true, false);
  }
  
  public EzFSConnection getConnection(String url) throws IOException {
    final int index = url.indexOf("://");
    if (index < 0) {
      throw new IOException("Invalid FS URL"); 
    }
    final String prefix = url.substring(0, index);
    final EzFSDriver manager = managers.get(prefix);
    if (manager == null) {
      throw new IOException("Unknown FS Kind ("+prefix+")"); 
    }
    return manager.getConnection(prefix, url.substring(index+3));
  }
  
  public void register(EzFSDriver manager) {
    final EzArray<String> prefixes = manager.getEzFSPrefix();
    prefixes.forEach(prefixesI -> {this.managers.put(prefixesI, manager); });
  }
  
  public int getCurrentRequestCount() {
    final Lock readLock = currentConnectionLock.readLock();
    readLock.lock();
    try {
      return currentConnections.size();
    }
    finally {
      readLock.unlock();
    }
  }
    
  public EzArray<? extends EzFSConnectionState> currentRequest() {
    final Lock readLock = currentConnectionLock.readLock();
    readLock.lock();
    try {
      final EzArrayList<EzFSConnectionState> list = new EzArrayList<>();
      for (final EzFSConnection connection : currentConnections.values()) {
        list.add(new SimpleEzFSConnectionState(connection));
      }
      return list;
    }
    finally {
      readLock.unlock();
    }
  }
  
  public EzFSConnection find(String id) {
    final Lock readLock = currentConnectionLock.readLock();
    readLock.lock();
    try {
      return currentConnections.get(id);
    }
    finally {
      readLock.unlock();
    }
  }
  
  public void add(EzFSConnection connection) {
    final Lock writeLock = currentConnectionLock.writeLock();
    writeLock.lock();
    try {
      currentConnections.put(connection.getID(), connection);
    }
    finally {
      writeLock.unlock();
    }
  }
  
  public void remove(EzFSConnection connection) {
    final Lock writeLock = currentConnectionLock.writeLock();
    writeLock.lock();
    try {
      currentConnections.remove(connection.getID());
    }
    finally {
      writeLock.unlock();
    }
  }
  
  public boolean unmount(String name) {
    name = mountNormalize(name);
    final Lock writeLock = currentMountedDescriporsLock.writeLock();
    writeLock.lock();
    try {
      EzFSMount ezMount = currentMountedDescripors.remove(name);
      if (ezMount != null) {
        currentMountedDescriporsByFile.remove(EzFSUtil.getAbsolutePath(ezMount.getFileDescriptor()));
      }
      mountList.reset();
    }
    finally {
      writeLock.unlock();
    }
    return true;
  }
  public boolean mount(String name, EzFSFileDescriptor fileDescriptor) {
    name = mountNormalize(name);
    final Lock writeLock = currentMountedDescriporsLock.writeLock();
    writeLock.lock();
    try {
      if (currentMountedDescripors.containsKey(name)) {
        return false;
      }
      mountList.reset();
      final EzFSMount ezMount = new SimpleEzFSMount(name, fileDescriptor);
      if (currentMountedDescripors.put(name, ezMount) == null) {
        currentMountedDescriporsByFile.put(EzFSUtil.getAbsolutePath(ezMount.getFileDescriptor()), ezMount);
        return true;
      }
      return false;
    }
    finally {
      writeLock.unlock();
    }
  }
  
  public EzFSMount findMount(EzFSFileDescriptor fileDescriptor) {
    if (fileDescriptor == null) {
      return null;
    }
    final Lock readLock = currentMountedDescriporsLock.readLock();
    readLock.lock();
    try {
      return currentMountedDescriporsByFile.get(EzFSUtil.getAbsolutePath(fileDescriptor));
    }
    finally {
      readLock.unlock();
    }
  }
  
  public EzFSMount findMount(String name) {
    name = mountNormalize(name);
    final Lock readLock = currentMountedDescriporsLock.readLock();
    readLock.lock();
    try {
      return currentMountedDescripors.get(name);
    }
    finally {
      readLock.unlock();
    }
  }
  
  public EzArray<EzFSMount> getMounts() {
    return mountList.get();
  }
  
  public static interface EzFSMount {
    
    String getName();
    EzFSFileDescriptor getFileDescriptor();
  }
  
  private static class SimpleEzFSMount extends Tuple2<String, EzFSFileDescriptor> implements EzFSMount {

    public SimpleEzFSMount(String name, EzFSFileDescriptor fileDescriptor) {
      super(name, fileDescriptor);
    }
    
    public String getName() {
      return get0();
    }
    
    public EzFSFileDescriptor getFileDescriptor() {
      return get1();
    }
  }

  private final ReentrantReadWriteLock currentConnectionLock = new ReentrantReadWriteLock();
  private final HashMap<String, EzFSConnection> currentConnections = new HashMap<>();
  private final ReentrantReadWriteLock currentMountedDescriporsLock = new ReentrantReadWriteLock();
  private final HashMap<String, EzFSMount> currentMountedDescripors = new HashMap<>();
  private final HashMap<String, EzFSMount> currentMountedDescriporsByFile = new HashMap<>();
  private final ObjectReference<EzArray<EzFSMount>> mountList = new AutoCreateReference<EzArray<EzFSMount>>() {

    @Override
    protected EzArray<EzFSMount> create() {
      return new EzArrayList<>(currentMountedDescripors.values());
    }    
  };
  
  private static final String mountNormalize(String mountName) {
    return mountName.replace("/", "|");
  }
  
  private final HashMap<String, EzFSDriver> managers = new HashMap<>();
}

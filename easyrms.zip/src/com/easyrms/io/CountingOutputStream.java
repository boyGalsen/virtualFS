package com.easyrms.io;

import java.io.*;

/**
 * An OutputStream capable of counting the number of written bytes. NOT Thread safe
 */
public class CountingOutputStream extends FilterOutputStream implements Countable{

  public CountingOutputStream(OutputStream outputStream) {
    super(outputStream);
  }

  public long getCount() {
    return count;
  }

  @Override
  public void write(int b) throws IOException {
    out.write(b);
    count++;
  }

  @Override
  public void write(byte[] b, int off, int len) throws IOException {
    out.write(b, off, len);
    count += len;
  }

  @Override
  public void write(byte[] b) throws IOException {
    out.write(b);
    count += b.length;
  }

  private long count = 0;
}

package com.easyrms.io.jmx;

import com.easyrms.util.*;

public interface JMXDirectory {

  String getName();
  StreamUtils.ValidatedDirectory getDirectory();
  boolean clearHistory(int numbreOfHistoryDateToKeep);
  JMXDirectoryStatistic getStatistic();
  
  EzArray<JMXDirectory> getSubDirectory();
  
  interface JMXDirectoryStatistic {
    
    long getTotalSize();
    int getTotalFileCount();
    long getLastModified();
    EzArray<JMXDirectory> getSubDirectory();
  }
}

package com.easyrms.io.jmx;

import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.array.*;
import com.easyrms.util.executor.*;

import java.util.*;


public class SimpleJMXDirectory implements JMXDirectory {
  
  public static SimpleJMXDirectory get(String name, ValidatedDirectory directory, int defaultNumberOfHistoryDateToKeep) {
    synchronized (jmxDirectoryByFiles) {
      final String key = directory.getFullName();
      SimpleJMXDirectory jmxDirectoryByFile = jmxDirectoryByFiles.get(directory.getFullName());
      if (jmxDirectoryByFile == null) {
        jmxDirectoryByFile = new SimpleJMXDirectory(name, directory, defaultNumberOfHistoryDateToKeep);
        jmxDirectoryByFiles.put(key, jmxDirectoryByFile);
      }
      return jmxDirectoryByFile;
    }
  }
  
  private static final HashMap<String, SimpleJMXDirectory> jmxDirectoryByFiles = new HashMap<String, SimpleJMXDirectory>();
  
  private SimpleJMXDirectory(String name, ValidatedDirectory directory) {
    this(name, directory, -1);
  }
  
  /**
   * -1 for No DefaultHistoryClear;
   */
  private SimpleJMXDirectory(String name, ValidatedDirectory directory, int defaultNumberOfHistoryDateToKeep) {
    this.directory = directory;
//    this.parent = null;
    this.name = name;
    JMXDirectoryManager.reference.add(this);
  }
  
  private SimpleJMXDirectory(SimpleJMXDirectory parent, ValidatedDirectory directory) {
    this.directory = directory;
//    this.parent = parent;
    this.name = null;
  }
  
  public String getName() {
    return name;
  }
  
  public String getKey() {
    return directory.getName();
  }
  
  public synchronized boolean clearHistory(int numberOfHistoryDateToKeep) {
    if (numberOfHistoryDateToKeep >= 0) {
      statistic = new Statistic(numberOfHistoryDateToKeep);
    }
    return true;
  }
  
  public StreamUtils.ValidatedDirectory getDirectory() {
    return directory;
  }

  public synchronized JMXDirectoryStatistic getStatistic(int numberOfHistoryDateToKeep) {
    if (numberOfHistoryDateToKeep < 0) {
      return getStatistic();
    }
    statistic = new Statistic(numberOfHistoryDateToKeep);
    return statistic;
  }

  public synchronized JMXDirectoryStatistic getStatistic() {
    if (statistic == null || statistic.lastModification < directory.getLastModification()) {
      statistic = new Statistic(defaultNumberOfHistoryDateToKeep);
    }
    return statistic;
  }
  
  public synchronized EzArray<JMXDirectory> getSubDirectory() {
    return new EzArrayList<JMXDirectory>(subDirectories.values());
  }

  private class Statistic implements JMXDirectory.JMXDirectoryStatistic {
    
    public Statistic(final int numberOfHistoryDateToKeep) {
      final long clearHistory = (numberOfHistoryDateToKeep < 0) ? 0 : StampUtil.getStampValue()-(numberOfHistoryDateToKeep*3600000*24L);
      this.lastModification = directory.getLastModification();
      final HashListThreadPool hashListPool = HashListThreadPool.threadPools.get();
      final HashList<String> toRemove = hashListPool.get();
      final HashList<ValidatedDirectory> validDirectories = hashListPool.get();
      try {
        directory.forEach(new ValidatedFindFilter() {
          
          public boolean accept(ValidatedDirectory directory, boolean isFile, String name, long length, long lastModification, boolean isExist) {
            if (!isFile) {
              validDirectories.add(StreamUtils.getChildDirectory(directory, name));
            }
            else if (lastModification < clearHistory) {
              StreamUtils.delete(StreamUtils.getChildFile(directory, name));
            }
            else {
              add(StreamUtils.getChildFile(directory, name));
            }
            return false;
          }
        });
        for (final SimpleJMXDirectory directory : subDirectories.values()) {
          if (!validDirectories.contains(directory.getDirectory())) {
            toRemove.add(directory.getKey());
          }
        }
        for (int i = 0, n = validDirectories.getCount(); i < n; i++) {
          final ValidatedDirectory file = validDirectories.get(i);
          SimpleJMXDirectory directory = subDirectories.get(file.getName());
          if (directory == null) {
            subDirectories.put(file.getName(), new SimpleJMXDirectory(SimpleJMXDirectory.this, file));
          }
        }
        for (int i = 0, n = toRemove.getCount(); i < n; i++) {
          subDirectories.remove(toRemove.get(i));
        }
        toRemove.clear();
        final SimpleJMXDirectory[] directories = subDirectories.values().toArray(new SimpleJMXDirectory[0]);
        EzPoolExecutor.DEFAULT.run(new EzRunnableTaskArray("SimpleJMXDirectory", directories.length) {

          @Override
          protected void run(int i) {
            final JMXDirectoryStatistic statistic = directories[i].getStatistic(numberOfHistoryDateToKeep);
            toRemove.add(directories[i].getKey());
            if (statistic.getTotalFileCount() <= 0) {
              StreamUtils.delete(directories[i].getDirectory());
            }
          }

          @Override
          public String description(int i) {
            return directories[i].getKey();
          }

          @Override
          public void fillContext(int i, EzTaskContext context) {
          }
        });
        for (int i = 0, n = toRemove.getCount(); i < n; i++) {
          subDirectories.remove(toRemove.get(i));
        }
      }
      finally {
        hashListPool.free(validDirectories);
        hashListPool.free(toRemove);
      }
    }

    public int getTotalFileCount() {
      return count;
    }

    public long getTotalSize() {
      return size;
    }
    
    public long getLastModified() {
      return lastModification;
    }
    
    private void add(ValidatedFile file) {
      size += file.getLength();
      count++;
    }
    
//    private synchronized void add(JMXDirectory.JMXDirectoryStatistic statistic) {
//      size += statistic.getTotalSize();
//      count += statistic.getTotalFileCount();
//    }
    
    public EzArray<JMXDirectory> getSubDirectory() {
      return SimpleJMXDirectory.this.getSubDirectory();
    }
    
    private long size;
    private int count;
     
    private final long lastModification;
  }
  
  private final HashMap<String, SimpleJMXDirectory> subDirectories = new HashMap<String, SimpleJMXDirectory>();
  private final String name;
  private final ValidatedDirectory directory;
//  private final SimpleJMXDirectory parent;
  private int defaultNumberOfHistoryDateToKeep;
  private Statistic statistic;
}

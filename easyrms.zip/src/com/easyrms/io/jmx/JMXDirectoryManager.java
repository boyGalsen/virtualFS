package com.easyrms.io.jmx;

import com.easyrms.util.*;


public class JMXDirectoryManager {

public static final JMXDirectoryManager reference = new JMXDirectoryManager();
  
  public synchronized EzArray<JMXDirectory> getDirectory() {
    isNeedToBeCloned = true;
    return processes;
  }

  public synchronized void add(JMXDirectory directory) {
    if (isNeedToBeCloned) {
      final EzArrayList<JMXDirectory> old = processes;
      processes = new EzArrayList<JMXDirectory>((EzArray<JMXDirectory>)old);
      isNeedToBeCloned = false;
    }
    processes.add(directory);
  }
  
  public synchronized void remove(JMXDirectory directory) {
    if (isNeedToBeCloned) {
      final EzArrayList<JMXDirectory> old = processes;
      processes = new EzArrayList<JMXDirectory>((EzArray<JMXDirectory>)old);
      isNeedToBeCloned = false;
    }
    processes.remove(directory);
  }
  
  private EzArrayList<JMXDirectory> processes = new EzArrayList<JMXDirectory>();
  private boolean isNeedToBeCloned;
}

package com.easyrms.io;

import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;

import java.awt.*;


public interface EzContextOutput extends EzContext, TranslationFilter {
  
  String translate(String text);
  EzWriter getOut();
  
  boolean isHTML();
  HtmlBlockWriter getHtmlOut();
  
  String addComponent(Component component);
  String addDynamicResource(String content, EzMimeType mimeType, EzEncoding encoding, String name, boolean isTranslatable);
  String addDynamicResource(byte[] content, EzMimeType mimeType, String name);
}

package com.easyrms.io;

import com.easyrms.util.net.content.*;

import java.io.*;

public class SimpleEzOut implements EzOut {
  
  public SimpleEzOut(EzWriter writer) {
    this.writer = writer;
  }

  public OutputStream getOutputStream() {
    return null;
  }

  public EzWriter getWriter() {
    return writer;
  }

  public boolean isWriter() {
    return true;
  }

  
  private EzWriter writer;
}

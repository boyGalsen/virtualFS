package com.easyrms.io;

import java.io.*;

/**
 * An InputStream capable of counting read bytes.
 * 
 * @author rpelissier
 */
public class CountingInputStream extends FilterInputStream  implements Countable{

  /**
   * By default, skipped bytes are not included in the count.
   * 
   * @param inputStream
   */
  public CountingInputStream(InputStream inputStream) {
    this(inputStream, false);
  }

  public long getCount() {
    return count;
  }

  /**
   * @param inputStream
   * @param countSkippedBytes
   *          True if you want to include skipped bytes into the count
   */
  public CountingInputStream(InputStream inputStream, boolean countSkippedBytes) {
    super(inputStream);
    this.countSkippedBytes = countSkippedBytes;
  }

  @Override
  public int read() throws IOException {
    final int value = in.read();
    if (value > -1) count(1);
    return value;
  }

  @Override
  public int read(byte[] b, int off, int len) throws IOException {
    final int nRead = in.read(b, off, len);
    count(nRead);
    return nRead;
  }

  @Override
  public int read(byte[] b) throws IOException {
    final int nRead = in.read(b);
    count(nRead);
    return nRead;
  }

  @Override
  public long skip(long n) throws IOException {
    final long nRead = in.skip(n);
    if (countSkippedBytes) count(nRead);
    return nRead;
  }

  private void count(long n) {
    if (n > -1) {
      count += n;
    }
  }

  private long count = 0;
  private final boolean countSkippedBytes;
}

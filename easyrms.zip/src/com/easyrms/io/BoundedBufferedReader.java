package com.easyrms.io;


import java.io.*;


public class BoundedBufferedReader extends BufferedReader {
  
  public BoundedBufferedReader(Reader reader) {
    this(reader, DEFAULT_MAX_LINES, DEFAULT_MAX_LINE_LENGTH);
  }


  public BoundedBufferedReader(Reader reader, int maxLines, int maxLineLength) {
    super(reader);
    if ((maxLines <= 0) || (maxLineLength <= 0)) {
      throw new IllegalArgumentException("maxLines and maxLineLength Have to be > 0");
    }
    this.maxLines = maxLines;
    this.maxLineLength = maxLineLength;
    this.data = null;
  }
  
  @Override
  public String readLine() throws IOException {
    /*
    synchronized(lock) {
      if (currentLine >= maxLines) {
        throw new IOException("BoundedBufferedReader - Max Line count read limit has been reached.");
      }
      final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
      data = bufferPool.get();
      try {
        currentLine++;
        int currentPos = 0;
        int currentCharVal = super.read();
        
        while ((currentCharVal != CR) && (currentCharVal != LF) && (currentCharVal >= 0)) {
          data.append((char)currentCharVal);
          currentPos++;
          if (currentPos >= maxLineLength) {
            throw new IOException("BoundedBufferedReader - Max Line length read limit has been reached.");
          }
          currentCharVal = super.read();
        }
    
        if (currentCharVal < 0) {
          // End of file
          return null;
        }
        else {
          // Remove newline characters from the buffer
          if (currentCharVal == CR) {
            // Check for LF and remove from buffer
            super.mark(1);
            if (super.read() != LF) {
              super.reset();
            }
          }
          else if (currentCharVal != LF) {
            // readerMaxLineLen has been hit, but we still need to remove newline characters.
            super.mark(1);
            int nextCharVal = super.read();
            if (nextCharVal == CR) {
              super.mark(1);
              if (super.read() != LF) {
                super.reset();
              }
            }
            else if (nextCharVal != LF) {
              super.reset();
            }
          }
          return (data.toString());
        }
      }
      finally {
        bufferPool.free(data);
      }
    }*/
    final String line = super.readLine();
    return line;
  }

  private final int maxLines;
  private final int maxLineLength;
  private StringBuilder data;
  private int currentLine = 0;

  private static final int DEFAULT_MAX_LINES = Integer.MAX_VALUE;
  private static final int DEFAULT_MAX_LINE_LENGTH = 128*1024*1024;

  private static final int CR = 13;
  private static final int LF = 10;
}
package com.easyrms.io;


public interface EzContext {

  boolean isMobileContext();
  String getApplicationContext();
  String getLanguage();
  String getJargon();
  
  String defaultApplicationMode = "StandAlone";
  String mobileApplicationMode = "mobile";
  String defaultJargon =  "EzRMS";
  String defaultLanguage =  "GB";
}

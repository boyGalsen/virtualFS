package com.easyrms.io;

import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;

import java.awt.*;


public class SimpleEzContextOutput implements EzContextOutput {
   
  public SimpleEzContextOutput(EzWriter out, EzContext refContext) {
    this.out = out;
    this.htmlOut = (out instanceof HtmlBlockWriter) ? (HtmlBlockWriter)out : null;
    this.refContextOut = null;
    this.ezContext = SimpleEzContext.getEzContext(refContext);
  }  
  public SimpleEzContextOutput(EzWriter out, EzContextOutput refContextOut) {
    this.out = out;
    this.htmlOut = (out instanceof HtmlBlockWriter) ? (HtmlBlockWriter)out : null;
    this.refContextOut = refContextOut;
    this.ezContext = refContextOut; 
  }  
  public SimpleEzContextOutput(EzWriter out, String applicationContext, String language, String jargon) {
    this.out = out;
    this.htmlOut = (out instanceof HtmlBlockWriter) ? (HtmlBlockWriter)out : null;
    this.refContextOut = null;
    this.ezContext = SimpleEzContext.getEzContext(applicationContext, language, jargon);
  }

  public EzWriter getOut() {
    return out;
  }
  
  public String getJargon() {
    return ezContext.getJargon();
  }

  public String getLanguage() {
    return ezContext.getLanguage();
  }

  public String getApplicationContext() {
    return ezContext.getApplicationContext();
  }
  
  public boolean isMobileContext() {
    return ezContext.isMobileContext();  
  }
  
  public String addComponent(Component compotent) {
    if (refContextOut == null) return null;
    return refContextOut.addComponent(compotent);
  }
  
  public String addDynamicResource(String content, EzMimeType mimeType, EzEncoding encoding, String extension, boolean isTralatable) {
    if (refContextOut == null) return null;
    return refContextOut.addDynamicResource(content, mimeType, encoding, extension, isTralatable);
  }
  
  public String addDynamicResource(byte[] content, EzMimeType mimeType, String extension) {
    if (refContextOut == null) {
      return null;
    }
    return refContextOut.addDynamicResource(content, mimeType, extension);
  }

  public boolean isHTML() {
    return htmlOut != null;
  }

  public HtmlBlockWriter getHtmlOut() {
    return htmlOut;
  }

  public String translate(String value, EzContext ezContext) {
    if (refContextOut == null) {
      return HTMLHeaderFilter.standardTranslate.translate(value, ezContext);
    }
    return refContextOut.translate(value, ezContext);
  }

  public String translate(String text) {
    return translate(text, this);
  }

  private final HtmlBlockWriter htmlOut;
  private final EzWriter out;
  private final EzContextOutput refContextOut;
  private final EzContext ezContext;
}

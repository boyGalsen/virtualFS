package com.easyrms.io;

import com.easyrms.util.comparator.*;


public final class SimpleEzContext implements EzContext {
  
  public static EzContext getEzContext(String applicationContext, EzContext refContext) {
    if (refContext instanceof SimpleEzContext && ObjectComparator.equals(applicationContext, refContext.getApplicationContext())) return refContext;
    return new SimpleEzContext(applicationContext, refContext);
  }
  
  public static EzContext getEzContext(EzContext refContext) {
    return (refContext == null) ? standardContext : refContext;
  }
  
  public static EzContext getEzContext(EzContext refContext, String language, String jargon) {
    if (refContext instanceof SimpleEzContext 
      && StringComparator.equals(StringComparator.NVL(language, defaultLanguage), refContext.getLanguage())
      && StringComparator.equals(StringComparator.NVL(jargon, defaultJargon), refContext.getJargon())) return refContext;
    return new SimpleEzContext(refContext, language, jargon);
  }
  
  public static EzContext getEzContext(String applicationContext, String language, String jargon) {
    return new SimpleEzContext(applicationContext, language, jargon);
  }
  
  private SimpleEzContext(String applicationContext, EzContext refContext) {
    this(
      applicationContext,
      (refContext == null) ? null : refContext.getLanguage(), 
      (refContext == null) ? null : refContext.getJargon());
  }  
  private SimpleEzContext(EzContext refContext, String language, String jargon) {
    this(
      (refContext == null) ? null : refContext.getApplicationContext(), 
      language, 
      jargon);
  }  
  private SimpleEzContext(String applicationContext, String language, String jargon) {
    this.applicationContext = StringComparator.NVL(applicationContext, defaultApplicationMode);
    this.language = StringComparator.NVL(language, defaultLanguage);
    this.jargon = StringComparator.NVL(jargon, defaultJargon);
    this.isMobileContext = mobileApplicationMode.equals(this.applicationContext);
  }

  public String getLanguage() {
    return language;
  }

  public String getJargon() {
    return jargon;
  }
  
  public String getApplicationContext() {
    return applicationContext;
  }
  
  public boolean isMobileContext() {
    return isMobileContext;
  }

  private final String language;
  private final String jargon;
  private final String applicationContext;
  private final boolean isMobileContext;
  
  public static final SimpleEzContext standardContext = new SimpleEzContext((EzContext)null, (String)null, (String)null);
}

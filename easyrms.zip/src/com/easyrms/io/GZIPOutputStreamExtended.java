package com.easyrms.io;

import java.io.*;
import java.io.OutputStream;
import java.io.IOException;
import java.util.zip.*;


public class GZIPOutputStreamExtended extends FilterOutputStream {
  
  
  public GZIPOutputStreamExtended(final OutputStream out, final Deflater def) {
    this(out, def, 512);
  }
  
  public GZIPOutputStreamExtended(final OutputStream out, final int size, final String embedded) throws IOException {
    this(out, new Deflater(Deflater.DEFAULT_COMPRESSION, true), size);
    writeHeader(embedded);
    crc.reset();
  }
  
  public GZIPOutputStreamExtended(final OutputStream out) throws IOException {
    this(out, 512, null);
  }
  
  public GZIPOutputStreamExtended(final OutputStream out, final String embedded) throws IOException {
    this(out, 512, embedded);
  }
  
  public GZIPOutputStreamExtended(final OutputStream out, final Deflater def, final int size) {
    super(out);
    if (out == null || def == null) {
      throw new NullPointerException();
    } else if (size <= 0) {
      throw new IllegalArgumentException("buffer size <= 0");
    }
    this.def = def;
    buf = new byte[size];
  }
  
  
  @Override
  public void write(final int b) throws IOException {
    byte[] buffer = new byte[1];
    buffer[0] = (byte)(b & 0xff);
    writeLocal(buffer, 0, 1);
  }
  
  @Override
  public void write(final byte[] buffer, final int offset, final int length) throws IOException {
    writeLocal(buffer, offset, length);
    crc.update(buffer, offset, length);
  }
  
  private void writeLocal(final byte[] buffer, final int offset, final int length) throws IOException {
    if (def.finished()) {
      throw new IOException("write beyond end of stream");
    }
    if ((offset | length | (offset + length) | (buffer.length - (offset + length))) < 0) {
      throw new IndexOutOfBoundsException();
    } else if (length == 0) {
      return;
    }
    if (!def.finished()) {
      int stride = buf.length;
      for (int i = 0; i < length; i+= stride) {
        def.setInput(buffer, offset + i, Math.min(stride, length - i));
        while (!def.needsInput()) {
          deflate();
        }
      }
    }
  }
  
  @Override
  public void close() throws IOException {
    if (!closed) {
      finish();
      if (usesDefaultDeflater)
        def.end();
      out.close();
      closed = true;
    }
  }
  
  protected void deflate() throws IOException {
    int len = def.deflate(buf, 0, buf.length);
    if (len > 0) {
      out.write(buf, 0, len);
    }
  }
  
  public void finish() throws IOException {
    if (!def.finished()) {
      def.finish();
      while (!def.finished()) {
        int len = def.deflate(buf, 0, buf.length);
        if (def.finished() && len <= buf.length - TRAILER_SIZE) {
          writeTrailer(buf, len);
          len = len + TRAILER_SIZE;
          out.write(buf, 0, len);
          return;
        }
        if (len > 0)
          out.write(buf, 0, len);
      }
      byte[] trailer = new byte[TRAILER_SIZE];
      writeTrailer(trailer, 0);
      out.write(trailer);
    }
  }
  
  private void writeHeader(final String embedded) throws IOException {
    if (embedded != null) {
      byte head[] = header.clone();
      head[3] |= (1<<gzipFlags.FNAME.ordinal());
      out.write(head);
      out.write(embedded.getBytes());
      out.write(new byte[] {0});
      return;
    }
    
    out.write(header);
  }
  
  private void writeTrailer(final byte[] buffer, final int offset) {
    writeInt((int)crc.getValue(), buffer, offset);
    writeInt(def.getTotalIn(), buffer, offset + 4);
  }
  
  private void writeInt(final int i, final byte[] buffer, final int offset) {
    writeShort(i & 0xffff, buffer, offset);
    writeShort((i >> 16) & 0xffff, buffer, offset + 2);
  }
  
  private void writeShort(final int s, final byte[] buffer, final int offset) {
    buffer[offset] = (byte)(s & 0xff);
    buffer[offset + 1] = (byte)((s >> 8) & 0xff);
  }
  
  private final Deflater def;
  private byte[] buf;
  private boolean closed = false;
  
  protected CRC32 crc = new CRC32();
  
  private static enum gzipFlags {
    FTEXT,
    FHCRC,
    FEXTRA,
    FNAME,
    FCOMMENT,
  }
  
  private static final boolean usesDefaultDeflater = true;
  
  private final static int GZIP_MAGIC = 0x8b1f;
  private final static int TRAILER_SIZE = 8;
  
  private final static byte[] header = {
    (byte) GZIP_MAGIC,                // Magic number (short)
    (byte)(GZIP_MAGIC >> 8),          // Magic number (short)
    Deflater.DEFLATED,                // Compression method (CM)
    0,                                // Flags (FLG)
    0,                                // Modification time MTIME (int)
    0,                                // Modification time MTIME (int)
    0,                                // Modification time MTIME (int)
    0,                                // Modification time MTIME (int)
    0,                                // Extra flags (XFLG)
    0                                 // Operating system (OS)
  };
}

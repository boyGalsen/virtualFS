package com.easyrms.io.file;

import java.io.*;


public class XMLSpecialStartFileStream extends InputStream {
	
	public 	XMLSpecialStartFileStream(InputStream stream) {
		this.stream = stream;
		this.isOk = false;
		this.isFullOk = false;
		this.state = 0;
	}

  @Override
	public void close() throws IOException {
		if (stream != null) stream.close();
		this.stream = null;
  }

  @Override
	public int read() throws IOException {
  	if (isFullOk) return stream.read();
  	if (isOk) {
  		int c = stream.read();
  		switch (this.state) {
  			case 0: if (c == ' ' || c == '\t' || c == '\r' || c == '\n') { state = 1; } break;
  			case 1: if (c == 'x') { state = 2; } else { state = 0; } break;
  			case 2: if (c == 'm') { state = 3; } else { state = 0; } break;
				case 3: if (c == 'l') { state = 4; } else { state = 0; } break;
				case 4: if (c == 'n') { state = 5; } else { state = 0; } break;
				case 5: if (c == 's') { state = 6; } else { state = 0; } break;
				case 6: if (c == ':') { c = stream.read(); } isFullOk = true; break;
  		}
  		return c;
  	}
  	int c = 0;
    while ((c = stream.read()) != (byte)'<') {
      if (c == -1) {
        return -1;
      }
		}
		isOk = true;
		return (byte)'<';
  }

	private InputStream stream;
	private boolean isOk = false;
	private boolean isFullOk = false;
	private int state = 0;
}

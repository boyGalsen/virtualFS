package com.easyrms.io.file;

import java.io.*;


public class XMLSimpleSpecialStartFileStream extends InputStream {
	
	public XMLSimpleSpecialStartFileStream(InputStream stream) {
		this.stream = stream;
		this.isOk = false;
	}

  @Override
	public void close() throws IOException {
		if (stream != null) {
		  stream.close();
		}
		this.stream = null;
  }

  @Override
	public int read() throws IOException {
  	if (isOk) {
  	  return stream.read();
  	}
  	int c = 0;
  	while ((c = stream.read()) != (byte)'<') {
  	  if (c == -1) {
  	    return -1;
  	  }
  	}
		isOk = true;
		return (byte)'<';
  }

	private InputStream stream;
	private boolean isOk = false;
}

package com.easyrms.io;

import com.easyrms.util.net.content.*;

import java.io.*;


public interface EzOut {

  boolean isWriter();
  EzWriter getWriter();
  OutputStream getOutputStream();
}

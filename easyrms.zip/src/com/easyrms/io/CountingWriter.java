package com.easyrms.io;

import java.io.*;

public class CountingWriter extends FilterWriter implements Countable {

  public CountingWriter(Writer out) {
    super(out);
  }

  public long getCount() {
    return count;
  }

  @Override
  public Writer append(char c) throws IOException {
    return out.append(c);
  }

  @Override
  public Writer append(CharSequence csq, int start, int end) throws IOException {
    out.append(csq, start, end);
    count += (end - start);
    return this;
  }

  @Override
  public Writer append(CharSequence csq) throws IOException {
    out.append(csq);
    count += csq.length();
    return this;
  }

  @Override
  public void write(char[] cbuf) throws IOException {
    out.write(cbuf);
    count += cbuf.length;
  }

  @Override
  public void write(int c) throws IOException {
    out.write(c);
    count++;
  }

  @Override
  public void write(String str, int off, int len) throws IOException {
    out.write(str, off, len);
    count += len;
  }

  @Override
  public void write(String str) throws IOException {
    out.write(str);
    count += str.length();
  }

  @Override
  public void write(char[] cbuf, int off, int len) throws IOException {
    out.write(cbuf, off, len);
    count += len;
  }

  private long count = 0;
}

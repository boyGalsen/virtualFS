package com.easyrms.io;

import com.easyrms.util.*;
import java.awt.image.*;
import java.io.*;
import java.io.InputStream;
import javax.imageio.*;
import org.imgscalr.*;


public final class PictureUtil {
  
  public static ByteArrayOutputStream resize(ByteArrayOutputStream destinationFile, InputStream in, int finalwidth, int finalheigth, String filename){
    try {
    final BufferedImage imgUpload = ImageIO.read(in);
    final double width = imgUpload.getWidth();
    final double height = imgUpload.getHeight();
    final double imgUploadRatio = width / height;
    final double thumbnailRatio = (double)finalwidth /(double)finalheigth;
    
    final BufferedImage thumbnail;
    if (imgUploadRatio >= thumbnailRatio) {
      BufferedImage thumbnailToWork = Scalr.resize(imgUpload, Scalr.Mode.FIT_TO_HEIGHT, finalheigth);
      final int topLeftX = (thumbnailToWork.getWidth() / 2) - (finalwidth / 2);
      final int topLeftY = 0;
      thumbnailToWork = Scalr.crop(thumbnailToWork, topLeftX, topLeftY, finalwidth, finalheigth);
      thumbnail = thumbnailToWork;
    }
    else {
      BufferedImage thumbnailToWork = Scalr.resize(imgUpload, Scalr.Mode.FIT_TO_WIDTH, finalwidth);
      final int topLeftX = 0;
      final int topLeftY = (thumbnailToWork.getHeight() / 2) - (finalheigth / 2);
      thumbnailToWork = Scalr.crop(thumbnailToWork, topLeftX, topLeftY, finalwidth, finalheigth);
      thumbnail = thumbnailToWork;
    }
    
    final int extensionPos = filename.lastIndexOf('.');
    final String fileExt = filename.substring(extensionPos + 1);
  
    ImageIO.write(thumbnail, fileExt, destinationFile);
    if (in==null|| StringUtil.isNull(filename)) {
      throw new IllegalArgumentException();
    }
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
      ExceptionUtils.newRuntimeException(ignored);
    }
    return destinationFile;
    
    
  }

}

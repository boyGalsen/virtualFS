package com.easyrms.io.stream;

import com.easyrms.util.*;

import java.io.*;

public class EzByteArrayOutputStream extends ByteArrayOutputStream {

  public EzByteArrayOutputStream() {
    super();
  }

  public EzByteArrayOutputStream(int size) {
    super(size);
  }

  @Override
  public synchronized byte[] toByteArray() {
    countAll.add(count);
    return super.toByteArray();
  }

  private static Counter countAll = new Counter("EzByteArrayOutputStream");
}

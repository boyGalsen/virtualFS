package com.easyrms.io;

import java.io.*;

public class BigStringWriter extends StringWriter {

  public BigStringWriter() {
    super();
  }
  public BigStringWriter(int initialSize) {
    super(initialSize);
  }
}

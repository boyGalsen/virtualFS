package com.easyrms.io.mail;

import com.easyrms.cache.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.ezjmx.*;
import com.easyrms.util.net.content.*;

import java.io.*;
import java.net.InetAddress;
import java.util.*;

import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;


public class MailUtil {
  
  public static void check() {}
  
  public static void refresh() {
    if (directory != null) {
      directory.refresh();
    }
  }
  
  public static MailDirectory.MailDirectoryStatusSnapshot getStatusSnapshot(EzDate day) {
    return (directory != null) ? directory.getStatusSnapshot(day) : MailDirectory.noStatus;
  }
  
  public static MailDirectory.MailDirectoryStatusSnapshot getStatusSnapshot(EzDate day, String key1) {
    return (directory != null) ? directory.getStatusSnapshot(day, key1) : MailDirectory.noStatus;
  }
  
  public static MailDirectory.MailDirectoryStatusSnapshot getStatusSnapshot(EzDate day, String key1, String key2) {
    return (directory != null) ? directory.getStatusSnapshot(day, key1, key2) : MailDirectory.noStatus;
  }

  
  public static EzArray<MailDirectory.MailMessage> listMails(MailDirectory.MailMessageFilter filter, EzDate day) {
    if (directory != null && EasyRMSSMTPHost != null) {
      final EzArrayList<MailDirectory.MailMessage> result = new EzArrayList<MailDirectory.MailMessage>(directory.getToSendMailDirectoryCount());
      try {
        final Iterator<MailDirectory.MailMessage> i = directory.iterator(findSession(EasyRMSSMTPHost, EasyRMSSMTPUser, EasyRMSSMTPPassword), filter, day);
        while (i.hasNext()) {
          result.add(i.next());
        }
        return result;
      }
      catch (Throwable e) {
        trace.log(e);
      }
    }
    return MailDirectory.noMessage;
  }
  
  public static final MailDirectory.MailMessage findMail(final String refUid, EzDate day) {
    if (directory != null && EasyRMSSMTPHost != null) {
      final EzArrayList<MailDirectory.MailMessage> result = new EzArrayList<MailDirectory.MailMessage>(directory.getToSendMailDirectoryCount());
      try {
        final Iterator<MailDirectory.MailMessage> i = directory.iterator(
          findSession(EasyRMSSMTPHost, EasyRMSSMTPUser, EasyRMSSMTPPassword), 
          (p, uid, f1, f2, m) -> { return StringComparator.equals(uid, refUid); },
          day);
        while (i.hasNext()) {
          result.add(i.next());
        }
        if (result.size() > 0) {
          return result.get(0);
        }
      }
      catch (Throwable e) {
        trace.log(e);
      }    
    }
    return null;
  }
  
  public static void sendSimpleEmail(
    String prefix,
    String user,
    String password,
    String replyTo,
    String[] to,
    String[] cc,
    String[] bcc,
    String subject,
    String messageBody,
    String smtpHost,
    String from,
    ValidatedFile fileToAdd,
    boolean isHTML) throws Exception
  {
		sendSimpleEmail(
      prefix,
      user,
      password,
			replyTo,
			to,
			cc,
			bcc,
			subject,
			messageBody,
			smtpHost,
			from,
			((fileToAdd == null) ? null : new com.easyrms.util.ByteArrayDataSource(fileToAdd.getName(), StreamUtils.toByteArray(fileToAdd), EzMimeType.findMimeTypeFromFileName(fileToAdd.getName()))),
			isHTML);
  }
	public static void sendSimpleEmail(
		 String prefix,
     String user,
     String password,
     String replyTo,
		 String[] to,
		 String[] cc,
		 String[] bcc,
		 String subject,
		 String messageBody,
		 String smtpHost,
		 String from,
		 String attachName,
		 String attachMessage,
		 boolean isHTML) throws Exception
	 {
		 sendSimpleEmail(
       prefix, 
       user, 
       password,
			 replyTo,
			 to,
			 cc,
			 bcc,
			 subject,
			 messageBody,
			 smtpHost,
			 from,
			 attachName,
			 attachMessage,
			 "text/plain",
			 isHTML);
  }
	public static void sendSimpleEmail(
    String prefix,
    String user,
    String password,
		String replyTo,
		String[] to,
		String[] cc,
		String[] bcc,
		String subject,
		String messageBody,
		String smtpHost,
		String from,
		String attachName,
		String attachMessage,
		String contentType,
		boolean isHTML) throws Exception
	{
    sendSimpleEmail(
      prefix,
      user,
      password,
      replyTo,
			to,
			cc,
			bcc,
			subject,
			messageBody,
			smtpHost,
			from,
		  (attachMessage == null) ? null : new StringDataSource(attachName, attachMessage, contentType),
			isHTML);
  }
  public static void sendSimpleEmail(
    String prefix,
    String user,
    String password,
    String replyTo,
    String[] to,
    String[] cc,
    String[] bcc,
    String subject,
    String messageBody,
    String smtpHost,
    String from,
    DataSource attachment,
    boolean isHTML) throws Exception
  {
    sendSimpleEmail(
      prefix,
      user,
      password,
			replyTo,
			to,
			cc,
			bcc,
			subject,
			messageBody,
			smtpHost,
			from,
			(attachment == null) ? null : new DataSource[] { attachment,},
			isHTML);
  }
  public static void sendSimpleEmail(
    String prefix,                                     
    String user,
    String password,
    String replyTo,
    String[] to,
    String[] cc,
    String[] bcc,
    String subject,
    String messageBody,
    String smtpHost,
    String from,
    boolean isHTML) throws Exception
  {
    sendSimpleEmail(prefix, user, password, replyTo, to, cc, bcc,subject, messageBody, smtpHost, from, (DataSource[])null,isHTML);
  }
	public static void sendSimpleEmail(
    String prefix,
    String user,
    String password,
		String replyTo,
		String[] to,
		String[] cc,
		String[] bcc,
		String subject,
		String messageBody,
		String smtpHost,
		String from,
		DataSource[] attachment,
		boolean isHTML) throws Exception
	{
    if (StringComparator.isNull(smtpHost)) {
      smtpHost = EasyRMSSMTPHost;
    }
    if (smtpHost != null && smtpHost.equals(EasyRMSSMTPHost)) {
      if (StringComparator.isNull(user)) {
        user = EasyRMSSMTPUser;
      }
      if (StringComparator.isNull(password)) {
        password = EasyRMSSMTPPassword;
      }
      if (password == null) {
        user = null;
      }
    }
		if (from != null && smtpHost != null) {
			final MimeMessage message = new MimeMessage(findSession(smtpHost, user, password));
			message.setFrom(findInternetAddress(from));
			if (replyTo != null) {
				message.setReplyTo(new InternetAddress[] {findInternetAddress(replyTo)});
			}
			if (to != null) {
				for (int i = 0, n = to.length; i < n; i++) {
					message.addRecipient(Message.RecipientType.TO, findInternetAddress(to[i]));
				}
			}
			if (cc != null) {
				for (int i = 0, n = cc.length; i < n; i++) {
					message.addRecipient(Message.RecipientType.CC, findInternetAddress(cc[i]));
				}
			}
			if (bcc != null) {
				for (int i = 0, n = bcc.length; i < n; i++) {
					message.addRecipient(Message.RecipientType.BCC, findInternetAddress(bcc[i]));
				}
			}
			message.setSubject(StringComparator.NVL(subject));

			if (attachment != null) {
        final MimeBodyPart messageBodyPart = new MimeBodyPart();
        if (isHTML) {
          messageBodyPart.setContent(StringComparator.NVL(messageBody), EzMimeType.TEXT_HTML_UTF8.getName());
        }
        else {
          messageBodyPart.setText(StringComparator.NVL(messageBody), EzEncoding.UTF_8.getName());
        }
				final Multipart multipart = new MimeMultipart();
				multipart.addBodyPart(messageBodyPart);
        for (int i = 0, n = attachment.length; i < n ; i++) {
          final DataSource attachementI = attachment[i];
  				final MimeBodyPart messageAttachementPart = new MimeBodyPart();
          messageAttachementPart.setDataHandler(new DataHandler(attachementI));
          messageAttachementPart.setFileName(attachementI.getName());
          messageAttachementPart.setHeader("Content-ID", "<attachment_"+i+">");
          final String contentType = attachementI.getContentType();
          if (contentType.indexOf(";") >= 0) {
            messageAttachementPart.setHeader("Content-Type", contentType);
          }
          multipart.addBodyPart(messageAttachementPart);
        }
  			message.setContent(multipart);
			}
			else {
				if (isHTML) {
					message.setContent(StringComparator.NVL(messageBody), EzMimeType.TEXT_HTML_UTF8.getName());
				}
				else {
          message.setText(StringComparator.NVL(messageBody), EzEncoding.UTF_8.getName());
				}
			}
			if (!mailTransport.send(prefix, smtpHost, user, password, message)) {
        throw ExceptionUtils.newRuntimeException("Message cannot be sent");
      }
		}
		else {
			trace.log("Mail can not be send: host [" + smtpHost + "] and/or from [" + from + "] be 'null' values.");
		}
	}
	
	public static Session findSession(String smtpHost, String user, String password) throws Exception {
	  if (password == null) {
	    user = null;
	  }
		final Properties props = new Properties();
    props.put("mail.smtp.localhost", localHost);
		props.put("mail.smtp.host", smtpHost);
    props.put("mail.smtp.auth", StringComparator.isNotNull(user) ? "true" : "false");
    final Session session = Session.getInstance(props, null);
		session.setDebug(false);
		return session;
	}
	
	public static InternetAddress findInternetAddress(String email) throws Exception {
    return internetAdressCache.get(email);
  }
	
	private static final Cache<String, InternetAddress> internetAdressCache = Caches.newManagerInstance(new Creator<String, InternetAddress>() {
		
		public InternetAddress create(String email) throws Exception {
      final int indexOfBracket = email.indexOf('<');
      if (indexOfBracket >= 0 && email.charAt(email.length()-1) == '>') {
        final String personal = email.substring(indexOfBracket+1, email.length()-1);
        final String address = email.substring(0, indexOfBracket).toLowerCase();
        return new InternetAddress(address, personal);
      }
      return new InternetAddress(email);
		}
	});

  public static javax.mail.Message[] filterMailMessages(javax.mail.Message messages[], MailFilter filter) {
    if (messages == null) return null;
    final javax.mail.Message[] filteredMessages = new javax.mail.Message[messages.length];
    int index = 0;
    for (int i = 0, n = messages.length; i < n; i++) {
    	final javax.mail.Message message = messages[i];
      try {
        if (message != null && filter.accept(message)) {
          filteredMessages[index++] = message;
        }
      }
      catch (Throwable exception) {
        trace.log(exception, true);
      }
    }
    final javax.mail.Message[] resultMessages = new javax.mail.Message[index];
    System.arraycopy(filteredMessages, 0, resultMessages, 0, index);
    return resultMessages;
  }
  
	private static EzMailTransport mailTransport;

	private static class EzMailTransport extends AbstractEzProcessPeriodic {
    
   	public EzMailTransport(String name, int delayInMilliSeconds) {
      super(null, name, delayInMilliSeconds, true);
		}
    
    @Override
    protected PeriodicContextType getContextType() {
      return PeriodicContextType.LAUNCHERS;
    }
    
		public boolean send(String prefix, String smtpHost, String user, String password, Message mailMesssage) {
			try {
				trace.log(mailMesssage.getSubject());
        if (outprocess && directory != null) {
          addToJMS(prefix, smtpHost, user, password, mailMesssage);
        }
        else if (backup && directory != null) {
          if (sendBySMTPMessage(smtpHost, user, password, mailMesssage)) {
            try {
              bakcupToJMS(prefix, smtpHost, user, password, mailMesssage);
            }
            catch (Throwable ignored) {
              trace.log(ExceptionUtils.getMessage(ignored));
            }
            return true;
          }
          addToJMS(prefix, smtpHost, user, password, mailMesssage);
        }
        else {
  				if (!sendBySMTPMessage(smtpHost, user, password, mailMesssage)) {
  					return addToJMS(prefix, smtpHost, user, password, mailMesssage) != null;
  				}
        }
				return true;
			}
			catch (Throwable ignored) {
				trace.log(ignored, true);
			}
			return false;
		}
    
    private boolean sendBySMTPMessage(String logConstant, Transport transport, Message message) throws Throwable {
      if (!allowSendMail.isActive()) {
        trace.log("Send Email Not Allowed");
        return false;
      }
      String additionalInformation = "";
      try {
        additionalInformation += "subject:["+message.getAllRecipients()[0].toString()+"]"+message.getSubject()+"";
      }
      catch (Throwable ignored) {
        additionalInformation += "with problem";
      }
      trace.log("MAILTRANSPORT STARTSEND"+logConstant+additionalInformation);
      transport.sendMessage(message, message.getAllRecipients());
      trace.log("MAILTRANSPORT FINNISH SEND"+logConstant+additionalInformation);
      return true;
    }

		private boolean sendBySMTPMessage(String smtpHost, String user, String password, Message message) {
      if (!allowSendMail.isActive()) {
        trace.log("Send Email Not Allowed");
        return false;
      }
      try {
        final String logConstant = " host:"+smtpHost+";user:"+user+";password:"+password+";";
				try {
					trace.log("MAILTRANSPORT INIT"+logConstant);
					final Session session = findSession(smtpHost, user, password);
          trace.log("MAILTRANSPORT SESSION GETTED"+logConstant);
          final Transport transport = session.getTransport("smtp");
          try {
            transport.connect(smtpHost, user, password);
            trace.log("MAILTRANSPORT CONNECTED"+logConstant);
            sendBySMTPMessage(logConstant, transport, message);
					}
					finally {
						transport.close();
					}
          trace.log("MAILTRANSPORT CLOSE"+logConstant);
					return true;
				}
				catch (Throwable ignored) {
          trace.log("MAILTRANSPORT ERROR SEND"+logConstant);
					trace.log(ignored, true);
          final Throwable cause = ignored.getCause();
          if (cause != null) {
            trace.log(cause, true);
          }
				}
			}
			catch (Throwable ignored) {
				trace.log(ignored, true);
			}
      return false;
		}

		private MailDirectory.MailMessage addToJMS(String prefix, String smtpHost, String user, String password, Message message) {
			if (directory != null) {
  			try {
  				trace.log("MAILTRANSPORT PERSISTANT SAVE "+ message.getSubject());
          return directory.save(prefix, message);
  			}
  			catch (Throwable ignored) {
  				trace.log(ignored, true);
  			}
			}
      return null; 
		}
    
    private void bakcupToJMS(String prefix, String smtpHost, String user, String password, Message message) {
      if (directory == null) return;
      try {
        trace.log("MAILTRANSPORT PERSISTANT BACKUP "+ message.getSubject());
        directory.saveAndDelete(prefix, message);
      }
      catch (Throwable ignored) {
        trace.log(ignored, true);
      }
    }

		@Override
    protected void runPeriodicProcess() {
      final String smtpHost = EasyRMSSMTPHost;
      String user = EasyRMSSMTPUser;
      String password = EasyRMSSMTPPassword;
      if (password == null) {
        user = null;
      }
			if (allowSendMail.isActive() && sendSerializedMessage && directory != null && EasyRMSSMTPHost != null) {
        trace.log("START MAILTRANSPORT");
        try {
          
          final String logConstant = " host:"+smtpHost+";user:"+user+";password:"+password+";";
          try {
            trace.log("MAILTRANSPORT INIT"+logConstant);
            final Session session = findSession(smtpHost, user, password);
            if (session == null) {
              trace.log("MAILTRANSPORT SESSION CANNOT BE GETTED"+logConstant);
            }
            else {
              trace.log("MAILTRANSPORT SESSION GETTED"+logConstant);
              final Transport transport = session.getTransport("smtp");
              if (transport == null) {
                trace.log("CANNOT GET SMTP TRANSPORT"+logConstant);
              }
              else {
                try {
                  trace.log("TRY CONNECT SMTP SERVER "+logConstant);
                  transport.connect(smtpHost, user, password);
                  trace.log("MAILTRANSPORT CONNECTED"+logConstant);
                  for (final Iterator<MailDirectory.MailMessage> i = directory.iterator(session); i.hasNext();) {
                    try {
                      final MailDirectory.MailMessage message = i.next();
                      try {
                        if (message != null && sendBySMTPMessage(logConstant, transport, message.getMessage())) {
                          directory.delete(message);
                        }
                      }
                      catch (Throwable ignored) {
                        trace.log("ERROR IN MESSAGE:"+ExceptionUtils.getMessage(ignored));
                        trace.log(ignored, true);
                      }
                    }
                    catch (Throwable ignored) {
                      trace.log("ERROR IN MESSAGE:"+ExceptionUtils.getMessage(ignored));
                      trace.log(ignored, true);
                    }
                  }
                }
                finally {
                  transport.close();
                }
              }
            }
            trace.log("MAILTRANSPORT CLOSE"+logConstant);
          }
          catch (Throwable ignored) {
            trace.log("MAILTRANSPORT ERROR SEND"+logConstant);
            trace.log(ignored, true);
            final Throwable cause = ignored.getCause();
            if (cause != null) trace.log(cause, true);
          }
  			}
        catch (Throwable ignored) {
          trace.log("ERROR IN DIRECTORY:"+ExceptionUtils.getMessage(ignored));
          trace.log(ignored, true);
        }
        trace.log("STOP MAILTRANSPORT");
      }
  	}
  }  
  
  public static Message read(Session session, ValidatedFile file) throws Exception {
    try (final InputStream in = StreamUtils.newFileInputStream(file)) {
      return new MimeMessage(session, in);
    }
  }
  
  public static void save(Message mailMesssage, ValidatedFile file) throws Exception {
    try (final FileOutputStream tmp = StreamUtils.newFileOutputStream(file)) {
      mailMesssage.writeTo(tmp);
    }
  }

	static final Trace trace = new Trace("MailUtil", false);
  
  /**
   * return -1 if no transport defined
   */
  public static int getDelayInMilliSeconds() {
    final EzMailTransport innerMailTransport = mailTransport;
    return (innerMailTransport != null) ? innerMailTransport.getDelay() : -1;
  }
  
  public static int getFirstDelayLimit() {
    final int delay = getDelayInMilliSeconds();
    return (delay < 0) ? delay : 2*delay;
  }
  
  public static int getSecondDelayLimit() {
    final int delay = getDelayInMilliSeconds();
    return (delay < 0) ? delay : 4*delay;
  }

  public static synchronized void init(MailDirectory mailDirectory, String name, int delayInMilliSeconds, boolean start) {
    trace.log("HOST:"+EasyRMSSMTPHost);
    directory = mailDirectory; 
    mailTransport = new EzMailTransport(name, delayInMilliSeconds);
    if (start) {
      mailTransport.start();
    }
  }

  private static MailDirectory directory = null;
  private static String localHost = "";
  static {
    try {
      PropertiesUtil.getString("com.easyrms.io.mail.localHost", InetAddress.getLocalHost().getHostName()+"EZRMSJAVA");
    }
    catch (Throwable ignored) {
      trace.log(ignored);
    }
  }
  private static final String EasyRMSSMTPHost = PropertiesUtil.getString("com.easyrms.io.mail.EasyRMSSMTPHost", null);	
  private static final String EasyRMSSMTPUser = PropertiesUtil.getString("com.easyrms.io.mail.EasyRMSSMTPUser", null);  
  private static final String EasyRMSSMTPPassword = PropertiesUtil.getString("com.easyrms.io.mail.EasyRMSSMTPPassword", null);  
  private static final boolean outprocess = PropertiesUtil.getBoolean("com.easyrms.io.mail.Outprocess", true);
  private static final boolean sendSerializedMessage = PropertiesUtil.getBoolean("com.easyrms.io.mail.SendSerializedMessage", true);
  private static final boolean backup = PropertiesUtil.getBoolean("com.easyrms.io.mail.Backup", true);
  private static final EzFlag allowSendMail = new EzFlag("Allow Send Mail", !EasyRMS.isStandby && PropertiesUtil.getBoolean("com.easyrms.io.mail.allowSendMail", !EasyRMS.isDebug), EasyRMS.isStandby);
  static {
    init(
      new MailDirectory(
        "EzRMS Send Box", 
        StreamUtils.getWorkDirectory(PropertiesUtil.getString("com.easyrms.io.mail.DirectoryName", "mails"))),
      PropertiesUtil.getString("com.easyrms.io.mail.ThreadName", "Mail Transporter"),
      PropertiesUtil.getInt("com.easyrms.io.mail.WaitTime", 10)*60*1000,
      PropertiesUtil.getBoolean("com.easyrms.io.mail.Start", true));
  }
}

package com.easyrms.io.mail;

import com.easyrms.date.*;
import com.easyrms.io.*;
import com.easyrms.table.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;

import com.sun.mail.pop3.*;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.mail.*;


public class MailBox {
	
	public MailBox(String host, String user, String password) {
		this.host = host;
		this.user = user;
		this.password = password;
    this.trace = new Trace("Mail Box "+user+"@"+host, false);
	}
	
	public  boolean isInList(String value, String[] list) {
    if (list != null) {
  		for (int i = 0, maxi = list.length; i < maxi; i++) {
        if (value.equals(list[i])) {
          return true;
        }
  		}
    }
		return false;
	}
	
	public void delete(String[] messageNumbers) {
		final Session session = Session.getInstance(properties, null);
		try {
			final Store store = session.getStore("pop3");
			store.connect(host, user, password);
			try {
				final POP3Folder folder = (POP3Folder)store.getFolder("INBOX");
				folder.open(Folder.READ_WRITE);
				try {
					if (folder.isOpen()) {
						final FetchProfile profile = new FetchProfile();
						profile.add(UIDFolder.FetchProfileItem.UID);
						final Message[] messages = folder.getMessages();
            if (messages != null) {
  						folder.fetch(messages, profile);
  						for (int i = 0, maxi = messages.length ; i < maxi; i++) {
                final Message message = messages[i];
                if (message != null ) {
  								final String messageNumber = folder.getUID(message);
  								if (isInList(messageNumber, messageNumbers)) {
                    message.setFlag(Flags.Flag.DELETED, true);
  								}
  							}
  						}
            }
					}
				}
				finally {
					folder.close(true);
				}
			}
			finally {
				store.close();
			}
		}
		catch (Throwable exception) {
      trace.log(exception);
		}
	}
	
	public String detail(int index) {
		return null;
	}
	
	private String errorCode = null;
	private boolean hasError = false;
	
	private EzArray<EzMessage> toEzMessage(POP3Folder folder, Message[] messages) throws Exception{
		if (messages == null) return null;
		final EzArrayList<EzMessage> ezMessages= new EzArrayList<EzMessage>(messages.length);
		for (int i= 0, n = messages.length; i < n; i++) {
			try {
        final Message message = messages[i];
				if (message != null) {
					final Address[] from =  message.getFrom();
					ezMessages.add(new EzMessage(
					folder.getUID(message),
					message.getMessageNumber(), 
					(from == null || from.length < 1 || from[0] == null) ? "" : from[0].toString(), 
					message.getSubject(), 
					message.getSize(), 
					message.getFileName(),
					new SimpleDateAccessor(message.getReceivedDate()),
					new SimpleDateAccessor(message.getSentDate()),
					null,
					message.getDescription(),
					message.getContentType(),
					message.getDisposition()
					));
				}
			}
			catch(Exception ignored) {
				trace.log(ignored);
			}
			
		}
		return ezMessages;
	}
	
	public EzArray<EzMessage> getMessages() {
		final Session session = Session.getInstance(properties, null);
		try {
			try {
				final Store store = session.getStore("pop3");
				store.connect(host, user, password);
				try {
					final Folder ffolder = store.getFolder("INBOX");
					if (ffolder instanceof POP3Folder) {
						final POP3Folder folder = (POP3Folder)ffolder;
						final FetchProfile profile = new FetchProfile();
						profile.add(UIDFolder.FetchProfileItem.UID);
						folder.open(Folder.READ_ONLY);
						try {
							if (folder.isOpen()) {
								final Message[] messages = folder.getMessages();
								folder.fetch(messages,profile);
								return toEzMessage(folder, messages);
							}
							errorCode += "Folder is not open";
							hasError = true;
						}
						finally {
							folder.close(true);
						}
					}
				}
				finally {
					store.close();
				}
			}
			catch (Throwable exception) {
        trace.log(exception);
				errorCode += ExceptionUtils.getMessage(exception);
				hasError = true;
			}
		}
		finally {
		}
		return null;
	}
  
  
  public Message findMessage(String uid) {
    final ValidatedFile file = findMessageFile(uid);
    if (file != null) {
      final Session session = Session.getInstance(properties, null);
      try {
        return MailUtil.read(session, file);
      }
      catch (Throwable exception) {
        trace.log(exception);
      }
    }
    return null;
  }    

  public ValidatedFile findMessageFile(String uid) {
    final ValidatedFile file = StreamUtils.getWorkFile("/mail/"+user.replace("[@. \r\n\t]","_")+"/"+uid+".eml");
    final Session session = Session.getInstance(properties, null);
    try {
      if (file.isExists()) {
        return file;
      }
      final Store store = session.getStore("pop3");
      store.connect(host, user, password);
      try {
        final POP3Folder folder = (POP3Folder)store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        try {
          if (folder.isOpen()) {
            final FetchProfile profile = new FetchProfile();
            profile.add(UIDFolder.FetchProfileItem.UID);
            final Message[] messages = folder.getMessages();
            folder.fetch(messages, profile);
            for (int i= 0, n = messages.length; i < n; i++) {
              final Message message = messages[i];
              if (uid.equals(folder.getUID(message))) {
                MailUtil.save(message, file);
                return file;
              }
            }
          }
        }
        finally {
          folder.close(true);
        }
      }
      finally {
        store.close();
      }
    }
    catch (Throwable exception) {
      trace.log(exception);
    }
    return null;
  }    
  
  
	private void printDetail(EzContextOutput ezout, Message message, String uuid) throws IOException {
		try {
      if (EasyRMS.isDebug) {
        MailUtil.save(message, StreamUtils.getWorkFile("/mail/"+EzYYYYMMDDDateFormat.referenceFormat(EzDate.now())+"/"+(uuid == null ? message.getMessageNumber()+"" : uuid)+".eml"));
      }
      final EzWriter out = ezout.getOut();
			out.write("<table border='0'><tr><td>From</td><td width='100%'>");
			final Address[] from = message.getFrom();
      if (from != null) {
  			for (int i = 0, maxi = from.length ; i < maxi ; i++) {
          if (from[i] != null) {
  					out.write("<DIV>");				
  					out.write(from[i].toString());
  					out.write("</DIV>");				
  				}
  			}
      }
			out.write("</td></tr><tr><td>Sent Date</td><td>");
			final Date senddate = message.getSentDate();
			out.write((senddate != null) ? ebXMLDateFormat.referenceFormat(senddate) : "&nbsp;");
		  out.write("</td></tr><tr><td>Receive Date</td><td>");
			final Date reiceivedate = message.getReceivedDate();
			out.write((reiceivedate != null) ? ebXMLDateFormat.referenceFormat(reiceivedate) : "&nbsp;");
			out.write("</td></tr><tr><td>Size</td><td>");
			out.write(IntegerCache.toString(message.getSize()));
			out.write("</td></tr><tr><td>Subject</td><td>");
			out.write(StringComparator.NVL(message.getSubject(),"&nbsp;"));
			out.write("</td></tr><tr><td>FileName</td><td>");
			out.write(StringComparator.NVL(message.getFileName(),"&nbsp;"));
			out.write("</td></tr><tr><td>Disposition</td><td>");
			out.write(StringComparator.NVL(message.getDisposition(),"&nbsp;"));
			out.write("</td></tr><tr><td>Description</td><td>");
			out.write(StringComparator.NVL(message.getDescription(),"&nbsp;"));
			out.write("</td></tr><tr><td>Content Type</td><td>");
			out.write(StringComparator.NVL(message.getContentType(),"&nbsp;"));
			out.write("</td></tr>");
	
			final Enumeration headers = message.getAllHeaders();
			while (headers.hasMoreElements()) {
				try {
					final Header header = (Header)headers.nextElement();
					out.write("<tr><td>");
					out.write(StringComparator.NVL(header == null ? null : header.getName(),"&nbsp;"));
					out.write("</td><td>");
					out.write(StringComparator.NVL(header == null ? null : header.getValue(),"&nbsp;"));
					out.write("</td></tr>");
				}
				catch(Exception e) {
					EasyRMS.trace.log(e);
				}
			}
			out.write("<tr><td colspan=2 style='padding-top:10px;'><pre>");
			out.write(message.getContent().toString());
			out.write("</pre></td></tr></table>");
		}
		catch (Exception exception) {
			throw new IOException(ExceptionUtils.getMessage(exception));		
		}
	}

	public synchronized void printDetail(EzContextOutput ezout, final String uid) throws IOException {
		final Session session = Session.getInstance(properties, null);
		try {
			final Store store = session.getStore("pop3");
			store.connect(host, user, password);
			try {
				final POP3Folder folder = (POP3Folder)store.getFolder("INBOX");
				folder.open(Folder.READ_ONLY);
				try {
					if (folder.isOpen()) {
						final FetchProfile profile = new FetchProfile();
						profile.add(UIDFolder.FetchProfileItem.UID);
						final Message[] messages = folder.getMessages();
						folder.fetch(messages, profile);
						for (int i= 0, n = messages.length; i < n; i++) {
              final Message message = messages[i];
							if (uid.equals(folder.getUID(message))) {
								printDetail(ezout, message, uid);
							}
						}
					}
				}
				finally {
					folder.close(true);
				}
			}
			finally {
				store.close();
			}
		}
		catch (Throwable exception) {
			trace.log(exception);
		}
	}
	
	
	public synchronized void print(EzContextOutput ezout) throws IOException {
		hasError = false;
		errorCode = StringArrays.emptyString;
		final Data data = new MailListData(getMessages());
		final HTMLSimpleGrid grid = new HTMLSimpleGrid();
		final SimpleHTMLTable table = new SimpleHTMLTable(data, grid);
		grid.setFullGrid(true);
		if (hasError) {
      final EzWriter out = ezout.getOut();
			out.write("<div>");
			out.write(errorCode);
			out.write("</div>");
		}
		table.print(ezout);
	}
	
	public static class EzMessage {
		
		public EzMessage(String uid, int messageNumber, String from, String subject, int size, String fileName, DateAccessor receiveDate, DateAccessor sendDate, Map headers, String contentType, String description, String definition) {
			this.uid = uid;
			this.messageNumber = messageNumber;
			this.from = from;
			this.subject = subject;
			this.size = size;
			this.fileName = fileName;
		}

		public String getUID() { return this.uid; }
		public int getNumber() { return this.messageNumber; }
		public String getFileName() { return fileName; }
    public String getFrom() { return from; }
    public int getSize() { return size; }
    public String getSubject() { return subject; }

		private final String uid;
		private final int messageNumber;
		private final String from;
		private final String subject;
		private final int size;
		private final String fileName;
	}


	public class MailListData extends SimpleArrayData<EzMessage> {
		
	  public MailListData(EzArray<EzMessage> messages) {
      super();
      setTitle(false, headers);
      setObjects(messages);
    }
    
		public boolean isNull(int row, int column) {
			return false; 
		}

		@Override
    public Object get(EzMessage message, int row, int column) {
			try {
				switch(column) {
					case 0: {
						final int number = message.getNumber(); 
						return "<a href=\"/com/ezrms/www/mail/mail.isp?host="+URLEncoder.encode(host,"utf8")+"&user="+URLEncoder.encode(user,"utf8")+"&password="+URLEncoder.encode(password,"utf8")+"&operation=detail&mailmessage="+message.getUID()+"\">"+IntegerCache.toString(number)+"</A><input type='checkbox' class='ezcheck' name='mailmessage' value='"+message.getUID()+"'/>";
					}
					case 1: return message.getFrom();
					//TODO lines non coherants;
					case 2: return "<a href=\"/com/ezrms/www/mail/mail.isp?host="+URLEncoder.encode(host,"utf8")+"&user="+URLEncoder.encode(user,"utf8")+"&password="+URLEncoder.encode(password,"utf8")+"&operation=detail&mailmessage="+message.getUID()+"\">"+message.getSubject()+"</a>";
					case 3: return IntegerCache.toString(message.getSize());
					case 4: return message.getFileName();
					default : throw new IllegalStateException();
				}
			}
			catch (Exception ignored) {
				errorCode += "Folder is not open";
				hasError = true;
				return StringArrays.emptyString;
			}
		}

	}
		
	private final String host;
	private final String user;
	private final String password;
	private final Properties properties = new Properties();
	private final Trace trace;
  private static final String[] headers = TranslationUtil.getEzRMSContextLabelsIntern(new String[] { "ID", "From", "Subject", "Size", "Filename", });
}

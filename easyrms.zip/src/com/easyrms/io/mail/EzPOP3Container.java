package com.easyrms.io.mail;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.util.*;


public class EzPOP3Container {
	
	public static final EzPOP3Container reference = new EzPOP3Container();

	public EzPOP3Box getPOP3Box(String host, String user, String password, int delay) {
		return getPOP3Box(host, 110, user, password, delay);
	}
	
	public synchronized EzPOP3Box getPOP3Box(String host, int port, String user, String password, int delay) {
		final POP3Key key = new POP3Key(host, port, user, password);
		if (!boxesByKey.containsKey(key)) {
			final EzPOP3Box box = new EzPOP3Box(host, port, user, password, delay);
			add(box);
			boxesByKey.put(key, box);
			return box;
		}
		return boxesByKey.get(key);
	}
	
	public void add(EzPOP3Box pop3Box) {
		boxes.add(pop3Box);
	}

	public void remove(EzPOP3Box pop3Box) {
		boxes.remove(pop3Box);
	}
	
	public int getCount() {
		return boxes.size();
	}
	
	public EzPOP3Box get(int i) {
		return boxes.get(i);
	}
	
	public EzPOP3Box find(int id) {
		synchronized (boxes) {
			for (int i = 0, n = boxes.size() ; i < n ; i++) {
				final EzPOP3Box box = boxes.get(i);
				if (box.getID() == id) return box;
			}
		}
		return null;
	}

	public EzPOP3Box[] get() {
		return boxes.toArray(EzPOP3Box.empty);
	}

	public EzArray<EzPOP3Box.EzMailReport> getReport() {
		final EzPOP3Box[] boxes = get();
		final EzArrayList<EzPOP3Box.EzMailReport> reports = new EzArrayList<EzPOP3Box.EzMailReport>(boxes.length);
		for (int i = 0, n = boxes.length; i < n; i++)	reports.add(boxes[i].getLastReport());
		return reports;
	}
	
	public EzPOP3Box.EzMailReport getReport(int i) {
		return get(i).getLastReport();
	}
	
  //TODO: to be refactored with a Cache and with the read only flag
	private final List<EzPOP3Box> boxes = Collections.synchronizedList(new ArrayList<EzPOP3Box>());
	private final HashMap<POP3Key, EzPOP3Box> boxesByKey = new HashMap<POP3Key, EzPOP3Box>();
	
	private static class POP3Key {
		
		public POP3Key(String host, int port, String user, String password) {
			this.host = StringComparator.NVL(host);
			this.port = port;
			this.user = StringComparator.NVL(user);
			this.password = StringComparator.NVL(password);
		}

    @Override
		public boolean equals(Object obj) {
			if (obj == this) return true;
			if (obj == null) return false;
			if (!(obj instanceof POP3Key)) return false;
			final POP3Key other = (POP3Key) obj;
			return this.host.equals(other.host) && this.port == other.port && this.user.equals(other.user) && this.password.equals(other.password);
		}
		
    @Override
    public int hashCode() {
			if (hash == 0) {
				this.hash = this.host.length() + port + user.length() + password.length(); 
			}
			//TODO GAc refaire 1 meilleur hashCode;
			return this.hash; 
		}
		
		private int hash = 0;
		private final String host;
		private final int port;
		private final String user;
		private final String password;
	}
}

package com.easyrms.io.mail;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.executor.*;
import com.easyrms.util.ezjmx.*;

import com.sun.mail.pop3.*;

import java.io.*;
import java.util.*;

import javax.mail.*;


public class EzPOP3Box extends AbstractEzProcessPeriodic {
	
	EzPOP3Box(String host, int port, String user, String password, int delay) {
    super(null, "POP3 Box "+user+"@"+host+":"+IntegerCache.toString(port), delay, false);
		this.host = host;
		this.port = port;
		this.user = user;
		this.password = password;
		this.id = IDGenerator.staticReference.getNewValue();
		this.lastReport = new EzMailReport(this.id, host, port, user, password);
    this.previousMessages = new SerialisableReference<HashMap<String, EzMailMessage>>("POP3BOX_"+user+"_"+host+"_"+IntegerCache.toString(port)) {

      @Override
      protected HashMap<String, EzMailMessage> createDefault() {
        return new HashMap<String, EzMailMessage>();
      }
    };
	}
  
  @Override
  protected PeriodicContextType getContextType() {
    return PeriodicContextType.BOXES;
  }
	
	public int getID() {
		return this.id;
	}
	
	public String getHost() {
		return this.host;
	}
	
	public int getPort() {
		return this.port;
	}

	public String getUser() {
		return this.user;
	}

	public String getPassword() {
		return this.password;
	}
	
	public synchronized EzMailReport getLastReport() {
		return lastReport;
	}
	
  //TODO: to get rid of or to synchronize but with a correct cache and a correct behavior
  public void setReadOnly(boolean readOnly) {
    this.mode = readOnly ? Folder.READ_ONLY : Folder.READ_WRITE;
  }
  
	@Override
  protected void runPeriodicProcess() {
    run(pop3Listeners.getList(), pop3MultiListeners.getList());
	}

	public void run(Pop3MessageListener listeners) {
		run(new EzArray.AsArray<Pop3MessageListener>(listeners), Pop3MultiMessageListener.noPop3MultiMessageListenerArray);
	}

	public void run(Pop3MultiMessageListener listeners) {
		run(Pop3MessageListener.noPop3MultiMessageListenerArray, new EzArray.AsArray<Pop3MultiMessageListener>(listeners));
	}
  
  public Message findMessage(String uid) {
    final ValidatedFile file = StreamUtils.getWorkFile("/mail/"+user.replace("[@. \r\n\t]","_")+"/"+uid+".eml");
    final Session session = Session.getInstance(emptyProperties, null);
    try {
      if (file.isExists()) {
        return MailUtil.read(session, file);
      }
      final Store store = session.getStore("pop3");
      store.connect(host, user, password);
      try {
        final POP3Folder folder = (POP3Folder)store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        try {
          if (folder.isOpen()) {
            final FetchProfile profile = new FetchProfile();
            profile.add(UIDFolder.FetchProfileItem.UID);
            final Message[] messages = folder.getMessages();
            folder.fetch(messages, profile);
            for (int i= 0, n = messages.length; i < n; i++) {
              final Message message = messages[i];
              if (uid.equals(folder.getUID(message))) {
                MailUtil.save(message, file);
                return MailUtil.read(session, file);
              }
            }
          }
        }
        finally {
          folder.close(true);
        }
      }
      finally {
        store.close();
      }
    }
    catch (Throwable exception) {
      trace.log(exception);
    }
    return null;
  }    
  
  public void run(EzArray<? extends Pop3MessageListener> listeners, EzArray<? extends Pop3MultiMessageListener> multiListeners) {
    final String host = getHost();
    final int port = getPort();
    final String user = getUser();
    final String password = getPassword();
    final EzTreeTask<?> currentTask = EzTreeTask.findCurrentTask();
    if (currentTask != null) {
      currentTask.setContextParameter("pop3.host", host);
      currentTask.setContextParameter("pop3.port", port);
      currentTask.setContextParameter("pop3.user", user);
      currentTask.setContextParameter("pop3.password", password);
    }
    try {
      boolean continueRead = true;
      while (continueRead) { 
        if (smartModeCount <= 0) {
          continueRead = false;
        }
    		boolean hasError = false;
    		final int mode;
    		synchronized (this) {
          mode = this.mode; 
    		}
    		String errorCode = "";
    		EzMailMessage[] ezMessages = EzMailMessage.empty;
    		synchronized (runLock) {
    			try {
    				final Session session = Session.getInstance(emptyProperties, null);
            synchronized (session) {
      				final Store store = session.getStore("pop3");
      				store.connect(host, port, user, password);
      				try {
      					final POP3Folder folder = (POP3Folder)store.getFolder("INBOX");
      					folder.open(mode);
      					try {
      						if (folder.isOpen()) {
      							final FetchProfile profile = new FetchProfile();
      							profile.add(UIDFolder.FetchProfileItem.UID);
      							final Message[] messages = folder.getMessages();
      							folder.fetch(messages, profile);
                    final HashMap<String, EzMailMessage> newMessages = new HashMap<String, EzMailMessage>();
      							try { 
      								ezMessages = getEzMessage(user, folder, messages, previousMessages.get(), newMessages);
      								if (multiListeners != null && multiListeners.getCount() > 0) {
      									final int ezMessagesLength = ezMessages.length;
      									final int[] flags = new int[ezMessagesLength];
      									for (int j = 0 ; j < ezMessagesLength; j++) {
      										flags[j] = ezMessages[j].getEzFlag();
      									}
      									for (int i = 0, n = multiListeners.getCount(); i < n; i++) {
      										final int[] checks = multiListeners.get(i).process(messages, flags);
      										for (int j = 0, m = checks.length ; j < m; j++) {
      											ezMessages[j].check(checks[j]);
      										}
      									}
      								}
      								if (listeners != null && listeners.getCount() > 0) {
                        int nbNew = 0;
      									for (int j = 0, n = listeners.getCount(), m = ezMessages.length; j < m; j++) {
                          if (j == m-1) continueRead = false;
                          final Message message = messages[j];
                          try { 
        										final EzMailMessage ezMessage = ezMessages[j];
                            if (ezMessage != null) {
                              final boolean isNew = (ezMessage.getEzFlag() == Pop3MessageListener.NEW_FLAG);
                              if (isNew && smartModeCount > 0 && (multiListeners == null || multiListeners.getCount() <= 0)) {
                                nbNew++; 
                              }
                              if (trace.isActive()) {
          											final Address from = (ezMessage.getFromCount() > 0) ? ezMessage.getFrom(0) : null;
          											trace.traceln((isNew ? "[NEW]" : "[OLD]")+"\""+StringComparator.NVL(ezMessages[j].getObject())+"\" from "+(from == null ? "" : from.toString()));
          										}
                              for (int i = 0; i < n; i++) {
                                int state = Pop3MessageListener.UNKNOWN_STATE;
                                try {
                                  state = listeners.get(i).process(message, ezMessage.getEzFlag());
                                }
                                catch (Throwable error) {
                                  state = Pop3MessageListener.ERROR_STATE;
                                }
                                ezMessage.check(state);
        											}
        										}
        										else {
        											ezMessages[j] = EzMailMessage.badHeader;	
        										}
                            if (nbNew > smartModeCount) break;
                          }
                          finally {
                            messages[j] = null;
                          }
      								  }
      								}
      							}
      							finally {
      								this.previousMessages.set(newMessages);
      							}
      						}
      						else {
      							errorCode += "Folder is not open";
      							hasError = true;
      						}
      					}
      					finally {
      						folder.close(true);
      					}
      				}
      				finally {
      					store.close();
      				}
            }
    			}
    			catch (Throwable exception) {
    				errorCode += ExceptionUtils.getMessage(exception);
    				trace.log("ERROR "+ errorCode, true);
    				hasError = true;
    			}
    		}
    		synchronized (this) {
          lastReport = (hasError) 
    				? (lastReport == null)
    					? new EzMailReport(getID(), getHost(), getPort(), getUser(), getPassword(), ezMessages, isRunning(), getDelay(), errorCode)
    				  : new EzMailReport(getID(), getHost(), getPort(), getUser(), getPassword(), lastReport.getEzMailMessage(), isRunning(), getDelay(), errorCode)
    				: new EzMailReport(getID(), getHost(), getPort(), getUser(), getPassword(), ezMessages, isRunning(), getDelay());
    		}
        if (continueRead) {
          trace.traceln("continue");
          ThreadUtil.sleepSilently(delayContinueRead);
        }
      }
    }
    finally {
      if (currentTask != null) {
        currentTask.setContextParameter("pop3.host", null);
        currentTask.setContextParameter("pop3.port", null);
        currentTask.setContextParameter("pop3.user", null);
        currentTask.setContextParameter("pop3.password", null);
      }
    }
	}
	
	public int getSmartModeCount() {
    return smartModeCount;
  }

  @Override
  public synchronized void start() {
    canStart = true;
    if (pop3Listeners.getCount() > 0 || pop3MultiListeners.getCount() > 0) {
      super.start();
    }
  }
  
  @Override
  public synchronized void stop() {
    canStart = false;
    super.stop();
  }
  
  public void setSmartModeCount(int smartModeCount) {
    this.smartModeCount = smartModeCount;
  }

  public synchronized void add(Pop3MessageListener listener) {
		if (pop3Listeners.addIfNotExist(listener)) {
			previousMessages.get().clear();
      if (canStart) super.start();
		}
	}

	public synchronized void remove(Pop3MessageListener listener) {
		if (pop3Listeners.remove(listener)) {
			if (pop3Listeners.getCount() <= 0 && pop3MultiListeners.getCount() <= 0) {
				stop();
			}
		}
	}
	
	public synchronized void add(Pop3MultiMessageListener listener) {
		if (pop3MultiListeners.addIfNotExist(listener)) {
			previousMessages.get().clear();
      if (canStart) super.start();
		}
	}

	public synchronized void remove(Pop3MultiMessageListener listener) {
		if (pop3MultiListeners.remove(listener)) {
			if (pop3MultiListeners.getCount() <= 0 && pop3Listeners.getCount() <= 0) {
				stop();
			}
		}
	}

  private boolean canStart;
  private final String host;
	private final int port;
	private final String user;
	private final String password;
	private int mode = Folder.READ_ONLY;
	private EzMailReport lastReport;
	
  private final EzArrayCopyOnWriteList<Pop3MessageListener> pop3Listeners = new EzArrayCopyOnWriteList<Pop3MessageListener>();
	private final EzArrayCopyOnWriteList<Pop3MultiMessageListener> pop3MultiListeners = new EzArrayCopyOnWriteList<Pop3MultiMessageListener>();
	
	private final Object runLock = new Object();

	public static class EzMailReport {
    
    public static Comparator<EzMailReport> hostComparator = new Comparator<EzMailReport>() {

      public int compare(EzMailReport o1, EzMailReport o2) {
        return StringComparator.compare(o1.getHost(),o2.getHost());
      }
    };

		public EzMailReport(int boxID, String host, int port, String user, String password) {
			this(boxID, host, port, user, password, UNKNOWN_STATE, null, null, EzMailMessage.empty, null);
		}
		
		public EzMailReport(int boxID, String host, int port, String user, String password, EzMailMessage[] headers, boolean isRunning, int wait, String errorMessage) {
			this(boxID, host, port, user, password, ERROR_STATE, StampUtil.getNow(), isRunning ? new SimpleDateAccessor(StampUtil.getStampValue()+ wait): null, headers, errorMessage);
		}
    
    public EzMailReport(int boxID, String host, int port, String user, String password, EzArray<EzMailMessage> headers, boolean isRunning, int wait, String errorMessage) {
      this(boxID, host, port, user, password, ERROR_STATE, StampUtil.getNow(), isRunning ? new SimpleDateAccessor(StampUtil.getStampValue()+ wait): null, headers, errorMessage);
    }

		public EzMailReport(int boxID, String host, int port, String user, String password, EzMailMessage[] headers, boolean isRunning, int wait) {
			this(boxID, host, port, user, password, OK_STATE, StampUtil.getNow(), isRunning ? new SimpleDateAccessor(StampUtil.getStampValue()+ wait): null, headers, null);
		}
		
		private EzMailReport(int boxID, String host, int port, String user, String password, int state, DateAccessor date, DateAccessor nextDate, EzMailMessage[] headers, String errorMessage) {
      this(boxID, host, port, user, password, state, date, nextDate, (headers == null) ? EzMailMessage.emptyArray : new EzArrayList<EzMailMessage>(headers), errorMessage);
    }
    
    private EzMailReport(int boxID, String host, int port, String user, String password, int state, DateAccessor date, DateAccessor nextDate, EzArray<EzMailMessage> headers, String errorMessage) {
      this.boxID = boxID; 
			this.host = host;
			this.port = port;
			this.user = user;
			this.state = state;
			this.date = date;
			this.nextDate = nextDate;
			this.messages = (headers == null) ? EzMailMessage.emptyArray : headers;
			this.errorMessage = errorMessage;
			
			int unknownMessageCount = 0;
			int okMessageCount = 0;
			int errorMessageCount = 0;
      int errorRetryMessageCount = 0;
      int warningMessageCount = 0;
			int ignoredMessageCount = 0;
      int newMessageCount = 0;
			
			for (int i = 0, n = this.messages.getCount(); i < n; i++) {
        final EzMailMessage message = this.messages.get(i);
				if (message != null) {
          if (message.getEzFlag() == Pop3MessageListener.NEW_FLAG) newMessageCount++;
					switch (message.getState()) {
						case Pop3MessageListener.UNKNOWN_STATE : unknownMessageCount++; break;
						case Pop3MessageListener.OK_STATE : okMessageCount++; break;
						case Pop3MessageListener.ERROR_STATE : errorMessageCount++; break;
            case Pop3MessageListener.ERROR_RECHECK_STATE : errorRetryMessageCount++; break;
						case Pop3MessageListener.WARNING_STATE : warningMessageCount++; break;
						case Pop3MessageListener.IGNORED_STATE : ignoredMessageCount++; break;
					}
				}
			}
      this.newMessageCount = newMessageCount;
			this.unknownMessageCount = unknownMessageCount;
      this.errorRetryMessageCount = errorRetryMessageCount;
			this.okMessageCount = okMessageCount;
			this.errorMessageCount = errorMessageCount;
			this.warningMessageCount = warningMessageCount;
			this.ignoredMessageCount = ignoredMessageCount;
		}
		
		public String getHost() { return this.host; }
		public int getPort() { return this.port; }
		public String getUser() { return this.user; }
		public int getState() { return state; }
		public DateAccessor getDate() { return this.date; }
		public DateAccessor getNextDate() { return this.nextDate; }
		public String getErrorMessage() { return this.errorMessage; }
		public EzMailMessage getEzMailMessage(int i) { return messages.get(i); }
		public EzArray<EzMailMessage> getEzMailMessage() { return messages; }
		public int getEzMailHeaderCount() { return messages.getCount(); }
		public int getMessageCount() { return messages.getCount(); }
		public int getUnknownMessageCount() { return unknownMessageCount; }
		public int getOkMessageCount() { return okMessageCount; }
		public int getErrorMessageCount() { return errorMessageCount; }
    public int getErrorRetryMessageCount() { return errorRetryMessageCount; }
    public int getWarningMessageCount() { return warningMessageCount; }
		public int getIgnoredMessageCount() { return ignoredMessageCount; }
		public int getBoxID() { return boxID; }
    public int getNewMessageCount() { return newMessageCount; }
		
		private final int boxID;
		private final String errorMessage;
		private final String user;
		private final String host;
		private final int port;
		private final DateAccessor date;
		private final DateAccessor nextDate;
		private final int state;
		private final EzArray<EzMailMessage> messages;
		private final int newMessageCount;
    private final int unknownMessageCount;
		private final int okMessageCount;
		private final int errorMessageCount;
    private final int errorRetryMessageCount;
		private final int warningMessageCount;
		private final int ignoredMessageCount;
		
		public static final int UNKNOWN_STATE = 0;
		public static final int OK_STATE = 1;
		public static final int ERROR_STATE = 2;
	}
	
	private static EzMailMessage[] getEzMessage(String user, POP3Folder folder, Message[] message, HashMap<String, EzMailMessage> oldMessages, HashMap<String, EzMailMessage> newMessages) {
		if (message == null) return null;
		final int messageLength = message.length;
		final EzMailMessage[] ezMessages = new EzMailMessage[messageLength];
		for (int i = 0; i < messageLength; i++) {
			if (message[i] != null) {
				try {
					final String uid = folder.getUID(message[i]);
					EzMailMessage ezMessage = oldMessages.get(uid);
					if (ezMessage == null) {
						ezMessage = EzMailMessage.create(user, uid, message[i]);
					}
					else {
						ezMessage.setAsOldMessage();
					}
					ezMessages[i]= ezMessage;
					newMessages.put(uid, ezMessage);
				}
				catch (Exception ignored) {
					EasyRMS.trace.log(ignored);
				}
			}
			else {
				ezMessages[i]= null;
			}
		}
		return ezMessages;
	}
	
	public static final EzPOP3Box[] empty = new EzPOP3Box[0];
	private final int id;
  private int smartModeCount = 0;
	private static final Properties emptyProperties = new Properties();
	private final SerialisableReference<HashMap<String, EzMailMessage>> previousMessages;
  private static final int delayContinueRead = 2000;
}
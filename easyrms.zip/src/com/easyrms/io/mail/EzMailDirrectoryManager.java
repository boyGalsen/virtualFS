package com.easyrms.io.mail;

import com.easyrms.util.*;


public class EzMailDirrectoryManager {
	
	public static final EzMailDirrectoryManager reference = new EzMailDirrectoryManager();
	
	public synchronized EzArray<EzMailDirectory> getMailDirectories() {
    isNeedToBeCloned = true;
		return mails;
	}

	public synchronized void add(EzMailDirectory mailDirectory) {
    if (isNeedToBeCloned) {
      final EzArrayList<EzMailDirectory> old = mails;
      mails = new EzArrayList<EzMailDirectory>((EzArray<EzMailDirectory>)old);
      isNeedToBeCloned = false;
    }
    mails.add(mailDirectory);
	}
	
	public synchronized void remove(EzMailDirectory mailDirectory) {
    if (isNeedToBeCloned) {
      final EzArrayList<EzMailDirectory> old = mails;
      mails = new EzArrayList<EzMailDirectory>((EzArray<EzMailDirectory>)old);
      isNeedToBeCloned = false;
    }
    mails.remove(mailDirectory);
	}
	
	private EzArrayList<EzMailDirectory> mails = new EzArrayList<EzMailDirectory>();
  private boolean isNeedToBeCloned;
}

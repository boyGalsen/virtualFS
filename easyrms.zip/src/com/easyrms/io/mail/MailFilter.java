package com.easyrms.io.mail;

import javax.mail.Message;


public interface MailFilter {

  public boolean accept(Message message);

	public static final MailFilter noFilter = new MailFilter() {
		
    public boolean accept(Message message) {
      return true;
    }
  };
}

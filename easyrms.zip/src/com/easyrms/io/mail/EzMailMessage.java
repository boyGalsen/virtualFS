package com.easyrms.io.mail;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.mail.*;

import com.easyrms.date.*;
import com.easyrms.util.*;

public class EzMailMessage implements Serializable {
	
	public static final EzMailMessage[] empty = new EzMailMessage[0];
  public static final EzArray<EzMailMessage> emptyArray = new EzArray.NoEzArray<EzMailMessage>();
  public static final Header[] noHeader = new Header[0];
	public static final EzMailMessage badHeader = new EzMailMessage(null, null, null, null, null, null, null, -1, null, null, null, false, false, false);
	
	private EzMailMessage(
		String uid,
	  Address[] from,
		Address[] to,
	  String object,
	  String contentType,
	  String description,
	  String disposition,
	  int size,
	  String fileName,
		DateAccessor sendDate,
		DateAccessor receiveDate,
		boolean isRecent,
	  boolean isSeen,
	  boolean isDeleted) 
	{
		this.uid = uid;
		this.from = (from == null) ? noAddress : from;
		this.to = (to == null) ? noAddress : to;
		this.object = object;
		this.contentType = contentType;
		this.description = description;
		this.disposition = disposition;
		this.size = size;
		this.fileName = fileName;
		this.sendDate = sendDate;
		this.receivedDate = receiveDate;
		this.isRecent = isRecent;
		this.isSeen = isSeen;
		this.isDeleted = isDeleted;
		this.flag = Pop3MessageListener.NEW_FLAG;
	}
	
	public String getUID() {
		return uid;
	}

	public Address getFrom(int i) {
		return from[i];
	}

	public int getFromCount() {
		return from.length;
	}
	
	public Address getTo(int i) {
		return to[i];
	}

	public int getToCount() {
		return to.length;
	}
	
	public String getObject() {
		return object;
	}
	
	public int getSize() {
		return size;
	}
	
	public String getFileName() {
		return fileName;
	}

	public boolean isRecent() {
		return isRecent;
	}
	
	public boolean isSeen() {
		return isSeen;
	}
	
	public boolean isDeleted() {
		return isDeleted;
	}
	
	public DateAccessor getSendDate() {
		return sendDate;
	}

	public DateAccessor getReceivedDate() {
		return receivedDate;
	}
	
	public int getState() {
		return state;
	}
	
	public void clearState() {
		this.state = Pop3MessageListener.UNKNOWN_STATE;
	}
	
	public void check(int state) {
		if (this.state < state) {
			this.state = state;
		}
	}
	
	public String getContentType() {
		return contentType;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getDisposition() {
		return disposition;
	}
	
	
	public int getEzFlag() {
		return this.flag;
	}
		
	public void setAsOldMessage() {
    if (getState() != Pop3MessageListener.UNKNOWN_STATE) {
		  this.flag = (getState() == Pop3MessageListener.ERROR_RECHECK_STATE) ? Pop3MessageListener.RECHECK_FLAG : Pop3MessageListener.OLD_FLAG;
    }
		clearState();
	}
	
	private final String uid;
	private final Address[] from;
	private final Address[] to;
	private final String object;
	private final int size;
	private String fileName;
	private boolean isSeen;
	private boolean isDeleted; 
	private boolean isRecent;
	private DateAccessor sendDate;
	private DateAccessor receivedDate;
	private int state = Pop3MessageListener.UNKNOWN_STATE;
	private final String description;
	private final String disposition;
	private final String contentType;
	private int flag;

	private static DateAccessor findReceiveDate(String headerValue) {
		if (headerValue == null) return null;
		try {
			final int index = headerValue.lastIndexOf(";");
			if (index >= 0) {
				return new SimpleDateAccessor(dateFormat.parse(headerValue.substring(index+1)));
			}
		}
		catch (Exception e) {
		}
		return null; 
	}
	
	private static final DateFormat dateFormat = new SimpleDateFormat(" EEE, d MMM y H:m:s", Locale.US);

	public static EzMailMessage create(String user, String uid, Message message) {
		try {
      trace.traceln("start create user:"+user+";uid="+uid);
			message.getAllHeaders();
			final Flags flags = message.getFlags();
			final Date receivedDateValue = message.getReceivedDate();
		  DateAccessor receivedDate = null;
			if (receivedDateValue == null) {
				final Enumeration<Header> allHeaders = message.getAllHeaders();
				while (allHeaders.hasMoreElements()) {
					final Header header = allHeaders.nextElement();
					if (header != null && "Received".equalsIgnoreCase(header.getName())) {
						receivedDate = findReceiveDate(header.getValue());
						break;
					}
				}
			}
			else {
			  receivedDate = SimpleDateAccessor.getSimpleDateAccessor(receivedDateValue);
			}
			return new EzMailMessage(
				uid, 
				message.getFrom(), 
				message.getRecipients(Message.RecipientType.TO), 
				message.getSubject(), 
				message.getContentType(), 
				message.getDescription(), 
				message.getDisposition(), 
				message.getSize(), 
				message.getFileName(),
				new SimpleDateAccessor(message.getSentDate()),
				receivedDate,
				flags.contains(Flags.Flag.RECENT),
				flags.contains(Flags.Flag.SEEN),
				flags.contains(Flags.Flag.DELETED));
		}
		catch (Throwable ignored) {
      trace.log("exception create user:"+user+";uid="+uid+";", ignored);
			return null;
		}
    finally {
      trace.traceln("end create user:"+user+";uid="+uid);
    }
	}
  
	public static final Address[] noAddress = new Address[0];
  private static final Trace trace = new Trace("EzMailMessages", false);
}

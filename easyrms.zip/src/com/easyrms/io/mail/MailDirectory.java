package com.easyrms.io.mail;

import java.io.*;
import java.util.*;

import javax.mail.*;

import com.easyrms.cache.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.StreamUtils.*;
import com.easyrms.util.comparator.*;


public class MailDirectory {
  
  public MailDirectory(String name, ValidatedDirectory directory) {
    MailUtil.trace.log("MAILDIRECTORY name="+name+";path="+directory.getFullName());
    this.name = name;
    this.fileCount = new Counter("Mail Directocry:"+name);
    this.directory = StreamUtils.controlExistDirectory(directory);
    this.lastAdded = new SerialisableReference<DateAccessor>("MAILDIRECTORY_"+name+"_lastAdded") {

      @Override
      protected DateAccessor createDefault() {
        return null;
      }
    };
    this.lastDeleted = new SerialisableReference<DateAccessor>("MAILDIRECTORY_"+name+"_lastDeleted") {

      @Override
      protected DateAccessor createDefault() {
        return null;
      }
    };
  }
  
  public void refresh() {
    lastStatusSnapshots.clear();
  }
  
  public MailDirectoryStatusSnapshot getStatusSnapshot() {
    return getStatusSnapshot(null);
  }
  
  public synchronized MailDirectoryStatusSnapshot getStatusSnapshot(EzDate history) {
    return getStatusSnapshot(history, null, null);
  }
  
  public synchronized MailDirectoryStatusSnapshot getStatusSnapshot(EzDate history, String key1) {
    return getStatusSnapshot(history, key1, null);
  }
  
  public synchronized MailDirectoryStatusSnapshot getStatusSnapshot(EzDate history, String key1, String key2) {
    return lastStatusSnapshots.get(history == null ? EzDate.ever : history).get(new Tuple3<EzDate, String, String>(history == null ? EzDate.ever : history, key1, key2));
  }
  
  
  public synchronized void saveAndDelete(final String prefix, final Message message) throws Throwable {
    delete(save(prefix, message));
  }
  
  public synchronized MailMessage save(final String prefix, final Message message) {
    try {
      final String uid = idGenerator.getNewID();
      final EzDate now = EzDate.now();
      final ValidatedFile file = getFile(now, prefix, uid, false);
      if (file.isExists()) {
        throw new IllegalStateException("Message Alleady Exist");
      }
      lastStatusSnapshots.remove(EzDate.ever);
      lastStatusSnapshots.remove(now);
      fileCount.inc();
      MailUtil.save(message, file);
      final DateAccessor date = file.getLastModificationDate();
      lastAdded.set(date);
      final boolean isValid = file.getLength() > 0;
      return new MailMessage() {

        public boolean isValid() { 
          return isValid; 
        }
        public DateAccessor getLastModificationDate() { 
          return date; 
        }
        public boolean isSent() { 
          return false; 
        }
        public String getPrefix() { 
          return prefix; 
        }
        public String getUID() { 
          return uid; 
        }
        public Message getMessage() { 
          return message; 
        }
        public boolean isFileAvailable() { 
          return false; 
        }
        public ValidatedFile getAsFile() { 
          throw ExceptionUtils.newRuntimeException("Not Available"); 
        }

      };
    }
    catch (Throwable ignored) {
      MailUtil.trace.log("Cannot Save Mail Message", ignored);
      return null;
    }
  }
  
  
  public void delete(MailMessage message) throws Throwable {
    fileCount.dec();
    final EzDate now = EzDate.now();
    final String prefix = message.getPrefix();
    final String uid = message.getUID();
    final ValidatedFile file = getFile(now, prefix, uid, false);
    if (file.isExists()) {
      lastStatusSnapshots.remove(EzDate.ever);
      lastStatusSnapshots.remove(now);
      StreamUtils.renameTo(file, getFile(now, prefix, uid, true));
    }
    lastDeleted.set(StampUtil.getNow());
  }
  
  public Iterator<MailMessage> iterator(final Session session, final MailMessageFilter filter) {
    return iterator(session, filter, null);
  }
  
  public Iterator<MailMessage> iterator(final Session session, final MailMessageFilter filter, EzDate history) {
    return iterator(session, new ValidatedFindFilter() {
      
      public boolean accept(ValidatedDirectory directory, boolean isFile, String name, long length, long lastModification, boolean isExist) {
        if (!isFile) return false;
        if (filter == null) return true; 
        final int prefixIndex = name.indexOf("__");
        final String prefix = (prefixIndex <= 0) ? "" : name.substring(0, prefixIndex);
        final int deleteIndex = name.indexOf(".deleted");
        final int suffIndex = (deleteIndex < 0) ? name.indexOf(".eml") : deleteIndex;
        final String uid = (prefixIndex < 0) ? (suffIndex > 0) ? name.substring(0, suffIndex) : name : (suffIndex > 0) ? name.substring(prefixIndex+2, suffIndex) : name.substring(prefixIndex+2);
        final boolean isValid = length > 0;
        final boolean isSent = deleteIndex >= 0;
        return filter.accept(prefix, uid, isSent, isValid, lastModification);
      }
    },
    history);
  }

  public Iterator<MailMessage> iterator(final Session session) {
    return iterator(session, filter, null);
  }
  
  public Iterator<MailMessage> iterator(final Session session, EzDate history) {
    return iterator(session, EzDate.ever.equals(history) ? filter : null, history);
  }
  
  public int getToSendMailDirectoryCount() {
    final EzArray<? extends ValidatedFile> files = directory.findValidatedFiles(filter);
    return (files == null) ? 0 : files.getCount(); 
  }
  
  /*
  public EzArray<MailDirectorySnapshotDetail> getToSendMailDirectory() {
    final File[] files = directory.listFiles(filter);
    final int n = (files == null) ? 0 : files.length;
    final EzArrayList<MailDirectorySnapshotDetail> snapshotDetails = new EzArrayList<MailDirectorySnapshotDetail>(n);
    if (files != null) {
      for (int i = 0; i < n; i++) {
        final File file = files[i];
        if (file != null) {
          snapshotDetails.add(new MailDirectorySnapshotDetail(file));
        }
      }
    }
    return snapshotDetails;
  }*/
  /*
  public static class MailDirectorySnapshotDetail {

    
    private MailDirectorySnapshotDetail(File file) {
      this.lastModification = file.lastModified();
      this.name = file.getName();
    }
    
    public synchronized Date getLastModificationDate() {
      if (lastModificationDate == null) lastModificationDate = new Date(lastModification);
      return lastModificationDate;
    }
    
    public long getLastModification() {
      return lastModification;
    }
    
    public String getName() {
      return name;
    }
    
    private final long lastModification;
    private Date lastModificationDate;
    private final String name;
  }*/
  
  private ValidatedDirectory getDirectory(EzDate history) {
    if (history != null && !EzDate.ever.equals(history)) {
      return StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(this.directory, "SENT"), EzYYYYMMDDDateFormat.referenceYYYYMMFormat(history)), EzYYYYMMDDDateFormat.referenceYYYYMMDDFormat(history));
    }
    return directory;
  }
   
  
  private Iterator<MailMessage> iterator(final Session session, final ValidatedFindFilter filter, EzDate history) {
    final EzArray<? extends ValidatedFile> files = getDirectory(history).findValidatedFiles(filter);
    if (files == null || files.getCount() == 0) {
      return noIterator; 
    }
    final int n = files.getCount();
    return new Iterator<MailMessage>() {
      
      private int i = 0;

      public boolean hasNext() {
        return i < n;
      }

      public MailMessage next() {
        final ValidatedFile f = files.get(i);
        if (MailUtil.trace.isActive()) {
          MailUtil.trace.traceln("get:"+f.getFullName());
        }
        i++;
            final String name = f.getName();
            final int prefixIndex = name.indexOf("__");
            final String prefix = (prefixIndex <= 0) ? "" : name.substring(0, prefixIndex);
            final int deleteIndex = name.indexOf(".deleted");
            final int suffIndex = (deleteIndex < 0) ? name.indexOf(".eml") : deleteIndex;
            final String uid = (prefixIndex < 0) ? (suffIndex > 0) ? name.substring(0, suffIndex) : name : (suffIndex > 0) ? name.substring(prefixIndex+2, suffIndex) : name.substring(prefixIndex+2);
            final DateAccessor date = new SimpleDateAccessor(f.getLastModification());
            final boolean isValid = f.getLength() > 0;
            final boolean isSent = deleteIndex >= 0;
            return new MailMessage() {
              
              public boolean isValid() { return isValid; }
              public DateAccessor getLastModificationDate() { return date; }
              public boolean isSent() { return isSent; }
              public String getPrefix() { return prefix; }
              public String getUID() { return uid; }
              public Message getMessage() { 
                try {
                  return MailUtil.read(session, f);
                }
                catch (Throwable ignored) {
                  throw ExceptionUtils.newRuntimeException(ignored);
                }
              }
              public boolean isFileAvailable() { return f.isExists(); }
              public ValidatedFile getAsFile() { return f; }
            };
      }

      public void remove() {
        if (i >= files.getCount()) {
          throw new IndexOutOfBoundsException("i max:"+files.getCount());
        }
        i++;
      }
    };
  }
  
  private final String name;
  private final ValidatedDirectory directory;
  //private final File deletedDirectory;
  private final Counter fileCount;
  private final SerialisableReference<DateAccessor> lastAdded;
  private final SerialisableReference<DateAccessor> lastDeleted;
  
  private static final ValidatedFindFilter filter = new ValidatedFindFilter() {

    public boolean accept(ValidatedDirectory directory, boolean isFile, String name, long length, long lastModification, boolean isExist) {
      return isFile && name.indexOf(".deleted") < 0;
    }
  };

  
  public static interface MailMessageFilter {
    
    public boolean accept(String prefix, String uid, boolean isSent,  boolean isValid, long lastModification);
    
    MailMessageFilter noFilter = new MailDirectory.MailMessageFilter() {

      public boolean accept(String prefix, String uid, boolean isDeleted, boolean isValid, long lastModification) {
        return true;
      }
    };
  }
  
  public static interface MailMessage {
    
    boolean isValid();
    DateAccessor getLastModificationDate();
    String getPrefix();
    String getUID();
    Message getMessage();
    boolean isSent();
    boolean isFileAvailable();
    ValidatedFile getAsFile();
  }
  
  public static class MailDirectoryStatusSnapshot {
    
    public MailDirectoryStatusSnapshot(String directoryName, DateAccessor lastAdded, DateAccessor lastDeleted, int numberOfMailToSent, DateAccessor oldestMailToSent, DateAccessor youngestMailToSent) {
      this.directoryName = directoryName;
      this.lastAdded = lastAdded;
      this.lastDeleted = lastDeleted;
      this.numberOfMailToSent = numberOfMailToSent;
      this.oldestMailToSent = oldestMailToSent;
      this.youngestMailToSent = youngestMailToSent;
    }
    
    public String getDirectoryName() {
      return directoryName;
    }

    public DateAccessor getLastAdded() {
      return lastAdded;
    }

    public DateAccessor getLastDeleted() {
      return lastDeleted;
    }

    public int getNumberOfMailToSent() {
      return numberOfMailToSent;
    }

    public DateAccessor getOldestMailToSent() {
      return oldestMailToSent;
    }

    public DateAccessor getYoungestMailToSent() {
      return youngestMailToSent;
    }
    
    private final String directoryName; 
    private final DateAccessor lastAdded;
    private final DateAccessor lastDeleted;
    private final int numberOfMailToSent;
    private final DateAccessor oldestMailToSent;
    private final DateAccessor youngestMailToSent;
  }
  
  private Cache<EzDate, Cache<Tuple3<EzDate, String, String>, MailDirectoryStatusSnapshot>> lastStatusSnapshots = Caches.newManagerInstance(new Creator<EzDate, Cache<Tuple3<EzDate, String, String>, MailDirectoryStatusSnapshot>>() {

    public Cache<Tuple3<EzDate, String, String>, MailDirectoryStatusSnapshot> create(EzDate key) throws Exception {
      return Caches.newManagerInstance(new Creator<Tuple3<EzDate, String, String>, MailDirectoryStatusSnapshot>() {

        public MailDirectoryStatusSnapshot create(Tuple3<EzDate, String, String> key) throws Exception {
          final EzDate dateKey = key.get0();
          final String key1 = key.get1();
          final String key2 = key.get1();
          final boolean isWithKey1 = StringComparator.isNotNull(key1);
          final boolean isWithKey2 = StringComparator.isNotNull(key2);
          final ValidatedFindFilter filteFilter = (isWithKey1 || isWithKey2) ? new ValidatedFindFilter() {

            public boolean accept(ValidatedDirectory directory, boolean isFile, String name, long length, long lastModification, boolean isExist) {
              if (isWithKey1 && name.indexOf(key1) < 0) return false;
              if (isWithKey2 && name.indexOf(key2) < 0) return false;
              return false;
            }
            
          } : EzDate.ever.equals(dateKey) ? filter : null;
          final EzArray<? extends ValidatedFile> files = getDirectory(dateKey).findValidatedFiles(filteFilter);
          final int fileCount = (files == null) ? 0 : files.getCount();
          DateAccessor yougestToSendDate = null;
          DateAccessor oldestToSendDate = null;
          if (files != null && fileCount > 0) {
            long yougestToSendDateTime = -1;
            long oldestToSendDateTime = -1;
            for (int i = 0; i < fileCount; i++) {
              final ValidatedFile file = files.get(i);
              final long dateTime = file.getLastModification();
              if (yougestToSendDateTime < 0 || dateTime < yougestToSendDateTime) {
                yougestToSendDateTime = dateTime;
              }
              if (oldestToSendDateTime < 0 || dateTime > oldestToSendDateTime) {
                oldestToSendDateTime = dateTime;
              }
            }
            if (yougestToSendDateTime >= 0) {
              yougestToSendDate = new SimpleDateAccessor(yougestToSendDateTime);
            }
            if (oldestToSendDateTime >= 0) {
              oldestToSendDate = new SimpleDateAccessor(oldestToSendDateTime);
            }
          }
          return new MailDirectoryStatusSnapshot(
            name, 
            lastAdded.get(), 
            lastDeleted.get(),
            fileCount,
            yougestToSendDate,
            oldestToSendDate);
        }
      });
    }
  });
  
  public static final MailDirectoryStatusSnapshot noStatus = new MailDirectoryStatusSnapshot("", null, null, 0, null, null); 
  
  public static final EzArray<MailMessage> noMessage = new EzArray.NoEzArray<MailMessage>();
  
  public static final Iterator<MailDirectory.MailMessage> noIterator = new Iterator<MailDirectory.MailMessage>() {

    public boolean hasNext() { return false; }
    public MailDirectory.MailMessage next() { throw new ArrayIndexOutOfBoundsException("Test hasNext Before Acesses next operation"); }
    public void remove() {}
  };
  
  private final ValidatedFile getFile(EzDate now, String prefix, String uid, boolean sent) {
    return StreamUtils.getChildFile(sent 
        ? StreamUtils.controlExistDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(StreamUtils.getChildDirectory(this.directory, "SENT"), EzYYYYMMDDDateFormat.referenceYYYYMMFormat(now)), EzYYYYMMDDDateFormat.referenceYYYYMMDDFormat(now))) 
        : directory, 
      getFileName(prefix, uid, sent));
  }
  
  private final String getFileName(String prefix, String uid, boolean sent) {
    return StringComparator.NVL(prefix)+"__"+uid+(sent ? ".deleted.eml" : ".eml");
  }
  
  private static final IDGenerator idGenerator = new IDGenerator("X", true);  
}

package com.easyrms.io.mail;

import com.easyrms.util.*;

public class MailDirectoryManager {
	
	public static final MailDirectoryManager reference = new MailDirectoryManager();
	
	public synchronized EzArray<MailDirectory> getProcess() {
    isNeedToBeCloned = true;
		return directories;
	}

	public synchronized void add(MailDirectory mailDirectory) {
    if (isNeedToBeCloned) {
      final EzArrayList<MailDirectory> old = directories;
      directories = new EzArrayList<MailDirectory>((EzArray<MailDirectory>)old);
      isNeedToBeCloned = false;
    }
		directories.add(mailDirectory);
	}
	
	public synchronized void remove(MailDirectory mailDirectory) {
    if (isNeedToBeCloned) {
      final EzArrayList<MailDirectory> old = directories;
      directories = new EzArrayList<MailDirectory>((EzArray<MailDirectory>)old);
      isNeedToBeCloned = false;
    }
		directories.remove(mailDirectory);
	}
	
	private EzArrayList<MailDirectory> directories = new EzArrayList<MailDirectory>();
  private boolean isNeedToBeCloned;
}

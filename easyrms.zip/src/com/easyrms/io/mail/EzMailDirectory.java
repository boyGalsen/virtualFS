package com.easyrms.io.mail;

public interface EzMailDirectory {

}

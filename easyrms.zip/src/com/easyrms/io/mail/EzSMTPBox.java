package com.easyrms.io.mail;


public class EzSMTPBox {

}

package com.easyrms.io.mail;

import com.easyrms.util.*;

import javax.mail.*;

public interface Pop3MessageListener {

	int process(Message message, int flag);
	
	Pop3MessageListener[] empty = new Pop3MessageListener[0];
  EzArray<Pop3MessageListener> noPop3MultiMessageListenerArray = new EzArray.NoEzArray<Pop3MessageListener>();
  
	int UNKNOWN_STATE = 0;
	int IGNORED_STATE = 1;
	int OK_STATE = 2;
	int WARNING_STATE = 3;
	int ERROR_STATE = 4;
	int ERROR_RECHECK_STATE = 5;
	
	int NEW_FLAG = 1;
	int OLD_FLAG = 2;
	int RECHECK_FLAG = 3;
}

package com.easyrms.io.mail;

import com.easyrms.date.*;
import com.easyrms.io.*;
import com.easyrms.table.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.mail.*;


public class ImapBox {


	public ImapBox(String host, String user, String password) {
		this.host = host;
		this.user = user;
		this.password = password;
	}
	
	public  boolean isInList(int value, int[] list) {
    if (list != null) {
  		for (int i = 0, maxi = list.length; i < maxi; i++) {
        if (value == list[i]) return true;
  		}
    }
		return false;
	}
	
	public void delete(String[] messageNumbers) {
		if (messageNumbers != null) {
			final int[] numbers = new int[messageNumbers.length];
			for (int i = 0 ; i < numbers.length ; i++) {
				numbers[i] = Integer.parseInt(messageNumbers[i]);  
			}
			delete(numbers);
		}
	}

	public void delete(int[] messageNumbers) {
		final Session session = Session.getInstance(properties, null);
		try {
			final Store store = session.getStore("imap");
			store.connect(host, user, password);
			try {
				final Folder folder = store.getFolder("INBOX");
				folder.open(Folder.READ_WRITE);
				try {
					if (folder.isOpen()) {
						final Message[] messages = folder.getMessages(messageNumbers);
            if (messages != null) {
  						for (int i = 0, maxi = messages.length ; i < maxi; i++) {
                final Message message = messages[i];
                if (message != null ) {
  								final int messageNumber = message.getMessageNumber();
  								if (isInList(messageNumber, messageNumbers)) {
                    message.setFlag(Flags.Flag.DELETED, true);
  								}
  							}
  						}
            }
					}
				}
				finally {
					folder.close(true);
				}
			}
			finally {
				store.close();
			}
		}
		catch(Exception exception) {
		}
	}
	
	public String detail(int index) {
		return null;
	}
	
	private String errorCode = null;
	private boolean hasError = false;
	
	private EzArray<EzMessage> toEzMessage(Message[] messages) throws Exception{
		if (messages == null) return null;
		final EzArrayList<EzMessage> ezMessages= new EzArrayList<EzMessage>(messages.length);
		for (int i= 0, n = messages.length; i < n; i++) {
      final Message message = messages[i];
			if (message == null) {
        ezMessages.add(new EzMessage(-1, null, null, -1, null, null, null, null, null, null));
      }
			else {
        ezMessages.add(new EzMessage(
          message.getMessageNumber(), 
          message.getFrom()[0].toString(), 
          message.getSubject(), 
          message.getSize(), 
          message.getFileName(),
          new SimpleDateAccessor(message.getReceivedDate()),
          new SimpleDateAccessor(message.getSentDate()),
          message.getDescription(),
          message.getContentType(),
          message.getDisposition()));
      }
			
		}
		return ezMessages;
	}
	
	private EzArray<EzMessage> getMessages() {
		final Session session = Session.getInstance(properties, null);
		try {
			try {
				final Store store = session.getStore("imap");
				store.connect(host, user, password);
				try {
					final Folder folder = store.getFolder("INBOX");
					folder.open(Folder.READ_WRITE);
					try {
						if (folder.isOpen()) {
							return toEzMessage(folder.getMessages());
						}
						errorCode += "Folder is not open";
						hasError = true;
						return null;
					}
					finally {
						folder.close(true);
					}
				}
				finally {
					store.close();
				}
			}
			catch (Throwable exception) {
				errorCode += ExceptionUtils.getMessage(exception);
				hasError = true;
				return null;
			}
		}
		finally {
		}
	}
	
	private void printDetail(EzContextOutput ezout, Message message) throws IOException {
    final EzWriter out = ezout.getOut();
		try {
			  out.write("<table border='0'><tr><td>From</td><td width='100%'>");
				final Address[] from = message.getFrom();
        if (from != null) {
  				for (int i = 0, maxi = from.length ; i < maxi ; i++) {
            if (from[i] != null) {
  						out.write("<DIV>");				
  						out.write(from[i].toString());
  						out.write("</DIV>");				
  					}
  				}
        }
				out.write("</td></tr><tr><td>Sent Date</td><td>");
				final DateAccessor senddate = new SimpleDateAccessor(message.getSentDate());
				out.write((senddate != null) ? ebXMLDateFormat.referenceFormat(senddate) : "&nbsp;");
				out.write("</td></tr><tr><td>Receive Date</td><td>");
				final DateAccessor reiceivedate = new SimpleDateAccessor(message.getReceivedDate());
				out.write((reiceivedate != null) ? ebXMLDateFormat.referenceFormat(reiceivedate) : "&nbsp;");
				out.write("</td></tr><tr><td>Size</td><td>");
				out.write(IntegerCache.toString(message.getSize()));
				out.write("</td></tr><tr><td>Subject</td><td>");
				out.write(StringComparator.NVL(message.getSubject(),"&nbsp;"));
				out.write("</td></tr><tr><td>FileName</td><td>");
				out.write(StringComparator.NVL(message.getFileName(),"&nbsp;"));
				out.write("</td></tr><tr><td>Disposition</td><td>");
				out.write(StringComparator.NVL(message.getDisposition(),"&nbsp;"));
				out.write("</td></tr><tr><td>Description</td><td>");
				out.write(StringComparator.NVL(message.getDescription(),"&nbsp;"));
				out.write("</td></tr><tr><td>Content Type</td><td>");
				out.write(StringComparator.NVL(message.getContentType(),"&nbsp;"));
				out.write("</td></tr>");
	
				final Enumeration headers = message.getAllHeaders();
				while (headers.hasMoreElements()) {
					try {
						final Header header = (Header)headers.nextElement();
						out.write("<tr><td>");
						out.write(StringComparator.NVL(header == null ? null : header.getName(), "&nbsp;"));
						out.write("</td><td>");
						out.write(StringComparator.NVL(header == null ? null : header.getValue(), "&nbsp;"));
						out.write("</td></tr>");
					}
					catch(Exception e) {
						EasyRMS.trace.log(e);
					}

				}
				
				out.write("<tr>");
				out.write("<td colspan=2 style='padding-top:10px;'>");
				out.write("<pre>");
				out.write(message.getContent().toString());
				out.write("</pre>");
				out.write("</td>");
				out.write("</tr>");

				out.write("<tr>");
				out.write("<td colspan=2 style='padding-top:10px;'>");
				out.write("<pre>");
				out.write(message.isSet(Flags.Flag.FLAGGED) ? "SEEN" : "NOT SEEN");
				out.write("</pre>");
				out.write("</td>");
				out.write("</tr>");
									
				message.setFlag(Flags.Flag.FLAGGED, false);
				//message.saveChanges();

			out.write("</table>");
		}
		catch (Exception exception) {
			throw new IOException(ExceptionUtils.getMessage(exception));		
		}
	}

	public void printDetail(EzContextOutput ezout, String message) throws IOException {
		printDetail(ezout, Integer.parseInt(message));
	}
	
	public synchronized void printDetail(EzContextOutput ezout, int message) throws IOException {
		final Session session = Session.getInstance(properties, null);
		try {
			final Store store = session.getStore("imap");
			store.connect(host, user, password);
			try {
				final Folder folder = store.getFolder("INBOX");
				folder.open(Folder.READ_WRITE);
				try {
					if (folder.isOpen()) {
						final Message messages = folder.getMessage(message);
						final int messageNumber = messages.getMessageNumber();
						if (messageNumber == message) {
							printDetail(ezout, messages);
						}
					}
				}
				finally {
					folder.close(true);
				}
			}
			finally {
				store.close();
			}
		}
		catch(Exception exception) {
			EasyRMS.trace.log(exception);
		}
	}
	
	//TODO is hasError correctly protected ? and initialized
	public synchronized void print(EzContextOutput ezout) throws IOException {
		hasError = false;
		errorCode = StringArrays.emptyString;
		final Data data = new MailListData(getMessages());
		final HTMLSimpleGrid grid = new HTMLSimpleGrid();
		final SimpleHTMLTable table = new SimpleHTMLTable(data, grid);
		grid.setFullGrid(true);
		if (hasError) {
      final EzWriter out = ezout.getOut();
			out.write("<div>");
			out.write(errorCode);
			out.write("</div>");
		}
		table.print(ezout);
	}
	
	public static class EzMessage {
		
		public EzMessage(int messageNumber, String from, String subject, int size, String fileName, DateAccessor receiveDate, DateAccessor sendDate, String contentType, String description, String definition) {
			this.messageNumber = messageNumber;
			this.from = from;
			this.subject = subject;
			this.size = size;
			this.fileName = fileName;
    }
		
		public int getNumber() {
			return this.messageNumber;
		}
		
    public String getFileName() {
      return fileName;
    }

    public String getFrom() {
      return from;
    }

    public int getSize() {
      return size;
    }

    public String getSubject() {
      return subject;
    }

		private final int messageNumber;
		private final String from;
		private final String subject;
		private final int size;
		private final String fileName;
	}


	public class MailListData extends SimpleArrayData<EzMessage> {
		
	  public MailListData(EzArray<EzMessage> messages) {
      super();
      setTitle(false, headers);
      setObjects(messages);
    }
    
		public boolean isNull(int row, int column) {
			return false; 
		}

		@Override
    public Object get(EzMessage message, int row, int column) {
			try {
				switch(column) {
					case 0: {
						final int number = message.getNumber(); 
						return IntegerCache.toString(number)+"<input type='checkbox' class='ezcheck' name='mailmessage' value='"+IntegerCache.toString(number)+"'/>";
					}
					case 1: return message.getFrom();
					//TODO lines non coherants;
					case 2: return "<a href=\"/com/ezrms/www/mail/imap.jsp?host="+URLEncoder.encode(host,"utf8")+"&user="+URLEncoder.encode(user,"utf8")+"&password="+URLEncoder.encode(password,"utf8")+"&operation=detail&mailmessage="+message.getNumber()+"\">"+message.getSubject()+"</a>";
					case 3: return IntegerCache.toString(message.getSize());
					case 4: return message.getFileName();
					default : throw new IllegalStateException();
				}
			}
			catch (Exception ignored) {
				errorCode += "Folder is not open";
				hasError = true;
				return StringArrays.emptyString;
			}
		}
	}
		
	private final String host;
	private final String user;
	private final String password;
	private final Properties properties = new Properties();
	
	private static final String[] headers = TranslationUtil.getEzRMSContextLabelsIntern(new String[] { "ID", "From", "Subject", "Size", "Filename", });
}
package com.easyrms.io.mail;


import com.easyrms.util.*;

import javax.mail.*;

public interface Pop3MultiMessageListener {

	int[] process(Message[] message, int[] flag);
	
	Pop3MultiMessageListener[] empty = new Pop3MultiMessageListener[0];
  EzArray<Pop3MultiMessageListener> noPop3MultiMessageListenerArray = new EzArray.NoEzArray<Pop3MultiMessageListener>();
	
	int UNKNOWN_STATE = 0;
	int IGNORED_STATE = 1;
	int OK_STATE = 2;
	int ERROR_STATE = 3;
	int WARNING_STATE = 4;
	
	int NEW_FLAG = 1;
	int OLD_FLAG = 2;
}

package com.easyrms.io;

/*
 * LZW.java
 *
 * Created on 01 Dec 2005
 *
 * Implementation of LZW compression/decompression algorithm
 */

import java.io.* ;
import java.util.* ;

/**
 * @author Moshe Fresko
 * @course Algorithmic Programming 1
 * @exercise 3
 */

public class LZW 
{
  boolean stopped = false ;

  Dict dict ;
    // The bits that should be written for each code
  int numOfBits ;
    // The previous string that we should remember
    // in order to insert into the dictionary
  final ByteArray emptyBA = new ByteArray() ;
  ByteArray w=emptyBA ;
    // Constructor gets the number of bits to be written for each code
  public LZW() {
    numOfBits = 12 ;
      // Create a new Limited Dictionary
      // For maximum of 2^bits entries
    dict = new LimitedDict(1<<numOfBits) ;
      // Add all ascii characters to the dictionary
    for (int i=0;i<256;++i)
      dict.add(new ByteArray((byte)i)) ;
  }
    // Encodes the next character.
    // If there is a code generated returns it.
    // If not returns -1.
  int encodeOneChar(int n) {
    byte c = (byte) n ;
    ByteArray nw = w.conc(c) ;
    int code = dict.numFromStr(nw) ;
      // if it exists then we continue to search for a longer string
    if (code!=-1) {
      w = nw ;
      return -1 ;
    } else {
      dict.add(nw) ;
      nw = w ;
      w = new ByteArray(c) ;
      return dict.numFromStr(nw) ;
    }
  }
    // If there is something left in w, returns its code
  int encodeLast() {
    ByteArray nw = w ;
    w = emptyBA ;
    return dict.numFromStr(nw) ;
  }
    // Write the code in bits into output stream
  void writeCode(OutputStream os, int code) throws IOException
  {
    for (int i=0;i<numOfBits;++i) {
      os.write(code&1) ;
      code /= 2 ;
    }
  }

  int readCode(InputStream is) throws IOException
  {
    int num = 0 ;
    for (int i=0;i<numOfBits;++i) {
      int next = is.read() ;
      if (next<0)
        return -1 ;
      num += next<<i ;
    }
    return num ;
  }

  ByteArray decodeOne(int code) {
      // Either "ABA" or null, w="AB"
    ByteArray str = dict.strFromNum(code) ;
    if (str==null) {
      str = w.conc(w.getAt(0)) ;
      dict.add(str) ;
    } else
      if (! w.isEmpty())
        dict.add(w.conc(str.getAt(0))) ;
            w = str ;
    return w ;
  }

  public void decompress(InputStream is, OutputStream os) throws IOException {
    is = new BitInputStream(is) ;
    ByteArray str ; // Next entry
    int code ;    // Next code to be read
    while ((code=readCode(is))>=0) {
      if (stopped)
        break ;
      str = decodeOne(code) ;
      os.write(str.getBytes()) ;
    }
  }

  public void stop()
    { stopped = true ; }

  
  
  public static class LimitedDict extends Dict {
      int maxSize ;
      LimitedDict(int maxSize)
        { this.maxSize = maxSize ; }
      @Override
      public void add(ByteArray str)
        { if (size()<maxSize)
          super.add(str) ; }
  }
  public static class Dict {
      // mp keeps : Word => Index
      // ls keeps : Index => Word
    Map mp = new HashMap() ;
    List ls = new ArrayList() ;
      // Adds an element into the dictionary
    public void add(ByteArray str)
      { mp.put(str,new Integer(ls.size())) ;
        ls.add(str) ;
        }
      // Gets the number for the given string.
      // If it does not exist, returns -1
    public final int numFromStr(ByteArray str)
      { return ( mp.containsKey(str) ?
             ((Integer)mp.get(str)).intValue() :
             -1 ) ; }
      // Gets the string for the given number
      // If the number does not exist, return null
    public final ByteArray strFromNum(int i)
      { return ( i<ls.size() ?
             (ByteArray) ls.get(i) :
             null ) ; }
    public final int size()
      { return ls.size() ; }
  }

  public static class ByteArray {
    // The single member variable is a byte array kept inside, it is immutable
  final byte[] arr ;
    // Constructor with a byte arrays will clone it, since we dont want access from outside
  ByteArray(byte[] b)
    { arr = (byte[]) b.clone() ; }
    // Default Constructor, 0 length array
  ByteArray()
    { arr = new byte[0] ; }
    // Constructor with a single byte
  ByteArray(byte b)
    { arr = new byte[] { b } ; }
    // For the hash-table we need this
  @Override
  public boolean equals(Object o)
    { ByteArray ba = (ByteArray) o ;
      return java.util.Arrays.equals(arr,ba.arr) ; }
    // For the hash-table we need to give a hash code. (Change must be done for a better hash code)
  @Override
  public int hashCode()
    { int code = 0 ;
      for (int i=0;i<arr.length;++i)
      code = code*2+arr[i] ;
      return code ; }
    // returns the size of the byte array
  public int size()
    { return arr.length ; }
    // returns the byte in a given position
  byte getAt(int i)
    { return arr[i] ; }
    // concatenates another byte array into this one,
    // and returns the concatenation in another newly created one. (ByteArray is immutable)
  public ByteArray conc(ByteArray b2)
    { int sz = size()+b2.size() ;
      byte[] b = new byte[sz] ;
      for (int i=0;i<size();++i) b[i]=getAt(i) ;
      for (int i=0;i<b2.size();++i) b[i+size()]=b2.getAt(i) ;
      return new ByteArray(b) ; }
    // Concatenates a byte into this ByteArray.
    // The result is returned in a new ByteArray. (ByteArray is immutable)
  public ByteArray conc(byte b2)
    { return conc(new ByteArray(b2)) ; }
    // Returns a byte array of the copy of the inner byte arrays
  public byte[] getBytes()
    { return (byte[]) arr.clone() ; }
    // Checks if it is zero length
  public boolean isEmpty()
    { return size()==0 ; }
    // Drops the last character and returns it
  public byte getLast()
    { return arr[size()-1] ; }
  public ByteArray dropLast()
    { byte[] newarr = new byte[size()-1] ;
      for (int i=0;i<newarr.length;++i)
        newarr[i] = arr[i] ;
      return new ByteArray(newarr) ; }
  @Override
  public String toString()
    { return new String(arr) ; }
  }
  


}

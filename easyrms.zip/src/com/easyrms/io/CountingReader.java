package com.easyrms.io;

import java.io.*;
import java.nio.*;

public class CountingReader extends FilterReader implements Countable {

  /**
   * By default, skipped characters are not included in the count.
   * 
   * @param in
   */
  public CountingReader(Reader in) {
    this(in, false);
  }

  /**
   * @param in
   * @param countSkippedChars
   *          True if you want to include skipped characters into the count
   */
  public CountingReader(Reader in, boolean countSkippedChars) {
    super(in);
    this.countSkippedChars = countSkippedChars;
  }

  public long getCount() {
    return count;
  }

  @Override
  public int read() throws IOException {
    final int c = in.read();
    if (c > -1) count(1);
    return c;
  }

  @Override
  public int read(char[] cbuf) throws IOException {
    final int nRead = in.read(cbuf);
    count(nRead);
    return nRead;
  }

  @Override
  public int read(CharBuffer target) throws IOException {
    final int nRead = in.read(target);
    count(nRead);
    return nRead;
  }

  @Override
  public long skip(long n) throws IOException {
    final long nRead = in.skip(n);
    if (countSkippedChars) count(nRead);
    return nRead;
  }

  @Override
  public int read(char[] cbuf, int off, int len) throws IOException {
    final int nRead = in.read(cbuf, off, len);
    count(nRead);
    return nRead;
  }

  private void count(long n) {
    if (n > -1) {
      count += n;
    }
  }

  private long count = 0;
  private final boolean countSkippedChars;

}

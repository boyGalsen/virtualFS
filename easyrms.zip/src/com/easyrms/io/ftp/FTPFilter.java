package com.easyrms.io.ftp;

import org.apache.commons.net.ftp.*;


public interface FTPFilter {

   public boolean accept(FTPFile file);
  
  public static final FTPFilter noFilter = new FTPFilter() {
    
    public boolean accept(FTPFile file) {
      return true;
    }
  };
}

package com.easyrms.io;

public interface Countable {
    public long getCount();
}

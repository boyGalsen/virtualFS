package com.easyrms.code;

import com.easyrms.cache.*;
import com.easyrms.util.*;

import java.io.*;


public final class SmallCode implements Serializable, Cloneable {

  public static SmallCode get(String value) {
    allCount.inc();
    if (value == null) {
      throw new BadCodeException();
    }
    final SmallCode code = codes.get(value);
    if (code == null) {
      throw new BadCodeException(value);
    }
    return code;
  }  

  public SmallCode(int x) {
    this.value = IntegerEncoder.encode6(this.x = x);
  }
  public SmallCode(char v, int x) {
    this.value = IntegerEncoder.encode6(v, this.x = x);
  }
  private SmallCode(String value) throws BadCodeException {
    if (value == null) {
      throw new BadCodeException();
    }
    value = value.toUpperCase();
    //TODO: to get rid of
    if (value.equals("S6Z2AN")) {
      value = "SGZ2AN";
      this.x = 258;
    }
    else if (value.equals("AD9HWS")) {
      value = "AD9HW5";
      this.x = 3419;
    }
    else if (value.equals("PILOT1")) {
      this.x = 8603;
    }
    else if (value.equals("PILOT1")) {
      this.x = 8603;
    }
    else if (value.equals("PILOT2")) {
      this.x = 8606;
    }
    else if (value.equals("PILOT3")) {
      this.x = 8613;
    }
    else if (value.equals("PILOT4")) {
      this.x = 8622;
    }
    else if (value.equals("PILOT5")) {
      this.x = 8625;
    }
    else if (value.equals("PILOT6")) {
      this.x = 8658;
    }
    else if (value.startsWith("PILOT") || value.startsWith("HOTEL")) {
      this.x = MathUtils.parseInt(value.substring(5));
    }
    else if (value.startsWith("HOTE")) {
      this.x = MathUtils.parseInt(value.substring(4));
    }
    else {
      this.x = IntegerEncoder.decode6(value);
    }
    this.value = value;
  }
  public SmallCode(char v, String value) throws BadCodeException  {
    this.x = IntegerEncoder.decode6(v, this.value = value.toUpperCase());
  }

  public int intValue() { 
    return x; 
  }
  @Override
  public String toString() { 
    return value; 
  }

  @Override
  public int hashCode() { 
    return x; 
  }
  @Override
  public boolean equals(Object o) { 
    return ((o instanceof SmallCode) && ((SmallCode)o).value.equals(value)); 
  }

  private final String value;
  private final int x;
  
  private static Counter allCount = new Counter("Small Code Get");
  private static Counter createCount = new Counter("Small Code Create");
  
  private static Cache<String, SmallCode> codes = Caches.newCacheInstance(
    v -> { createCount.inc(); return new SmallCode(v); },
    false);
}
package com.easyrms.code;

import com.easyrms.util.*;

public class XORCodec {

	public XORCodec(byte[] key) {
		this.key = key.clone();
	}
	
	public String decode(String value) throws Exception {
		return new String(xor(StreamUtils.base64decode(value), key), "UTF-8");
	}
	
	public String encode(String value) throws Exception {
		return StreamUtils.base64encode(xor(value.getBytes("UTF-8"), key));
	}

	public byte[] decode(byte[] value) throws Exception {
		final byte[] bytes = new byte[value.length];
		System.arraycopy(value, 0, bytes, 0, value.length);
		return xor(value, key);
	}
	
	public byte[] encode(byte[] value) throws Exception {
		final byte[] bytes = new byte[value.length];
		System.arraycopy(value, 0, bytes, 0, value.length);
		return xor(bytes, key);
	}
	
	public static byte[] xor(byte[] bytes, byte[] key) {
		for (int i = 0, n = bytes.length, keyLength = key.length ; i < n ; i++) {
			bytes[i] ^= key[i%keyLength];			 
		}
		return bytes;
	}
	
	public static byte xor(byte a, byte b) {
		a ^= b;
		return a;
	}

	
	private final byte[] key;
}

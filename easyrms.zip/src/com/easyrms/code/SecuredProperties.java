package com.easyrms.code;

import com.easyrms.util.*;

import java.io.*;
import java.math.*;
import java.util.*;

public class SecuredProperties {

  
  public static String encode(Properties properties, char[] key) throws IOException {
    final StringWriter out = StreamUtils.openStringWriter();
    try {
      properties.store(out, ""); 
      return LoginPasswordEncrypt.encode(out.toString(), LoginPasswordEncrypt.getRandomString(10, 20), LoginPasswordEncrypt.XOR, key, 0, null, 0);
    }
    finally {
      StreamUtils.closeNotCatch(out);
    }
  }
  
  public static Properties decode(Properties originalProperties, String excryptProperties, char[] key) throws IOException {
    final StringReader in = new StringReader(LoginPasswordEncrypt.decodeLogin(excryptProperties, key, new BigInteger("0"), 0));
    try {
      final Properties newProperties = (originalProperties == null) ? new Properties() : new Properties(originalProperties);
      newProperties.load(in);
      return newProperties;
    }
    finally {
      in.close();
    }
  }
}

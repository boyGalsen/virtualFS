package com.easyrms.code;

import java.security.*;

class IntegerEncoder {

  public static String encode6(int x) {
    final StringBuffer key = decompose(x);
    if (key.length() > p) throw new IllegalArgumentException("id too big");
    char[] value = new char[n+1];
    for (int i = 0; i < n-p; i++) {
     value[i] = map(random.nextInt(Integer.MAX_VALUE));
    }
    for (int i = 0; i < p+1; i++) {
      int intermediateKey = value[0];
      for (int j = 0; j < n-p; j++) {
        intermediateKey += unmap(value[i+j]);
      }
      final int cIndex = i + key.length() - p;
      final char c = (cIndex < 0) ? possible[0] : (i == p) ? validatorChar : key.charAt(cIndex);
      value[n-p+i] = map(unmap(c) - intermediateKey);
    }
    return new String(value);
  }
  public static String encode6(char v, int x) {
    final StringBuffer key = decompose(x);
    if (key.length() > p) throw new IllegalArgumentException("id too big");
    char[] value = new char[n+1];
    for (int i = 0; i < n-p; i++) {
     value[i] = map(random.nextInt(Integer.MAX_VALUE));
    }
    for (int i = 0; i < p+1; i++) {
      int intermediateKey = v;
      for (int j = 0; j < n-p; j++) {
        intermediateKey += unmap(value[i+j]);
      }
      final int cIndex = i + key.length() - p;
      final char c = (cIndex < 0) ? possible[0] : (i == p) ? validatorChar : key.charAt(cIndex);
      value[n-p+i] = map(unmap(c) - intermediateKey);
    }
    return new String(value);
  }
  public static String encode18(char v, int x) {
    return encode6(v, x) + encode6('E', x) + encode6('Z', x);
  }

  public static int decode6(String value) throws BadCodeException {
    if (value.length() != n+1) return 0;
    char[] key = new char[p+1];
    for (int i = 0; i < p+1; i++) {
      int intermediateKey = value.charAt(0);
      for (int j = 0; j < n-p+1; j++) {
        intermediateKey += unmap(value.charAt(i+j));
      }
      key[i] = map(intermediateKey);
    }
    if (key[p] != validatorChar) throw new BadCodeException(value);

    return parse(new String(key, 0, p));
  }
  public static int decode6(char v, String value) throws BadCodeException {
    if (value.length() != n+1) return 0;
    char[] key = new char[p+1];
    for (int i = 0; i < p+1; i++) {
      int intermediateKey = v;
      for (int j = 0; j < n-p+1; j++) {
        intermediateKey += unmap(value.charAt(i+j));
      }
      key[i] = map(intermediateKey);
    }
    if (key[p] != validatorChar) throw new BadCodeException(value);
    return parse(new String(key, 0, p));
  }

  public static int decode18(char v, String value) throws BadCodeException {
    int x1 = decode6(v,   value.substring( 0, 6));
    int x2 = decode6('E', value.substring( 6,12));
    int x3 = decode6('Z', value.substring(12,18));
    if (x1 != x2 || x1 != x3)  throw new BadCodeException(value);
    return x1;
  }

  private static final int p = 3;
  private static final int n = 5;
  private static final char validatorChar = 'Z';
  private static final char[] possible = new char[] {
    'A','B','C','D','E','F','G','H',    'J','K','L','M','N',    'P','Q','R','S','T','U','V','W','X','Y','Z',
            '2','3','4','5','6','7','8','9'
  };
  private static int[] indexes = new int[256];
  static {
    for (int i = 0; i < possible.length; i++) {
      indexes[possible[i]] = i;
    }
  }

  private static StringBuffer decompose(int x) {
    if (x < possible.length) return new StringBuffer().append(possible[x]);
    final int y = x / possible.length;
    return decompose(y).append(possible[x-y*possible.length]);
  }
  private static int parse(String s) {
    int x = 0;
    for (int i = 0; i < s.length(); i++) {
      x *= possible.length;
      x += indexes[s.charAt(i)];
    }
    return x;
  }

  private static char map(double d) {
    return map((int)d);
  }
  private static char map(int i) {
    while (i < 0) i += possible.length;
    return possible[i % possible.length];
  }
  private static int unmap(char c) {
    return indexes[c];
  }
  
  private static final SecureRandom random = new SecureRandom(); 

}

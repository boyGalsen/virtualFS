package com.easyrms.code;

import java.io.*;


public final class LongCode implements Serializable, Cloneable {

  public LongCode(char v, int x) {
    this.value = IntegerEncoder.encode18(v, this.x = x);
  }
  public LongCode(char v, String value) throws BadCodeException  {
    this.x = IntegerEncoder.decode18(v, this.value = value.toUpperCase());
  }

  public int intValue() { return x; }
  @Override
  public String toString() { return value; }

  @Override
  public int hashCode() { return x; }
  @Override
  public boolean equals(Object o) { return ((o instanceof LongCode) && ((LongCode)o).value.equals(value)); }

  @Override
  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  private final String value;
  private final int x;
}
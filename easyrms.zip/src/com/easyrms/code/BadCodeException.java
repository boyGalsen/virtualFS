package com.easyrms.code;

public class BadCodeException extends RuntimeException {

  public BadCodeException() {
    super("Not an Easy Code");
  }
  public BadCodeException(String code) {
    super("Not an Easy Code ("+code+")");
  }
}
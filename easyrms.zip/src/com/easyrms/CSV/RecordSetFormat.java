package com.easyrms.CSV;

import com.easyrms.util.*;

import java.io.*;
import java.text.*;
import java.util.*;


public class RecordSetFormat implements RecordSet {

  public RecordSetFormat(String[] columns, FormatManager formatManager, RecordSet recordSet) {
    this.width = (columns == null) ? recordSet.getWidth() : columns.length;
    this.formatManager = formatManager;
    this.recordSet = recordSet;
    this.columns = (columns == null) ? new String[this.width] : (String[])columns.clone();
    if (columns == null) {
      for (int i = 0; i < width; i++) this.columns[i] = recordSet.getColumnName(i);
    }
    this.indexes = new int[width];
    this.types = new Class[width];
    Arrays.fill(this.indexes, -1);
    for (int i = 0, m = recordSet.getWidth(); i < width; i++) {
      final String name = this.columns[i];
      columnsIndexes.put(name, IntegerCache.get(i));
      if (columns == null) {
        indexes[i] = i;
      }
      else {
        for (int j = 0; j < m; j++) {
          if (name.equals(recordSet.getColumnName(j))) {
            indexes[i] = j;
            break;
          }
        }
        if (indexes[i] < 0) throw new IllegalStateException("Column ["+name+"] not found");
      }
    }
  }
  
  public void setType(String column, Class<?> type) {
    types[getIndex(column)] = type;
  }
  
  public Class<?> getType(String column) {
    return types[getIndex(column)];
  }
  
  private int getIndex(String column) {
    final Integer i = columnsIndexes.get(column);
    return (i == null) ? - 1: i.intValue();
  }

  public boolean next() throws ParseException, IOException {
    init();
    return recordSet.next();
  }

  public int getWidth() {
    return width;
  }

  public String getColumnName(int column) {
    return columns[column];
  }

  public String getCell(int column) {
    return recordSet.getCell(indexes[column]);
  }

  public Object getObject(int column) {
    if (formats[column] != null) {
      final String cell = getCell(column);
      if (cell == null) return null;
      noPosition.setIndex(0);
      return formats[column].parseObject(cell, noPosition);
    }
    return recordSet.getObject(indexes[column]);
  }
  
  private void init() {
    if (!isInit) {
      formats = new Format[width];
      for (int i = 0; i < width; i++) {
        if (types[i] != null) formats[i] = formatManager.getFormat(types[i]);
      }
      this.isInit = true;
    }
  }
  
  private boolean isInit = false;
  private Format[] formats;
  
  private final int width;
  private final HashMap<String, Integer> columnsIndexes = new HashMap<String, Integer>();
  private final String[] columns;
  private final Class<?>[] types;
  private final int[] indexes;
  private final FormatManager formatManager;
  private final RecordSet recordSet;
  private final ParsePosition noPosition = new ParsePosition(0);
}
package com.easyrms.CSV;

import java.io.*;
import java.text.*;
import java.util.*;

import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;


public class OtherSimpleCSVRecord implements ExtendedRecordSet {
  
  public OtherSimpleCSVRecord(Reader in) {
    this(in, defaultParser);
  }
  public OtherSimpleCSVRecord(Reader in, CSVParser parser) {
    this.in = new BoundedBufferedReader(in);
    this.parser = parser;
    try {
      if (!next()) {
        throw new IllegalStateException();
      }
      this.titles = this.cells.clone();
      for (int i = 0, n = this.titles.length; i < n; i++) {
        this.titles[i] = normalizedTitle(this.titles[i]);
        this.columnByName.put(this.titles[i], IntegerCache.get(i));
      }
    }
    catch (Throwable exception) {
      throw ExceptionUtils.newRuntimeException(exception);
    }
  }
  
  protected String normalizedTitle(String title) {
    return title;
  }
  
  public int findColumnIndex(String name) {
    final Integer index = columnByName.get(name);
    return (index == null) ? -getWidth() : index.intValue();
  }
  public String getColumnName(int column) {
    if (titles == null) {
      throw new IllegalStateException();
    }
    return titles[column];
  }
  public String[] getColumnName() {
    if (titles == null) {
      throw new IllegalStateException();
    }
    return StringArrays.clone(titles);
  }

  public boolean next() throws ParseException, IOException {
    do {
      if (!in.ready()) {
        return false;
      }
      buffer = in.readLine();
    } 
    while (buffer == null);
    lineIndex++;
    if (cells == null) {
      cells = parser.parse(buffer);
    }
    else {
      parser.parse(buffer, cells);
    }
    return true;
  }

  public int getWidth() {
    if (titles == null) {
      throw new IllegalStateException();
    }
    return titles.length;
  }
  public String getCell(int column) {
    if (cells == null) {
      throw new IllegalStateException();
    }
    if (column < 0 || column >= cells.length) {
      throw new IllegalArgumentException();
    }
    return cells[column];
  }
  public Object getObject(int column) {
    return getCell(column);
  }
  
  protected final BoundedBufferedReader in;
  protected final CSVParser parser;
  protected final String[] titles;
  private final HashMap<String, Integer> columnByName = new HashMap<String, Integer>(); 
  protected String[] cells;
  protected String buffer;
  protected int lineIndex = 0;
  protected static final SimpleCSVParser defaultParser = new SimpleCSVParser('"', ',');
}
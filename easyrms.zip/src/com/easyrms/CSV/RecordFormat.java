package com.easyrms.CSV;

import com.easyrms.util.*;
import java.text.*;
import java.io.*;
import java.util.*;


public class RecordFormat {

  public RecordFormat() {
  }

  public RecordFormat(String[] names, Class<?>[] types) {
    if (names == null || types == null || names.length != types.length) {
      throw new IllegalArgumentException();
    }
    for (int i = 0; i < names.length; i++) {
      addColumn(names[i], 0);
      setType(names[i], types[i]);
    }
  }
  public int getColumnCount() {
    return columns.size();
  }
  public String[] getColumn() {
    return columns.toArray(new String[columns.size()]);
  }
  public String getColumn(int i) {
    return columns.get(i);
  }
  public int getIndex(int i) {
    return indexes.get(i).intValue();
  }
  public void addColumn(String name, int index) {
    if (name == null) throw new IllegalArgumentException();
    columns.add(name);
    indexes.add(IntegerCache.get(index));
  }

  public Class<?> getType(String name) {
    return types.get(name);
  }
  public void setType(String name, Class<?> type) {
    types.put(name, type);
  }

  public RecordSet format(final RecordSet data, FormatManager formats) {
    final int n = getColumnCount();
    final Format[] parsers = new Format[n];
    final int[] map = new int[n];
    for (int i = 0; i < n; i++) {
      map[i] = getIndex(i);
      parsers[i] = formats.getFormat(getType(getColumn(i)));
    }
    return new RecordSet() {
      
      final ParsePosition position = new ParsePosition(0);
      public boolean next() throws ParseException, IOException {
        return data != null && data.next();
      }
      public int getWidth() {
        return n;
      }
      public String getCell(int column) {
        if (column < 0 || column >= n) throw new IllegalArgumentException();
        if (map[column] < 0) return null;
        return data.getCell(map[column]);
      }
      public Object getObject(int column) {
        final String text = getCell(column);
        if (text == null || parsers[column] == null) return text;
        position.setIndex(0);
        return parsers[column].parseObject(text, position);
      }
      public String getColumnName(int column) {
        return null;
      }
    };
  }

  private ArrayList<String> columns = new ArrayList<String>();
  private ArrayList<Integer> indexes = new ArrayList<Integer>();
  private HashMap<String, Class<?>> types = new HashMap<String, Class<?>>();
}
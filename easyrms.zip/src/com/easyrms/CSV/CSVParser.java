package com.easyrms.CSV;

import java.text.*;


public interface CSVParser {

  String[] parse(String line) throws ParseException;
  void parse(String line, String[] cells) throws ParseException;
}
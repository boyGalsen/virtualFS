package com.easyrms.CSV;

public interface ExtendedRecordSet extends RecordSet {

  int findColumnIndex(String name);  
}

package com.easyrms.CSV;

import java.io.*;
import java.text.*;


public interface AbstractRecordSet {
  
  boolean next() throws ParseException, IOException;

  int getWidth();
    
  Object getObject(int column);
}
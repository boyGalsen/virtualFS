package com.easyrms.CSV;



public interface RecordSet extends AbstractRecordSet {
  
  String getColumnName(int column);
  String getCell(int column);  
}
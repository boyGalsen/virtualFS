package com.easyrms.CSV;

import java.text.*;
import java.io.*;


public class NullReplaceFilter implements RecordSet {

	public NullReplaceFilter(RecordSet record, String nullColumnName, String replacingColumnName) {
		this.record = record;
    this.nullColumnName = nullColumnName;
    this.replacingColumnName = replacingColumnName;
	}

  public boolean next() throws ParseException, IOException {
    while (record.next()) {
      if (check()) return true;
    }
    return false;
  }

  protected boolean check() { return true; }

  public int getWidth() {
    return record.getWidth();
  }
  public String getCell(int column) {
    initColumns();
    return (nullColumn == column) ? getReplaceCell(column) : record.getCell(column);
  }
  
  private String getReplaceCell(int column) {
    if (replacingColumn < 0 || replacingColumn == Integer.MAX_VALUE) return record.getCell(column); 
    final String cell = record.getCell(column);
    return (cell == null) ? record.getCell(replacingColumn) : cell; 
  }
  private Object getReplaceObject(int column) {
    if (replacingColumn < 0 || replacingColumn == Integer.MAX_VALUE) return record.getObject(column); 
    final Object o = record.getObject(column);
    return (o == null) ? record.getObject(replacingColumn) : o; 
  }
  public Object getObject(int column) {
    initColumns();
    return (nullColumn == column) ? getReplaceObject(column) : record.getObject(column);
  }
  public String getColumnName(int column) {
    return record.getColumnName(column);
  }
  
  private void initColumns() {
    initNullColumn();
    initReplacingColumn();
  }

  private void initNullColumn() {
    if (nullColumn < 0) {
      for (int i = 0, n  = getWidth() ; i < n; i++) {
        if (nullColumnName.equals(getColumnName(i))) {
          nullColumn = i; 
          return;
        }
      }
      nullColumn = Integer.MAX_VALUE;
    }
  }
  private void initReplacingColumn() {
    if (replacingColumn < 0) {
      for (int i = 0, n  = getWidth() ; i < n; i++) {
        if (replacingColumnName.equals(getColumnName(i))) {
          replacingColumn = i; 
          return;
        }
      }
      replacingColumn = Integer.MAX_VALUE;
    }
  }
  private int nullColumn = -1;
  private int replacingColumn = -1;
  private final String replacingColumnName;
  private final String nullColumnName;
  protected final RecordSet record;
}
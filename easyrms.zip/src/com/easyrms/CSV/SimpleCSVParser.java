package com.easyrms.CSV;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.text.*;


public class SimpleCSVParser implements CSVParser {

  public SimpleCSVParser(char stringSeparator, char columnSeparator) {
    this.stringSeparator = stringSeparator;
    this.columnSeparator = columnSeparator;
  }

  public String[] parse(String line) throws ParseException {
    final int n = line.length();
    final ParsePosition position = new ParsePosition(0);
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<String> strings = arrayPool.get();
    try {
      while (position.getIndex() < n) {
        final String string = parse(line, position);
        if (position.getErrorIndex() < 0) {
          strings.add(string);
        }
      }
      return strings.toArray(new String[strings.size()]);
    }
    finally {
      arrayPool.free(strings);
    }
  }
  public void parse(String line, String[] cells) throws ParseException {
    final int n = line.length();
    final ParsePosition position = new ParsePosition(0);
    int i;
    final int cellsLength = cells.length;
    for (i = 0; i < cellsLength && position.getIndex() < n; i++) {
      cells[i] = parse(line, position);
    }
    while (i < cellsLength) {
      cells[i++] = null;
    }
  }

  protected String parse(String line, ParsePosition position) throws ParseException {
    final int n = line.length();
    final int previousIndex = position.getIndex();
    int c = previousIndex;

    while (c < n && line.charAt(c) == ' ') {
      c++;
    }
    if (c >= n) {
      position.setErrorIndex(previousIndex);
      position.setIndex(n);
      return null;
    }
    if (line.charAt(c) == stringSeparator) {
      do {
        c++;
      } 
      while (line.charAt(c) == ' ');
      int c2 = c-1;
      do {
        c2 = line.indexOf(stringSeparator, c2+1);
      } 
      while (c2 > 0 && c2 < n-1 && line.charAt(c2+1) != columnSeparator);
      if (c2 > 0) {
        position.setIndex(Math.min(c2+2, n));
        do {
          c2--;
        } 
        while (c2 >= c && line.charAt(c2) == ' ');
        if (c2 < c) {
          return null;
        }
        return line.substring(c, c2+1);
      }
      position.setErrorIndex(previousIndex);
      position.setIndex(n);
      throw new ParseException(line, previousIndex);
    }
    int c2 = line.indexOf(columnSeparator, c);
    if (c2 < 0) {
      c2 = n;
      position.setIndex(n+1);
      return line.substring(c);
    }
    if (c2 == c) {
      position.setIndex(c2+1);
      return null;
    }
    if (c2 > c) {
      position.setIndex(c2+1);
      return line.substring(c, c2);
    }
    position.setErrorIndex(previousIndex);
    position.setIndex(n);
    throw new ParseException(line, previousIndex);
  }

  private final char stringSeparator;
  private final char columnSeparator;
}
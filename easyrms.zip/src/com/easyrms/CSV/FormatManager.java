package com.easyrms.CSV;

import com.easyrms.util.*;
import com.easyrms.util.format.*;

import java.text.*;
import java.util.*;


public class FormatManager {

	public FormatManager() {
		formats.put(Integer.class, new IntegerParser());
		formats.put(Double.class, new DoubleParser());
		formats.put(String.class, new StringParser());
	}
	
  public void setFormat(Class<?> type, Format format) {
    if (type == null || format == null) throw new IllegalArgumentException();
    formats.put(type, format);
  }
  
  public Format getFormat(Class<?> type) {
    return formats.get(type);
  }
  
  public static final FormatManager noFormat = new FormatManager() {
  	
    @Override
		public void setFormat(Class<?> type, Format format) { throw new UnsupportedOperationException(); }
    @Override
		public Format getFormat(Class<?> type) { return null; }
  };

	private final HashMap<Class<?>, Format> formats = new HashMap<>();
  
  public static class IntegerParser extends AbstractParser {

    @Override
		public Object parseObject(String source, ParsePosition pos) {
      pos.setIndex(source.length());
      return IntegerCache.get(Integer.parseInt(source));
    }
  } 
  
  public static class DoubleParser extends AbstractParser {

    @Override
		public Object parseObject(String source, ParsePosition pos) {
      pos.setIndex(source.length());
      return MathUtils.getDouble(MathUtils.parseDouble(source));
    }
  } 
  
  public static class StringParser extends AbstractParser {

		public StringParser() {
			this(-1);
		}
		public StringParser(int max) {
			this.max = max;
		}
		
    @Override
		public Object parseObject(String source, ParsePosition pos) {
    	final int sourceLength = source.length();
      pos.setIndex(sourceLength);
      return (max < 0 || sourceLength < max) ? source : source.subSequence(0, max);
    }
    
    private final int max;
  }
  
	//public static final Format stringParserReference = new StringParser();
	//public static final Format integerParserReference = new IntegerParser();
	//public static final Format doubleParserReference = new DoubleParser();
}
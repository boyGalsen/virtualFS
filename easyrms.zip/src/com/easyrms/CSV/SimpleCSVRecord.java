package com.easyrms.CSV;

import java.io.*;
import java.text.*;
import java.util.*;

import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;


public class SimpleCSVRecord implements RecordSet, ExtendedRecordSet {
  
  public SimpleCSVRecord(Reader in, String cp) {
    this(in, new EzCSVParser('"', ','), cp);
  }
  
  public SimpleCSVRecord(Reader in, AbstractEzCSVParser parser, String cp) {
    this.parser = parser;
    try {
      this.parser.init(new BoundedBufferedReader(in), cp);
      if (!next()) {
        throw new IllegalStateException();
      }
      this.titles = this.cells.clone();
    }
    catch (Throwable exception) {
      throw ExceptionUtils.newRuntimeException(exception);
    }
  }
  
  public int findColumnIndex(String column) {
    return StringArrays.find(titles, column);
  }
  
  public String getColumnName(int column) {
    if (titles == null) {
      throw new IllegalStateException();
    }
    return titles[column];
  }
  public String[] getColumnName() {
    if (titles == null) {
      throw new IllegalStateException();
    }
    return StringArrays.clone(titles);
  }

  public boolean next() throws ParseException, IOException {
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<String> cells = arrayPool.get();
    try {
      if (!parser.hasMoreRow()) {
        return false;
      }
      parser.getNextRow();
      while (parser.hasMoreElement()) {
        cells.add(parser.getNextElement());
      }
      this.cells = cells.toArray(new String[cells.size()]);
      return (this.cells.length != 0);
    }
    finally {
      arrayPool.free(cells);
    }
  }

  public int getWidth() {
    if (titles == null) {
      throw new IllegalStateException();
    }
    return titles.length;
  }
  
  public String getCell(int column) {
    if (cells == null) {
      throw new IllegalStateException();
    }
    if (column < 0 || column >= titles.length) {
      throw new IllegalArgumentException(column +" is invalidColumn");
    }
    if (column >= cells.length) {
      return null;
    }
    return cells[column];
  }
  
  public Object getObject(int column) {
    return getCell(column);
  }
  
  public int getLine() {
    return lineIndex;
  }

  public boolean isNull(int column) {
    return StringComparator.isNull(cells[column]);
  }

  public Properties getHeader() {
    return parser.getHeader();
  }
  
  protected final AbstractEzCSVParser parser;
  protected final String[] titles;
  protected String[] cells;
  protected String buffer;
  protected int lineIndex = 0;
}
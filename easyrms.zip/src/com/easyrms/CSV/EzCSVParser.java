package com.easyrms.CSV;

import java.io.*;
import java.util.Properties;

import com.easyrms.util.*;


public class EzCSVParser implements AbstractEzCSVParser {
  
  public EzCSVParser(char otherSep) {
    this.sepChar = otherSep;
    this.textChar = '"';
    this.withTextChar = false;
  }

  public EzCSVParser(char textSep, char otherSep) {
    this.sepChar = otherSep;
    this.textChar = textSep;
    this.withTextChar = true;
  }
  
  public void reset() throws IOException {
    this.in.reset();
    this.state = START;
    this.currentRow = 0;
    this.hasMoreElement = false;
    this.hasMoreRow = true; 
    this.header = new Properties();
    this.readHeader = true;
  }
    
  public EzCSVParser init(final Reader in, String cp) throws IOException {
    this.state = START;
    this.in = in;
    this.currentRow = 0;
    this.hasMoreElement = false;
    this.hasMoreRow = true; 
    this.header = new Properties();
    this.readHeader = true;
    this.cp = cp;
    return this;
  }

  public String getNextElement() throws IOException {
    hasMoreElement = false;
    final String element = (this.element == null || cp == null) 
      ? this.element 
      : new String(this.element.getBytes(), cp);
    if (!this.hasMoreRow) findNextElement();
    return element;
  }
  
  public int getNextRow() throws IOException {
    hasMoreRow = false;
    final int currentRow = this.currentRow;
    findNextElement();
    return currentRow;
  }
  
  public boolean hasMoreHeader() {
    return hasMoreHeader;
  }
  
  public boolean hasMoreRow() throws IOException {
    return hasMoreRow;
  }
  
  public boolean hasMoreElement() throws IOException {
    return hasMoreElement;
  }
  
  public Properties getHeader() {
    return header;
  }
  
  private void findNextElement() throws IOException {
    state = START;
    element = null;
    hasMoreElement = false;
    hasMoreRow = false;
    final StringBuilderThreadPool pool = StringBuilderThreadPool.threadPools.get();
    final StringBuilder buffer = pool.get();
    try {
      while (in.read(buff) >= 0) {
        final char c = buff[0];
        if (readHeader) {
          switch (state) {
            case START : 
              switch (c) {
                case '.' : {
                  buffer.append(c);
                  state = END_HEADER;
                  break;
                }
                case '"' : {
                  readHeader = false;
                  buffer.setLength(0);
                  state = IN_DATA;
                  break;
                }
                case ':' : {
                  headerName = "";
                  state = HEADER_VALUE;
                  break;
                }
                case '\r' : case '\t' : case ' ' : case '\f' : case '\n' : {
                  break;
                }
                default : {
                  buffer.append(c);
                  state = IN_HEADER;
                }
              }
              break;
            case END_HEADER : 
              switch (c) {
                case '\r' : case '\t' : case ' ' : case '\f' : {
                  break;
                } 
                case '\n' : {
                  buffer.setLength(0);
                  readHeader = false;
                  state = START;
                  break;
                }
                default : throw new IllegalStateException();
              }
              break;
            case IN_HEADER : 
              switch (c) {
                case ':' : {
                  headerName = buffer.toString();
                  buffer.setLength(0);
                  state = HEADER_VALUE;
                  break;
                }
                case '\r' : case '\t' : case ' ' : case '\f' : {
                  break;
                } 
                case '\n' : {
                  header.put(buffer.toString(), "");  
                  buffer.setLength(0);
                  state = HEADER_VALUE;
                }
                default : {
                  buffer.append(c);
                }
              }
              break;
            case HEADER_VALUE : 
              switch (c) {
                case '\r' : case '\t' : case ' ' : case '\f' : {
                  break;
                } 
                case '\n' : {
                  header.put(headerName, buffer.toString());  
                  buffer.setLength(0);
                  state = START;
                }
                default : {
                  buffer.append(c);
                }
              }
              break;
            default : 
              throw new IllegalStateException();  
          }
        }
        else {
          switch (state) {
            case START : 
              if (c == sepChar) {
                element = null;
                hasMoreElement = true;
                return;
              }
              else if (c == '\r' || c == '\t' || c == '\f') {
//              ignored character
              }
              else if (c == '\n') {
                currentRow++;
                hasMoreRow = true;
                return;
              }
              else if (withTextChar && c == textChar) {
                state = IN_DATA;
              }
              else {
                buffer.append(c);
                state = IN_DATA2;
              }
              break;
            case END :
              if (c == sepChar) {
                return;
              }
              else if (c == '\r' || c == '\t' || c == '\f') {
                //ignored character
              }
              else if (c == '\n') {
                currentRow++;
                hasMoreRow = true;
                return;
              }
              else {
                throw new IllegalStateException();
              }
              break;
            case IN_DATA : 
              if (c == escapeChar) {
                state = IN_ESCAPE;
              }
              else if (c == '\r' || c == '\n') {
//              ignored character
              }
              else if (c == textChar) {
                state = IN_DATA_END;
              }
              else {
                buffer.append(c);
              }
              break;
            case IN_DATA_END :
              if (c == escapeChar) {
                buffer.append('"');
                state = IN_ESCAPE;
              }
              else if (c == sepChar) {
//              element = buffer.toString();
                buffer.setLength(0);
                hasMoreElement = true;
                state = END;
                return;
              }
              else if (c == '\r') {
                element = buffer.toString();
                buffer.setLength(0);
                hasMoreElement = true;
                state = END;
              } 
             else if (c == '\n') {
                element = buffer.toString();
                buffer.setLength(0);
                hasMoreElement = true;
                currentRow++;
                hasMoreRow = true;
                state = END;
                return;
              }
              else  {
                buffer.append(textChar).append(c);
                state = IN_DATA;
              }
              break;
            case IN_DATA2 :
              if (c == sepChar) {
                element = buffer.toString();
                buffer.setLength(0);
                hasMoreElement = true;
                return;
              }
              else if (c == '\r') {
              } 
              else if (c == '\n') {
                element = buffer.toString();
                buffer.setLength(0);
                currentRow++;
                hasMoreElement = true;
                hasMoreRow = true;
                return;
              }
              else  {
                buffer.append(c);
              }
              break;
            case IN_ESCAPE : 
              if (c == escapeChar || c == textChar) {
                buffer.append(c);
                state = IN_DATA;
              }
              else { 
                throw new IllegalStateException();
              }
              break;
            default : throw new IllegalStateException();
          }
        }
      }
      element = buffer.toString();
      buffer.setLength(0);
      hasMoreElement = (state != START);
      hasMoreRow = (state != START);
      state = START;
    }
    finally {
      pool.free(buffer);
    }
  }
  
  public void close() {
    in = null;
    element = null;
    hasMoreElement = false;
    hasMoreRow = false;
    hasMoreHeader = false;
    headerName = null;
    header = null;
    readHeader = false;
  }
  
  private final char sepChar;
  private final char textChar;
  private final char escapeChar = '\\';
  private final boolean withTextChar;
  
  private String element = null;
  private boolean hasMoreElement = false;
  private boolean hasMoreRow = false; 
  private boolean hasMoreHeader = false; 
  private boolean readHeader = false;
  private String cp = null;
  private String headerName; 
  private int state = START;
  private Reader in = null;
  private int currentRow = 0;
  private Properties header = null;
  private final char[] buff = new char[1];
  
  private static final int START = 0;
  private static final int IN_DATA = 1;
  private static final int IN_DATA2 = 2;
  private static final int IN_ESCAPE = 3;
  private static final int END = 4;
  private static final int IN_DATA_END = 5;
  
  private static final int IN_HEADER = 2;
  private static final int END_HEADER = 3;
  private static final int HEADER_VALUE = 4;
}
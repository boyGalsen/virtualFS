package com.easyrms.CSV;

import java.io.*;
import java.util.*;

public interface AbstractEzCSVParser {

  AbstractEzCSVParser init(Reader reader, String codePage)  throws IOException;
  
  Properties getHeader();
  
  boolean hasMoreRow() throws IOException;
  int getNextRow()  throws IOException;
  boolean hasMoreElement()  throws IOException;
  String getNextElement()  throws IOException;
}

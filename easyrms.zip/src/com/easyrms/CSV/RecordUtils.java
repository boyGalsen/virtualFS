package com.easyrms.CSV;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.text.*;
import java.io.*;
import java.util.*;


public class RecordUtils {

  public static String[] record2columns(RecordSet record) throws ParseException, IOException {
    if (record == null) {
      throw new IOException();
    }
    if (!record.next()) {
      return EmptyArrays.emptyStringArray;
    }
    final int width = record.getWidth();
    final String[] data = new String[width];
    for (int i = 0; i < width; i++) {
      data[i] = record.getCell(i);
    }
    return data;
  }

  public static Object[] record2line(RecordSet record) throws ParseException, IOException {
    if (record == null) {
      throw new IOException();
    }
    if (!record.next()) {
      return EmptyArrays.emptyStringArray;
    }
    final int width = record.getWidth();
    final Object[] data = new Object[width];
    for (int i = 0; i < width; i++) {
      data[i] = record.getObject(i);
    }
    return data;
  }

  public static Object[][] record2array(RecordSet record) throws ParseException, IOException {
    return record2array(record, Integer.MAX_VALUE);
  }
  public static Object[][] record2array(RecordSet record, int maxRows) throws ParseException, IOException {
    if (record == null) {
      throw new IOException();
    }
    if (!record.next()) {
      return null;
    }
    final int width = record.getWidth();
    final EzArrayList<Object>[] data = new EzArrayList[width];
    final Object[][] arrays = new Object[width][];
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    for (int i = 0; i < width; i++) {
      data[i] = arrayPool.get();
    }
    try {
      do {
        for (int i = 0; i < width; i++) {
          data[i].add(record.getObject(i));
        }
      } 
      while (record.next() && maxRows-- > 0);
      for (int i = 0; i < width; i++) {
        arrays[i] = data[i].toArray(new Object[data[i].size()]);
      }
    }
    finally {
      for (int i = 0; i < width; i++) {
        arrayPool.free(data[i]);
      }
    }
    return arrays;
  }
  public static Object[][] record2Lines(RecordSet record) throws ParseException, IOException {
    return record2Lines(record, Integer.MAX_VALUE);
  }
  public static Object[][] record2Lines(RecordSet record, int maxRows) throws ParseException, IOException {
    if (record == null) {
      throw new IOException();
    }
    if (!record.next()) {
      return null;
    }
    final int width = record.getWidth();
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<Object[]> lines = arrayPool.get();
    try {
      do {
        final Object[] line = new Object[width];
        for (int i = 0; i < width; i++) {
          line[i] = record.getObject(i);
        }
        lines.add(line);
      } while(record.next() && maxRows-- > 0);
      return lines.toArray(new Object[lines.size()][]);
    }
    finally {
      arrayPool.free(lines);
    }
  }

  public interface RecordDispatcher {
    int getWidth();
    int getArray(RecordSet record);
  }
  public static Object[][][] record2arrays(RecordSet record, RecordDispatcher dispatcher) throws ParseException, IOException {
    if (!record.next()) return null;
    final int n = dispatcher.getWidth();
    final int p = record.getWidth();
    final ArrayList<Object>[][] data = new ArrayList[n][];
    do {
      final int i = dispatcher.getArray(record);
      if (data[i] == null) {
        data[i] = new ArrayList[p];
        for (int j = 0; j < p; j++) {
          data[i][j] = new ArrayList<Object>();
        }
      }
      for (int j = 0; j < p; j++) {
        data[i][j].add(record.getObject(j));
      }
    } while(record.next());
    final Object[][][] arrays = new Object[n][][];
    for (int i = 0; i < n; i++) {
      if (data[i] == null) continue;
      arrays[i] = new Object[p][];
      for (int j = 0; j < p; j++) {
        arrays[i][j] = data[i][j].toArray(new Object[data[i][j].size()]);
      }
    }
    return arrays;
  }

  public static RecordFormat format(String[] columns, String[] titles, boolean isNullAllowed) {
    final RecordFormat format = new RecordFormat();
    final HashMapThreadPool mapPool = HashMapThreadPool.threadPools.get();
    final HashMap<String, Integer> map = mapPool.get();
    try {
	    for (int i = 0, n = titles.length; i < n; i++) {
	      map.put(titles[i], IntegerCache.get(i));
	    }
	    for (int i = 0, n = columns.length; i < n; i++) {
	      final Integer index = map.get(columns[i]);
	      if (index == null) {
	        if (isNullAllowed) {
	          format.addColumn(columns[i], -1);
	        }
	        else {
	          throw new IllegalArgumentException();
	        }
	      }
	      else {
	        format.addColumn(columns[i], index.intValue());
	      }
	    }
	    return format;
    }
    finally {
    	mapPool.free(map);
    }
  }
}
package com.easyrms.CSV;

import java.text.*;
import java.io.*;

import com.easyrms.util.*;
import com.easyrms.util.comparator.StringComparator;
import com.easyrms.util.log.*;


public class RecordFilter implements RecordSet {

	public RecordFilter(RecordSet record) {
		this(record, 0);
	}
  
  public RecordFilter(RecordSet record, int truncatedColumnCount) {
		this.record = record;
		this.truncatedColumnCount = truncatedColumnCount;
	}
  
  public void setLog(Log log, String tag) {
    this.log = log;
    this.logTag = tag;
  }

  protected void log(boolean isDisplayed, String text) {
    log.log(false, logTag, text);
  }
  
  public boolean next() throws ParseException, IOException {
    if (currentIndex == 0 && log != null) log.log(false, logTag, "start Read");
    currentIndex++;
    final StringBuilder buf = (log != null) ? StreamUtils.getStringBuilder() : null;
    try {
      while (record.next()) {
        if (check()) return true;
        if (log != null) {
          StreamUtils.reset(buf);
          for (int i = 0, n = getWidth(); i < n; i++) {
            buf.append(getColumnName(i)).append("=[").append(StringComparator.NVL(getCell(i))).append("]");
          }
          log(false, buf.toString());
        }
        nbIgnored++;
      }
    }
    finally {
      if (log != null) StreamUtils.free(buf);
    }
    if (log != null) log.log(false, logTag, "end Read");
    return false;
  }
  
  public int getNbIgnored() {
    return nbIgnored;
  }

  protected boolean check() { 
    return true; 
  }

  public int getWidth() {
    return record.getWidth()-truncatedColumnCount;
  }
  public String getCell(int column) {
    return record.getCell(column);
  }
  public Object getObject(int column) {
    return record.getObject(column);
  }
  public String getColumnName(int column) {
    return record.getColumnName(column);
  }
  
  public int nbReadLine() {
    return currentIndex;
  }

  private final int truncatedColumnCount;
  private int nbIgnored = 0;
  private int currentIndex = 0;
  protected final RecordSet record;
  private Log log;
  private String logTag;
}
package com.easyrms.CSV;

import java.text.*;
import java.io.*;


public class TruncateFilter implements RecordSet {

	public TruncateFilter(RecordSet record, String truncateColumnName, int truncateLimit) {
		this.record = record;
    this.truncateColumnName = truncateColumnName;
    this.truncateLimit = truncateLimit;
	}

  public boolean next() throws ParseException, IOException {
    while (record.next()) {
      if (check()) {
        return true;
      }
    }
    return false;
  }

  protected boolean check() { 
    return true; 
  }

  public int getWidth() {
    return record.getWidth();
  }

  public String getCell(int column) {
    initTruncateColumn();
    return (truncateColumn == column) ? getTruncatedCell(column) : record.getCell(column);
  }
  
  public Object getObject(int column) {
    initTruncateColumn();
    return (truncateColumn == column) ? getTruncatedCell(column) : record.getObject(column);
  }

  public String getColumnName(int column) {
    return record.getColumnName(column);
  }

  private String getTruncatedCell(int column) {
    return truncate(record.getCell(column), truncateLimit);
  }

  private void initTruncateColumn() {
    if (truncateColumn < 0) {
      for (int i = 0, n = getWidth(); i < n; i++) {
        if (truncateColumnName.equals(getColumnName(i))) {
          truncateColumn = i; 
          return;
        }
      }
      truncateColumn = Integer.MAX_VALUE;
    }
  }

  private int truncateColumn = -1;
  private final String truncateColumnName;
  private final int truncateLimit;
  protected final RecordSet record;
  
  private static String truncate(String value, int maxLength) {
    if (value == null) {
      return null;
    }
    return (value.length() <= maxLength) ? value : value.substring(0, maxLength);
  }
}
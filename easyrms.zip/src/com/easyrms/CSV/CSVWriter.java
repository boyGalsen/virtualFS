package com.easyrms.CSV;

import com.easyrms.builder.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.preferences.*;

import java.io.*;
import java.util.*;


public class CSVWriter {
  
  public static enum CSVObjectType {
    DEFAULT_QUOTE(true), STRING_QUOTE(true), DECIMAL_QUOTE(true), INTEGER_QUOTE(true),
    DEFAULT(false), STRING(false), DECIMAL(false), INTEGER(false);
    
    CSVObjectType(boolean isQuoted) {
      this.isQuoted = isQuoted;
    }
    
    public boolean isQUOTE() {
      return this.isQuoted;
    }
    
    private final boolean isQuoted;
  }
  
	public CSVWriter() {
	}
  
  public void write(final Parameters parameters) throws IOException {
    if (parameters != null) {
      boolean withParameter = false;
      for (final ParametersTuple parameter : parameters) {
        this.out.write(parameter.getParameter());
        this.out.write("=");
        this.out.write(StringUtil.NVL(parameter.getParameterValue()));
        this.out.write("\r\n");
      }
      if (withParameter) {
        this.out.write(".\r\n");
      }
    }
  }
	
	public CSVWriter init(final Writer out) {
		this.out = out;
		return this;
	}

  public void write(final Object[] values) throws IOException {
    write(values, (CSVObjectType[])null, (Builder[])null);
  }

  public void write(final Object[] values, final CSVObjectType[] types, final Builder[] builders) throws IOException {
  	if (values.length > 0) {
      for (int i = 0, n = values.length; i < n; i++) {
  			if (i > 0) out.write(separator);
        write(values[i], (types == null) ? CSVObjectType.DEFAULT_QUOTE : types[i], (builders == null) ? null : builders[i]);
      }
  		out.write("\r\n");
  		out.flush();
  	}
  }
  
  public void close() {
  	out = null;
  }
  
  private final void write(final Object value, final CSVObjectType type, final Builder builder) throws IOException {
    if (value != null) {
      if (type.isQUOTE()) out.write("\"");
      out.write(toCSVValue(value, type, builder));
      if (type.isQUOTE()) out.write("\"");
    }
  }
  
  private final String toCSVValue(final Object value, final CSVObjectType type, final Builder builder) {
    final Builder valueBuilder = (builder == null) ? formats.get(type) : builder;
    if (valueBuilder != null) {
      return valueBuilder.format(value);
    }
    String valueString = value.toString();
    if (StringComparator.isWithDoubleQuote(valueString)) {
      valueString = valueString.replaceAll("\"", "\\\"");
    }
    return valueString;
  }
  
  public void set(final CSVObjectType type, final Builder builder) {
    formats.put(type, builder);
  }
  
  private final HashMap<CSVObjectType, Builder> formats = new HashMap<CSVObjectType, Builder>(); 
  
  private Writer out;
  private static final String separator  = ";";
}
package com.easyrms.CSV;

import com.easyrms.util.*;

import java.io.*;


public class MultiLineReader implements Closeable {

  public MultiLineReader(Reader reader) {
    this.reader = reader;
  }
  
  public boolean isReadAvailable() {
    return !isFinish;
  }
  
  public String readLine() throws IOException {
    if (isFinish) {
      throw new IllegalStateException();
    }
    if (buf == null) {
      pool = StringBuilderThreadPool.threadPools.get();
      buf = pool.get();
    }
    else {
      buf.setLength(0);
    }
    try {
      char c;
      while (reader.ready() && (c = (char)reader.read()) >= 0) {
        switch (state) {
          case START:
            switch (c) {
              case '\r': state = END_LINE; break;
              case '\n': state = START; return (buf.length() > 0) ? buf.toString() : null;
              default: buf.append(c); state = IN_LINE; break;
            }
            break;
          case IN_LINE:
            switch (c) {
              case '\r': state = END_LINE; break;
              case '\n': state = START; return (buf.length() > 0) ? buf.toString() : null;
              default: buf.append(c); state = IN_LINE; break;
            }
            break;
          case END_LINE:
            switch (c) {
              case '\n': state = START; return (buf.length() > 0) ? buf.toString() : null;
              default: throw new IllegalStateException();
            }
        }
      }
      final String lastLine = (buf.length() > 0) ? buf.toString() : null;
      close();
      return lastLine;
    }
    catch (Throwable exception) {
      close();
      throw exception;
    }
  }
  
  public void close() {
    isFinish = true;
    if (buf != null) {
      pool.free(buf);
      buf = null;
    }
  }

  private int state = START;
  private final Reader reader; 
  private boolean isFinish = false;
  StringBuilderThreadPool pool;
  private StringBuilder buf;
  
  private static final int START = 0;
  private static final int IN_LINE = 1;
  private static final int END_LINE = 3;
}
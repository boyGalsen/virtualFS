package com.easyrms.cache;

@FunctionalInterface
public interface Getter<K, T> {

  T get(K key);
}

package com.easyrms.cache;

import java.io.*;
import java.util.*;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

/**
 * The <code>CheckManager</code> class is an implementation of the interface
 * <code>Cache</code>. It manages the objects by their key and creates a new
 * one if it is not present in the cache. This aim is achieved by implementing
 * the method called <code>create</code> or by delegating this to an instance of
 * the interface <code>Creator</code> passed as argument to the constructor.
 *
 * @author  Guy TABARY
 * @version 1, 10/01/2000
 * @see     com.easyrms.cache.Creator
 */
public abstract class CheckManager<K, T, U> implements Cache<K, T>, Runnable, Serializable {

  /**
   * Standard creator
   * Overridding the create() method is required with this constructor 
   *
   */
  protected CheckManager() {
    this(false);
  }
  /**
   * Standard creator
   * Overridding the create() method is required with this constructor 
   *
   * @param      cache     the map which will contain the objects.
   */
  protected CheckManager(boolean withNull) {
    this(new SoftHashMap<K, Element<T>>(), withNull);
  }
  /**
   * Standard creator
   * Overridding the create() method is required with this constructor 
   *
   * @param      cache     the map which will contain the objects.
   */
  protected CheckManager(Map<K, Element<T>> cache, boolean withNull) {
    this.objects = cache;
    this.creator = null;
    this.withNull = withNull;
  }
  /**
   * Standard creator which takes an instance of the interface <code>Creator</code>
   * that is delegated the object creation to
   *
   * @param      creator   the creator that is delegated the object creation to.
   */
  protected CheckManager(Creator<K, T> creator, boolean withNull) {
    this(new SoftHashMap<K, Element<T>>(), creator, withNull);
  }
  /**
   * Standard creator which takes an instance of the interface <code>Creator</code>
   * that is delegated the object creation to and a cache which the objects are stored in
   *
   * @param      cache     the map which will contain the objects.
   * @param      creator   the creator that is delegated the object creation to.
   */
  protected CheckManager(Map<K, Element<T>> cache, Creator<K, T> creator, boolean withNull) {
    this.objects = cache;
    this.creator = creator;
    this.withNull = withNull;
  }
  /**
   * Standard creator which takes an instance of the interface <code>Creator</code>
   * that is delegated the object creation to and a cache which the objects are stored in
   *
   * @param      cache     the map which will contain the objects.
   * @param      manager   the manager that is delegated the object creation to.
   */
  protected CheckManager(Map<K, Element<T> > cache, final Cache<K, T> manager, boolean withNull) {
    this.objects = cache;
    this.creator = key -> manager.get(key);
    this.withNull = withNull;
  }

  /**
   * Delegates the Element instantiation.
   *
   * @return  the Element just created.
   * @see        com.easyrms.cache.Manager.Element
   */
  protected Element<T> newElement(T value) {
    return new Element<>(value);
  }
  protected Element<T> newElement() {
    return new Element<>();
  }

  /**
   * Delegates the object instantiation to the creator.
   *
   * @return  the object just created from the key <code>key</code> or null if error.
   * @param      key   the argument for the creation of the object, typically a key.
   * @see        com.easyrms.cache.Creator
   */
  protected T create(K key, U u) throws Exception {
    return create(key);
  }
  protected T create(K key) throws Exception {
    return creator.create(key);
  }

  protected void free() {
    EasyRMS.gc("Check Manager", "Free If Out Of Memory");
    try {
      Thread.sleep(outOfMemoryLatency);
    }
    catch (Throwable ignored) {
    }
  }
  
  protected abstract U createAdditionalData(K key);
  protected abstract void freeAdditionalData(K key, T t, U u);
 
  private T internalCreate(K key, U u) {
    try {
      try {
        return create(key, u);
      }
      catch (OutOfMemoryError ignored) {
        EasyRMS.checkOutOfMemoryError(ignored);
        free();
        return create(key, u);
      }
    }
    catch (Throwable exception) {
      trace.log("Exception when creating Object from "+key+(creator != null ? (" in "+creator.getClass()) : ""), true);
      trace.log(exception, true);
      return null;
    }
  }
  /**
   * Returns the object associated with the key <code>key</code>.
   * <p>
   * If the object associated with the key is already in the cache, returns it;
   * Else creates a new instance, tipically loads data from a database with the
   * key as search criteria.
   *
   * @return  the object associated with the key <code>key</code> or null if error.
   * @param   key   the data for retrieving the object associated with.
    */
  public final T get(K key) {
    if (key == null) {
      throw new IllegalArgumentException(getClass().getName() + ": can't have null key");
    }
    T object = null;
    final Element<T> withKey;
    final Element<T> sameKey;
    synchronized (this) {
      if (isGetFirst) {
        sameKey = objects.get(key);
        if (sameKey != null) {
          withKey = null;
        }
        else {
          withKey = newElement();
          objects.put(key, withKey);
        }
      }
      else {
        withKey = newElement();
        sameKey = objects.put(key, withKey);
      }
    }
    try {
      U u = null;
      try {
        if (sameKey == null) {
          u = createAdditionalData(key);
          object = internalCreate(key, u);
        }
        else {
          if (!sameKey.internalIsNotSet() && check(null, null, null)) {
            object = sameKey.internalGet();
          }
          else {
            synchronized (sameKey) {
              if (sameKey.internalIsNotSet()) {
                object = sameKey.getWhenSet();
              }
              else {
                object = sameKey.internalGet();
                if (withNull || object != null) {
                  u = createAdditionalData(key);
                  if (!check(key, object, u)) {
                    object = internalCreate(key, u);
                  }
                }
              }
            }
            if (object == null && !withNull) {
              if (u == null) {
                u = createAdditionalData(key);
              }
              object = internalCreate(key, u);
            }
          }
        }
      }
      finally {
        if (u != null) {
          freeAdditionalData(key, object, u);
        }
      }
    }
    finally {
      if (withKey != null) {
        withKey.setAndNotify(object);
      }
    }
    return object;
  }

  /**
   * Checks if the <code>object</code> from the cache is still valid.
   * <p>
   * If <code>key</code> is null, returns if the <code>check</code> method should be applied
   *
   */
  protected boolean check(K key, T object, U u) {
    return true;
  }

  /**
   * Retrieves the object associated with the key <code>key</code> in the cache.
   * <p>
   * If the object associated with the key is already in the cache, returns it;
   * Else returns null.
   *
   * @return  the object associated with the key <code>key</code> or null
   * if the key is not in the cache yet.
   * @param      key   the data for retrieving the object associated with.
   */
  public T retrieve(K key) {
    if (key == null) {
      throw new IllegalArgumentException(getClass().getName() + ": can't have null key");
    }

    final Element<T> withKey;
    synchronized (this) {
      withKey = objects.get(key);
    }
    
    return (withKey == null) ? null : withKey.getWhenSet();
  }
  /**
   * Associates the object <code>object</code> with the key <code>key</code>.
   * <p>
   * Returns the previous object associated with this key or null if none.
   *
   * @return  the object previously associated with the key <code>key</code> or null
   * if the key was not in the cache yet.
   * @param      key.
   * @param      object.
   */
  public T put(K key, T object) {
    if (key == null) {
      throw new IllegalArgumentException(getClass().getName() + ": can't have null key");
    }
    if (object == null && !withNull) {
      throw new IllegalArgumentException(getClass().getName() + ": can't put null value for " + key);
    }

    final Element<T> current = newElement(object);
    final Element<T> previous;
    synchronized (this) {
      previous = objects.put(key, current);
    }

    return (previous != null) ? previous.internalGet() : null;
  }

  /**
   * Removes the key <code>key</code>.
   * <p>
   * Returns the previous object associated with this key or null if none.
   *
   * @return  the object previously associated with the key <code>key</code> or null
   * if the key was not in the cache.
   */
  public T remove(K key) {
    final Element<T> sameKey;
    synchronized (this) {
      sameKey = objects.remove(key);
    }
    return (sameKey == null) ? null : sameKey.getAndSet(null);
  }

  /**
   * Removes the object <code>object</code>.
   */
  public synchronized void removeObject(T object) {
    if (object == null) return;
    for (Iterator<Map.Entry<K, Element<T>>> i = objects.entrySet().iterator(); i.hasNext(); ) {
      final Map.Entry<K, Element<T> > entry = i.next();
      final Element<T> element = entry.getValue();
      if (element == null || object.equals(element.internalGet())) {
        i.remove();
      }
    }
  }

  /**
   * Clear the cache.
   */
  public synchronized void clear() {
    objects.clear();
    if (listeners != null) {
      listeners.run();
    }
  }

  public synchronized void addClearListener(Runnable listener) {
    if (listeners == null) {
      listeners = new ListenerHelper(null);
    }
    listeners.addListener(listener);
  }
  
  public void run() {
    clear();
  }
  
  public synchronized Set<K> getKeys() {
    return new HashSet<>(objects.keySet());
  }

  public synchronized Collection<T> getValues() {
    final ArrayList<Element<T>> objectValues = new ArrayList<>(objects.values());
    return new Collection<T>() {

      public int size() { 
        return objectValues.size(); 
      }
      public boolean isEmpty() { 
        return objectValues.isEmpty(); 
      }
      public Object[] toArray() { 
        return toArray(new Object[size()]); 
      }
      public boolean contains(Object o) {
        return objectValues.contains(new Element<>(o));
      }
      public boolean containsAll(Collection<?> c) {
        for (Iterator<?> i = c.iterator(); i.hasNext(); ) {
          if (!contains(i.next())) {
            return false;
          }
        }
        return true;
      }

      public Iterator<T> iterator() {
        final Iterator<Element<T>> objectIterator = objectValues.iterator();
        return new Iterator<T>() {

          public boolean hasNext() {
            return objectIterator.hasNext();
          }

          public T next() {
            element = objectIterator.next();
            return element.getWhenSet();
          }

          public void remove() { 
            objectIterator.remove(); 
          }
          
          private Element<T> element;
        };
      }

      public <X> X[] toArray(X[] a) {
        final EzArrayListThreadPool pool = EzArrayListThreadPool.threadPools.get();
        final EzArrayList<T> objects = pool.get();
        try {
          for (int i = 0, n = objectValues.size(); i < n; i++) {
            objects.add(objectValues.get(i).getWhenSet());
          }
          return objects.toArray(a);
        }
        finally {
          pool.free(objects);
        }
      }

      public void clear() { 
        throw new UnsupportedOperationException(); 
      }
      public boolean add(T o) {
        throw new UnsupportedOperationException(); 
      }
      public boolean remove(Object o) { 
        throw new UnsupportedOperationException(); 
      }
      public boolean addAll(Collection<? extends T> c) { 
        throw new UnsupportedOperationException(); 
      }
      public boolean removeAll(Collection<?> c) { 
        throw new UnsupportedOperationException(); 
      }
      public boolean retainAll(Collection<?> c) { 
        throw new UnsupportedOperationException(); 
      }
    };
  }

  protected static final class Element<T> {
    
    public Element() {
    }
    public Element(T object) {
      internalSet(object);
    }
    
    synchronized T getAndSet(T newValue) {
      final T result = internalGet();
      setAndNotify(newValue);
      return result; 
    }
    
    synchronized void setAndNotify(T object) {
      internalSet(object);
      notifyAll();
    }
    
    boolean internalIsNotSet() {
      return isNotSet;
    }
    
    private void internalSet(T object) {
      this.object = object;
      isNotSet = false;
    }

    private T internalGet() {
      return isNotSet ? null : object;
    }  
    
    T getWhenSet() {
      if (internalIsNotSet()) {
        synchronized (this) {
          while (internalIsNotSet()) {
            ThreadUtil.waitSilently(this);
          }
        }
      }
      return internalGet();      
    }

    public void clear() {
      isNotSet = true;
      object = null;
    }
    
    private T object;
    private volatile boolean isNotSet = true;
  }

  private synchronized void writeObject(ObjectOutputStream aOutputStream) throws IOException {
    objects.clear();
    aOutputStream.defaultWriteObject();
  }

  private final Creator<K, T> creator;
  private final boolean withNull;
  private final Map<K, Element<T>> objects;
  private ListenerHelper listeners;
  
  protected static final Trace trace = new Trace("Map Manager", false);
  protected static final int outOfMemoryLatency = PropertiesUtil.getInt("com.easyrms.cache.CheckManager.outOfMemoryLatency", 25);
  private static final boolean isGetFirst = PropertiesUtil.getBoolean("com.easyrms.cache.CheckManager.isGetFirst", true);
}
package com.easyrms.cache;

import java.util.*;

public class MapManager<K, T> extends CheckManager<K, T, Void> {

  protected MapManager() {
    super();
  }
  protected MapManager(boolean withNull) {
    super(withNull);
  }
  protected MapManager(Creator<K, T> creator, boolean withNull) {
    super(creator, withNull);
  }
  protected MapManager(Map<K, Element<T>> cache, boolean withNull) {
    super(cache, withNull);
  }
  protected MapManager(Map<K, Element<T>> cache, Creator<K, T> creator, boolean withNull) {
    super(cache, creator, withNull);
  }
  protected MapManager(Map<K, Element<T> > cache, Cache<K, T> manager, boolean withNull) {
    super(cache, manager, withNull);
  }
  
  @Override
  protected Void createAdditionalData(K key) {
    return null;
  }
  @Override
  protected void freeAdditionalData(K key, T t, Void u) {
  }
}
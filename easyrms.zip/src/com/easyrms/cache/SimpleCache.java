package com.easyrms.cache;

import com.easyrms.util.*;

import java.util.*;


public class SimpleCache<K, T> implements Cache<K, T> {

	public SimpleCache() {
		this(null);
	}
	public SimpleCache(Creator<K, T> creator) {
	  this.creator = creator;
	}
	
  public void addClearListener(Runnable listener) {
  	if (listeners == null) {
  	  listeners = new ListenerHelper(null);
  	}
  	listeners.addListener(listener);
  }
  
	public T get(K key) {
    if (key == null) {
      throw new IllegalArgumentException(getClass().getName() + ": can't have null key");
    }
		T object = objects.get(key);
		if (object == null) {
			try {
				object = create(key);
				if (object != null) {
				  objects.put(key, object);
				}
			}
			catch (Exception exception) {
				EasyRMS.trace.log("CACHE Cannot create object with key="+key, exception);
			}
		}
		return object;
	}
	
	public void removeObject(T object) { 
		if (object != null) {
			for (Iterator<K> i = objects.keySet().iterator(); i.hasNext(); ) {
				final K key = i.next();
				final T other = objects.get(key);
				if (object.equals(other)) {
					objects.remove(key);
				}
			}
		}
	}

	public T retrieve(K key) { 
	  return objects.get(key); 
	}
	
	public T put(K key, T object) {	
	  return objects.put(key, object); 
	}
	
	public T remove(K key) { 
	  return objects.remove(key); 
	}
	public void clear() { 
	  objects.clear();
	}
	
	public Set<K> getKeys() { 
	  return objects.keySet(); 
	}
	
	public Collection<T> getValues() { 
	  return objects.values(); 
	}

	protected T create(K key) throws Exception {	
	  return creator.create(key);	
	}
	
	private final Creator<K, T> creator;
	private final HashMap<K, T> objects = new HashMap<>();
  private ListenerHelper listeners;
}
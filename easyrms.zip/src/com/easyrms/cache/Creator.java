package com.easyrms.cache;

/**
 * The <code>Creator</code> interface should be implemented by any
 * class whose instances are intended to instantiate new objects on demand.
 * The class must define a method called <code>create</code>.
 * <p>
 * This interface is designed to provide a common protocol for objects that
 * wish to create objects that are managed by class <code>Manager</code>.
 *
 * @author  Guy TABARY
 * @version 1, 10/01/2000
 * @see     com.ezrms.core.cache.Manager
 */

@FunctionalInterface
public interface Creator<K, T> {

    /**
     * Returns a just instantiated object from a single argument,
     * typically loading an object from its key.
     *
     * @param      key   the argument for the creation of the object, typically a key.
     * @see        com.ezrms.core.cache.Manager#create(Object key)
     */
  T create(K key) throws Exception;
  
  Creator<?, ?> nullCreator = new Creator<Object, Object>() {
  	
  	public Object create(Object key) { 
    	assert(key != null);
  		return null; 
  	}
  };
}
package com.easyrms.cache;

import com.easyrms.util.*;
import com.easyrms.util.executor.*;

import java.lang.ref.WeakReference;


class PeriodicManager {

	public static class PeriodicReference extends WeakReference<Cache<?,?>> implements NamedRunnable {
    
		public PeriodicReference(Cache<?,?> cache) {
			super(cache);
		}
    
		public String getName() {
      return PeriodicReference.class.getSimpleName(); //TODO add more details
    }

    public void run() {
			final Cache<?,?> cache = get();
			if (cache == null) {
				periodic.remove(this);
			}
			else {
				cache.clear();
			}
		}
	}

  static final com.easyrms.util.PeriodicManager fastPeriodic =
    com.easyrms.util.PeriodicManager.getAlonePeriodicManager(PeriodicContextType.DEFAULT, Integer.getInteger("com.easyrms.cache.period.fast", 1*60*1000).intValue(), "Fast Periodic Cache Manager");

	static final com.easyrms.util.PeriodicManager periodic =
		com.easyrms.util.PeriodicManager.getAlonePeriodicManager(PeriodicContextType.DEFAULT, Integer.getInteger("com.easyrms.cache.period", 10*60*1000).intValue(), "Periodic Cache Manager");

  static final com.easyrms.util.PeriodicManager dailyPeriodic =
    com.easyrms.util.PeriodicManager.getAlonePeriodicManager(PeriodicContextType.DEFAULT, 24*60*60*1000, "Daily Periodic Cache Manager");
}

package com.easyrms.cache;

import java.util.*;


/**
 * The <code>Cache</code> interface should be implemented by any
 * class whose instances are intended to manage objects by key like
 * Dictionary or Map.
 *
 * @author  Guy TABARY
 * @version 1, 10/01/2000
 * @see     com.ezrms.core.cache.Manager
 */

public interface Cache<K, T> extends Getter<K, T> {

  /**
   * Returns the object associated with the key <code>key</code> or null if error.
   *
   * @return  the object associated with the key <code>key</code> or null if error.
   * @param   key   the data for retrieving the object associated with.
    */
  T get(K key);

  /**
   * Retrieves the object associated with the key <code>key</code> in the cache
   * or null otherwise
   *
   * @return  the object associated with the key <code>key</code> or null
   * if the key is not in the cache yet.
   * @param      key   the data for retrieving the object associated with.
   */
  T retrieve(K key);

  /**
   * Associates the object <code>object</code> with the key <code>key</code>.
   * <p>
   * Returns the previous object associated with this key or null if none.
   *
   * @return  the object previously associated with the key <code>key</code> or null
   * if the key was not in the cache yet.
   */
  T put(K key, T object);

  /**
   * Removes the key <code>key</code> and the object associated with.
   * <p>
   * Returns the previous object associated with this key or null if none.
   *
   * @return  the object previously associated with the key <code>key</code> or null
   * if the key was not in the cache.
   */
  T remove(K key);

  /**
   * Removes the object <code>object</code>.
   */
  void removeObject(T object);

  /**
   * Clear the cache.
   */
  void clear();
  
  /**
   * add listener called when clear is called
   */
  void addClearListener(Runnable listener);
  
  /**
   * List of the keys
   */
	Set<K> getKeys();

	/**
	 * List of the Values
	 */
	Collection<T> getValues();
}

package com.easyrms.cache;

import java.io.*;
import java.util.*;


class LRUManager extends HashMap implements Externalizable {

  public LRUManager(int maximumSize) {
    super(maximumSize);
    this.maximumSize = maximumSize;
    bubbleList = new ArrayList(maximumSize);
  }
  public LRUManager() {
    this(Integer.getInteger("com.easyrms.cache.LRUManager.size", 128).intValue());
  }

  public int getMaximumSize() {
    return maximumSize;
  }

    // Map interface
    //-------------------------------------------------------------------------
  @Override
  public Object get(Object key) {
    final ValuePositionPair pair = getPair(key);
    if (pair == null) {
      return null;
    }
    final int position = pair.position;
    if (position > 0) {
      // lets bubble up this entry up the list
      // avoiding expesive list removal / insertion
      int position2 = position - 1;
      Object key2 = bubbleList.get(position2);
      ValuePositionPair pair2 = getPair(key2);
      if (pair2 != null) {
        pair2.position = position;
        pair.position = position2;
        bubbleList.set(position, key2);
        bubbleList.set(position2, key);
      }
    }
    return pair.value;
  }

  @Override
  public Object put(Object key, Object value) {
    final int size = size();
    final ValuePositionPair pair = new ValuePositionPair(value);
    if (size >= maximumSize) {
      // lets retire the least recently used item in the cache
      pair.position = maximumSize - 1;
      super.remove(bubbleList.set(pair.position, key));
    }
    else {
      pair.position = size;
      bubbleList.add(size, key);
    }
    final ValuePositionPair oldPair = putPair(key, pair);
    return (oldPair != null) ? oldPair.value : null;
  }

  @Override
  public Object remove(Object key) {
    final ValuePositionPair pair = removePair(key);
    return (pair != null) ? pair.value : null;
  }

  @Override
  public boolean containsValue(Object value) {
    for (Iterator i = pairIterator(); i.hasNext(); ) {
      final ValuePositionPair pair = (ValuePositionPair)i.next();
      if (value == pair.value) return true;
      if (value != null && value.equals(pair.value)) return true;
    }
    return false;
  }

  @Override
  public Set entrySet() {
    final HashSet result = new HashSet();
    for (Iterator i = super.entrySet().iterator(); i.hasNext(); ) {
      final Map.Entry entry = (Map.Entry)i.next();
      final Object key = entry.getKey();
      final ValuePositionPair pair = (ValuePositionPair)entry.getValue();
      result.add(new Entry(key, pair.value));
    }
    return result;
  }

  @Override
  public Collection values() {
    final ArrayList result = new ArrayList();
    for (Iterator i = super.values().iterator(); i.hasNext(); ) {
      final ValuePositionPair pair = (ValuePositionPair)i.next();
      result.add(pair.value);
    }
    return result;
  }

    // Externalizable interface
    //-------------------------------------------------------------------------
  public void readExternal( ObjectInput in )  throws IOException, ClassNotFoundException {
    maximumSize = in.readInt();
    int size = in.readInt();

    // create a populated list
    bubbleList = new ArrayList(maximumSize);
    for(int i = 0; i < size; i++)  {
      bubbleList.add(null);
    }

    for(int i = 0; i < size; i++ )  {
      final Object key = in.readObject();
      final ValuePositionPair pair = (ValuePositionPair)in.readObject();
      bubbleList.set(pair.position, pair);
      putPair(key, pair);
    }
  }

  public void writeExternal( ObjectOutput out ) throws IOException {
    out.writeInt(maximumSize);
    out.writeInt(size());
    for(Iterator i = keySet().iterator(); i.hasNext(); ) {
      final Object key = i.next();
      out.writeObject(key);
      out.writeObject(getPair(key));
    }
  }

    // Implementation
    //-------------------------------------------------------------------------
  private static class ValuePositionPair implements Serializable {

    public ValuePositionPair() {
    }
    public ValuePositionPair(Object value) {
      this.value = value;
    }

    Object value;
    int position;

    @Override
    public String toString() {
      return "[ " + position + ": " + value + " ]";
    }
  }

  protected ValuePositionPair getPair(Object key) {
    return (ValuePositionPair)super.get(key);
  }
  protected ValuePositionPair putPair(Object key, ValuePositionPair pair) {
    return (ValuePositionPair)super.put(key, pair);
  }
  protected ValuePositionPair removePair(Object key) {
    return (ValuePositionPair)super.remove(key);
  }
  protected Iterator pairIterator() {
    return super.values().iterator();
  }

  private class Entry implements Map.Entry {

    public Entry(Object key, Object value) {
      this.key = key;
      this.value = value;
    }

    public Object getKey() { return key; }
    public Object getValue() { return value; }

    public Object setValue(Object value) {
      this.value = value;
      put(key, value);
      return value;
    }
    @Override
    public boolean equals(Object o) {
      if (!(o instanceof Map.Entry)) return false;
      final Map.Entry entry = (Map.Entry)o;
      return key.equals(entry.getKey()) && (value == null ? entry.getValue() == null : value.equals(entry.getValue()));
    }
    @Override
    public int hashCode() {
      return key.hashCode() ^ (value == null ? 0 : value.hashCode());
    }

    private final Object key;
    private Object value;
  }

    /** Removes the least recently used object from the Map.
      * @return the key of the removed item
      */
/*  Object removeLRU() {
    int lastItem = size();
    Object key = bubbleList.remove( lastItem );
    ValuePositionPair pair = removePair( key );
    return key;
  }
*/
  private int maximumSize;
  private ArrayList bubbleList;
}
package com.easyrms.cache;

import java.io.*;

import java.util.*;


/**
 * The <code>Manager</code> class is an implementation of the interface
 * <code>Cache</code>. It manages the objects by their key and creates a new
 * one if it is not present in the cache. This aim is achieved by delegating
 * this to an instance of the interface <code>Creator</code> passed as argument
 * to the constructor.
 *
 * @author  Guy TABARY
 * @version 1, 17/02/2004
 * @see     com.easyrms.cache.Creator
 */
class FIFOManager<K, T> extends MapManager<K, T> {
  /**
   * Standard creator which takes an instance of the interface <code>Creator</code>
   * that is delegated the object creation to and a cache which the objects are stored in
   *
   * @param      cache     the map which will contain the objects.
   * @param      creator   the creator that is delegated the object creation to.
   */
  protected FIFOManager(Map<K, Element<T>> cache, Creator<K, T> creator, int size, boolean withNull) {
    super(cache, creator, withNull);
    this.objects = new Object[size];
    this.objectCount = size;
  }


  /**
   * Standard creator which takes an instance of the interface <code>Creator</code>
   * that is delegated the object creation to and a cache which the objects are stored in
   *
   * @param      cache     the map which will contain the objects.
   * @param      manager   the manager that is delegated the object creation to.
   */
  protected FIFOManager(Map<K, Element<T>> cache, final Cache<K, T> manager, int size, boolean withNull) {
    super(cache, manager, withNull);
    this.objects = new Object[size];
    this.objectCount = size;
  }

  @Override
  protected synchronized void free() {
  	for (int j = 0; j < objectCount; j++) {
  		objects[j] = null;
  	}
  	super.free();
  }

  @Override
  protected synchronized final T create(K key) throws Exception {
    final T object = super.create(key);
    if (object != null) {
      if (i >= objectCount) i = 0;
      objects[i++] = object;
    }
    return object;
  }

  @Override
	public final synchronized T put(K key, T object) {
		final T value = super.put(key, object);
		if (i >= objectCount) i = 0;
		objects[i++] = object;
		return value;
	}
	
	private synchronized void writeObject(ObjectOutputStream aOutputStream) throws IOException {
		for (int i = 0; i < objectCount; i++) objects[i] = null;
		aOutputStream.defaultWriteObject();
	}

  private int i;
  private final Object[] objects;
  private final int objectCount;

  private static final long serialVersionUID = 2973090456688547124L;
}

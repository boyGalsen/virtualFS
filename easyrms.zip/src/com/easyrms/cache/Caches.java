package com.easyrms.cache;

import com.easyrms.cache.CheckManager.Element;
import com.easyrms.util.*;

import java.io.*;
import java.util.*;
import java.util.function.*;

/**
 * The <code>Manager</code> class is an implementation of the interface
 * <code>Cache</code>. It manages the objects by their key and creates a new
 * one if it is not present in the cache. This aim is achieved by implementing
 * the method called <code>create</code> or by delegating this to an instance of
 * the interface <code>Creator</code> passed as argument to the constructor.
 *
 * @author  Guy TABARY
 * @version 1, 10/01/2000
 * @see     com.easyrms.cache.Creator
 */
public class Caches {

  /**
   * Standard creator for a Manager which does not free object if space is required
   *
   * @param      creator   the creator that is delegated the object creation to.
   */
	public static <K, T> MapManager<K, T> newCacheInstance(Creator<K, T> creator) {
		return newCacheInstance(creator, false);
	}
  public static <K, T> MapManager<K, T> newCacheInstance(Creator<K, T> creator, boolean withNull) {
    assertNotNullCreator(creator);
    return new MapManager<>(new HashMap<K, Element<T>>(), creator, withNull);
  }

  public static <K, T> MapManager<K, T> newCacheInstance(Supplier<T> creator) {
    return newCacheInstance(creator, false);
  }
  public static <K, T> MapManager<K, T> newCacheInstance(Supplier<T> creator, boolean withNull) {
    assertNotNullCreator(creator);
    return new MapManager<>(new HashMap<K, Element<T>>(), (k) -> creator.get(), withNull);
  }
  /**
   * Standard creator for a Manager which can free object if space is required (Weak Reference)
   * A standard cache (newCacheInstance) is created if the creator is listed in the system property EAYRMS_MANAGER
   *
   * @param      creator   the creator that is delegated the object creation to.
   */
	public static <K, T> MapManager<K, T> newManagerInstance(Creator<K, T> creator) {
		return newManagerInstance(creator, false);
	}
  public static <K, T> MapManager<K, T> newManagerInstance(Creator<K, T> creator, boolean withNull) {
    assertNotNullCreator(creator);
    if (isCacheCreator(creator)) {
      return newCacheInstance(creator, withNull);
    }
    return new MapManager<>(
    	getGarbageableMap(creator), 
    	creator, 
    	withNull);
  }

  /**
   * Standard creator for a Manager which can free object if space is required (Weak Reference)
   * A standard cache (newCacheInstance) is created if the creator is listed in the system property EAYRMS_MANAGER
   *
   * @param      creator   the creator that is delegated the object creation to.
   */
  public static <K, T> MapManager<K, T> newPeriodicManagerInstance(Creator<K, T> creator) {
    return newPeriodicManagerInstance(creator, false);
  }  
	public static <K, T> MapManager<K, T> newPeriodicManagerInstance(Creator<K, T> creator, boolean withNull) {
    assertNotNullCreator(creator);
    if (isCacheCreator(creator)) {
      return newCacheInstance(creator, withNull);
    }
		final MapManager<K, T> cache = new MapManager<>(new WeakHashMap<K, Element<T>>(), creator, withNull);
    PeriodicManager.periodic.add(new PeriodicManager.PeriodicReference(cache));
    return cache;
  }
  
  public static <K, T> MapManager<K, T> newDailyPeriodicManagerInstance(Creator<K, T> creator) {
    return newDailyPeriodicManagerInstance(creator, false);
  }  
  public static <K, T> MapManager<K, T> newDailyPeriodicManagerInstance(Creator<K, T> creator, boolean withNull) {
    assertNotNullCreator(creator);
    if (isCacheCreator(creator)) {
      return newCacheInstance(creator, withNull);
    }
    final MapManager<K, T> cache = new MapManager<>(new WeakHashMap<K, Element<T>>(), creator, withNull);
    PeriodicManager.dailyPeriodic.add(new PeriodicManager.PeriodicReference(cache));
    return cache;
  }
  
  /**
   * Standard creator for a Manager which can free object if space is requiered (Weak Reference)
   * A standard cache (newCacheInstance) is created if the creator is listed in the system property EAYRMS_MANAGER
   *
   * @param      creator   the creator that is delegated the object creation to.
   */
  public static <K, T> MapManager<K, T> newFastPeriodicManagerInstance(Creator<K, T> creator) {
    return newFastPeriodicManagerInstance(creator, false);
  }  
  public static <K, T> MapManager<K, T> newFastPeriodicManagerInstance(Creator<K, T> creator, boolean withNull) {
    assertNotNullCreator(creator);
    if (isCacheCreator(creator)) {
      return newCacheInstance(creator, withNull);
    }
    final MapManager<K, T> cache = new MapManager<>(new WeakHashMap<K, Element<T>>(), creator, withNull);
    PeriodicManager.fastPeriodic.add(new PeriodicManager.PeriodicReference(cache));
    return cache;
  }
  
  /**
   * Standard creator for a Manager which can free object if space is requiered (Weak Reference)
   * A standard cache (newCacheInstance) is created if the creator is listed in the system property EAYRMS_MANAGER
   *
   * @param      creator   the creator that is delegated the object creation to.
   */
  public static <K, T> MapManager<K, T> newFIFOManagerInstance(Creator<K, T> creator) {
    return newFIFOManagerInstance(creator, 64, false);
  }
  public static <K, T> MapManager<K, T> newFIFOManagerInstance(Creator<K, T> creator, int n, boolean withNull) {
    return newFIFOManagerInstance(creator, n, withNull, true);
  }
  public static <K, T> MapManager<K, T> newFIFOManagerInstance(Creator<K, T> creator, int n, boolean withNull, boolean isSynchronized) {
    assertNotNullCreator(creator);
    if (isCacheCreator(creator)) return newCacheInstance(creator, withNull);
    return new FIFOManager<>(
    	getGarbageableMap(creator), 
    	creator, 
    	n, 
    	withNull);
  }

  /**
   * Check the creator before creating a manager instance.
   *
   * @return  if the creator is listed in the system property EASYRMS_MANAGER,
   * null otherwise.
   *
   * @param      creator   the creator that is delegated the object creation to.
   * @param      maybeExcluded   if the creator should be excluded.
   */
  private static <K, V> void assertNotNullCreator(Object creator) {
    if (creator == null) {
      throw new IllegalArgumentException(Cache.class.getName() + ": can't have null creator");
    }
  }
  private static <K, V> boolean isCacheCreator(Creator<K, V> creator) {
    return forceCache.contains(creator.getClass().getName());
  }
  private static final Set<String> forceCache = new HashSet<>();
  static {
    try {
      final String property = System.getProperty("com.easyrms.cache.forceCache", "");
      final StreamTokenizer tokens = new StreamTokenizer(new StringReader(property));
      tokens.wordChars('.', '.');
      while (tokens.nextToken() != StreamTokenizer.TT_EOF) {
        if (tokens.ttype == StreamTokenizer.TT_WORD) {
          forceCache.add(tokens.sval);
        }
      }
    }
    catch (Exception e) {
    }
  }

  private static final boolean isWeakHashMapUsed = PropertiesUtil.getBoolean("com.easyrms.cache.isWeakHashMapUsed", false);
  static <K, T> Map<K, Element<T>> getGarbageableMap(Creator<K, T> c) {
  	assertNotNullCreator(c);
    if (isWeakHashMapUsed) {
      return new WeakHashMap<>();
    }
    return new SoftHashMap<>();
  }
}

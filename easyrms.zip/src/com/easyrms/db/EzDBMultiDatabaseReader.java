package com.easyrms.db;

import com.easyrms.cache.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.executor.*;

import java.sql.*;


public class EzDBMultiDatabaseReader<T> extends EzCallableTaskArray<EzArray<T>> implements Creator<ResultSet, T>, ObjectReference<EzArray<T>> {

  public EzDBMultiDatabaseReader(EzArray<? extends EzDBDatabase> databases, String request, Object... parameters) {
    this(databases, null, request, parameters);
  }
  public EzDBMultiDatabaseReader(EzArray<? extends EzDBDatabase> databases, Creator<ResultSet, T> creator, String request, Object... parameters) {
    super(request, databases.getCount());
    this.creator = creator;
    for (int i = 0, n = databases.getCount(); i < n; i++) {
      final int I = i;
      final EzDBDatabase database = databases.get(I);
      requests.add(new EzDBArrayReader<T>(database, request, parameters) {

        @Override
        public T create(ResultSet v) throws Exception {
          return EzDBMultiDatabaseReader.this.create(I, database, v);
        }        
      });
    }    
  }

  public EzArray<T> get() {
    init();
    return objects;
  }

  public T create(int i, EzDBDatabase database, ResultSet v) throws Exception {
    return create(v);
  }  
  public T create(ResultSet v) throws Exception {
    return creator.create(v);
  }

  protected boolean check(T t) {
    return true;
  }
  
  @Override
  public final EzArray<T> call(int i) {
    return requests.get(i).get();
  }

  public boolean isNull() {
    return objects.isEmpty();
  }

  public boolean isDefined() {
    return (objects != null);
  }

  public void init() {
    if (!isDefined()) {
      final EzArrayListThreadPool pool = EzArrayListThreadPool.threadPools.get();
      final EzArrayList<EzArray<T>> objects = pool.get();
      try {
        EzPoolExecutor.DEFAULT.call(this, objects);
        for (int i = 0, n = objects.getCount(); i < n; i++) {
          final EzArray<T> objectsI = objects.get(i);
          objectsI.forEach(t -> {
            if (check(t)) {
              this.objects.add(t);
            }            
          });
        }
      }
      finally {
        pool.free(objects);;
      }
    }
  }

  public void reset() {
    objects = null;
  }

  @Override
  public final String description(int i) {
    return "byDatabase";
  }

  @Override
  public void fillContext(int i, EzTaskContext context) {
    context.put("db.name", requests.get(i).getDatabase().getName());
  }

  private final EzArrayList<EzDBArrayReader<T>> requests = new EzArrayList<EzDBArrayReader<T>>();
  private final Creator<ResultSet, T> creator;
  private EzArrayList<T> objects;
}

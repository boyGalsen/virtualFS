package com.easyrms.db;


import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.io.*;

import java.io.*;
import java.sql.*;


public class JSONRequest extends AbstractXMLStatement {
  
  public String getRequest() {
    return this.request;
  } 

  public void setRequest(String request) {
		this.request = (request.endsWith(";")) ? request.substring(0, request.length()-1) : request;
  }
  
  public static String toJSONString(ResultSet resultSet) {
    final StringWriter sout = new StringWriter();
    boolean isWithData = false;
    int rowCount = 0;
    final JSONWriter jout = new JSONWriter(sout);
    try {
      jout.openObject();
      final ResultSetMetaData meta = resultSet.getMetaData();
      jout.openArray("metadata");
      final int columnCount = meta.getColumnCount();
      for (int i = 1; i <= columnCount; i++) {
        final int type = meta.getColumnType(i);
        jout.openObject();               
        jout.writeContent("type", type);
        jout.writeContent("precision", meta.getPrecision(i));
        jout.writeContent("scal", meta.getScale(i));
        jout.writeContent("name", meta.getColumnName(i));
        jout.writeContent("displaySize", meta.getColumnDisplaySize(i));
        jout.closeObject();               
      }
      jout.closeArray(); 
      while (resultSet.next()) {
        if (!isWithData) {
          jout.openArray("data");
          isWithData = true;
        }
        jout.openArray();
        rowCount++;
        for (int i = 1, n = columnCount; i <= n; i++) {
          final Object object = resultSet.getObject(i);
          jout.openObject();
          if (object != null && !resultSet.wasNull()) {
            if (object instanceof Number) {
              if (meta.getScale(i) > 0 || meta.getPrecision(i) == 0){
                jout.writeContent("value", ""+((Number)object).doubleValue());
              }
              else {
                jout.writeContent("value", ""+((Number)object).longValue());
              }
            }
            else if (object instanceof DateAccessor) {
              jout.writeContent("value", ebXMLDateBuilder.referenceWithTimeFormat(((DateAccessor)object).toDate()));
            }
            else if (object instanceof java.util.Date) {
              jout.writeContent("value", ebXMLDateBuilder.referenceWithTimeFormat(object));
            }
            else {
              jout.writeContent("value", object.toString());
            }
            jout.writeContent("isNull", false);
          }
          else {
            jout.writeContent("isNull", true);
          }                     
          jout.closeObject();
        }
        jout.closeArray();
      }
      if (isWithData) {
        jout.closeArray();
      }
      jout.closeObject();
      return sout.toString();
    }
    catch (Throwable exception) {
      throw ExceptionUtils.newRuntimeException(exception);
    }     
    finally {
    }
  }

  @Override
  protected XMLResponse loadResponse(EzDBConnection connection) throws Exception {
    final IntReference rowCount = new IntReference(0);
    final IntReference colCount = new IntReference(0);
    //final EzJDBCConnection connection = database.openAccess().getConnection();
    try {
      //boolean isReadOnly = connection.isReadOnly();
      //try {
        //connection.setAutoCommit(false);
        //connection.setReadOnly(true);
        //final Statement query = connection.createStatement();
        //if (query != null) {
      final BooleanReference isWithData = new BooleanReference(false);
      final StringWriter sout = new StringWriter();
          final JSONWriter jout = new JSONWriter(sout);
          try {
            jout.openObject();
            connection.query(request, new EzDBResultSetListener() {

              @Override
              public void init(ResultSet resultSet) throws SQLException {
                super.init(resultSet);
                try {
                  final ResultSetMetaData meta = resultSet.getMetaData();
                  jout.openArray("metadata");
                  final int columnCount = meta.getColumnCount();
                  colCount.setValue(columnCount);
                  for (int i = 1; i <= columnCount; i++) {
                    final int type = meta.getColumnType(i);
                    jout.openObject();               
                    jout.writeContent("type", type);
                    jout.writeContent("precision", meta.getPrecision(i));
                    jout.writeContent("scal", meta.getScale(i));
                    jout.writeContent("name", meta.getColumnName(i));
                    jout.writeContent("displaySize", meta.getColumnDisplaySize(i));
                    jout.closeObject();               
                  }
                  jout.closeArray();    
                }
                catch (SQLException exception) {
                  throw exception;
                }
                catch (Throwable forward) {
                  throw new SQLException(forward);
                }
              }

              @Override
              public void set(int j, ResultSet resultSet) throws SQLException {
                final ResultSetMetaData meta = resultSet.getMetaData();
                try {
                  if (j == 0) {
                    jout.openArray("data");
                    isWithData.setValue(true);
                  }
                  jout.openArray();
                  for (int i = 1, n = colCount.getValue(); i <= n; i++) {
                    if (i == 1) rowCount.setValue(j+1);
                    final Object object = resultSet.getObject(i);
                    jout.openObject();
                    if (object != null && !resultSet.wasNull()) {
                      if (object instanceof Number) {
                        if (meta.getScale(i) > 0 || meta.getPrecision(i) == 0){
                          jout.writeContent("value", ""+((Number)object).doubleValue());
                        }
                        else {
                          jout.writeContent("value", ""+((Number)object).longValue());
                        }
                      }
                      else if (object instanceof DateAccessor) {
                        jout.writeContent("value", dateFormat.format(((DateAccessor)object).toDate()));
                      }
                      else if (object instanceof java.util.Date) {
                        jout.writeContent("value", dateFormat.format(object));
                      }
                      else {
                        jout.writeContent("value", object.toString());
                      }
                      jout.writeContent("isNull", false);
                    }
                    else {
                      jout.writeContent("isNull", true);
                    }                     
                    jout.closeObject();
                  }
                  jout.closeArray();
                }
                catch (SQLException exception) {
                  throw exception;
                }
                catch (Throwable forward) {
                  throw new SQLException(forward);
                }
              }
            
          });
            if (isWithData.getValue()) {
              jout.closeArray();
            }
            jout.closeObject();
           return new XMLResponse(sout.toString(), colCount.getValue(), rowCount.getValue());
          }

          finally {
          }
      }
    catch (Throwable exception) {
      throw ExceptionUtils.newRuntimeException(exception);
    }     
    finally {
				//connection.close();
      }
    //throw new IllegalArgumentException(database+" connection return a null value");
  }
  
  @Override
  public String toString() {
    final String ID = getID();
    final StringBuilder buffer = new StringBuilder();
    buffer.append("<SQLREQUEST");
    if (StringComparator.isNotNull(ID)) buffer.append(" ID=\"").append(ID).append('"');
    buffer.append("><REQUEST><![CDATA[")
    	.append(request)
    	.append("]]></REQUEST></SQLREQUEST>");
    return buffer.toString();
  }
    
  private String request;
}
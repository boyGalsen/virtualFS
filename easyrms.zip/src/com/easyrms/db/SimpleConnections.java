package com.easyrms.db;

import com.easyrms.util.*;
import com.easyrms.util.ezjmx.*;

import oracle.jdbc.driver.*;

import java.sql.*;
import java.util.*;


public class SimpleConnections {

  static Connection logNullConnection(String name, String description, String url, Connection connection, boolean isSoftDatabase) {
    if (connection == null) {
      try {
        throw new NullPointerException("No Connections ["+url+"]");
      }
      catch (Exception exception) {
        log(name, description, exception, "No Connections", new Object[] { url, });
        if ((isSoftDatabase && isExitOnSoftConnectionError) || (!isSoftDatabase && isExitOnConnectionError)) {
          System.exit(-2);
        }
      }
    }
    return connection;
  }
  
	private static Connection getConnection(String name, String description, String url, boolean isSoftDatabase) {
		try {
      DriverManager.setLoginTimeout(loginTimeOut*1000);
      final Properties connectionProperties = new Properties();
      connectionProperties.put("v$session.program", "WebApp Server "+PropertiesUtil.getString("WebServerName", "Unknown")+" "+EasyRMS.launchDateLabel);
      return getConnection(logNullConnection(name, description, url, DriverManager.getConnection(url, connectionProperties), isSoftDatabase));
		}
		catch (SQLException exception) {
      final int errorCode = exception.getErrorCode();
			log(name, description, exception, "Getting a connection", (Object[])null);
			if (!isSoftDatabase) {
        if (errorCode == 1017) {
          ThreadUtil.sleepSilently(SimplePooledConnections.sleepBeforeAction);
          System.exit(-errorCode);
        }
			}
		}
		return logNullConnection(name, description, url, null, isSoftDatabase);
	}

  static Connection getConnection(Connection connection) throws SQLException {
    if (connection instanceof OracleConnection) return getConnection((OracleConnection)connection);
    connection.setAutoCommit(false);
    if (withRollBack) {
      connection.rollback();
    }
    return connection;
  }
  
  static Connection getConnection(OracleConnection connection) throws SQLException {
    connection.setAutoCommit(false);
    if (withRollBack) {
      connection.rollback();
    }
    if (defaultPrefetchRows >= 0 && SimplePooledConnections.prefetchFlag.booleanValue()) {
      connection.setDefaultRowPrefetch(defaultPrefetchRows);
    }
    return connection;
  }
  
  public static CallableStatement prepareCall(Connection connection, String request) throws SQLException {
    return SimplePooledConnections.prepareCall(connection, request);
  }
  public static PreparedStatement prepareStatement(Connection connection, String request) throws SQLException {
    return SimplePooledConnections.prepareStatement(connection, request);
  }
  public static Statement createStatement(Connection connection) throws SQLException {
    return SimplePooledConnections.createStatement(connection);
  }
  
  public static Connection getConnection(String name, String description, String url, boolean poolAllowed, boolean isSoftDatabase) {
    return poolAllowed ? SimplePooledConnections.getPooledConnection(name, description, url, isSoftDatabase) : getConnection(name, description, url, isSoftDatabase);
  }
  
  static boolean refresh(String url, boolean allConnection) {
    return SimplePooledConnections.refresh(url, allConnection);
  }

	public static void log(EzDBAccess databaseAccess, Throwable exception, String statement, Object... parameters) {
		SimplePooledConnections.log(databaseAccess, exception, statement, parameters);
	}
  
  public static void log(EzDBDatabase databaseAccess, Throwable exception, String statement, Object... parameters) {
    SimplePooledConnections.log(databaseAccess, exception, statement, parameters);
  }
  
  public static void log(String databaseName, String databaseDescription, Throwable exception, String statement, Object... parameters) {
    SimplePooledConnections.log(databaseName, databaseDescription, exception, statement, parameters);
  }
  
	public static Trace trace = SimplePooledConnections.trace;
  static final int loginTimeOut = PropertiesUtil.getInt("com.ezrms.core.db.SimplePooledConnections.LoginTimeOutInSecond", 20000/1000);
  static final int defaultPrefetchRows = PropertiesUtil.getInt("com.ezrms.core.db.SimplePooledConnections.defaultPrefetch", 100);
  private static final boolean withRollBack = EzJDBCDatabase.withRollBack;
  
  private static final boolean isExitOnConnectionError = new EzFlag(
    "Exit On Connection Error", 
    PropertiesUtil.getBoolean("com.ezrms.core.db.SimplePooledConnections.isExitOnConnectionError", true),
    true).booleanValue();
  
  private static final boolean isExitOnSoftConnectionError = new EzFlag(
    "Exit On Soft Connection Error", 
    PropertiesUtil.getBoolean("com.ezrms.core.db.SimplePooledConnections.isExitOnSoftConnectionError", false),
    true).booleanValue();
}
package com.easyrms.db;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.sql.*;


public class SimpleCall extends SimplePooledConnections {

  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object... parameters)
  {
    return commit(transaction, request, parameters, IntArrays.emptyIntArray, ObjectArrays.emptyObjectArray);
  }
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    int[] types, Object[] values)
  {
    return commit(transaction, request, parameters, types, values, true);
  }
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    int[] types, 
    Object[] values,
    boolean withLog)
  {
    return commit(transaction, request, parameters, types, values, withLog, callTimeOutFlag.isActive(), false);
  }
  
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    int[] types, Object[] values,
    boolean withLog,
    boolean isCallTimeOutActive,
    boolean isBlockingRequest)
  {
    try {
      if (call(transaction, request, parameters, types, values, withLog, isCallTimeOutActive, isBlockingRequest)) {
        return transaction.commit();
      }
      transaction.rollback();
    }
    catch (Exception exception) {
      if (withLog) {
        log(transaction, exception, request, parameters);
      }
    }
    return false;
  }
  
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    int[] types, 
    Object[] values,
    int[] positions,
    boolean withLog,
    boolean isBlockingRequest)
  {
    try {
      if (call(transaction, request, parameters, types, values, positions, withLog, isBlockingRequest)) {
        return transaction.commit();
      }
      transaction.rollback();
    }
    catch (Exception exception) {
      if (withLog) {
        log(transaction, exception, request, parameters);
      }
    }
    return false;
  }
  
  public static boolean commit(
    EzJDBCDatabase database,
    String request,
    Object[] parameters,
    int[] types, Object[] values,
    boolean withLog,
    boolean isCallTimeOutActive,
    boolean isBlockingRequest)
  {
    final EzDBTransaction transaction = database.openTransaction();
    try {
      return commit(transaction, request, parameters, types, values, withLog, isCallTimeOutActive, isBlockingRequest);
    }
    finally {
      transaction.close();
    }
  }
  
  public static boolean commit(
    EzJDBCDatabase database,
    String request,
    Object[] parameters,
    int[] types, 
    Object[] values,
    int[] positions,
    boolean withLog,
    boolean isBlockingRequest)
  {
    final EzDBTransaction transaction = database.openTransaction();
    try {
      return commit(transaction, request, parameters, types, values, positions, withLog, isBlockingRequest);
    }
    finally {
      transaction.close();
    }
  }

  public static boolean call(
    EzDBTransaction transaction,
    String request,
    Object... parameters)
  {
    return call(transaction, request, parameters, IntArrays.emptyIntArray, ObjectArrays.emptyObjectArray);
  }
  
  public static boolean call(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    int[] types, 
    Object[] values)
  {
    return call(transaction, request, parameters, types, values, true);
  }
  
  public static boolean call(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    int[] types, 
    Object[] values,
    boolean withLog)
  {
    return call(transaction, request, parameters, types, values, withLog, callTimeOutFlag.isActive(), false);
  }
  
  public static boolean call(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    final int[] types, 
    final Object[] values,
    final boolean isWithLog,
    final boolean isCallTimeOutActive,
    final boolean isBlockingRequest)
  {
    return transaction.call(
      request, 
      new EzDBCallListener() {

        @Override
        public int[] getResultTypes() { 
          return types; 
        }
        
        @Override
        void set(int i, Object object) {
          if (values != null && values.length > i) {
            values[i] = object; 
          }
        }
        
        @Override
        public boolean isBlockingRequest() { 
          return isBlockingRequest; 
        }
        
        @Override
        public boolean isWithLog() { 
          return isWithLog; 
        }
        @Override
        public boolean isWithTimeout() { 
          return isCallTimeOutActive; 
        }
      },
      parameters,
      null,
      null);
  }
  
  /*
  private static boolean internalCall(
    Connection connection,
    String request,
    Object[] parameters,
    int[] types, 
    Object[] values,
    boolean withLog,
    boolean isCallTimeOutActive,
    boolean isBlokingRequest) throws SQLException
  {
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(request, isBlokingRequest, parameters);
    try {
      perfRequest.fireLog();
      final CallableStatement call = prepareCall(connection, request, isCallTimeOutActive);
      try {
        final int typesLength = types.length;
        for (int i = 0; i < typesLength; i++) {
          call.registerOutParameter(i+1, types[i]);
        }
        for (int i = 0, n = parameters.length; i < n; i++) {
          final Object parameter = parameters[i];
          if (parameter == null) {
            call.setNull(i+1+typesLength, Types.VARCHAR);
          }
          else if (parameter instanceof java.util.Date) {
            final long millisecs = ((java.util.Date)parameter).getTime();
            if (millisecs == 0) {
              call.setNull(i+1+typesLength, Types.DATE);
            }
            else {
              call.setTimestamp(i+1+typesLength, new Timestamp(millisecs));
            }
          }
          else if (parameter instanceof Period) {
            call.setObject(i+1+typesLength, ((Period)parameter).getID());
          }
          else {
            call.setObject(i+1+typesLength, parameter);
          }
        }
        perfRequest.fireEndPreparation(call);
        call.executeUpdate();
        perfRequest.fireEndExecution();
        for (int i = 0, n = values.length; i < n; i++) {
          values[i] = call.getObject(i+1);
        }
        perfRequest.fireEnd(values.length, "call");
        return true;
      }
      finally {
        call.close();
      }
    }
    catch (SQLException exception) {
      perfRequest.fireError(exception);
      perfRequest.fireEnd(0, "call");
      if (withLog) log(exception, request, parameters);
      throw exception;
    }
    catch (Exception exception) {
      perfRequest.fireError(exception);
      perfRequest.fireEnd(0, "call");
      if (withLog) log(exception, request, parameters);
      return false;
    }
    finally {
      SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
  }*/
  
  public static boolean call(
		EzDBTransaction connection,
		String request,
		Object[] parameters,
		int[] types,
		Object[] values,
		int[] positions)
	{
		return call(connection, request, parameters, types, values, positions, true);
	}
	
  public static boolean call(
		EzDBTransaction connection,
		String request,
		Object[] parameters,
		int[] types,
		Object[] values,
		int[] positions,
		boolean withLog)
	{
		return call(connection, request, parameters, types, values, positions, withLog, false);
	}
  
  public static boolean call(
    EzDBTransaction connection,
    String request,
    Object[] parameters,
    int[] types,
    Object[] values,
    int[] positions,
    boolean withLog,
    boolean isBlockingRequest)
  {
    return call(connection, request, parameters, types, values, positions, withLog, !isBlockingRequest, isBlockingRequest);
  }
  
  public static boolean call(
    EzDBTransaction connection,
    String request,
    Object[] parameters,
    int[] types,
    Object[] values,
    int[] positions,
    boolean withLog,
    boolean isCallTimeOutActive,
    boolean isBlockingRequest)
  {
    final EzDBDatabase database = connection.getDatabase();
    final EzJDBCPhysicalConnection physicalConnection = connection.asJDBCConnection();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(database.getName(), database.getDescription(), connection.getUID(), physicalConnection.getUID(), isBlockingRequest, true, request, parameters);
		try {
      counter.inc();
      perfRequest.fireLog();
      final CallableStatement call = prepareCall(physicalConnection.getConnection(), request, isCallTimeOutActive);
			try {
        final int typesLength = types.length;
				int currentOut = 0;
				int currentIn = 0;
				for (int pos = 1, maxPos = typesLength + parameters.length; pos <= maxPos; pos++) {
          if (pos == positions[currentOut]) {
					  call.registerOutParameter(pos, types[currentOut++]);
				 	} 
				 	else {
					  if (parameters[currentIn] == null) {
					    call.setNull(pos, Types.VARCHAR);
					  }
					  else if (parameters[currentIn] instanceof DateAccessor) {
              final long millisecs = ((DateAccessor)parameters[currentIn]).getTime();
              if (millisecs == 0) {
                call.setNull(pos, Types.DATE);
              }
              else {
                call.setTimestamp(pos, new Timestamp(millisecs));
              }
            }
            else if (parameters[currentIn] instanceof java.util.Date) {
						  final long millisecs = ((java.util.Date)parameters[currentIn]).getTime();
						  if (millisecs == 0) {
					 	    call.setNull(pos, Types.DATE);
					 	  }
					 	  else {
							  call.setTimestamp(pos, new Timestamp(millisecs));
						  }
					  }
					  else {
						  call.setObject(pos, parameters[currentIn]);
					  }
					  currentIn++;
				  }
				}
				perfRequest.fireEndPreparation(call);
				call.executeUpdate();
				perfRequest.fireEndExecution();
				for (int i = 0, n = positions.length; i < n; i++) {
				  final Object result = call.getObject(positions[i]);
          if (types != null && types.length > i && SQLUtils.isDate(types[i], 0)) {
            if (result instanceof java.util.Date) {
              values[i] = new SimpleDateAccessor((java.util.Date)result);
            }
            else if (result instanceof Timestamp) {
              values[i] = new SimpleDateAccessor(((Timestamp)result).getTime());
            }
            else if (result instanceof Time) {
              values[i] = new SimpleDateAccessor(((Time)result).getTime());
            }
            else {
              values[i] = result;
            }
          }
          else {
            values[i] = result;
          }
				}
				perfRequest.fireEnd(values.length, "call");
				return true;
			}
			finally {
			  call.close();
			}
		}
		catch (Throwable exception) {
		  perfRequest.fireError( exception);
		  perfRequest.fireEnd(0, "call");
			if (withLog) log(connection, exception, request, parameters);
			return false;
		}
		finally {
		  SQLPerfmeter.freeSQLPerfRequest(perfRequest);
		}
	}
  
  public static void throwException(EzDBTransaction connection, String error, Object... parameters) {
    SimpleCall.log(connection, null, error, parameters);
    throw new RuntimeException(error);
  }
  
  private static final Counter counter = new Counter("SQL Simple Call");
}
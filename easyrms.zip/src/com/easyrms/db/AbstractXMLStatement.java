package com.easyrms.db;

import com.easyrms.builder.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.xml.*;

import java.io.*;


public abstract class AbstractXMLStatement implements XMLStatement {

  public String getID() {
    return this.ID;
  }

  public void setID(String ID) {
    this.ID = ID; 
  }
  
  public EzDBConnection getDatabaseConnection() {
    return this.connection;
  } 

  public String getResponse(EzDBConnection connection) {
    return getResponse(connection, false);  
  }
  
  public String getResponse(EzDBConnection connection, boolean exitOnError) {
    if (response == null || !connection.equals(this.connection)) {
      this.connection = connection;
      this.response = buildResponse(connection, exitOnError);
    }    
    return response;
  } 
  
  public void getResponse(Appendable appendable, EzDBConnection connection, boolean exitOnError) throws IOException {
    this.connection = connection;
    buildResponse(appendable , connection, exitOnError);
  } 
  
  public String throwException(String exception) {
    return generate(StampUtil.getStampValue(), new XMLResponse(exception, 0, 0), true);
  }
  
  private void buildResponse(Appendable buffer, EzDBConnection connection, boolean exitOnError) throws IOException {
    final long startExecution = StampUtil.getStampValue();  
    XMLResponse xmlResponse;
    boolean withError = false;
    try {
      xmlResponse = loadResponse(connection);
    }
    catch (Exception exception) {
      if (exitOnError) {
        System.exit(-1);
      }
      withError = true;
      xmlResponse = new XMLResponse(ExceptionUtils.getMessage(exception), 0, 0); 
    }
    generate(buffer, startExecution, xmlResponse, withError);
  }
  
  private void generate(Appendable buffer, long startExecution, XMLResponse xmlResponse, boolean withError) throws IOException {
    buffer.append("<SQLRESPONSE ID=\"")
      .append(StringComparator.NVL(ID))
      .append("\" WITHERROR=\"")
      .append(withError ? "YES" : "NO")
      .append("\" STARTTIME=\"")
      .append(dateFormat.format(new SimpleDateAccessor(startExecution).toDate()))
      .append("\" EXECUTIONDURATION=\"")
      .append(""+(StampUtil.getStampValue() - startExecution))
      .append("\" COLCOUNT=\"").append(IntegerCache.toString(xmlResponse.getColCount()))
      .append("\" ROWCOUNT=\"").append(IntegerCache.toString(xmlResponse.getRowCount())).append("\">\n")
      .append(toString());
      if (withError) {
        buffer.append("<SQLERROR>")
          .append(xmlResponse.getXMLSQLResponse())
          .append("</SQLERROR>");
      }
      else {
        buffer.append(xmlResponse.getXMLSQLResponse());
      }
      buffer.append("</SQLRESPONSE>\n");
  }
  
  private String buildResponse(EzDBConnection connection, boolean exitOnError) {
    final long startExecution = StampUtil.getStampValue();  
    XMLResponse xmlResponse;
    boolean withError = false;
    try {
      xmlResponse = loadResponse(connection);
    }
    catch (Exception exception) {
      if (exitOnError) {
        System.exit(-1);
      }
      withError = true;
      xmlResponse = new XMLResponse(ExceptionUtils.getMessage(exception), 0, 0); 
    }
    return generate(startExecution, xmlResponse, withError);
  }
  
  private String generate(long startExecution, XMLResponse xmlResponse, boolean withError) {
    final StringBuilder buffer = StreamUtils.sqlStringBuilderPool.getNew();
    try {
      buffer.append("<SQLRESPONSE ID=\"")
        .append(StringComparator.NVL(ID))
        .append("\" WITHERROR=\"")
        .append(withError ? "YES" : "NO")
        .append("\" STARTTIME=\"")
        .append(dateFormat.format(new SimpleDateAccessor(startExecution).toDate()))
        .append("\" EXECUTIONDURATION=\"")
        .append(StampUtil.getStampValue() - startExecution)
        .append("\" COLCOUNT=\"").append(xmlResponse.getColCount())
        .append("\" ROWCOUNT=\"").append(xmlResponse.getRowCount()).append("\">\n")
        .append(toString());
      if (withError) {
        buffer.append("<SQLERROR>")
          .append(xmlResponse.getXMLSQLResponse())
          .append("</SQLERROR>");
      }
      else {
        buffer.append(xmlResponse.getXMLSQLResponse());
      }
      buffer.append("</SQLRESPONSE>\n");
      return buffer.toString();
    }
    finally {
      StreamUtils.sqlStringBuilderPool.free(buffer);
    }
  }
    
  protected abstract XMLResponse loadResponse(EzDBConnection connection) throws Exception;
  //protected abstract void generateResponse(Appendable appendable, EzJDBCDatabase database) throws Exception;
  
  protected static class XMLResponse {
    
    public XMLResponse (String response, int colCount, int rowCount) {
      this.XMLSQLResponse = response;
      this.colCount = colCount;
      this.rowCount = rowCount;
    }
    
    public int getColCount() {
      return colCount;
    }

    public int getRowCount() {
      return rowCount;
    }

    public String getXMLSQLResponse() {
      return XMLSQLResponse;
    }
    
    private final int rowCount;
    private final int colCount;
    private final String XMLSQLResponse;
  }
  
  protected void clearResponse() {
    this.response = null;
    this.connection = null;
  }
  
  private String ID;
  private String response;
  private EzDBConnection connection;
  
  protected final DateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
  protected final CDataBuilder cdataFormat = CDataBuilder.referenceClone();
}
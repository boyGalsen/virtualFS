package com.easyrms.db;

import java.io.*;


public interface TSVStatement extends Serializable {

  String getID();
  String getResponse(EzDBConnection connection);
  String getResponse(EzDBConnection connection, boolean exitonerror);
}
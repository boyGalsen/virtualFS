package com.easyrms.db;


import java.io.*;
import java.sql.SQLException;

import com.easyrms.util.SynchronizedSimplePool;

public final class SQLResponseJSONParser {
  
  private static final int maxPOOL = 10;
  private static final SynchronizedSimplePool<SQLResponseXMLHandler> pool = new SynchronizedSimplePool<SQLResponseXMLHandler>(SQLResponseXMLHandler.class, maxPOOL);
	public static final SQLResponseJSONParser reference = new SQLResponseJSONParser();

	public final SimpleResultSet parse(String reader) throws SQLException {
		return parse(new StringReader(reader));
	}
	
	public final SimpleResultSet parse(Reader reader) throws SQLException {
		final SQLResponseXMLHandler handler = getSQLResponseXMLHandler();
		try {
			return handler.getProxyResultSet(reader);
		}
		finally {
			free(handler);
		}
	}
  
	private static synchronized SQLResponseXMLHandler getSQLResponseXMLHandler() {
    return pool.getNew();
	}

	private static synchronized void free(SQLResponseXMLHandler handler) {
    pool.free(handler);
	}
}

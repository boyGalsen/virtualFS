package com.easyrms.db;

public interface EzDBAccess extends AutoCloseable {

  EzDBDatabase getDatabase();
  EzDBConnection getConnection();
  
  void close();
}

package com.easyrms.db;

import java.sql.*;

import com.easyrms.util.*;


public class SimpleModify extends SimplePooledConnections {
  
  @Deprecated
  public static int commit(
    EzDBTransaction connection,
    String request,
    Object... parameters)
  {
    try {
      final int result = modify(connection, request, parameters);
      if (connection.commit()) {
        return result;
      }
    }
    catch (Exception exception) {
			log(connection, exception, request, parameters);
    }
    return -1;
  }

  public static int commit(
    EzDBDatabase database,
    String request,
    Object... parameters)
  {
    final EzDBTransaction transaction = database.openTransaction();
    try {
      final int result = modify(transaction, request, parameters);
      if (transaction.commit()) {
        return result;
      }
    }
    catch (Exception exception) {
      log(database, exception, request, parameters);
    }
    finally {
      transaction.close();
    }
    return -1;
  }

  public static int modify(
    EzDBTransaction connection,
    String request,
    Object... parameters) 
  {
    return modify(connection, request, parameters, null);
  }

  public static int modify(
    EzDBTransaction connection,
    String request,
    Object[] parameters,
    int[] sqlTypes)
  {  
    return modify(connection, request, parameters, sqlTypes, false);
  }
  public static int modify(
    EzDBTransaction connection,
    String request,
    Object[] parameters,
    int[] sqlTypes,
    boolean isCallTimeOutActive)
  {
    final EzDBDatabase database = connection.getDatabase();
    final EzJDBCPhysicalConnection physicalConnection = connection.asJDBCConnection();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(database.getName(), database.getDescription(), connection.getUID(), physicalConnection.getUID(), false, true, request, parameters);
    try {
      counter.inc();
      perfRequest.fireLog();
      final CallableStatement update = prepareCall(physicalConnection.getConnection(), request, isCallTimeOutActive);
      try {
        for (int i = 0, n = parameters.length; i < n; i++) {
          if (parameters[i] == null) {
            update.setNull(i+1, sqlTypes == null ? Types.VARCHAR : sqlTypes[i]);
          }
          else {
            update.setObject(i+1, parameters[i]);
          }
        }
        perfRequest.fireEndPreparation(update);
        final int result = update.executeUpdate();
        perfRequest.fireEndExecution();
        perfRequest.fireEnd(result, "Modify");
        return result;
      }
      finally {
        update.close();
      }
    }
    catch (Throwable exception) {
      perfRequest.fireError(exception);
      perfRequest.fireEnd(0, "Modify");
      log(connection, exception, request, parameters);
      return -1;
    }
    finally {
      SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
  }
  
  private static final Counter counter = new Counter("SQL Simple Modify");
}
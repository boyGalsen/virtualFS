package com.easyrms.db;

import com.easyrms.cache.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.ezjmx.*;

import oracle.jdbc.pool.*;

import java.io.*;
import java.sql.*;
import java.util.*;


public class SimplePooledConnections {

	public static CallableStatement prepareCall(Connection connection, String request) throws SQLException {
		return prepareCall(connection, request, callTimeOutFlag.isActive());
	}
	
  public static CallableStatement prepareCall(Connection connection, String request, boolean isCallTimeOutActive) throws SQLException {
    final CallableStatement call = connection.prepareCall(request);
    call.setQueryTimeout(isCallTimeOutActive ? callTimeOut : 0);
    return call;
  }
    
  public static PreparedStatement prepareStatement(Connection connection, String request) throws SQLException {
    return prepareStatement(connection, request, -1);
  }
  public static PreparedStatement prepareStatement(Connection connection, String request, int prefetch) throws SQLException {
    return prepareStatement(connection, request, prefetch, getDefaultQueryTimeOut());
  }
  public static PreparedStatement prepareStatement(Connection connection, String request, int prefetch, int queryTimeOut) throws SQLException {
    final PreparedStatement query = connection.prepareStatement(request);
    query.setQueryTimeout(queryTimeOut < 0 ? getDefaultQueryTimeOut() : queryTimeOut);
    if (prefetch >= 0 && prefetchFlag.booleanValue()) {
      query.setFetchSize(Math.min(prefetch, maxPrefetchRows));
    }
    return query;
  }
  public static Statement createStatement(Connection connection) throws SQLException {
    return createStatement(connection, -1);
  }
  public static Statement createStatement(Connection connection, int prefetch) throws SQLException {
    return createStatement(connection, prefetch, getDefaultQueryTimeOut());
  }
  public static Statement createStatement(Connection connection, int prefetch, int queryTimeOut) throws SQLException {
    final Statement query = connection.createStatement();
    query.setQueryTimeout(queryTimeOut < 0 ? getDefaultQueryTimeOut() : queryTimeOut);
    if (prefetchFlag.booleanValue()) {
      query.setFetchSize((prefetch >= 0) ? Math.min(prefetch, maxPrefetchRows) : defaultPrefetchRows);
    }
    return query;
  }
  private static int getDefaultQueryTimeOut() {
    return queryTimeOutFlag.booleanValue() ? queryTimeOut : 0;
  }
	
	static final Cache<String, OracleDataSource> ods = Caches.newCacheInstance(new Creator<String, OracleDataSource>() {
    
		public OracleDataSource create(String url) throws SQLException {
			final int hostIndex = url.indexOf('@')+1;
			final int loginIndex = url.lastIndexOf(':', hostIndex)+1;
			final int passwordIndex = url.indexOf('/', loginIndex)+1;
			final String user = url.substring(loginIndex, passwordIndex-1);
			final String password = url.substring(passwordIndex, hostIndex-1);
			//final PoolDataSource pds = PoolDataSourceFactory.getPoolDataSource();
			//pds.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
			final OracleDataSource cache = new OracleDataSource();
			cache.setURL(url);
			cache.setUser(user);
			cache.setPassword(password);
			cache.setConnectionCachingEnabled(true);
			cache.setConnectionCacheName(url);
			cache.setImplicitCachingEnabled(true);
      cache.setLoginTimeout(SimpleConnections.loginTimeOut);
			final Properties properties = new Properties();
			final String webServerName = PropertiesUtil.getString("WebServerName", "Unknown");
			properties.put("v$session.program", "WebApp Server "+webServerName+"-"+EasyRMS.launchDateLabel);
      properties.setProperty("MinLimit", IntegerCache.toString(minLimit));
			properties.setProperty("MaxLimit", IntegerCache.toString(maxLimit));
			//properties.setProperty("InactivityTimeout", IntegerCache.toString(inactivityTimeout));
      //properties.setProperty("AbandonedConnectionTimeout", "900");
      properties.setProperty("MaxStatementsLimit", IntegerCache.toString(maxStatementsLimit));
      //properties.setProperty("PropertyCheckInterval", "60"); // seconds
			cache.setConnectionCacheProperties (properties);
			final OracleConnectionCacheManager oracle = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
			oracle.createCache(url, cache, properties);
			return cache;
		}
	});
  
	private static synchronized void checkCache(String url) throws SQLException {
    final OracleConnectionCacheManager oracle = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
    final int activeConnectionCount = oracle.getNumberOfActiveConnections(url);
    if (trace.isActive()) {
      trace.traceln("Oracle Pool Size:"+activeConnectionCount+" ["+Thread.currentThread().getName()+"]");
    }
    if (activeConnectionCount >= maxLimit-garbageLimit) {
      trace.log("GARBAGE", "Garbage Limit Reached");
      oracle.refreshCache(url, OracleConnectionCacheManager.REFRESH_INVALID_CONNECTIONS);
      EasyRMS.gc("Simple Connection Pool Manager", "activeConnectionCount "+activeConnectionCount+" > "+(maxLimit-garbageLimit));
    }
  }
  static Connection getDataSourceConnection(String name, String description, String url, boolean isSoftDatabase) {
		final OracleDataSource ds = ods.get(url);
		if (ds == null) {
			log(url, null, null, "No Oracle Connection Available");
      SimpleConnections.logNullConnection(name, description, url, null, isSoftDatabase);
      return null;
		}
		try {
			if (trace.isActive() || garbageLimit > 0) {
			  checkCache(url);
			}
      for (int i = 0; i < maxRetry; i++) {
        try {
          final Connection connection = ds.getConnection();
          if (connection != null && !connection.isClosed() && (!isTestValidConnectionNeedJDK6 || connection.isValid(0))) {
            return SimpleConnections.getConnection(connection);
          }
        }
        catch (SQLException exception) {
          final int errorCode = exception.getErrorCode();
          log(url, null, exception, "Getting a connection");
          if (!isSoftDatabase) {
            if (errorCode == 1017) {
              Thread.sleep(sleepBeforeAction);
              System.exit(-errorCode);
            }
          }
        }
        catch (Throwable ignored) {
        }
        checkCache(url);
        Thread.sleep(sleepBeforeAction);
      }
		}
		catch (Throwable ignored) {
      trace.log(ignored);
		}
    return SimpleConnections.logNullConnection(name, description, url, null, isSoftDatabase);
	}
  
  
	protected static Connection getPooledConnection(String name, String description, String url, boolean isSoftDatabase) {
    if (!pool.isActive() || (url != null && !url.startsWith("jdbc:oracle:"))) {
      return SimpleConnections.getConnection(name, description, url, false, isSoftDatabase);
    }
    return getDataSourceConnection(name, description, url, isSoftDatabase);
	}
	public static boolean check(String name, String description, String url, boolean isSoftDatabase) {
		final Connection connection = getPooledConnection(name, description, url, isSoftDatabase);
		if (connection != null) {
			try {
				connection.close();
				return true;
			}
			catch (Throwable e) {
			}
		}
		return false;
	}
	public static boolean refresh(String url, boolean allConnections) {
		try {
			final OracleConnectionCacheManager oracle = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
			oracle.refreshCache(url, allConnections ? OracleConnectionCacheManager.REFRESH_ALL_CONNECTIONS : OracleConnectionCacheManager.REFRESH_INVALID_CONNECTIONS);
      return true;
		}
		catch (SQLException ignored) {
			log(url, null, ignored, "refresh", ObjectArrays.emptyObjectArray);
      return false;
		}
	}
	public static void clear(String url) {
		try {
			final OracleConnectionCacheManager oracle = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
			oracle.purgeCache(url, true);
		}
		catch (SQLException ignored) {
			log(url, null, ignored, "clear", ObjectArrays.emptyObjectArray);
		}
	}

  public static void log(EzDBAccess databaseAccess, Throwable exception, String statement, Object... parameters) {
    log((databaseAccess == null) ? null : databaseAccess.getDatabase(), exception, statement, parameters);
  }
  
	public static void log(EzDBDatabase database, Throwable exception, String statement, Object... parameters) {
    log((database == null) ? null : database.getName(), (database == null) ? null : database.getDescription(), exception, statement, parameters);
  }

  @Deprecated
  public static void log(Throwable exception, String statement, Object... parameters) {
    log(null, null, exception, statement, parameters);
  }

  public static void log(String databaseName, String databaseDescription, Throwable exception, String statement, Object... parameters) {
    final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
		final StringBuilder buffer = bufferPool.get();
		try {
			buffer.append(" [");
			if (parameters != null && parameters.length >= 1) {
				buffer.append(parameters[0]);
				for (int i = 1, n = parameters.length; i < n; i++) {
					buffer.append(',');
					if (parameters[i] != null) buffer.append(parameters[i]);
				}
			}
			buffer.append(']');
      String s = null;
      if (exception != null) {
        final StringWriter w = StreamUtils.openStringWriter();
        try {
          exception.printStackTrace(new PrintWriter(w));
          s = w.toString();
        }
        finally {
          StreamUtils.close(w);
        }
      }
			int index = 0;
			if (s != null) {
				for (int i = 0; i < 5; i++) {
					index = s.indexOf(index, '\n');
					if (index < 0) break;
				}
				if (index > 0) s = s.substring(0, index);
			}
			trace.log(
        (databaseName == null && databaseDescription == null
          ? ""
          : "(On "+StringComparator.NVL(databaseName, "???")+(StringComparator.isNotNull(databaseDescription) ? "-"+databaseDescription : "")+")")
 				 +(exception == null ? "" : exception.toString())
				 +(statement == null ? "" : (": "+statement+buffer.toString()))+'\n'+StringComparator.NVL(s),
        true);
		}
		finally {
		  bufferPool.free(buffer);
		}
	}
	
  public static final Trace trace = EzJDBCDatabase.trace;
  public static final EzFlag pool = EzJDBCDatabase.pool;
  public static final EzFlag callTimeOutFlag = EzJDBCDatabase.callTimeOutFlag;
  public static final EzFlag queryTimeOutFlag = EzJDBCDatabase.queryTimeOutFlag; 
  public static final EzFlag prefetchFlag = EzJDBCDatabase.prefetchFlag;
  
  public static final int defaultPrefetchRows = PropertiesUtil.getInt("com.ezrms.core.db.SimplePooledConnections.defaultPrefetch", 10);
  public static final int maxPrefetchRows = PropertiesUtil.getInt("com.ezrms.core.db.SimplePooledConnections.maxPrefetch", 100);
  public static final int sleepBeforeAction = PropertiesUtil.getInt("com.ezrms.core.db.SimplePooledConnections.userErrorSleepTime", 0)*1000;
  public static final int maxRetry = PropertiesUtil.getInt("com.ezrms.core.db.SimplePooledConnections.maxRetry", 2);
  public static final boolean isTestValidConnectionNeedJDK6 = PropertiesUtil.getBoolean("com.ezrms.core.db.SimplePooledConnections.isTestValidConnectionNeedJDK6", true);
  
  private static final int minLimit = EzJDBCDatabase.minLimit;
  private static final int maxLimit = EzJDBCDatabase.maxLimit;
  private static final int maxStatementsLimit = EzJDBCDatabase.maxStatementsLimit;
  private static final int garbageLimit = EzJDBCDatabase.garbageLimit;
//  private static final int inactivityTimeout = EzJDBCDatabase.inactivityTimeout;
  private static final int queryTimeOut = EzJDBCDatabase.queryTimeOut;
  private static final int callTimeOut = EzJDBCDatabase.callTimeOut;
}
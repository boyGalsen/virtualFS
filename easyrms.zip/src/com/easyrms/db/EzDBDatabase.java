package com.easyrms.db;

import com.easyrms.builder.*;
import com.easyrms.builder.FieldPosition;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.util.*;


public interface EzDBDatabase {
  
  String getName();
  String getDescription();
  boolean isSoftDatabase();
  
  EzDBAccess openAccess();
  EzDBTransaction openTransaction();
  EzArray<? extends EzDBDatabase> asArray();
  
  boolean refresh(boolean refreshAllConnection);
  
  EzDBDatabasePoolStatus getPoolStatus();
  
  interface EzDBDatabasePoolStatus {
    
    boolean isPooled();
    
    int getNumberOfActiveConnections();
    int getNumberOfAvailableConnections();
  }
  
  final Builder nameDescriptionFormat = new AbstractBuilder() {

    @Override
    public StringBuilder format(Object obj, StringBuilder toAppendTo, FieldPosition pos) {
      if (obj instanceof EzDBDatabase) {
        final EzDBDatabase database = (EzDBDatabase)obj;
        return toAppendTo.append(StringUtil.firstCharUpperCase(database.getName())).append("-").append(StringUtil.firstCharUpperCase(database.getDescription()));
      }
      return toAppendTo;
    }
    
  };
  
  final EzDBDatabasePoolStatus noDatabaseEzDBDatabasePoolStatus = new EzDBDatabasePoolStatus() {

    public boolean isPooled() { 
      return false; 
    }
    
    public int getNumberOfActiveConnections() { 
      return 0; 
    }
    public int getNumberOfAvailableConnections() {
      return 0; 
    }    
  };
  
  final Comparator<EzDBDatabase> ezDBDatabaseNameComparator = new Comparator<EzDBDatabase>() {

    public int compare(EzDBDatabase o1, EzDBDatabase o2) {
      return StringComparator.compare(o1.getName().toLowerCase(), o2.getName().toLowerCase());
    }    
  };
}
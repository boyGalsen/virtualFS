package com.easyrms.db;

import com.easyrms.cache.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.executor.*;
import com.easyrms.util.preferences.*;

import java.sql.*;
import java.util.*;


public class SimpleRequest extends SimplePooledConnections {
  
  public static boolean query(
    EzDBConnection connection,
    String request,
    Object[] parameters,
    EzDBResultSetListener listener)
  {
    return connection.query(request, listener, parameters);
  }
  public static boolean query(
    EzDBDatabase database,
    String request,
    Object[] parameters,
    EzDBResultSetListener listener)
  {
    final EzDBAccess access = database.openAccess();
    try {
      return query(
        access.getConnection(),
        request, 
        parameters, 
        listener);
    }
    finally {
      access.close();
    }
  }
  
  public static boolean query(int updateCount, ResultSet resultSet, EzDBResultSetListener listener) {
    try {
      listener.setUpdateCount(updateCount);
      listener.process(resultSet);
      try { 
        if (listener.checkWarning()) { 
          listener.setWarning(resultSet.getWarnings()); 
        } 
      } 
      catch (Throwable ignoredWarnings) {           
      }
      return true;
    }
    catch (Throwable ignored) {
      trace.log(ignored);
      return false;
    } 
  }
  
  
  public static abstract class ObjectListener extends EzDBResultSetListener {

    public ObjectListener() {
      super();
    }
    public ObjectListener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public ObjectListener(String request, Object... parameters) {
      super(request, parameters);
    }
    public ObjectListener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
	    	set(i, SQLUtils.getObject(v, 1));
	  	}
	  	catch (Exception exception) {
	  		throw new SQLException(exception);
	  	}
    }
    public abstract void set(int i, Object v) throws Exception;
  }
  public static abstract class StringListener extends EzDBResultSetListener {

    public StringListener() {
      super();
    }
    public StringListener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public StringListener(String request, Object... parameters) {
      super(request, parameters);
    }
    public StringListener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getString(v, 1));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, String v) throws Exception;
  }
  public static abstract class IntStringListener extends EzDBResultSetListener {

    public IntStringListener() {
      super();
    }
    public IntStringListener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public IntStringListener(String request, Object... parameters) {
      super(request, parameters);
    }
    public IntStringListener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getInt(v, 1), SQLUtils.getString(v, 2));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, int v1, String v2) throws Exception;
  }
  public static abstract class Int1Listener extends EzDBResultSetListener {

    public Int1Listener() {
      super();
    }
    public Int1Listener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public Int1Listener(String request, Object... parameters) {
      super(request, parameters);
    }
    public Int1Listener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getInt(v, 1));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, int v) throws Exception;
  }
  public static abstract class Int2Listener extends EzDBResultSetListener {

    public Int2Listener() {
      super();
    }
    public Int2Listener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public Int2Listener(String request, Object... parameters) {
      super(request, parameters);
    }
    public Int2Listener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getInt(v, 1), SQLUtils.getInt(v, 2));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, int v1, int v2) throws Exception;
  }
  public static abstract class Int3Listener extends EzDBResultSetListener {

    public Int3Listener() {
      super();
    }
    public Int3Listener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public Int3Listener(String request, Object... parameters) {
      super(request, parameters);
    }
    public Int3Listener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getInt(v, 1), SQLUtils.getInt(v, 2), SQLUtils.getInt(v, 3));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, int v1, int v2, int v3) throws Exception;
  }
  public static abstract class Int4Listener extends EzDBResultSetListener {

    public Int4Listener() {
      super();
    }
    public Int4Listener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public Int4Listener(String request, Object... parameters) {
      super(request, parameters);
    }
    public Int4Listener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getInt(v, 1), SQLUtils.getInt(v, 2), SQLUtils.getInt(v, 3), SQLUtils.getInt(v, 4));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, int v1, int v2, int v3, int v4) throws Exception;
  }
  public static abstract class Int5Listener extends EzDBResultSetListener {

    public Int5Listener() {
      super();
    }
    public Int5Listener(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public Int5Listener(String request, Object... parameters) {
      super(request, parameters);
    }
    public Int5Listener(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
    	try {
    		set(i, SQLUtils.getInt(v, 1), SQLUtils.getInt(v, 2), SQLUtils.getInt(v, 3), SQLUtils.getInt(v, 4), SQLUtils.getInt(v, 5));
    	}
    	catch (Exception exception) {
    		throw new SQLException(exception);
    	}
    }
    public abstract void set(int i, int v1, int v2, int v3, int v4, int v5) throws Exception;
  }


  public static class ObjectReader extends ObjectListener {

    public ObjectReader() {
      super();
    }
    public ObjectReader(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public ObjectReader(String request, Object... parameters) {
      super(request, parameters);
    }
    public ObjectReader(String request) {
      super(request);
    }

    @Override
    public void set(int i, Object v) {
      objects.add(v);
    }

    public String[] getStrings() { check(); return StringArrays.valueOf(objects); }
		public int[] getInts() { check();  return IntArrays.valueOf(objects); }
		public double[] getDoubles() { check();  return DoubleArrays.valueOf(objects); }
		public DateAccessor[] getDate() { check();  return objects.toArray(new DateAccessor[objects.size()]); }
		public Timestamp[] getTimeStamp() { check();  return objects.toArray(new Timestamp[objects.size()]); }
		public Time[] getTime() { check();  return objects.toArray(new Time[objects.size()]); }
    public Object[] getObjects() { check();  return objects.toArray(); }
    public Object getFirstObject() { check();  return objects.get(0); }

    private void check() {
      if (getException() != null) {
        throw ExceptionUtils.newRuntimeException(getException());
      }
    }
    private ArrayList<Object> objects = new ArrayList<Object>();
  }

  private static <T extends EzDBResultSetListener> T getReader(EzDBConnection connection, String request, Object[] parameters, T reader) {
    if (!query(connection, request, parameters, reader)) {
      reader.setException(new SQLException());
    }
    return reader;
  }

  public static class TimeStampReader extends EzDBResultSetListener {

    public TimeStampReader() {
      super();
    }
    public TimeStampReader(String request, boolean isCopyNeeeded, Object... parameters) {
      super(request, isCopyNeeeded, parameters);
    }
    public TimeStampReader(String request, Object... parameters) {
      super(request, parameters);
    }
    public TimeStampReader(String request) {
      super(request);
    }

    @Override
    public final void set(int i, ResultSet v) throws SQLException {
      try {
        objects.add(SQLUtils.getDate(v, 1, null));
      }
      catch (Exception exception) {
        throw new SQLException(exception);
      }
    }

    public DateAccessor[] getJavaTimeStamp() { 
      return objects.toArray(new DateAccessor[objects.size()]); 
    }
    public Timestamp[] getTimeStamp() {
      final DateAccessor[] javaDate = getJavaTimeStamp(); 
      final Timestamp[] timeStamps = new Timestamp[javaDate.length];
      for (int i = 0, n = javaDate.length; i < n ; i++) {
        final DateAccessor javaDateI = javaDate[i];
        timeStamps[i] = (javaDateI == null) ? null : new Timestamp(javaDateI.getTime());
      }
      return timeStamps; 
    }

    private ArrayList<DateAccessor> objects = new ArrayList<DateAccessor>();
  }

  public static EzDate querySingleEzDate(EzDBDatabase database, String request, Object... parameters) {
    final EzDBAccess access = database.openAccess();
    try {
      return querySingleEzDate(access.getConnection(), request, parameters, null);
    }
    finally {
      access.close();
    }
  }
  public static EzDate querySingleEzDate(EzDBConnection connection, String request, Object[] parameters) {
    return querySingleEzDate(connection, request, parameters, null);
  }
  public static EzDate querySingleEzDate(EzDBConnection connection, String request, Object[] parameters, EzDate defaultValue) {
    final int date = querySingleInt(connection, request, parameters);
    return (date <= 0) ? defaultValue : EzDate.valueOf(date);
  }
  
  public static EzDate[] queryEzDate(EzDBConnection connection, String request, Object[] parameters) {
    final int[] days = getReader(connection, request, parameters, new ObjectReader()).getInts();
    if (days == null) {
      return null;
    }
    final int dayCount = days.length;
    if (dayCount == 0) {
      return EzDate.noEzDates;
    }
    final EzDate[] dates = new EzDate[dayCount];
    for (int i = 0; i < dayCount; i++) {
      dates[i] = EzDate.valueOf(days[i]);
    }
    return dates;
  }
  
	public static DateAccessor querySingleJavaDate(EzDBConnection connection, String request, Object[] parameters) {
		return querySingleJavaDate(connection, request, parameters, null);
	}

	public static DateAccessor querySingleJavaDate(EzDBConnection connection, String request, Object[] parameters, DateAccessor defaultValue) {
		final DateAccessor date = querySingleDate(connection, request, parameters, null);
		return (date == null ) ? defaultValue : new SimpleDateAccessor(date.getTime());
	}

	public static DateAccessor querySingleJavaTime(EzDBConnection connection, String request, Object[] parameters) {
		return querySingleJavaTime(connection, request, parameters, null);
	}

	public static DateAccessor querySingleJavaTime(EzDBConnection connection, String request, Object[] parameters, DateAccessor defaultValue) {
		final Time time = querySingleTime(connection, request, parameters, null);
		return (time == null ) ? defaultValue : new SimpleDateAccessor(time.getTime());
	}

	public static DateAccessor querySingleJavaTimestamp(EzDBConnection connection, String request, Object[] parameters) {
    return querySingleJavaTimestamp(connection, request, parameters, null);
  }

	public static DateAccessor querySingleDate(EzDBConnection connection, String request, Object[] parameters) {
		return querySingleDate(connection, request, parameters, null);
	}
  
	public static DateAccessor querySingleDate(EzDBConnection connection, String request, Object[] parameters, DateAccessor defaultValue) {
		final DateAccessor[] dates = queryDate(connection, request, parameters);
		return (dates != null && dates.length == 1) ? dates[0] : defaultValue;
	}

	public static java.sql.Time querySingleTime(EzDBConnection connection, String request, Object[] parameters) {
		return querySingleTime(connection, request, parameters, null);
	}
  
	public static java.sql.Time querySingleTime(EzDBConnection connection, String request, Object[] parameters, java.sql.Time defaultValue) {
		final java.sql.Time[] dates = queryTime(connection, request, parameters);
		return (dates != null && dates.length == 1) ? dates[0] : defaultValue;
	}
  
  public static java.sql.Timestamp querySingleTimestamp(EzDBConnection connection, String request, Object[] parameters, java.sql.Timestamp defaultValue) {
    final java.sql.Timestamp[] dates = queryTimestamp(connection, request, parameters);
    return (dates != null && dates.length == 1) ? dates[0] : defaultValue;
  }
  
  public static DateAccessor querySingleJavaTimestamp(EzDBConnection connection, String request, Object[] parameters, DateAccessor defaultValue) {
    final DateAccessor[] dates = queryJavaTimestamp(connection, request, parameters);
    return (dates != null && dates.length == 1) ? dates[0] : defaultValue;
  }
  
  
  public static String querySingleString(EzDBConnection connection, String request, Object... parameters) {
    final String[] strings = queryString(connection, request, parameters);
    return (strings != null && strings.length == 1)
      ? strings[0]
      : null;
  }
  public static String querySingleString(EzDBConnection connection, String request, Object[] parameters, String defaultValue) {
    final String[] strings = queryString(connection, request, parameters);
    return (strings != null && strings.length == 1)
      ? strings[0]
      : defaultValue;
  }
 
	public static DateAccessor[] queryDate(EzDBConnection connection, String request, Object... parameters) {
		return getReader(connection, request, parameters, new ObjectReader()).getDate();
	}

	public static java.sql.Time[] queryTime(EzDBConnection connection, String request, Object... parameters) {
	  return getReader(connection, request, parameters, new ObjectReader()).getTime();
	}

	public static Timestamp[] queryTimestamp(EzDBConnection connection, String request, Object[] parameters) {
	  return getReader(connection, request, parameters, new TimeStampReader()).getTimeStamp();
  }
  
  public static DateAccessor[] queryJavaTimestamp(EzDBConnection connection, String request, Object[] parameters) {
    return getReader(connection, request, parameters, new TimeStampReader()).getJavaTimeStamp();
  }

  /**
   * Return 1 Column Data For Several Row Response. 
   */
  public static String[] queryString(EzDBConnection connection, String request, Object... parameters) {
    return getReader(connection, request, parameters, new ObjectReader()).getStrings();
  }

  public static String[] queryString(EzArray<? extends EzDBDatabase> databases, final String request, final Object... parameters) {final int n = databases.getCount();
    final EzArrayListThreadPool pool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<String[]> results = pool.get();
    final EzArrayList<String> strings = pool.get();
    try {
      EzPoolExecutor.DEFAULT.call(
        new EzCallableTaskArray<String[]>("Get Strings From Several Databases", n) {
  
          @Override
          public String description(int i) {
            return "Get Dates From DB="+databases.get(i)+"#"+i;
          }
  
          @Override
          public void fillContext(int i, EzTaskContext context) {
          }        
  
          @Override
          public String[] call(int i) {
            try (final EzDBAccess access = databases.get(i).openAccess()) {
              return queryString(access.getConnection(), request, parameters);
            }
          }
        }, 
        results);
      for (int i = 0; i < n; i++) {
        final String[] resultsI = results.get(i);
        for (int j = 0, m = resultsI.length; j < m; j++) {
          strings.add(resultsI[j]);
        }
      }
      return strings.toArray(new String[strings.getCount()]);
    }
    finally {
      pool.free(strings);
      pool.free(results);
    }
  }


  public static boolean queryCheck(EzDBConnection connection, String request, Object... parameters) {
    final String[] tests = queryString(connection, request, parameters);
    return (tests != null && tests.length == 1 
      && ("Y".equals(tests[0]) || "1".equals(tests[0]) || "T".equals(tests[0]) || "t".equals(tests[0]) || "y".equals(tests[0])));
  }
  public static boolean queryCheck(EzDBDatabase database, String request, Object... parameters) {
    final EzDBAccess access = database.openAccess();
    try {
      return queryCheck(access.getConnection(), request, parameters);
    }
    finally {
      access.close();
    }
  }
 
  public interface ResultSetCreator<T> {

    T create(ResultSet v) throws SQLException;
  }
  
  public static <T> T queryObject(EzDBConnection connection, String request, Object[] parameters, final ResultSetCreator<T> creator) {
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<T> objects = arrayPool.get();
    try {
      if (connection.query(request, new EzDBResultSetListener() {
  
          @Override
          public void set(int i, ResultSet v) throws SQLException {
            final T o = creator.create(v);
            if (o != null) {
              objects.add(o);
            }
          }
        },
        parameters))
      {
        return (objects.size() == 1) ? objects.get(0) : null;
      }
    }
    finally {
      arrayPool.free(objects);
    }
    throw ExceptionUtils.newRuntimeException("QueryObject Error ("+request+"["+parameters+"])");
  }
  public static <T> T queryObjectNoError(EzDBConnection connection, String request, Object[] parameters, final ResultSetCreator<T> creator) {
    try {
      return queryObjectNoError(connection, request, parameters, creator);
    }
    catch (Throwable ignored) {
    }
    return null;
  }
  public static <T> EzArray<T> queryObjects(EzDBConnection connection, String request, Object[] parameters, final ResultSetCreator<T> creator) {
    final EzArrayList<T> objects = new EzArrayList<T>();
    if (connection.query(request, new EzDBResultSetListener() {

        @Override
        public void set(int i, ResultSet v) throws SQLException {
          final T o = creator.create(v);
          if (o != null) {
            objects.add(o);
          }
        }
      },
      parameters))
    {
      return objects;
    }
    throw ExceptionUtils.newRuntimeException("QueryObjects Error");
  }
  
  public static <T> T[] queryObjects(EzDBConnection connection, String request, Object[] parameters, final ResultSetCreator<T> creator, T[] array) {
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<T> objects = arrayPool.get();
    try {
      if (connection.query(request, new EzDBResultSetListener() {
    
          @Override
          public void set(int i, ResultSet v) throws SQLException {
            final T o = creator.create(v);
            if (o != null) {
              objects.add(o);
            }
          }
        },
        parameters))
      {
        return objects.toArray(array);
      }
    }
    finally {
      arrayPool.free(objects);
    }
    throw ExceptionUtils.newRuntimeException("QueryObjects Error");
  }
  
  public static Object queryFirstObject(EzDBConnection connection, String request, Object... parameters) {
    return getReader(connection, request, parameters, new ObjectReader()).getFirstObject();
  }
  
  public static int querySingleInt(EzDBConnection connection, String request, Object[] parameters) {
    final int[] ints = queryInt(connection, request, parameters);
    return (ints != null && ints.length == 1)
      ? ints[0]
      : 0;
  }
  public static int querySingleInt(EzDBConnection connection, String request, Object[] parameters, int defaultValue) {
    final int[] ints = queryInt(connection, request, parameters);
    return (ints != null && ints.length == 1)
      ? ints[0]
      : defaultValue;
  } 

  public static int[] queryInt(EzDBConnection connection, String request, Object[] parameters) {
    return getReader(connection, request, parameters, new ObjectReader()).getInts();
  }
  
  public static double querySingleDouble(EzDBConnection connection, String request, Object[] parameters) {
		final double[] doubles = queryDouble(connection, request, parameters);
		return (doubles != null && doubles.length == 1)
			? doubles[0]
			: 0;
	}
	
  public static double querySingleDouble(EzDBConnection connection, String request, Object[] parameters, double defaultValue) {
    final double[] doubles = queryDouble(connection, request, parameters);
    return (doubles != null && doubles.length == 1)
      ? doubles[0]
      : defaultValue;
  } 

  public static double[] queryDouble(EzDBConnection connection, String request, Object[] parameters) {
    return getReader(connection, request, parameters, new ObjectReader()).getDoubles();
  }
  
  public static class SingleInt2Reader extends EzDBResultSetListener {

    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (i == 0) {
        final ResultSetMetaData meta = v.getMetaData();
        width = meta.getColumnCount();
        data = new ArrayList<int[]>();
      }
      final int[] array = new int[width];
      for (int j = 0; j < width; j++) {
        array[j] = SQLUtils.getInt(v, j+1);
      }
      data.add(array);
    }

    public int[] getResult() {
      if (data == null) {
        return IntArrays.emptyIntArray;
      }
      final int n = data.size();
      if (width > 1) {
        return (n <= 1) ? data.get(0) : null;
      }
      final int[] results = new int[n];
      for (int i = 0; i < n; i++) {
        final int[] array = data.get(i);
        results[i] = array[0];
      }
      return results;
    }

    private int width;
    private ArrayList<int[]> data;
  }

  public static int[] querySingleInt2(EzDBConnection connection, String request, Object... parameters) {
    return getReader(connection, request, parameters, new SingleInt2Reader()).getResult();
  }
  
  public static class SingleLong2Reader extends EzDBResultSetListener {

    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (i == 0) {
        final ResultSetMetaData meta = v.getMetaData();
        width = meta.getColumnCount();
        data = new ArrayList<long[]>();
      }
      final long[] array = new long[width];
      for (int j = 0; j < width; j++) {
        array[j] = SQLUtils.getLong(v, j+1);
      }
      data.add(array);
    }

    public long[] getResult() {
      if (data == null) {
        return IntArrays.emptyLongArray;
      }
      final int n = data.size();
      if (width > 1) {
        return (n <= 1) ? data.get(0) : null;
      }
      final long[] results = new long[n];
      for (int i = 0; i < n; i++) {
        final long[] array = data.get(i);
        results[i] = array[0];
      }
      return results;
    }

    private int width;
    private ArrayList<long[]> data;
  }
  
  public static long[] querySingleLong2(EzDBConnection connection, String request, Object... parameters) {
    return getReader(connection, request, parameters, new SingleLong2Reader()).getResult();
  }
  
  public static class Int2Reader extends EzDBResultSetListener {

    @Override
    public void init(ResultSet v) throws SQLException {
      super.init(v);
      final ResultSetMetaData meta = v.getMetaData();
      width = meta.getColumnCount();
    }

    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (i == 0) {
        data = new ArrayList<int[]>();
      }
      final int[] array = new int[width];
      for (int j = 0; j < width; j++) {
        array[j] = v.getInt(j+1);
      }
      data.add(array);
    }

    public int[][] getResult() {
      if (data == null) {
        return new int[width][0];
      }
      final int n = data.size();
      final int[][] results = new int[width][n];
      for (int i = 0; i < n; i++) {
        final int[] array = data.get(i);
        for (int j = 0; j < width; j++) {
          results[j][i] = array[j];
        }
      }
      return results;
    }

    private int width;
    private ArrayList<int[]> data;
  }  
  
  public static int[][] queryInt2(EzDBConnection connection, String request, Object[] parameters) {
    return getReader(connection, request, parameters, new Int2Reader()).getResult();
  }

  public static class SingleString2Reader extends EzDBResultSetListener {

    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (i == 0) {
        final ResultSetMetaData meta = v.getMetaData();
        width = meta.getColumnCount();
        data = new ArrayList<String[]>();
      }
      final String[] array = new String[width];
      for (int j = 0; j < width; j++) {
        array[j] = SQLUtils.getString(v, j+1);
      }
      data.add(array);
    }

    public String[] getResult() {
      if (data == null) {
        return StringArrays.emptyStringArray;
      }
      final int n = data.size();
      if (width > 1) {
        return (n <= 1) ? data.get(0) : null;
      }
      final String[] results = new String[n];
      for (int i = 0; i < n; i++) {
        final String[] array = data.get(i);
        results[i] = array[0];
      }
      return results;
    }

    private int width;
    private ArrayList<String[]> data;
  }

  /**
   * Return Several Columns Data For a 1 Row Length Response. 
   */
  public static String[] querySingleString2(EzDBConnection connection, String request, Object... parameters) {
    return getReader(connection, request, parameters, new SingleString2Reader()).getResult();
  }
  
  public static class String2Reader extends EzDBResultSetListener {

    @Override
    public void init(ResultSet v) throws SQLException {
      super.init(v);
      final ResultSetMetaData meta = v.getMetaData();
      width = meta.getColumnCount();
    }

    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (i == 0) {
        data = new ArrayList<String[]>();
      }
      final String[] array = new String[width];
      for (int j = 0; j < width; j++) {
        array[j] = SQLUtils.getString(v, j+1);
      }
      data.add(array);
    }

    public String[][] getResult() {
      if (data == null) {
        return new String[width][0];
      }
      final int n = data.size();
      final String[][] results = new String[width][n];
      for (int i = 0; i < n; i++) {
        final String[] array = data.get(i);
        for (int j = 0; j < width; j++) {
          results[j][i] = array[j];
        }
      }
      return results;
    }

    private int width;
    private ArrayList<String[]> data;
  }

  public static String[][] queryString2(EzDBConnection connection, String request, Object... parameters) {
    return getReader(connection, request, parameters, new String2Reader()).getResult();
  }
  
  public static class PropertiesReader extends EzDBResultSetListener {

    public PropertiesReader() {
    }
    public PropertiesReader(Properties properties) {
      this.properties = properties;
    }
    
    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (i == 0 && properties == null) {
        properties = new Properties();
      }
      final String property = SQLUtils.getString(v, 1); 
      final String value = SQLUtils.getString(v, 2);
      properties.put(property, StringComparator.NVL(value));
    }

    public Properties getResult() {
      return (properties == null) ? new Properties() : properties;
    }

    private Properties properties;
  }
  
  
  public static class PreferencesReader extends EzDBResultSetListener {

    public PreferencesReader() {}
    
    @Override
    public void init(ResultSet v) throws SQLException {
      super.init(v);
    }

    @Override
    public void set(int i, ResultSet v) throws SQLException {
      if (preferences == null) preferences = new SimplePreferences();
      preferences.setAndSavePreference(SQLUtils.getString(v, 1), SQLUtils.getString(v, 2, ""));
    }

    public Preferences getResult() {
      return (preferences == null) ? NoPreferences.noPreferences : preferences;
    }

    private SimplePreferences preferences;
  }


  public static Properties queryProperties(EzDBConnection connection, String request, Object[] parameters) {
    return getReader(connection, request, parameters, new PropertiesReader()).getResult();
  }

  public static Preferences queryPreferences(EzDBConnection connection, String request, Object[] parameters) {
    return getReader(connection, request, parameters, new PreferencesReader()).getResult();
  }
  
  public static String getOracleVersion(EzDBDatabase database) {
    return oracleVersions.get(database);
  }
  
  private static final Cache<EzDBDatabase, String> oracleVersions = Caches.newCacheInstance(new Creator<EzDBDatabase, String>() {

    public String create(EzDBDatabase database) throws Exception {
      final EzDBAccess access = database.openAccess();
      try {
        return SimpleRequest.querySingleString(
          access.getConnection(), 
          "select version from v$instance where rownum<=1", 
          ObjectArrays.emptyObjectArray);
      }
      finally {
        access.close();
      }
    }
  });
}
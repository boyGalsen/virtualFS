package com.easyrms.db;


public interface EzDBConnection {

  boolean query(String request, EzDBResultSetListener listener, Object... parameters);

  String getUID();
  
  @Deprecated
  EzJDBCPhysicalConnection asJDBCConnection(); 
}

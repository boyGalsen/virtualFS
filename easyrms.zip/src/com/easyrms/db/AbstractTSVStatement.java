package com.easyrms.db;

import com.easyrms.builder.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.xml.*;

import java.io.*;


public abstract class AbstractTSVStatement implements TSVStatement {

  public String getID() {
    return this.ID;
  }

  public void setID(String ID) {
    this.ID = ID; 
  }
  
  public EzDBConnection getDatabaseConnection() {
    return this.connection;
  } 

  public String getResponse(EzDBConnection connection) {
    return getResponse(connection, false);  
  }
  
  public String getResponse(EzDBConnection connection, boolean exitOnError) {
    if (response == null || !connection.equals(this.connection)) {
      this.connection = connection;
      this.response = buildResponse(connection, exitOnError);
    }    
    return response;
  } 
  
  public void getResponse(Appendable appendable, EzDBConnection connection, boolean exitOnError) throws IOException {
    this.connection = connection;
    buildResponse(appendable , connection, exitOnError);
  } 
  
  public String throwException(String exception) {
    return generate(StampUtil.getStampValue(), new TSVResponse(exception, 0, 0), true);
  }
  
  private void buildResponse(Appendable buffer, EzDBConnection connection, boolean exitOnError) throws IOException {
    final long startExecution = StampUtil.getStampValue();  
    TSVResponse xmlResponse;
    boolean withError = false;
    try {
      xmlResponse = loadResponse(connection);
    }
    catch (Exception exception) {
      if (exitOnError) {
        System.exit(-1);
      }
      withError = true;
      xmlResponse = new TSVResponse(ExceptionUtils.getMessage(exception), 0, 0); 
    }
    generate(buffer, startExecution, xmlResponse, withError);
  }
  
  private void generate(Appendable buffer, long startExecution, TSVResponse xmlResponse, boolean withError) throws IOException {
    buffer.append("~.~.~.~.~.Header Start~.~.~.~.~.\r\n")
      .append("ID\t").append(StringComparator.NVL(ID)).append("\r\n")
      .append("WITHERROR\t").append(withError ? "YES" : "NO").append("\r\n")
      .append("STARTTIME\t").append(dateFormat.format(new SimpleDateAccessor(startExecution).toDate())).append("\r\n")
      .append("EXECUTIONDURATION\t").append(""+(StampUtil.getStampValue() - startExecution)).append("\r\n")
      .append("COLCOUNT\t").append(IntegerCache.toString(xmlResponse.getColCount())).append("\r\n")
      .append("ROWCOUNT\t").append(IntegerCache.toString(xmlResponse.getRowCount())).append("\r\n")
      .append("~.~.~.~.~.Header End~.~.~.~.~.\r\n")
      .append(toString());
      if (withError) {
        buffer.append("~.~.~.~.~.Error Start~.~.~.~.~.\r\n")
          .append(encodeText(xmlResponse.getTSVSQLResponse()))
          .append("~.~.~.~.~.Error End~.~.~.~.~.\r\n");
      }
      else {
        buffer.append(xmlResponse.getTSVSQLResponse());
      }
  }
  
  private String buildResponse(EzDBConnection connection, boolean exitOnError) {
    final long startExecution = StampUtil.getStampValue();  
    TSVResponse xmlResponse;
    boolean withError = false;
    try {
      xmlResponse = loadResponse(connection);
    }
    catch (Exception exception) {
      if (exitOnError) {
        System.exit(-1);
      }
      withError = true;
      xmlResponse = new TSVResponse(ExceptionUtils.getMessage(exception), 0, 0); 
    }
    return generate(startExecution, xmlResponse, withError);
  }
  
  private String generate(long startExecution, TSVResponse xmlResponse, boolean withError) {
    final StringBuilder buffer = StreamUtils.sqlStringBuilderPool.getNew();
    try {
      buffer.append("~.~.~.~.~.Header Start~.~.~.~.~.\r\n")
      .append("ID\t").append(StringComparator.NVL(ID)).append("\r\n")
      .append("WITHERROR\t").append(withError ? "YES" : "NO").append("\r\n")
      .append("STARTTIME\t").append(dateFormat.format(new SimpleDateAccessor(startExecution).toDate())).append("\r\n")
      .append("EXECUTIONDURATION\t").append(""+(StampUtil.getStampValue() - startExecution)).append("\r\n")
      .append("COLCOUNT\t").append(IntegerCache.toString(xmlResponse.getColCount())).append("\r\n")
      .append("ROWCOUNT\t").append(IntegerCache.toString(xmlResponse.getRowCount())).append("\r\n")
      .append("~.~.~.~.~.Header End~.~.~.~.~.\r\n")
      .append(toString());
      if (withError) {
        buffer.append("~.~.~.~.~.Error Start~.~.~.~.~.\r\n")
          .append(encodeText(xmlResponse.getTSVSQLResponse()))
          .append("~.~.~.~.~.Error End~.~.~.~.~.\r\n");
      }
      else {
        buffer.append(xmlResponse.getTSVSQLResponse());
      }
      return buffer.toString();
    }
    finally {
      StreamUtils.sqlStringBuilderPool.free(buffer);
    }
  }
    
  protected abstract TSVResponse loadResponse(EzDBConnection connection) throws Exception;
  //protected abstract void generateResponse(Appendable appendable, EzJDBCDatabase database) throws Exception;
  
  protected static class TSVResponse {
    
    public TSVResponse (String response, int colCount, int rowCount) {
      this.TSVSQLResponse = response;
      this.colCount = colCount;
      this.rowCount = rowCount;
    }
    
    public int getColCount() {
      return colCount;
    }

    public int getRowCount() {
      return rowCount;
    }

    public String getTSVSQLResponse() {
      return TSVSQLResponse;
    }
    
    private final int rowCount;
    private final int colCount;
    private final String TSVSQLResponse;
  }
  
  protected void clearResponse() {
    this.response = null;
    this.connection = null;
  }
  
  private String ID;
  private String response;
  private EzDBConnection connection;
  
  protected final DateBuilder dateFormat = ebXMLDateBuilder.referenceClone();
  protected final CDataBuilder cdataFormat = CDataBuilder.referenceClone();
  
  public static String encodeText(String value) {
    if (value != null) {
      final int result = checkSpecialChar(value);
      if ((result&WIDTHTILD) != 0) {
        value = value.replace("~", "~~");
      }
      if ((result&WIDTHSLASHR) != 0) {
        value = value.replace("\r", "~r");
      }
      if ((result&WIDTHSLASHN) != 0) {
        value = value.replace("\n", "~n");
      }
      if ((result&WIDTHTAB) != 0) {
        value = value.replace("\t", "~t");
      }
      if ((result&WIDTZERO) != 0) {
        value = value.replace("�", "~�");
      }
      return value;
    }
    return null;
  }
  
  public static String decodeText(String value) {
    final int result = checkSpecialChar(value);
    if ((result&WIDTHTILD) != 0) {
      value = value.replace("~~", "~");
    }
    if ((result&WIDTHSLASHR) != 0) {
      value = value.replace("~r", "\r");
    }
    if ((result&WIDTHSLASHN) != 0) {
      value = value.replace("~n", "\n");
    }
    if ((result&WIDTHTAB) != 0) {
      value = value.replace("~t", "\t");
    }
    if ((result&WIDTZERO) != 0) {
      value = value.replace("~�", "�");
    }
    return value;
  }
  
  
  public static int checkSpecialChar(String value) {
    int result = 0;
    for (int i = 0, n = value.length(); i < n; i++) {
      switch (value.charAt(i)) {
        case '~' : result = result|WIDTHTILD; break;
        case '\r' : result = result|WIDTHSLASHR; break;
        case '\n' : result = result|WIDTHSLASHN; break;
        case '\t' : result = result|WIDTHTAB; break;
        case '�' : result = result|WIDTZERO; break;
      }
    }
    return result;
  }
  
  private static final int WIDTHTILD = 1;
  private static final int WIDTHSLASHR = 2;
  private static final int WIDTHSLASHN = 4;
  private static final int WIDTHTAB = 8;
  private static final int WIDTZERO = 16;
}
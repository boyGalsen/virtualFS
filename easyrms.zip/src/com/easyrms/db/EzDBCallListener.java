package com.easyrms.db;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.sql.*;
import java.util.*;


public class EzDBCallListener {

  public static final String shortString = "CONFIG.SHORTNAMES";
  public static final String mediumString = "CONFIG.MEDIUMSTRINGS";
  public static final String longString = "CONFIG.LONGNAMES";
  public static final String veryLongString = "CONFIG.VERYLONGNAMES";
  public static final String booleans = "CONFIG.BOOLEANS";
  public static final String singleChar = "CONFIG.CHARS";
  public static final String integers = "CONFIG.INTEGERS";
  public static final String keys = "CONFIG.KEYS";
  public static final String reals = "CONFIG.REALS";
  public static final String ezDates = "CONFIG.EZDATES";
  public static final String dates = "CONFIG.DATES";
  public static final String numbers1 = "CONFIG.NUMBERS1";

  public static class CallNumber1 extends EzDBCallListener {

    public CallNumber1() {
    }
    public CallNumber1(String request) {
      super(request);
    }
    public CallNumber1(String request, Object... parameters) {
      super(request, parameters);
    }
    
    public int intValue() { 
      final Number result = get(0);
      return result.intValue();
    }
    public double doubleValue() { 
      final Number result = get(0);
      return result.doubleValue();
    }
    
    @Override
    public int[] getResultTypes() { return types; }
    
    private static final int[] types = new int[] { Types.NUMERIC, };
  }
  public static class CallDate1 extends EzDBCallListener {

    public CallDate1() {
    }
    public CallDate1(String request) {
      super(request);
    }
    public CallDate1(String request, Object... parameters) {
      super(request, parameters);
    }
    
    public EzTime getEzTime() { 
      return EzTime.valueOf(getDate());
    }
    public DateAccessor getDate() { 
      final DateAccessor result = get(0);
      return result;
    }
    
    @Override
    public int[] getResultTypes() { return types; }
    
    private static final int[] types = new int[] { Types.TIMESTAMP, };
  }
  
  
  public EzDBCallListener() {
    this(null);
  }
  public EzDBCallListener(String request) {
    this.request = request;
    this.parameters = ObjectArrays.emptyObjectArray;
  }
  public EzDBCallListener(String request, Object... parameters) {
    this(request, true, parameters);
  }
  public EzDBCallListener(String request, boolean isCopyNeeeded, Object... parameters) {
    this.request = request;
    this.parameters = isCopyNeeeded ? parameters.clone() : parameters;
  }

  public boolean call(EzDBTransaction transaction) {
    return call(transaction, getParameters());
  }
  public boolean call(EzDBTransaction transaction, Object... parameters) {
    return call(transaction, parameters, getTypes(), getArrays());
  }
  public boolean call(EzDBTransaction transaction, Object[] parameters, String[] types, Object[][] arrays) {
    return call(transaction, getRequest(), parameters, types, arrays);
  }
  public boolean call(EzDBTransaction transaction, String request, Object[] parameters, String[] types, Object[][] arrays) {
    return transaction.call(request, this, parameters, types, arrays);
  }

  public <T> T get(int i) {
    return (T)results.get(IntegerCache.get(i)); 
  }
  
  public void init() { }
  void set(int i, Object object) {
    if (results == null) results = new HashMap<Integer, Object>();
    results.put(IntegerCache.get(i), object);
  }
  public void close() {}
  
  public String getRequest() { return request; }
  protected Object[] getParameters() { return parameters; }
  protected Object[][] getArrays() { return null; }

  public boolean isWithSplit() { return true; }
  public boolean isEmptyIgnored() { return true; }
  public boolean isWithTimeout() { return true; }
  public boolean isWithLog() { return true; }
  
  public boolean isBlockingRequest() { return false; }

  public String[] getTypes() { return null; }

  public int[] getResultTypes() { return null; }
  public int[] getResultPositions() { return null; }
  
  public final Throwable getException() { return exception; }
  void setException(Throwable exception) { this.exception = exception; }

  private Throwable exception;
  private final String request;
  private final Object[] parameters;
  private HashMap<Integer, Object> results;
}

package com.easyrms.db;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.sql.*;
import java.text.*;
import oracle.sql.*;

//TODO: to complete and flag as deprecated all functions using Connection
public class SimpleBulk extends SimplePooledConnections {

  public static final String shortString = "CONFIG.SHORTNAMES";
  public static final String mediumString = "CONFIG.MEDIUMSTRINGS";
  public static final String longString = "CONFIG.LONGNAMES";
  public static final String veryLongString = "CONFIG.VERYLONGNAMES";
  public static final String booleans = "CONFIG.BOOLEANS";
  public static final String singleChar = "CONFIG.CHARS";
  public static final String integers = "CONFIG.INTEGERS";
  public static final String keys = "CONFIG.KEYS";
  public static final String reals = "CONFIG.REALS";
  public static final String ezDates = "CONFIG.EZDATES";
  public static final String dates = "CONFIG.DATES";
  public static final String numbers1 = "CONFIG.NUMBERS1";

	public static void execute(
 	  CallableStatement call,
 	  Object[] parameters,
	  Object[][] arrays,
	  String[] types,
	  int[] resultTypes,
	  Object[] resultValues) throws SQLException
  {
    execute(
      null,
		  call,
		  parameters,
		  arrays,
		  true,
		  types,
		  resultTypes,
		  resultValues,
		  true,
		  false);
  }
	public static void execute(
 	  CallableStatement call,
 	  Object[] parameters,
	  Object[][] arrays,
	  boolean withSplit,
	  String[] types,
	  int[] resultTypes,
	  Object[] resultValues) throws SQLException
  {
    execute(
      null,
		  call,
		  parameters,
		  arrays,
		  withSplit,
		  types,
		  resultTypes,
		  resultValues,
		  true,
		  false);
  }
  private static void execute(
		SQLPerfmeter.SQLPerfRequest perf,
    CallableStatement call,
    Object[] parameters,
    Object[][] arrays,
    boolean withSplit,
    String[] types,
    int[] resultTypes,
    Object[] resultValues,
    boolean isEmptyIgnored,
    boolean isArrayNull) throws SQLException
  {
  	boolean localPerf = false;
  	//TODO: check if it works to setup a default perf request
  	if (perf == null) {
			perf = SQLPerfmeter.newSQLPerfRequest("???", "???", "???", "???", false, true, "???", parameters);
			perf.fireLog();
      localPerf = true;
  	}
  	try {
	    final int parametersLength = parameters.length;
	    final int typesLength = isArrayNull ? 0 : types.length;
	    final int resultTypesLength = (resultTypes == null) ? 0 : resultTypes.length;
	    final Object[][][] data = withSplit ? EzJDBCTransaction.split(arrays, splitLimit, isEmptyIgnored) :  new Object[][][] { arrays, };
	    if (data == null && !isArrayNull) return;
	    final int dataLength = isArrayNull ? 1 : (data == null) ? 1 : data.length;
			perf.fireEndPreparation(call);
	    for (int k = 0; k < dataLength; k++) {
	      int field = 1;
	      if (resultTypes != null) {
		      for (int i = 0; i < resultTypesLength; i++) {
		      	call.registerOutParameter(field++, resultTypes[i]);
		      }
	      }
	      for (int i = 0; i < parametersLength; i++) {
          final Object parameterI = parameters[i];  
	        if (parameterI == null) {
	          call.setNull(field++, Types.VARCHAR);
	        }
	        else if (parameterI instanceof DateAccessor) {
            final long millisecs = ((DateAccessor)parameterI).getTime();
            if (millisecs == 0) {
              call.setNull(field++, Types.DATE);
            }
            else {
              call.setTimestamp(field++, new Timestamp(millisecs));
            }
          }
          else if (parameterI instanceof java.util.Date) {
	          final long millisecs = ((java.util.Date)parameterI).getTime();
	          if (millisecs == 0) {
	            call.setNull(field++, Types.DATE);
	          }
	          else {
	            call.setTimestamp(field++, new Timestamp(millisecs));
	          }
	        }
	        else {
	          call.setObject(field++, parameterI);
	        }
	      }
	      if (typesLength > 0 && data != null) {
	        final Connection connection = call.getConnection();
	        for (int i = 0; i < typesLength; i++) {
            if (EzDBCallListener.ezDates.equals(types[i])) {
              final Object[] dataKI = data[k][i];
              final int n = dataKI.length;
              final Object[] newData = new Object[n];
              for (int l = 0; l < n; l++) {
                final Object dataKIL = dataKI[l];
                if (dataKIL != null) {
                  if (dataKIL  instanceof EzDate) {
                    newData[l] = ((EzDate)dataKIL).getID();
                  }
                  else {
                    newData[l] = dataKIL;
                  }
                }
              }
              data[k][i] = newData;
            }
            else if (EzDBCallListener.dates.equals(types[i])) {
							final Object[] dataKI = data[k][i];
							if (!(dataKI instanceof java.sql.Date[])
	            	&& !(dataKI instanceof java.sql.Time[])
	            	&& !(dataKI instanceof java.sql.Timestamp[]))
	          	{
		            final int n = dataKI.length;
		            final Object[] newData = new Object[n];
		            for (int l = 0; l < n; l++) {
		            	final Object dataKIL = dataKI[l];
		              if (dataKIL != null) {
		                if (dataKIL  instanceof java.sql.Date
		                  || dataKIL instanceof java.sql.Time
		                  || dataKIL instanceof java.sql.Timestamp)
		                {
		                  newData[l] = dataKIL;
		                }
		                else if (dataKIL instanceof DateAccessor) {
                      newData[l] = new java.sql.Timestamp(((DateAccessor)dataKIL).getTime());
		                }
		                else {
		                  newData[l] = new java.sql.Timestamp(((java.util.Date)dataKIL).getTime());
		                }
		              }
		            }
		            data[k][i] = newData;
		          }
	        	}
	          call.setArray(field++, new ARRAY(
	            ArrayDescriptor.createDescriptor(types[i], connection),
	            connection,
	            data[k][i]));
	        }
	      }
	      if (dataLength > 1 && data != null) {
	        boolean isTraceActive = trace.isActive();
	        if (isTraceActive) {
	          trace.trace("execute bulk " + formatFormat(StampUtil.getNow().toDate()));
	        }
	        if (splitLimit == 1 && data[k].length > 0 && data[k][0].length > 0) {
            Object[][] line = data[k];
            if (isTraceActive) {
              trace.trace("->"+k+":");
              for (int var = 0 ; var < line.length; var++) {
                trace.trace("["+line[var][0]+']');
              }
            }
          }
	        if (isTraceActive) {
	          trace.traceln("");
	        }
	      }
	      call.executeUpdate();
	      if (resultValues != null) {
		      for (int i = 0, n = resultValues.length; i < n; i++) {
		        final Object result = call.getObject(i+1);
		        if (resultTypes != null && resultTypes.length > i && SQLUtils.isDate(resultTypes[i], 0)) {
		          if (result instanceof java.util.Date) {
		            resultValues[i] = new SimpleDateAccessor((java.util.Date)result);
		          }
		          else if (result instanceof Timestamp) {
                resultValues[i] = new SimpleDateAccessor(((Timestamp)result).getTime());
		          }
              else if (result instanceof Time) {
                resultValues[i] = new SimpleDateAccessor(((Time)result).getTime());
              }
              else {
                resultValues[i] = result;
              }
		        }
		        else {
		      	  resultValues[i] = result;
		        }
		      }
	      }
	    }
			perf.fireEndExecution();
			if (localPerf) {
				perf.fireEnd((resultValues == null) ? 0 : resultValues.length, "Bulk");
			}
  	}
    catch (Throwable exception) {
      if (localPerf) {
        perf.fireError(exception);
        perf.fireEnd(0, "Bulk");
      }
      trace.log(exception);
      if (exception instanceof SQLException) {
        throw (SQLException)exception;
      }
      throw new SQLException(exception);
    }
  	finally {
  		if (localPerf) {
  			SQLPerfmeter.freeSQLPerfRequest(perf);
  		}
  	}
  }
	public static void execute(
		String request,
		CallableStatement call,
		Object[] parameters,
		Object[][] arrays,
		String types[]) throws SQLException
	{
		final SQLPerfmeter.SQLPerfRequest perf = SQLPerfmeter.newSQLPerfRequest("???", "???", "???", "???", false, true, request, parameters);
		try {
			perf.fireLog();
      execute(perf, call, parameters, arrays, true, types, null, null, true, false);
			perf.fireEnd(0, "Bulk");
		}
		catch (Throwable ignored) {
			perf.fireError(ignored);
			perf.fireEnd(0, "Bulk");
			throw new SQLException(ignored);
		}
		finally {
			SQLPerfmeter.freeSQLPerfRequest(perf);
		}
	}
	public static void execute(
		CallableStatement call,
		Object[] parameters,
		Object[][] arrays,
		String types[]) throws SQLException
	{
		execute(null, call, parameters, arrays, true, types, null, null, true, false);
	}
	public static void execute(
		CallableStatement call,
		Object[] parameters,
		Object[][] arrays,
		String types[],
		boolean isEmptyIgnored) throws SQLException
	{
		execute(null, call, parameters, arrays, true, types, null, null, isEmptyIgnored, false);
	}
  
	public static boolean call(
		EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		String types[])
	{
		return call(connection, request, parameters, arrays, true, types, true);
	}
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		boolean withSplit,
		String types[])
	{
		return call(connection, request, parameters, arrays, withSplit, types,	true);
	}
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		String types[],
		boolean isEmptyIgnored)
	{
    return call(connection, request, parameters, arrays, true, types, isEmptyIgnored);
  }
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		boolean withSplit,
		String types[],
		boolean isEmptyIgnored)
	{
    return call(connection, request, parameters, arrays, withSplit, types, null, null, isEmptyIgnored);
  }

	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		String types[],
		int[] resultTypes,
		Object[] resultValues)
	{
	  return call(
		  connection,
		  request,
		  parameters,
		  arrays,
		  true,
		  types,
		  resultTypes,
		  resultValues);
	}
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		boolean withSplit,
		String types[],
		int[] resultTypes,
		Object[] resultValues)
	{
	  return call(
		  connection,
		  request,
		  parameters,
		  arrays,
		  withSplit,
		  types,
		  resultTypes,
		  resultValues,
		  true);
	}
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		String types[],
		int[] resultTypes,
		Object[] resultValues,
		boolean isEmptyIgnored)
  {
		return call(connection, request, parameters, arrays, true, types, resultTypes, resultValues, isEmptyIgnored);
  }
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		Object[][] arrays,
		boolean withSplit,
		String types[],
		int[] resultTypes,
		Object[] resultValues,
		boolean isEmptyIgnored)
  {
		if (arrays == null || arrays.length == 0) return true;
	  if (isEmptyIgnored && arrays[0].length == 0) return true;
    final EzDBDatabase database = connection.getDatabase();
    final EzJDBCPhysicalConnection physicalConnection = connection.asJDBCConnection();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(database.getName(), database.getDescription(), connection.getUID(), physicalConnection.getUID(), false, true, request, parameters);
	  try {
      counter.inc();
      perfRequest.fireLog();
      final CallableStatement call = prepareCall(physicalConnection.getConnection(), request);
      try {
        execute(perfRequest, call, parameters, arrays, withSplit, types, resultTypes, resultValues, isEmptyIgnored, false);
				perfRequest.fireEnd(0, "Bulk");
        return true;
      }
      finally {
        call.close();
      }
    }
    catch (Throwable exception) {
			perfRequest.fireError(exception);
			perfRequest.fireEnd(0, "Bulk");
			log(connection, exception, request, parameters);
      throw ExceptionUtils.newRuntimeException(exception);
    }
    finally {
			SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
  }
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters)
  {
		return call(connection, request, parameters, IntArrays.emptyIntArray, null);
  }
	public static boolean call(
    EzDBTransaction connection,
		String request,
		Object[] parameters,
		int[] resultTypes,
		Object[] resultValues)
  {
    return call(connection, request, parameters, resultTypes, resultValues, true);
  }
  public static boolean call(
   EzDBTransaction connection,
   String request,
   Object[] parameters,
   int[] resultTypes,
   Object[] resultValues,
   boolean isCallTimeOutActive)
  {
    final EzDBDatabase database = connection.getDatabase();
    final EzJDBCPhysicalConnection physicalConnection = connection.asJDBCConnection();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(database.getName(), database.getDescription(), connection.getUID(), physicalConnection.getUID(), false, true, request, parameters);
	  try {
      counter.inc();
      perfRequest.fireLog();
      final CallableStatement call = prepareCall(physicalConnection.getConnection(), request, isCallTimeOutActive);
      try {
        execute(perfRequest, call, parameters, null, false, null, resultTypes, resultValues, false, true);
				perfRequest.fireEnd(0, "Bulk");
        return true;
      }
      finally {
        call.close();
      }
    }
    catch (Throwable exception) {
			perfRequest.fireError(exception);
			perfRequest.fireEnd(0, "Bulk");
			log(connection, exception, request, parameters);
      throw ExceptionUtils.newRuntimeException(exception);
    }
    finally {
			SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
  }

  public static boolean commit(
    EzDBDatabase database,
    String request,
    Object[] parameters,
    Object[][] arrays,
    String types[])
  {
    final EzDBTransaction transaction = database.openTransaction();
    try {
      return commit(transaction, request, parameters, arrays, types);
    }
    finally {
      transaction.close();
    }
  }
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    Object[][] arrays,
    String types[])
  {
    try {
      if (call(transaction, request, parameters, arrays, types)) {
        return transaction.commit();
      }
      transaction.rollback();
    }
    catch (Exception exception) {
      log(transaction, exception, request, parameters);
    }
    return false;
  }

  public static boolean commit(
    EzDBDatabase database,
    String request,
    Object[] parameters,
    Object[][] arrays,
    String types[],
    int[] resultTypes,
    Object[] resultValues)
  {
    final EzDBTransaction transaction = database.openTransaction();
    try {
      return commit(transaction, request, parameters, arrays, types, resultTypes, resultValues);
    }
    finally {
      transaction.close();
    }
  }
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    Object[][] arrays,
    String types[],
    int[] resultTypes,
    Object[] resultValues)
  {
    try {
      if (call(transaction, request, parameters, arrays, types, resultTypes, resultValues)) {
        return transaction.commit();
      }
      transaction.rollback();
    }
    catch (Exception exception) {
      log(transaction, exception, request, parameters);
    }
    return false;
  }

	public static boolean commit(
    EzDBDatabase database,
		String request,
		Object[] parameters,
		Object[][] arrays,
		String types[],
		boolean isEmptyIgnored)
	{
    final EzDBTransaction transaction = database.openTransaction();
		try {
			return commit(transaction, request, parameters, arrays, types, isEmptyIgnored);
    }
    finally {
      transaction.close();
    }
	}
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    Object[][] arrays,
    String types[],
    boolean isEmptyIgnored)
  {
    try {
      if (call(transaction, request, parameters, arrays, types, isEmptyIgnored)) {
        return transaction.commit();
      }
      transaction.rollback();
    }
    catch (Exception exception) {
      log(transaction, exception, request, parameters);
    }
    return false;
  }

	public static boolean commit(
    EzDBDatabase database,
		String request,
		Object[] parameters,
		Object[][] arrays,
		String types[],
		int[] resultTypes,
		Object[] resultValues,
		boolean isEmptyIgnored)
	{
    final EzDBTransaction transaction = database.openTransaction();
		try {
			return commit(transaction, request, parameters, arrays, types, resultTypes, resultValues, isEmptyIgnored);
    }
    finally {
      transaction.close();
    }
	}
  public static boolean commit(
    EzDBTransaction transaction,
    String request,
    Object[] parameters,
    Object[][] arrays,
    String types[],
    int[] resultTypes,
    Object[] resultValues,
    boolean isEmptyIgnored)
  {
    try {
      if (call(transaction, request, parameters, arrays, types, resultTypes, resultValues, isEmptyIgnored)) {
        return transaction.commit();
      }
      transaction.rollback();
    }
    catch (Exception exception) {
      log(transaction, exception, request, parameters);
    }
    return false;
  }

	public static final int splitLimit = EzJDBCDatabase.splitLimit;
  
  private static final String formatFormat(Object obj) {
    synchronized (formatX) {
      return formatX.format(obj);
    }
  }
	private static final DateFormat formatX = new SimpleDateFormat(" hh:mm:ss");
  private static final Counter counter = new Counter("SQL Simple Bulk");
}
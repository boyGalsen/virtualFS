package com.easyrms.db;


public class EzDBLock {

  public EzDBLock() {
    this.access = null;
    this.count = 0;
  }
  public EzDBLock(EzDBAccess access) {
    this.access = access;
    this.count = 1;
  }

  public EzDBConnection getConnection() {
    return access.getConnection();
  }
  
  public void lock() {
    if (count == 0) access = openAccess();
    count++;
  }
  public void unlock() {
    if (--count <= 0) {
      access.close();
      access = null;
    }
  }
  
  protected EzDBAccess openAccess() { return null; }
  
  private EzDBAccess access;
  private int count = 0;
}

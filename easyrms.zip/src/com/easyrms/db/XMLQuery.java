package com.easyrms.db;

import com.easyrms.util.*;

import java.io.*;
import java.util.*;


public final class XMLQuery implements Serializable {
		  
  public static String getResponse(EzDBAccess access, String request) {
    return getResponse(access,request,false);
  }
  
  
  public static String getResponse(EzDBAccess access, String request, boolean exitonerror) {
    final XMLQuery query = new XMLQuery();
    query.set(request);
    return query.getResponse(access, exitonerror);
  }
  
  public static XMLQuery getSimpleRequest(String request) {
    return getSimpleRequest(request, null);
  }
  public static XMLQuery getSimpleRequest(String request, String ID) {
    final XMLQuery query = new XMLQuery();
    final XMLRequest xmlRequest = new XMLRequest();
    xmlRequest.setRequest(request);
    xmlRequest.setID(ID);
    query.add(xmlRequest);
    return query;
  }
  
  public String getResponse(EzDBAccess access, boolean exitonerror) {
    final StringBuilder buffer = StreamUtils.bigStringBuilderPool.getNew();
    try {
      try {
        buffer.append("<RESPONSE DATABASE=\"").append(access.getDatabase().getName()).append("\">\n");
        for (int i = 0, n = getQueryCount(); i < n; i++) {
          buffer.append(getQuery(i).getResponse(access.getConnection(), exitonerror));
        }
        buffer.append("</RESPONSE>\n");
        return buffer.toString();
      }
      finally {
        access.close();
      }
    }
    finally {
			StreamUtils.bigStringBuilderPool.free(buffer);
    }
  }
  
  public void set(String query) {
    try {
    	this.queries.clear();
      final Reader reader = new StringReader(query);
      try {
        final Yylex yy = new Yylex(reader);
        yy.setQuery(this);
        while ((yy.yylex()) != null) {}
      }
      finally {
        reader.close();
      }
    }
    catch(Exception e) {
      EasyRMS.trace.log(e);
    }
  }
  
  public void add(XMLStatement query) {
    this.queries.add(query);
  }

  public void remove(XMLStatement query) {
    this.queries.remove(query);
  }
  
  public XMLStatement[] getQuery() {
    return queries.toArray(new XMLStatement[queries.size()]);
  }
  
  public XMLStatement getQuery(int i) {
  	return queries.get(i);
  }
    
  public int getQueryCount() {
    return queries.size();
  }
  
  @Override
  public String toString() {
    final StringBuilder buffer = StreamUtils.bigStringBuilderPool.getNew();
		try {
	    buffer.append("<SQLQUERY>");
	    for (int i = 0, n = getQueryCount(); i < n; i++) {
	      buffer.append(getQuery(i));
	    }
	    buffer.append("</SQLQUERY>");
	    return buffer.toString();
		}
		finally {
			StreamUtils.bigStringBuilderPool.free(buffer);
		}
  }
  
  public void reset() {
  	queries.clear();
  }
  
  private final ArrayList<XMLStatement> queries = new ArrayList<XMLStatement>();    
}
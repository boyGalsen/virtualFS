package com.easyrms.db;

import java.util.function.*;

public interface EzDBTransaction extends EzDBConnection, EzDBAccess {

  boolean call(
    String request,
    EzDBCallListener listener, 
    Object[] parameters,
    String[] types,
    Object[][] arrays);

  boolean rollback();
  boolean commit();
  
  void addBeforeCommitTrigger(Predicate<EzDBTransaction> trigger);
}

package com.easyrms.db;

import com.easyrms.table.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;

import java.sql.*;
import java.util.*;


public abstract class AbstractSQLData extends SimpleData {
  
  public AbstractSQLData() {
    super();
  }

  public String[] getMainTitle() {
    return (header != null && header.size() > 0) ? StringArrays.clone(header.get(0)) : null;
  }
  public String getMainTitle(int i) {
    return header.get(0)[i];
  }
  public int getMainTitleCount() {
    return (header != null && header.size() > 0) ? header.get(0).length : 0;
  }
  public void setMainTitle(String[] mainTitles) {
    isNeedToAddRequestTitles = true;
    if (mainTitles == null) {
      this.header = null;
    }
    else {
      this.header = new ArrayList<String[]>();
      this.header.add(mainTitles);
    }
  }
  public int getHeaderTitleCount() {
    if (header == null) return 0;
    return header.size();
  }
  public String getHeaderTitle(int i, int column) {
    final String[] header = this.header.get(i);
    if (header.length < column) return null;
    return header[column];
  }

  public void setHeaderTitles(String[][] headerTitles) {
    isNeedToAddRequestTitles = false;
    this.header = new ArrayList<String[]>();
    if (headerTitles != null) {
      for (int i = 0, n = headerTitles.length; i < n; i++) {
        header.add(headerTitles [i]);
      }
    }
  }
  public boolean isNeedToAddRequestTitles() {
    return isNeedToAddRequestTitles;
  }

  public String getRequest() {
    return this.request;
  }
  public void setRequest(String request) {
    this.request = request;
    data = null;
  }

  public final Object[] getParameter() {
    if (request == null) return null;
    return getInternalParameter().clone();
  }
  protected Object[] getInternalParameter() {
    return parameters;
  }
  public Object getParameter(int i) {
    if (request == null) return null;
    return parameters[i];
  }
  public void setParameter(int i, Object parameter) {
    this.parameters[i] = parameter;
    data = null;
  }
  public void setParameter(Object[] parameters) {
    this.parameters = parameters.clone();
    data = null;
  }
  public int getParameterCount() {
    return parameters.length;
  }
  public void setParameterCount(int count) {
    if (parameters.length != count) {
      final Object[] oldParameters = parameters;
      parameters = new Object[count];
      System.arraycopy(oldParameters, 0, parameters, 0, Math.min(count, oldParameters.length));
    }
  }

  protected abstract EzDBDatabase getDatabase();

  public void close(EzDBAccess transaction) {
    if (this.connection == null) transaction.close(); 
  }
  public EzDBAccess getConnection() {
    try {
      return (connection == null) ? getDatabase().openAccess() : connection;
    }
    catch (Throwable ignored) {
      throw ExceptionUtils.newRuntimeException(ignored);
    }
  }
  public void setConnection(EzDBAccess connection) {
    this.connection = connection;
  }

  @Override
  public void setTrailer(int trailer) {
    this.trailer = trailer;
  }
  
  @Override
	public final int getHeader() { return (dataHeight == 0) ? 0 : (header == null) ? 1 : !isNeedToAddRequestTitles ? header.size() : header.size()+1; }
  @Override
  public final int getTrailer() { return (dataHeight <= 1) ? 0 : Math.min(trailer, dataHeight-1); }
  @Override
  public final int getHeight() { return dataHeight; }
  @Override
  public Object get(int row, int column) {
    return data.get(row)[column];
  }
  
  protected void internalInit(EzDBConnection connection) { }
  
  @Override
  protected final void internalInit() {
    if (data != null) return;
    try {
      final EzDBAccess connection = getConnection();
      try {
        internalInit(connection.getConnection());
        SimpleRequest.query(
          connection.getConnection(), 
          getRequest(), 
          getInternalParameter(),
          new EzDBResultSetListener() {
          
            @Override
            public void init(ResultSet v) throws SQLException {
              initData(v, dataArray);
              data = dataArray;
            }
            @Override
            public void set(int i, ResultSet v) throws SQLException {
              updateData(i, v, dataArray);
              data = dataArray;
            }
            @Override
            public void close() throws SQLException {
              closeData(dataArray);
              dataHeight = dataArray.getCount();
              if (dataHeight > 0) {
                setWidth(dataArray.get(0).length);
              }
              data = dataArray;           
            }
            
            private final EzArrayList<Object[]> dataArray = new EzArrayList<>();
          });
      }
      finally {
        close(connection);
      }
    }
    catch (EzRMSNotCatchRuntimeException exception) {
      throw exception;
    }
    catch (Throwable exception) {
      EasyRMS.trace.log("(request="+request+")", exception);
    }
  }

  protected void initData(ResultSet v, EzArrayList<Object[]> data) throws SQLException {}
  protected abstract void updateData(int i, ResultSet v, EzArrayList<Object[]> data) throws SQLException;
  protected void closeData(EzArrayList<Object[]> data) {}
 
  private boolean isNeedToAddRequestTitles = true;
  private EzDBAccess connection = null;
  private String request = null;
  private Object[] parameters = EmptyArrays.emptyObjectArray;
  
  private ArrayList<String[]> header;
  
  private int trailer = 0;
  public EzArrayList<Object[]> data;
  private int dataHeight = 0;

}

package com.easyrms.db;

import com.easyrms.date.*;

import java.sql.*;
import java.util.function.*;
import oracle.sql.*;

//TO POOL
public class EzJDBCTransaction extends EzJDBCConnection implements EzDBTransaction {

  public EzJDBCTransaction(EzJDBCDatabase database) {
    super(database, 1);
  }
  
  public boolean call(
    String request,
    EzDBCallListener listener, 
    Object[] parameters, 
    String[] types,
    Object[][] arrays)
  {
    try {
      final EzJDBCPhysicalConnection connection = getNewConnection(false);
      final CallableStatement call = connection.getConnection().prepareCall(request);
      try {
        call.setQueryTimeout(listener.isWithTimeout() ? EzJDBCDatabase.callTimeOut : 0);
        return execute(
          database.getName(),
          database.getDescription(),
          getUID(),
          listener.isBlockingRequest(), 
          true,
          connection,
          request,
          call,
          parameters,
          arrays,
          (types == null) ? listener.getTypes() : types,
          listener.getResultTypes(),
          listener.getResultPositions(),
          listener);
      }
      finally {
        if (call != null) {
          call.close();
        }
      }
    }
    catch (Exception exception) {
      listener.setException(exception);
    }
    return false;
  }
  
  @Override
  protected boolean isWithRollBack() {
    return EzJDBCDatabase.withTransactionRollBack;
  }

  public synchronized boolean commit() {
    final EzJDBCPhysicalConnection connection = findMainConnection();
    return (connection == null) 
      ? !isClosed()
      : (checkTriggers() && SQLUtils.commit(connection));
  }

  public synchronized boolean rollback() {
    final EzJDBCPhysicalConnection connection = findMainConnection();
    return (connection == null)
      ? !isClosed()
      : SQLUtils.rollback(connection);
  }

  @Override
  public void close() {
    super.close();
    clearTriggers();
  }
  
  static Object[][][] split(final Object[][] data, final int l, final boolean isEmptyIgnored) {
    if (data == null || data.length == 0) {
      return null;
    }
    final int dataLength = data.length;
    final int p = data[0].length;
    if (p == 0) {
      if (isEmptyIgnored) {
        return null;
      }
      return new Object[][][] { data, };
    } 
    final int n = (p-1)/l+1;
    Object[][][] result = new Object[n][][];
    if (n == 1) {
      result[0] = data;
    }
    else {
      for (int i = 0; i < n; i++) {
        result[i] = new Object[dataLength][];
        final int lMuli = l*i;
        final int m = Math.min(l, p-lMuli);
        for (int j = 0; j < dataLength; j++) {
          result[i][j] = new Object[m];
          System.arraycopy(data[j], lMuli, result[i][j], 0, m);
        }
      }
    }
    return result;
  }

  //TODO: to check carefully
  static boolean execute(
    String databaseName,
    String databaseDescription,
    String connectionUID,
    boolean isBlockingRequest,
    boolean isTransaction,
    EzJDBCPhysicalConnection connection,
    String request,
    CallableStatement call,
    Object[] parameters,
    Object[][] arrays,
    String arrayTypes[],
    int[] resultTypes,
    int[] resultPositions,
    EzDBCallListener listener)
  {
    final SQLPerfmeter.SQLPerfRequest perf = SQLPerfmeter.newSQLPerfRequest(databaseName, databaseDescription, connectionUID, connection.getUID(), isBlockingRequest, isTransaction, request, parameters);
    try {
      perf.fireLog();
      final int parametersLength = parameters.length;
      final int typesLength = (arrayTypes == null) ? 0 : arrayTypes.length;
      final int resultTypesLength = (resultTypes == null) ? 0 : resultTypes.length;
      final Object[][][] data = (listener == null || listener.isWithSplit()) 
        ? split(arrays, EzJDBCDatabase.splitLimit, (listener == null || listener.isEmptyIgnored())) 
        : new Object[][][] { arrays, };
      if (data == null && typesLength > 0) {
        return false;
      }
      final int dataLength = (typesLength == 0 || data == null) ? 1 : data.length;
      perf.fireEndPreparation(call);
      int currentOut = 0;
      int currentIn = 0;
      for (int k = 0; k < dataLength; k++) {
        for (int pos = 1, maxPos = resultTypesLength+parametersLength+typesLength; pos <= maxPos; pos++) {
          if (resultTypesLength > 0 && ((resultPositions != null && pos == resultPositions[currentOut]) || pos <= resultTypesLength)) {
            call.registerOutParameter(pos, resultTypes[currentOut++]);
          } 
          else if (currentIn < parametersLength) {
            final Object parameter = parameters[currentIn];  
            if (parameter == null) {
              call.setNull(pos, Types.VARCHAR);
            }
            else if (parameter instanceof EzDate) {
              call.setInt(pos, ((EzDate)parameter).getDay());
            }
            else if (parameter instanceof DateAccessor) {
              final long millisecs = ((DateAccessor)parameter).getTime();
              if (millisecs == 0) {
                call.setNull(pos, Types.DATE);
              }
              else {
                call.setTimestamp(pos, new Timestamp(millisecs));
              }
            }
            else if (parameter instanceof java.util.Date) {
              final long millisecs = ((java.util.Date)parameter).getTime();
              if (millisecs == 0) {
                call.setNull(pos, Types.DATE);
              }
              else {
                call.setTimestamp(pos, new Timestamp(millisecs));
              }
            }
            else {
              call.setObject(pos, parameter);
            }
            currentIn++;
          }
          else if (arrayTypes != null && data != null) {
            final int i = currentIn - parametersLength;
            if (EzDBCallListener.dates.equals(arrayTypes[i])) {
              final Object[] dataKI = data[k][i];
              if (!(dataKI instanceof java.sql.Date[])
                && !(dataKI instanceof java.sql.Time[])
                && !(dataKI instanceof java.sql.Timestamp[]))
              {
                final int n = dataKI.length;
                final Object[] newData = new Object[n];
                for (int l = 0; l < n; l++) {
                  final Object dataKIL = dataKI[l];
                  if (dataKIL != null) {
                    if (dataKIL  instanceof java.sql.Date
                      || dataKIL instanceof java.sql.Time
                      || dataKIL instanceof java.sql.Timestamp)
                    {
                      newData[l] = dataKIL;
                    }
                    else if (dataKIL instanceof DateAccessor){
                      newData[l] = new java.sql.Timestamp(((DateAccessor)dataKIL).getTime());
                    }
                    else {
                      newData[l] = new java.sql.Timestamp(((java.util.Date)dataKIL).getTime());
                    }
                  }
                }
                data[k][i] = newData;
              }
            }
            call.setArray(pos, new ARRAY(
              ArrayDescriptor.createDescriptor(arrayTypes[i], connection.getConnection()),
              connection.getConnection(),
              data[k][i]));
          }
        }
        call.executeUpdate();
        perf.fireEndExecution();
        if (listener != null) {
          listener.init();
          try {
            if (resultTypes != null) {
              for (int i = 0, n = resultTypes.length; i < n; i++) {
                final Object result = call.getObject((resultPositions == null) ? i+1 : resultPositions[i]);
                if (resultTypes != null && resultTypes.length > i && SQLUtils.isDate(resultTypes[i], 0)) {
                  if (result instanceof java.util.Date) {
                    listener.set(i, new SimpleDateAccessor((java.util.Date)result));
                  }
                  else if (result instanceof Timestamp) {
                    listener.set(i, new SimpleDateAccessor(((Timestamp)result).getTime()));
                  }
                  else if (result instanceof Time) {
                    listener.set(i, new SimpleDateAccessor(((Time)result).getTime()));
                  }
                  else {
                    listener.set(i, result);
                  }
                }
                else {
                  listener.set(i, result);
                }
              }
            }
          }
          finally {
            listener.close();
          }
        }
      }
      perf.fireEnd((resultTypes == null) ? 0 : resultTypes.length, (data == null) ? "Call" : "Bulk");
      return true;
    }
    catch (Throwable exception) {
      listener.setException(exception);
      perf.fireError(exception);
      perf.fireEnd(0, "Bulk");
      EzJDBCDatabase.trace.log(exception);
    }
    finally {
      SQLPerfmeter.freeSQLPerfRequest(perf);
    }
    return false;
  }
  
  @Override
  boolean isATransaction() {
    return true;
  }  

  @Override
  public synchronized void addBeforeCommitTrigger(final Predicate<EzDBTransaction> trigger) {
    final Predicate<EzDBTransaction> previousTriggers = this.beforeCommitTriggers;
    if (previousTriggers == null) {
      this.beforeCommitTriggers = trigger;
    }
    else {
      this.beforeCommitTriggers = (x) -> { return (trigger.test(x) && previousTriggers.test(x)); };
    }
  }

  synchronized void clearTriggers() {
    beforeCommitTriggers = null;
  }
  
  boolean checkTriggers() {
    return (beforeCommitTriggers == null || beforeCommitTriggers.test(this));
  }

  private Predicate<EzDBTransaction> beforeCommitTriggers;
}

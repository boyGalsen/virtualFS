package com.easyrms.db;

import com.easyrms.builder.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.executor.*;
import com.easyrms.util.ezjmx.*;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.regex.*;


public class SQLPerfmeter {
  
  public static final int FIRSTLEVEL_INMILLIS = 30*1000;
  public static final int SECONDLEVEL_INMILLIS = 120*1000;
	
	public static final SQLPerfmeter reference = new SQLPerfmeter(); 
  
	public EzArray<RequestStatistics> getStatistics() {
    synchronized (map) {
      return new EzArrayList<RequestStatistics>(map.values());
    }
	} 
    
	public void clear() {
    synchronized (map) {
  		map.clear();
    }
	}
  
	public void clearErrors() {
    synchronized (errorRequests) {
     errorRequests.clear();
    }
	}
  
  public boolean cancelRequest(String id) {
    synchronized (currentRequests) {
      if (id == null) return false;
      for (final SQLRequest request : currentRequests) {
        final String requestID = request.getID();
        if (id.equals(requestID)) return request.cancel();
      }
      return false;
    }
  }
    
  public void clearErrors(String[] ids) {
    synchronized (errorRequests) {
      if (ids == null || ids.length <= 0) {
        return;
      }
      final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
      final EzArrayList<SQLRequest> toRemove = arrayPool.get();
      final HashSetThreadPool setPool = HashSetThreadPool.threadPools.get();
      final HashSet<String> idsToRemove = setPool.get();
      try {
        for (int i = 0, n = ids.length; i < n; i++) {
          idsToRemove.add(ids[i]);
        }
        for (final SQLRequest request : errorRequests) {
          if (idsToRemove.contains(request.getID())) {
            toRemove.add(request);
          }
        }
        errorRequests.removeAll(toRemove);
      }
      finally {
        setPool.free(idsToRemove);
        arrayPool.free(toRemove);
      }
    }
  }


	private void addError(SQLRequest request) {
    synchronized (errorRequests) {
  		errorRequests.add(request);
    }
	}
    
	private void add(SQLPerfRequest request) {
		synchronized (currentRequests) {
      currentRequests.add(request);
		}
	}
    
	private void remove(SQLPerfRequest request) {
		synchronized (currentRequests) {
			currentRequests.remove(request);
		}
	}
    
	public EzArray<? extends SQLRequestSnapshot> getCurrentRequests(boolean withStack) {
		synchronized (currentRequests) {
      final int n = currentRequests.size();
      final EzArrayList<SimplSQLRequestStatistic> newCurrentRequests = new EzArrayList<SimplSQLRequestStatistic>(n);
      for (int i = 0; i < n; i++) {
        final SQLPerfRequest requestI = currentRequests.get(i);
        if (requestI != null) {
          newCurrentRequests.add(new SimplSQLRequestStatistic(requestI, withStack));
        }
      }
      return newCurrentRequests;
		}
	}
  
  private static class SimplSQLRequestStatistic implements SQLRequestSnapshot {
    
    private SimplSQLRequestStatistic(SQLPerfRequest request, boolean withStack) {
      this.request = request.request;
      this.start = request.start;
      this.arguments = request.arguments; 
      this.errorMessage = request.errorMessage;
      this.currentThread = request.currentThread;
      this.currentThreadStack = (currentThread != null && withStack) ? currentThread.getStackTrace() : null;
      this.currentTask = request.currentTask;
      this.state = request.state;
      this.id = request.id;
      this.databaseName = request.databaseName;
      this.connectionUID = request.connectionUID;
      this.physicalUID = request.physicalUID;
      this.databaseDescription = request.databaseDescription;
      this.isBlockingRequest = request.isBlockingRequest;
      this.isTransaction = request.isTransaction;
    }
    
    public String getDatabaseFullName() {
      return SQLPerfmeter.nameDescriptionFormat.format(this);
    }

    public String getDatabaseName() {
      return databaseName;
    }

    public String getDatabaseDescription() {
      return databaseDescription;
    }

    public boolean isTransaction() {
      return isTransaction;
    }

    public DateAccessor getStart() {
      return new SimpleDateAccessor(start);
    }

    public String getRequest() {
      return this.request;
    }

    public String getArguments() {
      return this.arguments;
    }

    public boolean hasError() {
      return errorMessage == null;
    }

    public String getErrorMessage() {
      return errorMessage;
    }

    public String getID() {
      return this.id;
    }

    public SQLExecutionState getState() {
      return this.state;
    }

    public boolean isBlockingRequest() {
      return isBlockingRequest;
    }

    public Thread getAssociedThread() {
      return this.currentThread;
    }

    public EzTreeTask<?> getAssociedTask() {
      return this.currentTask;
    }

    public boolean cancel() {
      return false;
    }

    public String getConnectionUID() {
      return connectionUID;
    }

    public String getPhysicalUID() {
      return physicalUID;
    }
    public String getAssociedThreadStack() {
      final Thread currentThread = this.currentThread;
      if (currentThread != null) {
        final StringBuilderThreadPool stringBuilderThreadPool = StringBuilderThreadPool.threadPools.get();
        final StringBuilder buf = stringBuilderThreadPool.get();
        try {
          buf.append(currentThread.getName()).append("\r\n");
          final StackTraceElement[] currentThreadStack = this.currentThreadStack;
          if (currentThreadStack != null) {
            for (int i = 0, n = currentThreadStack.length; i < n; i++) {
              final StackTraceElement e = currentThreadStack[i];
              buf.append(e.getClassName()).append(".").append(e.getMethodName()).append(".line(").append(e.getLineNumber()).append(")\r\n");
            }
            return buf.toString();
          }
        }
        finally {
          stringBuilderThreadPool.free(buf); 
        }
      }
      return null;
    }
    
    private final String request;
    private final long start;
    private final String arguments; 
    private final String errorMessage;
    private final Thread currentThread;
    private final StackTraceElement[] currentThreadStack;
    private final EzTreeTask<?> currentTask;
    private final SQLExecutionState state;
    private final String id;
    private final String databaseName;
    private final String connectionUID;
    private final String physicalUID;
    private final String databaseDescription;
    private final boolean isBlockingRequest;
    private final boolean isTransaction;
  }

	public EzArray<? extends SQLRequest> getErrorRequests() {
    synchronized (errorRequests) {
      return new EzArrayList<SQLRequest>(errorRequests);
    }
	}
	private final HashMap<String, RequestStatistics> map = new HashMap<String, RequestStatistics>();
	private final LinkedList<SQLPerfRequest> currentRequests = new LinkedList<SQLPerfRequest>();
	private final List<SQLRequest> errorRequests = Collections.synchronizedList(new ArrayList<SQLRequest>());

	private void addRequest(boolean isBlockingRequest, boolean isTrasaction, String request, long duration, long prepareintermediateDuration, long executeIntermediate, long intermediateDuration, int nbresults, String method, String maxArguments) {
    allRequest.inc();
    final String normalizedRequest;
    if (isWithComment(request)) {
      normalizedRequest = pattern.matcher(request).replaceAll("");
      withcommentRequest.inc();
    }
    else {
      normalizedRequest = request;
    }
    synchronized (map) {
      RequestStatistics statistics = map.get(normalizedRequest);
  		if (statistics == null) {
  			statistics = new RequestStatistics(isBlockingRequest, isTrasaction, normalizedRequest, duration, prepareintermediateDuration, executeIntermediate, intermediateDuration, nbresults, method, maxArguments);
  			map.put(normalizedRequest, statistics);
  		}
  		else {
  			statistics.addSample(duration, prepareintermediateDuration, executeIntermediate, intermediateDuration, nbresults, maxArguments);
  		}
    }
    synchronized (currentRequests) {
      nbAllQuick++;
      int nbQuick = (int)(duration/timeUnitInMilliss);
      if (nbQuick > 0) nbQuickFlush++;
      histogram[(nbQuick >= histogram.length) ? histogram.length-1 : nbQuick]++;
    }

	}
  
  private static boolean isWithComment(String request) {
    boolean isComment = false;
    for (int i = 0, n = request.length(); i < n; i++) {
      final char c = request.charAt(i);
      if (c == '*') {
        if (!isComment && i >= 1) {
          final char c1 = request.charAt(i-1);
          if (c1 == '/') {
            isComment = true;
          }
        }
      }
      else if (c == '/') {
        if (isComment && i >= 1) {
          final char c1 = request.charAt(i-1);
          if (c1 == '*') {
            return true;
          }
        }
      }
    }
    return false;
  }
  
  private long[] histogram = new long[32];
  private long nbAllQuick = 0;
  private long nbQuickFlush = 0;
  private final int timeUnit = 10;
  private final int timeUnitInMilliss = timeUnit*1000;
  
  private static final Pattern pattern = Pattern.compile("/\\*\\+.*?\\*/", Pattern.DOTALL);

  
  public class SQLPerfmeterStatsSnapshot {
    
    private SQLPerfmeterStatsSnapshot() {
      final long[] snapshotHistogram = new long[histogram.length];
      System.arraycopy(histogram, 0, snapshotHistogram, 0, histogram.length);
      this.snapshotHistogram = snapshotHistogram;
      this.snapshotNbAllQuick = nbAllQuick;
      this.snapshotNbQuickFlush = nbQuickFlush;
      this.snapshotTimeUnit = timeUnit;
      this.snapshotCurrent = currentRequests.size();
    }
    
    public long get(int nbQuick) {
      return snapshotHistogram[nbQuick];
    }
    
    public int getCount() {
      return snapshotHistogram.length;
    }
    
    public long getQuickCount() {
      return snapshotNbAllQuick;
    }

    public long getFlushesQuickCount() {
      return snapshotNbQuickFlush;
    }
    
    public int getCurrentCount() {
      return snapshotCurrent;
    }
    
    public int getTimeInSeconds(int i) {
      return i*snapshotTimeUnit;
    }
    
    private final long[] snapshotHistogram;
    private final long snapshotNbAllQuick;
    private final long snapshotNbQuickFlush;
    private final int snapshotTimeUnit;
    private final int snapshotCurrent;
  }
  
  public SQLPerfmeterStatsSnapshot getSnapshot() {
    synchronized (currentRequests) {
      return new SQLPerfmeterStatsSnapshot();
    }
  }

	
	public static class RequestStatistics {
    
		private RequestStatistics(boolean isBlockingRequest, boolean isTrasaction, String request, long duration, long prepareIntermediate, long executeIntermediate, long resultIntermediate, int nbResults, String method, String maxArguments) {
      this.isBlockingRequest = isBlockingRequest;
      this.isTransaction = isTrasaction; 
			this.request = request;
			this.method = method;
			this.total = this.min = this.max = duration;
			this.prepareIntermediate = prepareIntermediate;
			this.executeIntermediate = executeIntermediate;
			this.resultIntermediate = resultIntermediate;
			this.nbResults = nbResults;
			this.maxArguments = maxArguments;
			count = 1;
      if (duration < FIRSTLEVEL_INMILLIS) {
        count0++;
      }
      else if (duration < SECONDLEVEL_INMILLIS) {
        count1++;
      }
      else {
        count2++;
      }
		}
    
		private synchronized void addSample(long duration,  long prepareIntermediate, long executeIntermediate, long resultIntermediate, int nbResults, String maxArguments) {
			this.count++;
			this.total += duration;
			this.prepareIntermediate += prepareIntermediate;
			this.executeIntermediate += executeIntermediate;
			this.resultIntermediate += resultIntermediate;
			this.nbResults += nbResults;
			if (this.min > duration) {
				this.min = duration;
			} 
			else if (this.max < duration) {
				this.max = duration;
				this.maxArguments = maxArguments;
			} 
      if (duration < FIRSTLEVEL_INMILLIS) {
        count0++;
      }
      else if (duration < SECONDLEVEL_INMILLIS) {
        count1++;
      }
      else {
        count2++;
      }
		}
    
		public synchronized double getPrepareAverage() { return prepareIntermediate / count; }
    public synchronized double getExecuteAverage() { return executeIntermediate / count; }
		public synchronized double getResultAverage() { return resultIntermediate / count; }
		public synchronized double getNbResultAverage() { return nbResults / count; }
    public final String getRequest() { return request; }
		public synchronized long getAverage() { return total / count; }
		public synchronized long getCount() { return count; }
    public synchronized long getCountUnderFistLevel() { return count0; }
    public synchronized long getCountUnderSecondLevel() { return count1; }
    public synchronized long getCountOverSecondLevel() { return count2; }
    public synchronized long getMin() { return min; }
    public synchronized long getMax() { return max; }
    public String getMethod() { return this.method; }
    public String getMaxArguments() { return maxArguments; }
    public boolean isBlockingRequest() { return isBlockingRequest; }
    public boolean isTransaction() { return isTransaction; }

		private final String request;
		private final String method;
    private boolean isBlockingRequest; 
    private boolean isTransaction; 
        
		private long min;
		private long max;
		private long total;
    
		private long count;
    
    private long count0;
    private long count1;
    private long count2;
    
		private long prepareIntermediate;
		private long executeIntermediate;
		private long resultIntermediate;
		private long nbResults;
		private String maxArguments;
	}
	
	public static interface SQLRequest { 
    
    public static enum SQLExecutionState {
      PREPARE, EXECUTE, READ, FINISH , CANCEL, 
    }
    
    boolean cancel();
    Thread getAssociedThread();
    EzTreeTask<?> getAssociedTask();
    SQLExecutionState getState();
    String getID();
		String getRequest();
    String getDatabaseFullName();
    String getDatabaseName();
    String getDatabaseDescription();
    String getConnectionUID();
    String getPhysicalUID();
    boolean isTransaction();
    String getArguments();
		DateAccessor getStart();
		boolean hasError();
    boolean isBlockingRequest();
		String getErrorMessage();
  	
		SQLRequest[] emptyArray = new SQLRequest[0];
	}
  
  public static interface SQLRequestSnapshot extends SQLRequest { 
    
    String getAssociedThreadStack();
  }
	 
	public static SQLPerfRequest newSQLPerfRequest(String databaseName, String databaseDescription, String connectionUID, String physicalUID, boolean isBlockingRequest, boolean isTransaction, String request, Object[] arguments) {
    return perfRequestsPool.getNew(databaseName, databaseDescription, connectionUID, physicalUID, isBlockingRequest, isTransaction, request, arguments);
	}

	public static void freeSQLPerfRequest(SQLPerfRequest perfRequest) {
    perfRequestsPool.free(perfRequest);
	}
	
  private static class PerfRequestsPool extends SynchronizedSimplePool<SQLPerfRequest>{
    
    public PerfRequestsPool () {
      super(StreamUtils.class.getName()+".perfRequestsPool",
      new AbstractCreator<SQLPerfRequest>() {
  
        @Override
				public final SQLPerfRequest create() {
          return new SQLPerfRequest();
        }
      }, 
      new ObjectDeleter<SQLPerfRequest>() {
    
        public boolean delete(SQLPerfRequest o) {
          final boolean canUseAgain = !o.isInError;
          if (canUseAgain) {
            o.clear();
          }
          return canUseAgain;
        }
        public void finalize(SQLPerfRequest o) {
          delete(o);
        }  
      },
      MAX_PERF_REQUEST);
    }
    
    public SQLPerfRequest getNew(String databaseName, String databaseDescription, String connectionUID, String physicalUID, boolean isBlockingRequest, boolean isTransaction, String request, Object[] arguments) {
      return super.getNew().init(databaseName, databaseDescription, connectionUID, physicalUID, isBlockingRequest, isTransaction, request, arguments);
    }
    
    private static final int MAX_PERF_REQUEST = 256;
  }
  private static final PerfRequestsPool perfRequestsPool = new PerfRequestsPool();
  
  public static final Builder nameDescriptionFormat = new AbstractBuilder() {

    @Override
    public StringBuilder format(Object obj, StringBuilder toAppendTo, FieldPosition pos) {
      if (obj instanceof SQLRequest) {
        final SQLRequest request = (SQLRequest)obj;
        return toAppendTo.append(StringUtil.firstCharUpperCase(request.getDatabaseName())).append("-").append(StringUtil.firstCharUpperCase(request.getDatabaseDescription()));
      }
      return toAppendTo;
    }    
  };
  
	public static class SQLPerfRequest implements SQLRequest {
    
    private static final IDGenerator sqlRequestIDS = new IDGenerator("SQLRID", 1, 2000000000);

		private SQLPerfRequest() {
		}
    
    private SQLPerfRequest init(String databaseName, String databaseDescription, String connectionUID, String physicalUID, boolean isBlockingRequest, boolean isTransaction, String request, Object[] arguments) {
      if (isWithAsTaskSQLRequest.booleanValue()) {
        this.asTask = new EzManualTask("sql");
        this.asTask.setContextParameter("sql", request);
        this.asTask.setContextParameter("args", ObjectArrays.toString(arguments));
        this.asTask.start();
      }
      this.isTraceActive = SimplePooledConnections.trace.isActive();
      this.currentThread = Thread.currentThread();
      this.currentTask = (this.asTask == null) ? EzTreeTask.findCurrentTask() : this.asTask.getParent();
      if (this.currentTask != null) {
        this.currentTask.setContextParameter("db.name", databaseName);
        this.currentTask.setContextParameter("db.description", databaseDescription);
        this.currentTask.setContextParameter("db.connectionUID", connectionUID);
        this.currentTask.setContextParameter("db.physicalUID", physicalUID);
      }
      this.start = StampUtil.getStampValue();
      this.databaseName = databaseName;
      this.databaseDescription = databaseDescription;
      this.connectionUID = connectionUID;
      this.physicalUID = physicalUID;
      this.request = request;
      this.url = this.currentTask.getContextParameter("session.uri");
      if (this.currentTask != null) {
        this.currentTask.setLongTask(isBlockingRequest);
      }
      this.isBlockingRequest = isBlockingRequest;
			this.arguments = ObjectArrays.toString(arguments);
      this.id = sqlRequestIDS.getNewID();
      this.state = SQLExecutionState.PREPARE;
			getStack().push(this);
			reference.add(this);
			return this;
		}
    
		private SQLPerfRequest clear() {
			reference.remove(this);
      if (this.asTask != null) this.asTask.end();
      this.asTask = null;
      this.state = SQLExecutionState.FINISH;
      this.currentThreadStack = null;
      this.currentThread = null;
      if (this.currentTask != null) {
        this.currentTask.setLongTask(false);
      }
      this.currentTask = null;
      this.currentStatement = null;
      this.connectionUID = null;
      this.physicalUID = null;
      this.request = null;
      this.url = null;
      this.arguments = "";
			this.start = 0;
			this.inside = 0;
			this.preparation = 0;
			this.execution = 0;
			this.duration = 0;
			this.traitement = 0;   
			this.errorMessage = null;
			this.isInError = false;
			this.isBlockingRequest = false;
      return this;
		}
    
    public void fireLog() {
			if (isTraceActive) {
        SimplePooledConnections.trace.traceln((url == null ? "" : url + " >>> ")+"(" + databaseName + "-" + databaseDescription + "(" + (isTransaction ? "" : "R") + ")" + ")" + request + "[" + arguments + "]");
      }
		}
    
    public void fireEndPreparation(Statement s) {
      final long endPreparation = StampUtil.getStampValue();
      this.currentStatement = s;
      this.state = SQLExecutionState.EXECUTE;
      this.preparation = endPreparation - this.start - this.inside;
		}
    
		public void fireEndExecution() {
			final long endExecution = StampUtil.getStampValue();
      this.state = SQLExecutionState.READ;
			this.execution = endExecution - this.start - this.preparation - this.inside;
		}
    
		public void fireEnd(int nbRequest, String method) {
			final long end = StampUtil.getStampValue();
      this.state = SQLExecutionState.FINISH;
			this.duration = end - start - inside;
			this.traitement = this.duration - execution - preparation;
			final Stack<SQLPerfRequest> stack = getStack();
			stack.pop();
			if (stack.size() > 0) {
				stack.peek().inside += this.duration;
			}
      reference.addRequest(this.isBlockingRequest, this.isTransaction, this.request, this.duration, this.preparation, this.execution, this.traitement, nbRequest, method, this.arguments);
      if (this.asTask != null) this.asTask.end();
      this.asTask = null;
      currentThread = null;
      currentThreadStack = null;
      if (this.currentTask != null) {
        this.currentTask.setLongTask(false);
      }
      currentTask = null;
      currentStatement = null;
      reference.remove(this);
		}

		public void fireError(final Throwable e) {
      if (this.asTask != null) {
        this.asTask.end();
      }
      this.asTask = null;
      this.isInError = true;
			this.errorMessage = ExceptionUtils.getMessage(e);
      this.currentThread = null;
      this.currentThreadStack = null;
      if (this.currentTask != null) {
        this.currentTask.setLongTask(false);
      }
      this.currentTask = null;
      this.currentStatement = null;
      Throwable loggedException;
      if (url == null) {
        loggedException = e;
      }
      else {
        loggedException = new Exception() {
          @Override
          public void printStackTrace(PrintWriter s) {
            if (e != null) {
              e.printStackTrace(s);
            }
          }
          @Override
          public String toString() {
            return " uri=" + url + (e != null ? " " + e.toString() : "");
          }
        };
      }
			SimplePooledConnections.log(databaseName, databaseDescription, loggedException, request, arguments);
			reference.addError(this);
		}

    public String getDatabaseFullName() {
      return SQLPerfmeter.nameDescriptionFormat.format(this);
    }

    public String getDatabaseName() {
      return databaseName;
    }

    public String getDatabaseDescription() {
      return databaseDescription;
    }

    public boolean isTransaction() {
      return isTransaction;
    }

    public DateAccessor getStart() {
      return new SimpleDateAccessor(start);
    }

    public String getRequest() {
      return this.request;
    }

    public String getArguments() {
      return this.arguments;
    }

    public boolean hasError() {
      return errorMessage == null;
    }

    public String getErrorMessage() {
      return errorMessage;
    }

    public String getID() {
      return this.id;
    }

    public SQLExecutionState getState() {
      return this.state;
    }

    public boolean isBlockingRequest() {
      return isBlockingRequest;
    }

    public Thread getAssociedThread() {
      return this.currentThread;
    }

    public EzTreeTask<?> getAssociedTask() {
      return this.currentTask;
    }
    
    public boolean cancel() {
      try {
        final Statement currentStatement = this.currentStatement;
        if (currentStatement != null) {
          this.state = SQLExecutionState.CANCEL;
          currentStatement.cancel();
        }
        return true;
      }
      catch (Throwable ignored) {
        EasyRMS.trace.log(ignored, true);
      }
      return false;
    }
    public String getConnectionUID() {
      return connectionUID;
    }
    
    public String getPhysicalUID() {
      return physicalUID;
    }
    public String getAssociedThreadStack() {
      final Thread currentThread = this.currentThread;
      if (currentThread != null) {
        final StringBuilderThreadPool stringBuilderThreadPool = StringBuilderThreadPool.threadPools.get();
        final StringBuilder buf = stringBuilderThreadPool.get();
        try {
          buf.append(currentThread.getName()).append("\r\n");
          final StackTraceElement[] currentThreadStack = this.currentThreadStack;
          if (currentThreadStack != null) {
            for (int i = 0, n = currentThreadStack.length; i < n; i++) {
              final StackTraceElement e = currentThreadStack[i];
              buf.append(e.getClassName()).append(".").append(e.getMethodName()).append(".line(").append(e.getLineNumber()).append(")\r\n");
            }
            return buf.toString();
          }
        }
        finally {
          stringBuilderThreadPool.free(buf); 
        }
      }
      return null;
    }
		
		private String request = null;
    private String url = null;
    private long start = 0;
		private long inside = 0;
		private long preparation = 0;
		private long execution = 0;
		private long duration = 0;
		private long traitement = 0;   
		private String arguments = ""; 
		private String errorMessage = null;
		private boolean isInError = false;
		private Thread currentThread = null;
    private StackTraceElement[] currentThreadStack;
    private EzTreeTask<?> currentTask = null;
    private EzManualTask asTask = null;
    private Statement currentStatement = null;
    private SQLExecutionState state = null;
    private String id = null;
    private String databaseName = null;
    private String connectionUID = null;
    private String physicalUID = null;
    private String databaseDescription = null;
    private boolean isBlockingRequest;
    private boolean isTraceActive;
    private boolean isTransaction;
    

		private static final ThreadLocal<Stack<SQLPerfRequest>> stack = new ThreadLocal<Stack<SQLPerfRequest>>() {
      
			@Override
			public Stack<SQLPerfRequest> initialValue() {
				return new Stack<SQLPerfRequest>();
			}
		}; 
    
		private static Stack<SQLPerfRequest> getStack() {
			return stack.get();
		}    
	}
  
  private static final EzFlag isWithAsTaskSQLRequest = new EzFlag("SQL Request As Task", PropertiesUtil.getBoolean("com.easyrms.db.SQLPerfmeter.isWithAsTaskSQLRequest", true));
  private static final Counter allRequest = new Counter("SQL Request All Request");
  private static final Counter withcommentRequest = new Counter("SQL Request With Comment Request");
}
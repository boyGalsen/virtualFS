package com.easyrms.db;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.ezjmx.*;

import oracle.jdbc.pool.*;

import java.util.concurrent.*;



public class EzJDBCDatabase implements EzDBDatabase, Comparable<EzJDBCDatabase> {

  public EzJDBCDatabase(String URL) {
    this(URL, URL, URL);
  }
  public EzJDBCDatabase(String name, String description, String URL) {
    this(name, description, URL, false, 1, 0);
  }
  public EzJDBCDatabase(String name, String description, String URL, boolean isPooled, int maxSimultaneousConnections, int maxSimultaneousExecutes) {
    this(name, description, URL, isPooled, maxSimultaneousConnections, maxSimultaneousExecutes, false);
  }
  public EzJDBCDatabase(String name, String description, String URL, boolean isPooled, int maxSimultaneousConnections, int maxSimultaneousExecutes, boolean isSoftDatabase) {
    count.inc();
    this.name = name;
    this.description = description;
    this.URL = URL;
    this.isPooled = isPooled;
    this.maxSimultaneousConnections = Math.max(maxSimultaneousConnections, 1);
    this.maxSimultaneousExecutes = maxSimultaneousExecutes;
    this.executePermits = new Semaphore(maxSimultaneousExecutes,true);
    this.asArray = new EzArray.AsArray<EzJDBCDatabase>(this);
    this.isSoftDatabase = isSoftDatabase;
  }
  
  public String getName() { 
    return name; 
  }
  public String getDescription() { 
    return description; 
  }
  
  @Deprecated
  public String getURL() { 
    return URL; 
  }
  
  public boolean isSoftDatabase() {
    return isSoftDatabase;
  }
  
  public EzJDBCConnection openAccess() { 
    return new EzJDBCConnection(this, maxSimultaneousConnections); 
  }
  public EzJDBCTransaction openTransaction() { 
    return new EzJDBCTransaction(this); 
  }
  
  public int getMaxSimultaneousConnections() { 
    return maxSimultaneousConnections; 
  }
  public int getMaxSimultaneousExecutes() { 
    return maxSimultaneousExecutes; 
  }
  
  public EzArray<EzJDBCDatabase> asArray() { 
    return asArray; 
  }
  
  EzJDBCPhysicalConnection getNewConnection() {
    return new EzJDBCPhysicalConnection(SimpleConnections.getConnection(name, description, URL, isPooled, isSoftDatabase)); 
  }
  EzJDBCPhysicalConnection getGlobalConnection() {
    synchronized (globalConnectionLock) {
      if (globalConnection == null) {
        globalConnection = new EzJDBCPhysicalConnection(SimpleConnections.getConnection(name, description, URL, false, isSoftDatabase));
      }
      return globalConnection;
    }
  }  
  boolean isGlobalConnection(EzJDBCPhysicalConnection connection) {
    synchronized (globalConnectionLock) {
      return (globalConnection == connection);
    }
  }  

  public int compareTo(EzJDBCDatabase other) {
    if (other == null) {
      return -1;
    }
    if (URL == null) {
      return 1;
    }
    return URL.compareTo(other.URL);
  }

  public EzDBDatabasePoolStatus getPoolStatus() {
    if (isPooled) {
      try {
        final OracleConnectionCacheManager oracle = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
        final int activeConnection = oracle.getNumberOfActiveConnections(URL);
        final int availableConnection = oracle.getNumberOfAvailableConnections(URL);
        return new EzDBDatabasePoolStatus() {
  
          public boolean isPooled() { 
            return true; 
          }
          
          public int getNumberOfActiveConnections() { 
            return activeConnection; 
          }
          public int getNumberOfAvailableConnections() { 
            return availableConnection; 
          }
        };
      }
      catch (Throwable ignored) {
      }
    }
    return noDatabaseEzDBDatabasePoolStatus;
  }

  public boolean refresh(boolean refreshAllConnection) {
    return SimpleConnections.refresh(URL, refreshAllConnection);
  }
  
  void takeLock() {
    if (maxSimultaneousExecutes > 0) { 
      try {
        executePermits.acquire();
      }
      catch (InterruptedException e) {
        throw ExceptionUtils.newRuntimeException(e);
      }
    }
  }
  void releaseLock() {
    if (maxSimultaneousExecutes > 0) { 
      executePermits.release();
    }
  }
  
  @Override
  public String toString() { 
    return StringComparator.NVL(name, URL); 
  }

  @Override
  protected void finalize() throws Throwable {
    SQLUtils.rollback(globalConnection);
    SQLUtils.close(globalConnection);
    count.dec();
    super.finalize();
  }

  private final String name;
  private final String description;
  private final String URL;
  private final boolean isPooled;
  private final int maxSimultaneousConnections;
  private final boolean isSoftDatabase;
  
  private final int maxSimultaneousExecutes;
  private final Semaphore executePermits;

  private EzJDBCPhysicalConnection globalConnection;
  private final EzArray<EzJDBCDatabase> asArray;
  private final Object globalConnectionLock = new Object();

  public static final Trace trace = new Trace("SQL Traces", PropertiesUtil.getBoolean("EZRMS_TRACE", false));
  public static final EzFlag pool = new EzFlag("Pooled Connections", PropertiesUtil.getBoolean("ORACLE_POOL", true));
  public static final EzFlag callTimeOutFlag = new EzFlag("Oracle Calls With Timeout", PropertiesUtil.getBoolean("com.ezrms.core.db.SimpleRequest.callTimeOutFlag", false));
  public static final EzFlag queryTimeOutFlag = new EzFlag("Oracle Queries With Timeout", PropertiesUtil.getBoolean("com.ezrms.core.db.SimpleRequest.queryTimeOutFlag", false));
  public static final EzFlag prefetchFlag = new EzFlag("Oracle Queries Prefetch", PropertiesUtil.getBoolean("com.ezrms.core.db.SimpleRequest.prefetchFlag", true));

  private static final Counter count = new Counter("EzJDBCDatabase");
  
  static final int minLimit = PropertiesUtil.getInt("com.easyrms.db.OracleConnectionPool.minLimit", 50);
  static final int maxLimit = PropertiesUtil.getInt("com.easyrms.db.OracleConnectionPool.maxLimit", 1000);
  static final int maxStatementsLimit = PropertiesUtil.getInt("com.easyrms.db.OracleConnectionPool.maxStatementsLimit", 10);
  static final boolean withRollBack = PropertiesUtil.getBoolean("com.easyrms.db.OracleConnectionPool.withRollBack", true);
  static final boolean withTransactionRollBack = PropertiesUtil.getBoolean("com.easyrms.db.OracleConnectionPool.withTransactionRollBack", true);
  static final int garbageLimit = PropertiesUtil.getInt("com.easyrms.db.OracleConnectionPool.garbageLimit", 0);
//  static final int inactivityTimeout = PropertiesUtil.getInt("com.easyrms.db.OracleConnectionPool.inactivityTimeout", 300);
  static final int queryTimeOut = PropertiesUtil.getInt("com.ezrms.core.db.SimpleRequest.queryTimeOut", 500);
  static final int callTimeOut = PropertiesUtil.getInt("com.ezrms.core.db.SimpleRequest.callTimeOut", 500);
  static final int splitLimit = PropertiesUtil.getInt("com.ezrms.core.db.SimpleBulk.splitLimit", 10000);
}

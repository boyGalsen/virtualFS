package com.easyrms.db;

import com.easyrms.util.*;

import javax.sql.*;
import java.sql.*;


public class Database {

  public Connection getConnection() {
    if (defaultPool == null) throw new IllegalStateException();
    try {
      return defaultPool.getConnection();
    }
    catch (Exception ignored) {
      EasyRMS.trace.log("DB", ignored);
      throw ExceptionUtils.newRuntimeException(ignored);
    }
  }

  public DataSource getDefaultDataSource() {
    return defaultPool;
  }
  protected void setDefaultDataSource(DataSource pool) {
    defaultPool = pool;
  }

  private DataSource defaultPool;
}
package com.easyrms.db;

import com.easyrms.cache.*;
import com.easyrms.util.*;

import java.sql.*;


public class EzDBArrayReader<T> extends EzDBResultSetListener implements Creator<ResultSet, T>, ObjectReference<EzArray<T>> {

  public EzDBArrayReader() {
    super();
    this.creator = null;
  }
  public EzDBArrayReader(String request, Object... parameters) {
    super(request, parameters);
    this.creator = null;
  }
  public EzDBArrayReader(Creator<ResultSet, T> creator) {
    super();
    this.creator = creator;
  }
  public EzDBArrayReader(Creator<ResultSet, T> creator, String request, Object... parameters) {
    super(request, parameters);
    this.creator = creator;
  }
  public EzDBArrayReader(EzDBDatabase database) {
    super(database);
    this.creator = null;
  }
  public EzDBArrayReader(EzDBDatabase database, String request, Object... parameters) {
    super(database, request, parameters);
    this.creator = null;
  }
  public EzDBArrayReader(EzDBDatabase database, Creator<ResultSet, T> creator) {
    super(database);
    this.creator = creator;
  }
  public EzDBArrayReader(EzDBDatabase database, Creator<ResultSet, T> creator, String request, Object... parameters) {
    super(database, request, parameters);
    this.creator = creator;
  }

  public final EzArray<T> get() {
    init();
    return objects;
  }
  public EzArray<T> get(EzDBDatabase database) {
    query(database);
    return get();
  }
  public EzArray<T> get(EzDBDatabase database, Object... parameters) {
    query(database, parameters);
    return get();
  }
  public EzArray<T> get(EzDBConnection connection) {
    query(connection);
    return get();
  }
  public EzArray<T> get(EzDBConnection connection, Object... parameters) {
    query(connection, parameters);
    return get();
  }
  
  @Override
  public void init(ResultSet v) throws SQLException {
    super.init(v);
    isDefined = true;
  }

  @Override
  public final void set(int i, ResultSet v) throws SQLException {
    try {
      final T t = create(v);
      if (check(t)) {
        objects.add(t);
      }
    }
    catch (Throwable exception) {
      EasyRMS.trace.log(exception);
    }
  }
    
  public final boolean isNull() {
    return objects.isEmpty();
  }
  
  public final boolean isDefined() {
    return isDefined;
  }

  public void init() {
    if (!isDefined()) {
      query();
    }
  }
  
  public void reset() {
    isDefined = false;
    objects.clear();
  }
  
  public T create(ResultSet key) throws Exception {
    return creator.create(key);
  }

  protected boolean check(T t) {
    return true;
  }
  
  private final Creator<ResultSet, T> creator;
  private boolean isDefined;
  private final EzArrayList<T> objects = new EzArrayList<T>();
}

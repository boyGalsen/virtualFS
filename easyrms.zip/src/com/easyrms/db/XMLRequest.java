package com.easyrms.db;


import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.sql.*;


public class XMLRequest extends AbstractXMLStatement {
  
  public String getRequest() {
    return this.request;
  } 

  public void setRequest(String request) {
		this.request = (request.endsWith(";")) ? request.substring(0, request.length()-1) : request;
  }

  @Override
  protected XMLResponse loadResponse(EzDBConnection connection) throws Exception {
    final IntReference rowCount = new IntReference(0);
    final IntReference colCount = new IntReference(0);
    //final EzJDBCConnection connection = database.openAccess().getConnection();
    try {
      //boolean isReadOnly = connection.isReadOnly();
      //try {
        //connection.setAutoCommit(false);
        //connection.setReadOnly(true);
        //final Statement query = connection.createStatement();
        //if (query != null) {
      final BooleanReference isWithData = new BooleanReference(false);
          final StringBuilder buffer = StreamUtils.sqlStringBuilderPool.getNew();
          try {
            buffer.append("<RSET>\n");
            connection.query(request, new EzDBResultSetListener() {

              @Override
              public void init(ResultSet resultSet) throws SQLException {
                super.init(resultSet);
                final ResultSetMetaData meta = resultSet.getMetaData();
                buffer.append("<METADATA>\n");
                final int columnCount = meta.getColumnCount();
                colCount.setValue(columnCount);
                for (int i = 1; i <= columnCount; i++) {
                  final int type = meta.getColumnType(i);
                  buffer.append("<COL TYPE=\"").append(type)
                    .append("\" PRECISION=\"").append(meta.getPrecision(i))
                    .append("\" SCALE=\"").append(meta.getScale(i))
                    .append("\" NAME=\"").append(meta.getColumnName(i))
                    .append("\" DISPLAYSIZE=\"").append(meta.getColumnDisplaySize(i))
                    .append("\"/>");
                }
                buffer.append("</METADATA>\n");                
              }

              @Override
              public void set(int j, ResultSet resultSet) throws SQLException {
                final ResultSetMetaData meta = resultSet.getMetaData();
                
                if (j == 0) {
                  buffer.append("<DATA>\n");                
                  isWithData.setValue(true);
                }
                buffer.append("<ROW>");
                for (int i = 1, n = colCount.getValue(); i <= n; i++) {
                  if (i == 1) rowCount.setValue(j+1);
                  final Object object = resultSet.getObject(i);
                  if (object != null && !resultSet.wasNull()) {
                    buffer.append("<COL>");
                    if (object instanceof Number) {
                      if (meta.getScale(i) > 0 || meta.getPrecision(i) == 0){
                        buffer.append(((Number)object).doubleValue());
                      }
                      else {
                        buffer.append(((Number)object).longValue());
                      }
                    }
                    else if (object instanceof DateAccessor) {
                      buffer.append(dateFormat.format(((DateAccessor)object).toDate()));
                    }
                    else if (object instanceof java.util.Date) {
                      buffer.append(dateFormat.format(object));
                    }
                    else {
                      cdataFormat.format(object.toString(), buffer, null);
                    }
                    buffer.append("</COL>");
                  }
                  else {
                    buffer.append("<COL NULL=\"YES\"/>");
                  }                     
                }
                buffer.append("</ROW>\n");
              }
            
          });
            if (isWithData.getValue()) {
              buffer.append("</DATA>\n");
            }
            buffer.append("</RSET>\n");
           return new XMLResponse(buffer.toString(), colCount.getValue(), rowCount.getValue());
          }
          finally {
          	StreamUtils.sqlStringBuilderPool.free(buffer);
          }
      }
      finally {
				//connection.close();
      }
    //throw new IllegalArgumentException(database+" connection return a null value");
  }
  
  @Override
  public String toString() {
    final String ID = getID();
    final StringBuilder buffer = new StringBuilder();
    buffer.append("<SQLREQUEST");
    if (StringComparator.isNotNull(ID)) buffer.append(" ID=\"").append(ID).append('"');
    buffer.append("><REQUEST><![CDATA[")
    	.append(request)
    	.append("]]></REQUEST></SQLREQUEST>");
    return buffer.toString();
  }
    
  private String request;
}
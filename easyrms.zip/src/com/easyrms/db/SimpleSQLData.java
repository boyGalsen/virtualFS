package com.easyrms.db;

import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;

import java.sql.*;
import java.util.*;


public abstract class SimpleSQLData extends AbstractSQLData {

  public String[] getIgnoredColumn() {
    return (ignored == null) 
      ? EmptyArrays.emptyStringArray
      : ignored.toArray(new String[ignored.size()]);
  }
  public void setIgnoredColumn(String[] columns) {
    if (ignored == null) {
      ignored = new ArrayList<String>();
    }
    else {
      ignored.clear();
    }
    ignored.addAll(Arrays.asList(columns));
  }
  public void setIgnoredColumn(int i, String column) {
    if (ignored == null) ignored = new ArrayList<String>();
    ignored.set(i, column);
  }
  public int getIgnoredColumnCount() {
    return (ignored == null) ? 0 : ignored.size();
  }
  
  public int[] getIgnoredColumnIndex() {
    return ignoredColumnsIndex;
  }
  
  @Override
	protected void initData(ResultSet v, EzArrayList<Object[]> data) throws SQLException {
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<String> header = arrayPool.get();
    final HashSetThreadPool setPool = HashSetThreadPool.threadPools.get();
    final HashSet<String> ignoredColumnsNames = setPool.get();
    final HashListThreadPool listPool = HashListThreadPool.threadPools.get();
    final HashList<Integer> ignoredColumnsIndex = listPool.get();
    try {
      final ResultSetMetaData meta = v.getMetaData();
      SQLWidth = meta.getColumnCount();
      if (ignored != null) {
        ignoredColumnsNames.addAll(ignored);
      }
      final int headerTitleCount = getHeaderTitleCount();
      for (int j = 0; j < SQLWidth; j++) {
        final String column = meta.getColumnLabel(j+1);
        if (ignoredColumnsNames.contains(column)) {
          if (isIngoredColumn == null) {
            isIngoredColumn = new boolean[SQLWidth];
          }
          isIngoredColumn[j] = true;
          ignoredColumnsIndex.add(IntegerCache.get(j));
        }
      }
      for (int i = 0; i < headerTitleCount; i++) {
        header.clear();
        for (int j = 0; j < SQLWidth; j++) {
          //if (isIngoredColumn == null || !isIngoredColumn[j]) {
            header.add(getHeaderTitle(i, j));
          //}
        }
        width = header.size();
        data.add(header.toArray(new String[width]));
      }
      if (isNeedToAddRequestTitles()) {
        header.clear();
        for (int i = 0; i < SQLWidth; i++) {
          //if (isIngoredColumn == null || !isIngoredColumn[i]) {
          final String column = meta.getColumnLabel(i+1);
          if (headerTitleCount > 0 && StringComparator.equals(column, getHeaderTitle(headerTitleCount-1, i))) {
            header.add(null);
          }
          else {
            header.add(column);
          }
          //}
        }
        width = header.size();
        data.add(header.toArray(new String[width]));
      }
      this.ignoredColumnsIndex = (ignoredColumnsIndex.size() == 0) ? null : IntArrays.valueOf(ignoredColumnsIndex.toArray(new Integer[ignoredColumnsIndex.size()]));
    }
    finally {
      listPool.free(ignoredColumnsIndex);
      setPool.free(ignoredColumnsNames);
      arrayPool.free(header);
    }
  }
  
  @Override
	protected void updateData(int i, ResultSet v, EzArrayList<Object[]> dataArray) throws SQLException {
    final Object[] line = new Object[width];
    for (int j = 0, k = 0; j < SQLWidth; j++) {
      //if (isIngoredColumn == null || !isIngoredColumn[j]) {
      line[k++] = SQLUtils.getObject(v, j+1);
      //}
    }
    dataArray.add(line);
  }
  
  @Override
	protected void closeData(EzArrayList<Object[]> data) {
    isIngoredColumn = null;
  }
  
  private ArrayList<String> ignored = null;
  private int[] ignoredColumnsIndex = null;
  private int SQLWidth;
  private int width;
  private boolean[] isIngoredColumn;
}

package com.easyrms.db;

import java.io.*;
import java.util.*;


public class XMLResponse {
  
  public static XMLResponse getResponse(String xml) {
    final Reader reader = new StringReader(xml);
    final XMLResponse response = new XMLResponse();
    try {
      try {
        final ResponseYyLex yy = new ResponseYyLex(reader);
        yy.setResponse(response);
        while ((yy.yylex()) != null) {}
      }
      finally {
        reader.close();
      }
    }
    catch(Exception exception) {
      return null;
    }
    return response;
  }
  
  public void add(String ID, String response) {
    if (responses.put(ID, response) == null) {
      IDs.add(ID);
    }
  }

  public String[] getResponse() {
    final int n = responses.size();
    final String[] responses = new String[n];
    for (int i = 0; i < n; i++) {
      responses[i] = getResponse(i);
    }
    return responses;
  }
  public String getResponse(int i) {
    return responses.get(IDs.get(i));
  }  
  public int getResponseCount() {
    return IDs.size();
  }

  public String[] getResponseID() {
    return IDs.toArray(new String[IDs.size()]);
  }
  public String getResponseID(int i) {
    return IDs.get(i);
  }
  public int getResponseIDCount() {
    return IDs.size();
  }
  
  public String findResponse(String ID) {
    return responses.get(ID);
  }
  
  final HashMap<String, String> responses = new HashMap<String, String>();
  final ArrayList<String> IDs = new ArrayList<String>();
}
package com.easyrms.db;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.math.*;
import java.sql.*;
import java.text.*;


public class SQLUtils {

  public static enum SQLErrorCategory {
    CONNECTION_ERROR,
    CRITICAL_ERROR,
    OTHER_ERROR;
  }
  
  public static SQLErrorCategory getSQLErrorCategory(String errorMessage) {
    errorMessage = StringComparator.NVL(errorMessage);
    if (errorMessage.indexOf("Closed Connection") >= 0
      || errorMessage.indexOf("No Connection") >= 0) 
    {
      return SQLErrorCategory.CONNECTION_ERROR;
    }
    if (errorMessage.indexOf("ORA-006") >= 0
      || errorMessage.indexOf("ORA-08") >= 0) 
    {
      return SQLErrorCategory.CRITICAL_ERROR;
    }
    return SQLErrorCategory.OTHER_ERROR;
  }
  
  public static boolean isOneModify(int modify) {
    return modify == 1;
  }
  
  public static boolean isOneOrZeroModify(int modify) {
    return modify == 1 || modify == 0;
  }
  
  public static long getSQLStateAsLong(SQLWarning warning) {
    final String state = warning.getSQLState();
    if (StringComparator.isInteger(state)) {
      return Long.parseLong(state);
    }
    return 0;
  }

  public static final String TRUESQLVALUE = "Y";
  public static final String FALSESQLVALUE = "N";
  
	public static String boolean2string(boolean flag) {
		return flag ? TRUESQLVALUE : FALSESQLVALUE;
	}
  
	public static String boolean2string(Boolean flag) {
		return (flag != null) ? boolean2string(flag.booleanValue()) : TRUESQLVALUE;
	}
  
  public static String boolean2string(Boolean flag, String nullValue) {
    return (flag != null) ? boolean2string(flag.booleanValue()) : nullValue;
  }

  public static String[] boolean2string(boolean[] flag) {
    final String[] flags = new String[flag.length];
    for (int i = 0, n = flag.length; i < n; i++) {
      flags[i] = boolean2string(flag[i]);
    }
    return flags;
  }
  
  public static java.sql.Date toSQLDate(DateAccessor accessor) {
    return (accessor != null) ? new java.sql.Date(accessor.getTime()) : null;
  }
  
  public static String[] boolean2string(Boolean[] flag) {
    final String[] flags = new String[flag.length];
    for (int i = 0, n = flag.length; i < n; i++) {
      flags[i] = boolean2string(flag[i]);
    }
    return flags;
  }
  
  public static String[] boolean2string(Boolean[] flag, String defaultValue) {
    final String[] flags = new String[flag.length];
    for (int i = 0, n = flag.length; i < n; i++) {
      flags[i] = boolean2string(flag[i], defaultValue);
    }
    return flags;
  }
  
  public static String normalizeTextToSQL(String value) {
    if (value == null) return null;
    return value.replace('\'','\u02B9');
  }
  
  public static String toString(Object[] source) {
    if (source == null) {
      return "";
    }
    final StringBuilderThreadPool stringBuilderThreadPool = StringBuilderThreadPool.threadPools.get();
    final StringBuilder buffer = stringBuilderThreadPool.get();
    try {
      for (int i = 0, n = source.length; i < n; i++) {
        final Object s = source[i];
        final String t = (s == null) ? null : s.toString();
        final String s2 = (t == null) ? "null" : t;
        if (i > 0) buffer.append(",");
        buffer.append("'");
        buffer.append(normalizeTextToSQL(s2));
        buffer.append("'");
      }
      return buffer.toString();
    }
    finally {
      stringBuilderThreadPool.free(buffer);
    }
  }


	public static Boolean getBoolean(ResultSet rset, int index) throws SQLException {
		return getBoolean(rset, index, null);
	}
	
  public static Character getCharacter(ResultSet rset, int index) throws SQLException {
    return getCharacter(rset, index, null);
  }
  public static Character getCharacter(ResultSet rset, int index, Character defaultValue) throws SQLException {
    final String value = getString(rset, index, null);
    return getCharacter(value, defaultValue);
  }
  public static Character getCharacter(String value) throws SQLException {
    return getCharacter(value, null);
  }
  public static Character getCharacter(String value, Character defaultValue) throws SQLException {
    return (value == null || value.length() != 1) ? defaultValue : Character.valueOf(value.charAt(0));
  }
  

  public static char getChar(ResultSet rset, int index) throws SQLException {
    return getChar(rset, index, ' ');
  }

  public static char getChar(ResultSet rset, int index, char defaultValue) throws SQLException {
    final String value = getString(rset, index, null);
    return getChar(value, defaultValue);
  }
  public static char getChar(String value) throws SQLException {
    return getChar(value, ' ');
  }
  public static char getChar(String value, char defaultValue) throws SQLException {
    return (value == null || value.length() != 1) ? defaultValue : value.charAt(0);
  }
	
  public static Boolean getBoolean(ResultSet rset, int index, Boolean defaultValue) throws SQLException {
    return getBoolean(getString(rset, index, null), defaultValue);
  }
  public static Boolean getBoolean(String value, Boolean defaultValue) {
    if (value == null) return defaultValue;
    return StringComparator.getBooleanValue(value, defaultValue);
  }

	public static Class<?> getClass(ResultSet rset, int index) throws SQLException {
		return getClass(rset, index, null);
	}		
  public static <T> Class<? extends T> getClass(ResultSet rset, int index, Class<T> defaultValue) throws SQLException {
    return getClass(rset, index, false, defaultValue);
  }
  public static <T> Class<? extends T> getClass(ResultSet rset, int index, boolean canBeNull, Class<T> defaultValue) throws SQLException {
    final String value = getString(rset, index, null);
		if (value == null) {
		  return canBeNull ? null : defaultValue;
		}
		try {
			return (Class<? extends T>)Class.forName(value);
		}
		catch (Exception ignored) {
      EasyRMS.trace.log("SQLUtils", "Cannot found "+value, true);
      EasyRMS.trace.log("SQLUtils", ignored, true);
			return defaultValue;
		}
	}
	
	public static boolean getBooleanValue(ResultSet rset, int index) throws SQLException {
		return getBoolean(rset, index, Boolean.FALSE).booleanValue();
	}
	
	public static boolean getBooleanValue(ResultSet rset, int index, boolean defaultValue) throws SQLException {
		return getBoolean(rset, index, defaultValue ? Boolean.TRUE : Boolean.FALSE).booleanValue();
	}
  
	public static String getString(ResultSet rset, int index) throws SQLException {
		return getString(rset, index, null);
	}
  
  public static String getInternString(ResultSet rset, int index) throws SQLException {
    final String value = getString(rset, index, null);
    return (value == null) ? null : value.intern();
  }

  public static String getInternString(ResultSet rset, int index, String defaultValue) throws SQLException {
    final String value = getString(rset, index, defaultValue);
    return (value == null) ? null : value.intern();
  }


	public static Object getObject(ResultSet rset, int index) throws SQLException {
		return getObject(rset, index, null);
	}
	
	public static Object getObject(ResultSet rset, int index, Object defaultValue) throws SQLException {
		final Object value = rset.getObject(index);
		return rset.wasNull() ? defaultValue : value;
	}
  
	public static String getString(ResultSet rset, int index, String defaultValue) throws SQLException {
		final String value = rset.getString(index);
		return rset.wasNull() ? defaultValue : value;
	}
  
	public static Integer getInteger(ResultSet rset, int index) throws SQLException {
		return getInteger(rset, index, null);
	}
  
	public static Integer getInteger(ResultSet rset, int index, Integer defaultValue) throws SQLException {
		final int value = rset.getInt(index);
		return rset.wasNull()	? defaultValue : IntegerCache.get(value);
	}
  
  public static long getLong(ResultSet rset, int index) throws SQLException {
    return getLong(rset, index, 0);
  }
  
  public static long getLong(ResultSet rset, int index, long defaultValue) throws SQLException {
    final long value = rset.getLong(index);
    return rset.wasNull() ? defaultValue : value;
  }
  
  public static Long getLONG(ResultSet rset, int index) throws SQLException {
    return getLONG(rset, index, null);
  }
  
  public static Long getLONG(ResultSet rset, int index, Long defaultValue) throws SQLException {
    final long value = rset.getLong(index);
    return rset.wasNull() ? defaultValue : MathUtils.getLong(value);
  }
  
	public static int getInt(ResultSet rset, int index) throws SQLException {
		return getInt(rset, index, 0);
	}

	public static int getInt(ResultSet rset, int index, int defaultValue) throws SQLException {
		final int value = rset.getInt(index);
		return rset.wasNull() ? defaultValue : value;
	}  
	
	public static double getDouble(ResultSet rset, int index) throws SQLException {
		return getDouble(rset, index, 0.0);
	}
  
	public static double getDouble(ResultSet rset, int index, double defaultValue) throws SQLException {
		final double value = rset.getDouble(index);
		return rset.wasNull() ? defaultValue : value;
	}
  
  public static Double getDOUBLE(ResultSet rset, int index) throws SQLException {
    return getDOUBLE(rset, index, null);
  }
  
  public static Double getDOUBLE(ResultSet rset, int index, Double defaultValue) throws SQLException {
    final double value = rset.getDouble(index);
    return rset.wasNull() ? defaultValue : MathUtils.getDouble(value);
  }
  
  public static BigInteger getBigInteger(ResultSet rset, int index) throws SQLException {
    return getBigInteger(rset, index, null);
  }
  
  public static BigInteger getBigInteger(ResultSet rset, int index, BigInteger defaultValue) throws SQLException {
    final BigDecimal intermediateValue = getBigDecimal(rset, index);
    return (intermediateValue == null ? defaultValue : intermediateValue.toBigInteger());
  }
  
  public static BigDecimal getBigDecimal(ResultSet rset, int index) throws SQLException {
    return getBigDecimal(rset, index, null);
  }
  
  public static BigDecimal getBigDecimal(ResultSet rset, int index, BigDecimal defaultValue) throws SQLException {
    final BigDecimal value = rset.getBigDecimal(index);
    return rset.wasNull() ? defaultValue : value;
  }
  
  public static String getNString(ResultSet rset, int index) throws SQLException {
    return getNString(rset, index, null);
  }
  
  public static String getNString(ResultSet rset, int index, String defaultValue) throws SQLException {
    final String value = rset.getNString(index);
    return rset.wasNull() ? defaultValue : value;
  }

  public static EzDate getEzDate(ResultSet rset, int index) throws SQLException {
		return getEzDate(rset, index, null);
	}
  
	public static EzDate getEzDate(ResultSet rset, int index, EzDate defaultValue) throws SQLException {
		final int value = rset.getInt(index);
		if (rset.wasNull()) {
		  return defaultValue;
		}
		return (value == EzDate.ever.getDay()) 
		  ?  EzDate.ever 
		  : (value < EzDate.firstEzDate.getDay()) ?	defaultValue : EzDate.valueOf(value);
	}

	public static DateAccessor getDate(ResultSet rset, int index) throws SQLException {
		return getDate(rset, index, null);
	}
	
	public static DateAccessor getDate(ResultSet rset, int index, DateAccessor defaultValue) throws SQLException {
		final Timestamp date = rset.getTimestamp(index);
		return (date == null) ? defaultValue : new SimpleDateAccessor(date.getTime()); 
	}

  public static String getSQLClassName(int column, ResultSetMetaData metaData) throws SQLException {
    return getSQLClassName(metaData.getColumnType(column), metaData.getScale(column), metaData.getPrecision(column));
  }
  
  public static String getSQLClassName(int type, int scale, int precision) throws SQLException{
    return getSQLClass(type, scale, precision).getName();
  }

  public static Class<?> getSQLClass(int column, ResultSetMetaData metaData) throws SQLException {
    return getSQLClass(metaData.getColumnType(column), metaData.getScale(column), metaData.getPrecision(column));
  }
  
  public static boolean close(Connection connection) {
		if (connection == null) return false;
  	try {
	  	connection.close();
	  	return true;
  	}
  	catch (Throwable ignored) {
  		EasyRMS.trace.log("SQLUtils", ignored, true);
			return false;
  	}
  }
  
  public static boolean close(EzJDBCPhysicalConnection connection) {
    if (connection == null) return false;
    try {
      connection.close();
      return true;
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
      return false;
    }
  }

	public static boolean close(CallableStatement statement) {
		if (statement == null) return false;
		try {
			statement.close();
			return true;
		}
		catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
			return false;
		}
	}

  public static boolean close(PreparedStatement statement) {
    if (statement == null) return false;
    try {
      statement.close();
      return true;
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
      return false;
    }
  }

  
  public static boolean commit(Connection connection) {
		if (connection == null) return false;
		try {
			connection.commit();
			return true;
		}
		catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
			return false;
		}
	}
  
  public static boolean commit(EzJDBCPhysicalConnection connection) {
    if (connection == null) return false;
    try {
      connection.commit();
      return true;
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
      return false;
    }
  }

	public static boolean rollback(Connection connection) {
		if (connection == null) return false;
		try {
			connection.rollback();
			return true;
		}
		catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
		}
    return false;
	}
  
  public static boolean rollback(EzJDBCPhysicalConnection connection) {
    if (connection == null) return false;
    try {
      connection.rollback();
      return true;
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log("SQLUtils", ignored, true);
    }
    return false;
  }

	public static Class<?> getSQLClass(int type, int scale, int precision) throws SQLException{
    switch (type) {
      case Types.ARRAY: throw new SQLException("Array not mapped yet");
      case Types.BIGINT: return Long.class;
      case Types.BINARY: throw new SQLException("Binary not mapped yet");
      case Types.BIT: return Byte.class;
      case Types.BLOB: throw new SQLException("Blob not mapped yet");
      case Types.BOOLEAN: return Boolean.class;
      case Types.CHAR: return String.class;
      
      case Types.CLOB: throw new SQLException("Clob not mapped yet");
      case Types.DATALINK: throw new SQLException("Datalink not mapped yet");
      case Types.DATE: return java.sql.Date.class;
      case Types.DECIMAL: return Double.class;
      case Types.DISTINCT: throw new SQLException("Distinc not mapped yet");
      case Types.DOUBLE: return Double.class;
      case Types.FLOAT: return Double.class;
      case Types.INTEGER: return Integer.class;

      case Types.JAVA_OBJECT: throw new SQLException("Java Object not mapped yet");
      case Types.LONGVARBINARY: throw new SQLException("Long var binary not mapped yet");
      case Types.LONGNVARCHAR: return String.class;
      case Types.LONGVARCHAR: return String.class;
      case Types.NULL: return null;
      case Types.NUMERIC: return (scale > 0 || precision == 0) ? Double.class : Integer.class;
      case Types.OTHER: throw new SQLException("Other not mapped yet");
      case Types.REAL: return Double.class;
      case Types.REF: throw new SQLException("Ref not mapped yet");
      case Types.SMALLINT: return Integer.class;
      case Types.STRUCT: throw new SQLException("Struct not mapped yet");
      case Types.TIME: return java.sql.Time.class;
      case Types.TIMESTAMP: return java.sql.Timestamp.class;
      case Types.TINYINT: return Integer.class;
      case Types.VARBINARY: throw new SQLException("Varbinary not mapped yet");
      case Types.VARCHAR: return String.class;
      default: throw new SQLException("Not a valid type");
    }    
  }  

  public static Object getSQLObjectValue(String value, int type, int scale, int precision) throws SQLException{
    switch (type) {
      case Types.ARRAY: throw new SQLException("Array not mapped yet");
      case Types.BIGINT: return Long.valueOf(value);
      case Types.BINARY: throw new SQLException("Binary not mapped yet");
      case Types.BIT: return Byte.decode(value);
      case Types.BLOB: throw new SQLException("Blob not mapped yet");
      case Types.BOOLEAN: return Boolean.valueOf(value);
      case Types.CHAR: return value;
      
      case Types.CLOB: throw new SQLException("Clob not mapped yet");
      case Types.DATALINK: throw new SQLException("Datalink not mapped yet");
      case Types.DATE: return parseDate(value);
      case Types.DECIMAL: return Double.valueOf(value);
      case Types.DISTINCT: throw new SQLException("Distinc not mapped yet");
      case Types.DOUBLE: return Double.valueOf(value);
      case Types.FLOAT: return Double.valueOf(value);
      case Types.INTEGER: return Integer.valueOf(value);

      case Types.JAVA_OBJECT: throw new SQLException("Java Object not mapped yet");
      case Types.LONGVARBINARY: throw new SQLException("Long var binary not mapped yet");
      case Types.LONGNVARCHAR: return value;
      case Types.LONGVARCHAR: return value;
      case Types.NULL: return null;
      case Types.NUMERIC: {
      	try {
					final Number number = decimalFormatParse(value);
					return (scale > 0 || precision == 0) 
						? (Object)MathUtils.getDouble(number.doubleValue())
					  : (Object)IntegerCache.get(number.intValue());
      	}
      	catch (ParseException parseException) {
      		throw new SQLException(ExceptionUtils.getMessage(parseException)); 
      	}
      }
      case Types.OTHER: throw new SQLException("Other not mapped yet");
      case Types.REAL: return Double.valueOf(value);
      case Types.REF: throw new SQLException("Ref not mapped yet");
      case Types.SMALLINT: return Integer.valueOf(value);
      case Types.STRUCT: throw new SQLException("Struct not mapped yet");
      case Types.TIME: return parseTime(value);
      case Types.TIMESTAMP: return parseTimestamp(value);
      case Types.TINYINT: return Integer.valueOf(value);
      case Types.VARBINARY: throw new SQLException("Varbinary not mapped yet");
      case Types.VARCHAR: return value;
      default: throw new SQLException("Not a valid type");
    }
  }
  
  public static boolean isInteger(int column, ResultSetMetaData meta) throws SQLException {
    return isInteger(meta.getColumnType(column), meta.getScale(column));
  }

  public static boolean isNumber(int column, ResultSetMetaData meta) throws SQLException {
    return isNumber(meta.getColumnType(column), meta.getScale(column));
  }
  
  public static boolean isDecimal(int column, ResultSetMetaData meta) throws SQLException {
    return isDecimal(meta.getColumnType(column), meta.getScale(column));
  }

  public static boolean isDate(int column, ResultSetMetaData meta) throws SQLException {
    return isDate(meta.getColumnType(column), meta.getScale(column));
  }

  
  public static boolean isInteger(int type, int scale) {
    switch (type) {
      case Types.BIGINT: return true;
      case Types.INTEGER: return true;
      case Types.NUMERIC: return (scale <= 0);
      case Types.SMALLINT: return true;
      case Types.TINYINT: return true;
      default: return false;
    }
  }
  
  public static boolean isNumber(int type, int scale) {
    switch (type) {
      case Types.DECIMAL: return true;
      case Types.DOUBLE: return true;
      case Types.FLOAT: return true;
      case Types.NUMERIC: return true ;
      case Types.REAL: return true;
      case Types.BIGINT: return true;
      case Types.INTEGER: return true;
      case Types.SMALLINT: return true;
      case Types.TINYINT: return true;      
      default: return false;
    }
  }
  
  public static boolean isDecimal(int type, int scale) {
    switch (type) {
      case Types.DECIMAL: return true;
      case Types.DOUBLE: return true;
      case Types.FLOAT: return true;
      case Types.NUMERIC: return (scale > 0);
      case Types.REAL: return true;
      default: return false;
    }
  }

  public static boolean isDate(int type, int scale) {
    switch (type) {
      case Types.TIME: return true;
      case Types.TIMESTAMP: return true;
      case Types.DATE: return true;
      default: return false;
    }
  }

  private static DateAccessor parseDate(String text) throws SQLException {
    try {
      final DateAccessor result = dateFormatParse(text);
      if (result == null) return null;
      return result;
    }
    catch (ParseException exception) {
      throw new SQLException(ExceptionUtils.getMessage(exception));
    }
  }

  private static java.sql.Time parseTime(String text) throws SQLException {
    try {
      final DateAccessor result = dateFormatParse(text);
      if (result == null) return null;
      return new java.sql.Time(result.getTime());
    }
    catch (ParseException exception) {
      throw new SQLException(ExceptionUtils.getMessage(exception));
    }
  }

  private static java.sql.Timestamp parseTimestamp(String text) throws SQLException {
    try {
      final DateAccessor result = dateFormatParse(text);
      if (result == null) return null;
      return new java.sql.Timestamp(result.getTime());
    }
    catch (ParseException exception) {
      throw new SQLException(ExceptionUtils.getMessage(exception));
    }
  }

  private static final DateAccessor dateFormatParse(String obj) throws ParseException {
    return ebXMLDateFormat.referenceParse(obj);
  }
  
  private static final Number decimalFormatParse(String obj) throws ParseException {
    synchronized (decimalFormatX) {
      return decimalFormatX.parse(obj);
    }
  }
  public static String getInOrNotInClause(String field, String[] options, boolean isIn) {
    final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
    final StringBuilder buffer = bufferPool.get();
    try {
      final int idsLength = options.length;
      buffer.append(' ');
      if (idsLength > 900) {
        buffer.append('(');
      }
      for (int i = 0, j = 0; j < idsLength; j++, i++) {
        if (i >= 900) {
          buffer.append(") ").append(isIn ? "or " : "and ");
          i = 0;
        }
        if (i == 0) {
          buffer.append(field);
          if (!isIn) buffer.append(" not");
          buffer.append(" in (")
          .append("'"+options[j]+"'");
        }
        else {
          buffer.append(',').append("'"+options[j]+"'");
        }
      }
      buffer.append(')');
      if (idsLength > 900) {
        buffer.append(')');
      }
      buffer.append(' ');
      return buffer.toString();
    }
    finally {
      bufferPool.free(buffer);
    }
  }
  private static final NumberFormat decimalFormatX = new DecimalFormat();
}
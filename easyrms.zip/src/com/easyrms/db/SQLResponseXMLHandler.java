package com.easyrms.db;


import com.easyrms.date.ebXMLDateBuilder;
import com.easyrms.util.comparator.StringComparator;
import com.easyrms.util.xml.*;

import java.io.Reader;
import java.sql.*;

import org.xml.sax.*;


public class SQLResponseXMLHandler extends SimpleXMLHandler {

  public SQLResponseXMLHandler() {
    this.setAutoValueReset(true);
    this.setIgnoreWhitespace(true);
  }

	public synchronized final SimpleResultSet getProxyResultSet(Reader reader) throws SQLException {
		try {
			load(reader);
			return getProxyResultSet();		
		}
    catch (SQLException sqlException) {
      throw sqlException;
    }
		catch (Throwable ignored) {
			throw new SQLException(ignored);
		}
		finally {
			reset();
		}
	}

  public SimpleResultSet getProxyResultSet() throws SQLException {
    if (withError) throw sqlException;
    return resultSet;
  }

  @Override
  public void extendStartElement(String namespaceURI, String localName, String qName, Attributes atts) throws Exception {
    localName = StringComparator.NVL(localName, qName).intern();
    if (SQLResponse == localName) {
      isInMetaData = false;
      isInData = false;
      resultSet = null;
      metaData = null;
      sqlRequest = null;
      try {
        executionTime = ebXMLDateBuilder.referenceParse(atts.getValue("STARTTIME")).getTime();
      }
      catch (Exception e) {
        executionTime = -1;
      }
      withError = "YES".equals(atts.getValue(SQLResponseAttrWithError));
      sqlException = new SQLException("WITH ERROR QUERY");
      colCount = Integer.parseInt(atts.getValue(SQLResponseAttrColCount));
      rowCount = Integer.parseInt(atts.getValue(SQLResponseAttrRowCount));
    }
		else if (SQLRequest == localName) {
		}
		else if (Request == localName) {
		}
    else if (SQLError == localName) {
    }
    else if (SQLMetadata == localName) {
      this.metaData = new SimpleResultSetMetadata(colCount);
      isInMetaData = true;
      currentCol = 0;
    }
    else if (SQLData == localName) {
      this.resultSet = new SimpleResultSet(metaData, rowCount);
      this.resultSet.setRequest(sqlRequest);
      this.resultSet.setExecutionTime(executionTime);
      isInData = true;
      currentRow = 0;
      currentCol = 0;
    }
		else if (SQLResultSet == localName) {
		}
    else if (SQLRow == localName) {
      currentRow ++;
      currentCol = 0;
    }
    else if (SQLCol == localName) {
      currentCol++;
      if (isInMetaData) {
        final String name = atts.getValue("NAME");
        final int type = Integer.parseInt(atts.getValue("TYPE"));
        final int scale = Integer.parseInt(atts.getValue("SCALE"));
        final int displaySize = Integer.parseInt(atts.getValue("DISPLAYSIZE"));
        final int precision = Integer.parseInt(atts.getValue("PRECISION"));
        metaData.set(currentCol, name, name, type, precision, scale, displaySize);
      }
      else if (isInData) {
        wasNull = "YES".equals(atts.getValue("NULL"));
      }
      else {
        throw new SQLException("Not valid response");
      }
    }
    else {
      super.extendStartElement(namespaceURI, localName, qName, atts);
    }
  }

  @Override
  public void extendEndElement(String namespaceURI, String localName, String qName, String value) throws Exception {
    localName = StringComparator.NVL(localName, qName).intern();
    if (SQLResponse == localName) {
    }
		else if (SQLRequest == localName) {
		}
		else if (Request == localName) {
			sqlRequest = getValue();
		}
    else if (SQLError == localName) {
    }
    else if (SQLMetadata == localName) {
      isInMetaData = false;
    }
    else if (SQLData == localName) {
      isInData = false;
    }
    else if (SQLResultSet == localName) {
    }
    else if (SQLRow == localName) {
    }    
    else if (SQLCol == localName) {
      if (isInMetaData) {
      }
      else if (isInData) {
        resultSet.set(wasNull ? null : SQLUtils.getSQLObjectValue(this.getValue(), metaData.getColumnType(currentCol), metaData.getScale(currentCol), metaData.getPrecision(currentCol)), currentRow, currentCol);
      }
      else {
        sqlException = new SQLException("Not valid response");
        withError = true;
        throw sqlException;
      }
    }
    else {
      super.extendEndElement(namespaceURI, localName, qName, value);
    }
  }
  
  @Override
  public void reset() {
		super.reset();
  	withError = false;
		colCount = 0;
		rowCount = 0;
		resultSet = null;
		metaData = null;
		currentRow = 0;
		currentCol = 0;
		wasNull = false;
		sqlRequest = null;
		isInMetaData = false;
		isInData = false;
    withError = false;
    sqlException = null;
		setAutoValueReset(true);
		setIgnoreWhitespace(true);
  }
  
  private SQLException sqlException;
  private boolean withError = false;
  private int colCount = 0;
  private int rowCount = 0;
  private SimpleResultSet resultSet = null;
  private SimpleResultSetMetadata metaData = null;
  private int currentRow = 0;
  private int currentCol = 0;
  private boolean wasNull = false;
  private long executionTime = -1;
  private String sqlRequest = null;
  
  private boolean isInMetaData = false;
  private boolean isInData = false;
  
	private static final String Request = "REQUEST";
  private static final String SQLRequest = "SQLREQUEST";
  private static final String SQLResponse = "SQLRESPONSE";
  private static final String SQLResponseAttrWithError = "WITHERROR";
  private static final String SQLResponseAttrColCount = "COLCOUNT";
  private static final String SQLResponseAttrRowCount = "ROWCOUNT";
  private static final String SQLError = "SQLERROR";
  private static final String SQLMetadata = "METADATA";
  private static final String SQLResultSet = "RSET";
  private static final String SQLData = "DATA";
  private static final String SQLRow = "ROW";
  private static final String SQLCol = "COL";
}
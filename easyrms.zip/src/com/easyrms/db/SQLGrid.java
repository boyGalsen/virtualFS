package com.easyrms.db;

import com.easyrms.table.HTMLSimpleGrid;
import com.easyrms.util.format.*;


public class SQLGrid extends HTMLSimpleGrid {
	
	public void setColumnNameAsTitle(boolean isColumnNameAsTitle) {
		this.isColumnNameAsTitle = isColumnNameAsTitle;
	}
	
	public final AbstractSQLData getSQLData() { 
    return sqlData;	
  }
	
	public void setSQLData(AbstractSQLData sqlData) {
		this.sqlData = sqlData;
	}
	
	public void setSelectedValue(String selectedValue) {
		this.selectedValue = selectedValue;
	}

	@Override
	public String getEzTitle(Object cell, boolean isHeader, boolean isTrailer, int row, int column) {
		if (!isColumnNameAsTitle) return super.getEzTitle(cell, isHeader, isTrailer, row, column);
		return formatRow(sqlData.get(row, column), isHeader, isTrailer, row, column);
  }

	@Override
  public String getTitle(Object cell, boolean isHeader, boolean isTrailer, int row, int column) {
		if (!isColumnNameAsTitle) return super.getTitle(cell, isHeader, isTrailer, row, column);
		final Object result = sqlData.get(0, column); 
    return (result == null) ? " " : result.toString();
  }
  
	@Override
  public String format(Object cell, boolean isHeader, boolean isTrailer, int row, int column) {
  	if (selectedValue != null && selectedValue.equals(super.format(sqlData.get(row, 0), isHeader, isTrailer, row, 0))) {
			if (column == 0) return "<a name=\"SELECTION\">" + HTMLBoldFormat.referenceFormat(super.format(cell, isHeader, isTrailer, row, column)) + "</a>";
  		return HTMLBoldFormat.referenceFormat(super.format(cell, isHeader, isTrailer, row, column));
  	} 
    return super.format(cell, isHeader, isTrailer, row, column);
  }
  
	protected AbstractSQLData sqlData;
  protected String selectedValue = null;
  private boolean isColumnNameAsTitle = false;
}

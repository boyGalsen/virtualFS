package com.easyrms.db;

import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.ezjmx.*;

import java.sql.*;
import java.util.*;
import java.util.concurrent.atomic.*;

public class EzJDBCConnection implements EzDBAccess, EzDBConnection {

  protected EzJDBCConnection(EzJDBCDatabase database, int maxConnection) {
    this.database = database;
    this.maxConnection = maxConnection;
    this.uid = ids.getNewID();
    addConnection(this);
  }
  
  public String getUID() {
    return uid;
  }
  
  public final EzJDBCConnection getConnection() {
    return isClosed.get() ? null : this;
  }
  
  public EzJDBCDatabase getDatabase() {
    return database;
  }
  
  @Deprecated
  public EzJDBCPhysicalConnection asJDBCConnection() {
    if (isClosed.get()) {
      return null;
    }
    synchronized (this) {
      if (connection0 == null) {
        connection0 = database.getNewConnection();
        connection0UseCount = 1;
      }
      else {
        connection0UseCount++;
      }
      return connection0;
    }
  }
  
  boolean isATransaction() {
    return false;
  }
  
  public boolean query(String request, EzDBResultSetListener listener, Object... parameters) {
    final EzJDBCPhysicalConnection connection = getNewConnection(true);
    try {
      return query(database, getUID(), false, isATransaction(), connection, request, parameters, true, listener);
    }
    finally {
      closeConnection(connection);
    }
  }
  
  protected boolean isWithRollBack() {
    return false;
  }

  public void close() {
    removeConnection(this);
    if (!isClosed.getAndSet(true)) {
      synchronized (this) {
        if (connection0 != null) {
          final boolean isWithRollBack = (withRollBack || isWithRollBack());
          if (isWithRollBack) {
            SQLUtils.rollback(connection0);
          }
          if (!database.isGlobalConnection(connection0)) {
            SQLUtils.close(connection0);
          }
          connection0 = null;
          if (connections != null) {
            for (int i = 0, n = connections.size(); i < n; i++) {
              final HashList<EzJDBCPhysicalConnection> connectionsI = connections.get(i);
              for (int j = 0, m = connectionsI.size(); j < m; j++) {
                final EzJDBCPhysicalConnection connection = connectionsI.get(j);
                if (isWithRollBack) {
                  SQLUtils.rollback(connection);
                }
                if (!database.isGlobalConnection(connection)) {
                  SQLUtils.close(connection);
                }
              }
            }
            connections.clear();
            connectionCounters.clear();
          }
        }
      }
    }
  }

  boolean isClosed() {
    return isClosed.get();
  }
  protected EzJDBCPhysicalConnection findMainConnection() {
    return connection0;
  }
  private EzJDBCPhysicalConnection createConnection(boolean isGlobalPossible) {
    EzJDBCPhysicalConnection connection = database.getNewConnection();
    if (connection == null) {
      if (!isGlobalPossible) {
        return null;
      }
      connection = database.getGlobalConnection();
    }
    return connection;
  }
  EzJDBCPhysicalConnection getNewConnection(boolean isGlobalPossible) {
    if (isClosed.get()) {
      return null;
    }
    synchronized (this) {
      if (this.connection0 == null) {
        connection0 = createConnection(isGlobalPossible);
        if (connection0 == null) {
          return null;
        }
        connection0UseCount = 1;
        return this.connection0;
      }
      if ((isGlobalPossible || !database.isGlobalConnection(this.connection0)) && (connection0UseCount == 0 || maxConnection <= 1)) {
        connection0UseCount++;
        return this.connection0;
      }
      if (maxConnection > 1) {
        if (connections == null) {
          connections = new ArrayList<HashList<EzJDBCPhysicalConnection>>();
          connectionCounters = new HashMap<EzJDBCPhysicalConnection, Integer>();
        }
        while (connectionInCreationCount > 0 && connectionCounters.size()+connectionInCreationCount >= maxConnection) {
          ThreadUtil.waitSilently(this);
        }
        final int connectionCount = connectionCounters.size();
        if (connectionCount >= maxConnection) {
          for (int i = 0, n = connections.size(); i < n; i++) {
            final HashList<EzJDBCPhysicalConnection> connectionI = connections.get(i);
            final int connectionISize = connectionI.size();
            if (connectionISize > 0) {
              final EzJDBCPhysicalConnection connection = connectionI.remove(connectionISize-1);
              if (i == n-1) {
                final HashList<EzJDBCPhysicalConnection> connectionN = new HashList<EzJDBCPhysicalConnection>(); 
                connections.add(connectionN);
                connectionN.add(connection);
              }
              else {
                connections.get(i+1).add(connection);
              }
              connectionCounters.put(connection, IntegerCache.get(i+2));
              return connection;
            }
          }
        }
        connectionInCreationCount++;
      }
    }
    final EzJDBCPhysicalConnection connection = createConnection(isGlobalPossible);
    if (connection != null) {
      synchronized (this) {
        connectionInCreationCount--;
        final HashList<EzJDBCPhysicalConnection> connection1;
        if (connections.size() == 0) {
          connection1 = new HashList<EzJDBCPhysicalConnection>(); 
          connections.add(connection1);
        }
        else {
          connection1 = connections.get(0);
        }
        connection1.add(connection);
        connectionCounters.put(connection, IntegerCache.one);
        notifyAll();
      }
      return connection;
    }
    if ((isGlobalPossible || !database.isGlobalConnection(this.connection0))) {
      connection0UseCount++;
      return connection0;
    }
    return null;
  }

  private void closeConnection(EzJDBCPhysicalConnection connection) {
    if (connection != null) {
      synchronized (this) {
        if (connection == connection0) {
          if (connection0UseCount > 0) {
            connection0UseCount--;
          }
          return;
        }
        final int index = connectionCounters.remove(connection).intValue()-1;
        connections.get(index).remove(connection);
        if (index > 0) {
          connectionCounters.put(connection, IntegerCache.get(index));
          connections.get(index-1).add(connection);
          connection = null;
        }
        else if (database.isGlobalConnection(connection)) {
          connection = null;
          notifyAll();
        }
      }
      if (connection != null) {
        if (withRollBack) {
          SQLUtils.rollback(connection);
        }
        SQLUtils.close(connection);
      }
    }
  }  
  
  protected final EzJDBCDatabase database;
  protected final int maxConnection;
  protected final String uid;
  
  private final AtomicBoolean isClosed = new AtomicBoolean(false);
  
  private EzJDBCPhysicalConnection connection0;
  private int connection0UseCount;

  private ArrayList<HashList<EzJDBCPhysicalConnection>> connections;
  private HashMap<EzJDBCPhysicalConnection, Integer> connectionCounters;
  private int connectionInCreationCount = 0;
  
  private static final HashSet<EzJDBCConnection> allConnections = new HashSet<EzJDBCConnection>();
  private static void addConnection(EzJDBCConnection connection) {
    synchronized (allConnections) {
      allConnections.add(connection);
    }
  }
  private static void removeConnection(EzJDBCConnection connection) {
    synchronized (allConnections) {
      allConnections.remove(connection);
    }
  }
  
  static boolean query(
    EzJDBCDatabase database,
    String connectionUID,
    boolean isBlockingRequest,
    boolean isTransaction,
    EzJDBCPhysicalConnection connection,
    String request,
    Object[] parameters,
    boolean usePrepareSatement,
    EzDBResultSetListener listener)
  {
    counter.inc();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(database.getName(), database.getDescription(), connectionUID, connection.getUID(), isBlockingRequest, isTransaction, request, parameters);
    try {
      perfRequest.fireLog();
      final int n;
      final int[] parameterTypes;
      boolean isPreparedStatementRequired = isPreparedStatementRequiredByDefault;
      if (parameters == null) {
        isPreparedStatementRequired = true;
        n = 0;
        parameterTypes = IntArrays.emptyIntArray;
      }
      else {
        n = parameters.length;
        parameterTypes = new int[n];
        isPreparedStatementRequired = isPreparedStatementRequiredByDefault || usePrepareSatement || preparedStatements.contains(request);
        if (!isPreparedStatementRequired) {
          for (int i = 0; i < n; i++) {
            final Object parameter = parameters[i];
            if (parameter != null) {
              if (parameter.getClass() == Integer.class) {
                parameterTypes[i] = INTEGER_TYPE; 
                continue;
              }
              if (parameter.getClass() == String.class
                && parameter.toString().indexOf('\'') < 0)
              {
                parameterTypes[i] = STRING_TYPE;
                continue;
              }
              if (parameter instanceof Period) {
                parameterTypes[i] = PERIOD_TYPE;
                continue;
              }
            }
            isPreparedStatementRequired = true;
            break;
          }
        }
      }
      final int prefetchRowCount = listener.getRowPrefetch();
      final int queryTimeOut = listener.getQueryTimeOutInSecond();
      Statement query = null;
      try {
        final String method;
        if (isPreparedStatementRequired) {
          final PreparedStatement preparedQuery = SimplePooledConnections.prepareStatement(connection.getConnection(), request, prefetchRowCount, queryTimeOut);
          query = preparedQuery;
          if (parameters != null) {
            for (int i = 0; i < n; i++) {
              final Object parameter = parameters[i];
              if (parameter instanceof Period) {
                preparedQuery.setInt(i+1, ((Period)parameter).getID().intValue());
              }
              else {
                preparedQuery.setObject(i+1, parameter);
              }
            }
          }
          perfRequest.fireEndPreparation(preparedQuery);
          method = "Prepared Statement";
          if (n >= minParameterForMaxExecute) {
            database.takeLock();
            try {
              preparedQuery.execute();
            }
            finally {
              database.releaseLock();
            }
          }
          else {
            preparedQuery.execute();
          }
        }
        else {
          query = SimplePooledConnections.createStatement(connection.getConnection(), prefetchRowCount, queryTimeOut);
          final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
          final StringBuilder statementBuffer = bufferPool.get();
          try {
            int start = 0;
            int end = 0;
            if (parameters != null) {
              for (int i = 0; i < n ; i++) {
                end = request.indexOf('?', start);
                statementBuffer.append(request.substring(start, end));
                switch (parameterTypes[i]) {
                  case INTEGER_TYPE : statementBuffer.append(IntegerCache.toString(((Integer)parameters[i]).intValue())); break;
                  case PERIOD_TYPE : statementBuffer.append(IntegerCache.toString(((Period)parameters[i]).getID().intValue())); break;
                  default : statementBuffer.append("'").append(toValidSQLParameter(parameters[i].toString())).append("'"); 
                }
                start = end+1;
              }
            }
            method = "Statement";
            perfRequest.fireEndPreparation(query);
            if (n >= minParameterForMaxExecute) {
              database.takeLock();
              try {
                query.executeQuery(statementBuffer.append(request.substring(start)).toString());
              }
              finally {
                database.releaseLock();
              }
            }
            else {
              query.executeQuery(statementBuffer.append(request.substring(start)).toString());
            }
          }
          finally {
            bufferPool.free(statementBuffer); 
          }
        }
        executeListener(perfRequest, query, method, listener);
      }
      finally {
        if (query != null) {
          query.close();
        }
      }
    }
    catch (Throwable exception) {
      listener.setException(exception);
      perfRequest.fireError(exception);
      perfRequest.fireEnd(0, null);
      return false;
    }
    finally {
      SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
    return true;
  }

  static boolean executePreparedStatement(
    EzJDBCDatabase database,
    PreparedStatement query,
    String connectionUID,
    EzJDBCPhysicalConnection connection,
    String request,
    Object[] parameters,
    EzDBResultSetListener listener)
  {
    counter.inc();
    final SQLPerfmeter.SQLPerfRequest perfRequest = SQLPerfmeter.newSQLPerfRequest(database.getName(), database.getDescription(), connectionUID, connection.getUID(), false, false, request, parameters);
    perfRequest.fireLog();
    try {
      if (parameters != null) {
        for (int i = 0, n = parameters.length; i < n; i++) {
          final Object parameter = parameters[i];
          if (parameter instanceof Period) {
            query.setInt(i+1, ((Period)parameter).getID().intValue());
          }
          else {
            query.setObject(i+1, parameter);
          }
        }
      }
      perfRequest.fireEndPreparation(query);
      query.execute();
      executeListener(perfRequest, query, "Prepared Statement", listener);
    }
    catch (Throwable exception) {
      listener.setException(exception);
      perfRequest.fireError(exception);
      perfRequest.fireEnd(0, null);
      return false;
    }
    finally {
      SQLPerfmeter.freeSQLPerfRequest(perfRequest);
    }
    return true;
  }

  static void executeListener(
    SQLPerfmeter.SQLPerfRequest perfRequest,
    Statement query,
    String method,
    EzDBResultSetListener listener) throws SQLException
  {
    perfRequest.fireEndExecution();
    final int updateCount = query.getUpdateCount();
    listener.setUpdateCount(updateCount);
    if (updateCount < 0) {
      final ResultSet rset = query.getResultSet();
      try {
        final int count = listener.process(rset);
        try { 
          if (listener.checkWarning()) { 
            listener.setWarning(query.getWarnings()); 
          } 
        } 
        catch (Throwable ignoredWarnings) {           
        } 
        perfRequest.fireEnd(count, method);
      }
      finally {
        rset.close();
      }
    }
  }

  private static String toValidSQLParameter(String sqlParameter) {
    return sqlParameter;
  }

  public static void usePrepareStatement(String request) {
    preparedStatements.add(request);
  }
  
  private static final Counter counter = new Counter("SQL Simple Request");
  private static final IDGenerator ids = new IDGenerator("DB", 1, 999999999, true);
  private static final Set<String> preparedStatements = Collections.synchronizedSet(new HashSet<String>());
  private static final int INTEGER_TYPE = 1; 
  private static final int STRING_TYPE = 2; 
  private static final int PERIOD_TYPE = 3; 
  private static final boolean isPreparedStatementRequiredByDefault = new EzFlag(
    "SQL PreparedStatement", 
    PropertiesUtil.getBoolean(
      "com.ezrms.core.db.SimpleRequest.isPreparedStatementRequired", 
      true), 
    true).booleanValue();
  private static final int minParameterForMaxExecute = PropertiesUtil.getInt(
    "com.ezrms.core.db.SimpleRequest.minParameterForMaxExecute", 
    4);
  private static final boolean withRollBack = EzJDBCDatabase.withRollBack;

  //TODO
  public boolean queryPrepare(PreparedStatement statement, EzDBResultSetListener listener, Object... parameters) {
    return true;//query(database, getUID(), false, isATransaction(), connection, request, parameters, true, listener);
  }
}
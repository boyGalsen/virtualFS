package com.easyrms.db;

import com.easyrms.util.*;

import java.sql.*;

public class EzJDBCPhysicalConnection {

  public EzJDBCPhysicalConnection(Connection connection) {
    this.uid = physicalIds.getNewID();
    this.connection = connection;
  }
  
  public Connection getConnection() {
    return connection;
  }
  
  public String getUID() {
    return uid;
  }
  
  public void rollback() throws SQLException {
    connection.rollback();
  }

  public void commit() throws SQLException {
    connection.commit();
  }
  
  public void close() throws SQLException {
    connection.close();
  }

  private final String uid;
  private final Connection connection;
  
  private static final IDGenerator physicalIds = new IDGenerator("DBP", 1, 999999999, true);
  
}

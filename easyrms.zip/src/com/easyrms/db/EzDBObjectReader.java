package com.easyrms.db;

import com.easyrms.cache.*;
import com.easyrms.util.*;

import java.sql.*;


public class EzDBObjectReader<T> extends EzDBResultSetListener implements Creator<ResultSet, T>, ObjectReference<T> {

  public EzDBObjectReader() {
    super();
    this.creator = null;
  }
  public EzDBObjectReader(String request, Object... parameters) {
    super(request, parameters);
    this.creator = null;
  }
  public EzDBObjectReader(Creator<ResultSet, T> creator) {
    super();
    this.creator = creator;
  }
  public EzDBObjectReader(Creator<ResultSet, T> creator, String request, Object... parameters) {
    super(request, parameters);
    this.creator = creator;
  }
  public EzDBObjectReader(EzDBDatabase database) {
    super(database);
    this.creator = null;
  }
  public EzDBObjectReader(EzDBDatabase database, String request, Object... parameters) {
    super(database, request, parameters);
    this.creator = null;
  }
  public EzDBObjectReader(EzDBDatabase database, Creator<ResultSet, T> creator) {
    super(database);
    this.creator = creator;
  }
  public EzDBObjectReader(EzDBDatabase database, Creator<ResultSet, T> creator, String request, Object... parameters) {
    super(database, request, parameters);
    this.creator = creator;
  }

  public final T get() {
    init();
    return object;
  }
  public T get(EzDBDatabase database) {
    query(database);
    return get();
  }
  public T get(EzDBDatabase database, Object... parameters) {
    query(database, parameters);
    return get();
  }
  public T get(EzDBConnection connection) {
    query(connection);
    return get();
  }
  public T get(EzDBConnection connection, Object... parameters) {
    query(connection, parameters);
    return get();
  }
  
  @Override
  public void init(ResultSet v) throws SQLException {
    super.init(v);
    isDefined = true;
  }

  @Override
  public final void set(int i, ResultSet v) throws SQLException {
    if (i > 0) {
      throw new RuntimeException("More than One Single Row");
    }
    try {
      object = create(v);
    }
    catch (Throwable exception) {
      EasyRMS.trace.log(exception);
    }
  }
  
  public final boolean isNull() {
    return (object == null);
  }
  
  public final boolean isDefined() {
    return isDefined;
  }

  public void init() {
    if (!isDefined()) {
      query();
    }
  }
  
  public void reset() {
    isDefined = false;
    object = null;
  }
  
  public T create(ResultSet key) throws Exception {
    return creator.create(key);
  }

  private final Creator<ResultSet, T> creator;
  private boolean isDefined;
  private T object;
}

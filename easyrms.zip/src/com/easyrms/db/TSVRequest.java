package com.easyrms.db;


import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.sql.*;


public class TSVRequest extends AbstractTSVStatement {
  
  public String getRequest() {
    return this.request;
  } 

  public void setRequest(String request) {
		this.request = (request.endsWith(";")) ? request.substring(0, request.length()-1) : request;
  }

  @Override
  protected TSVResponse loadResponse(EzDBConnection connection) throws Exception {
    final IntReference rowCount = new IntReference(0);
    final IntReference colCount = new IntReference(0);
    //final EzJDBCConnection connection = database.openAccess().getConnection();
    try {
      //boolean isReadOnly = connection.isReadOnly();
      //try {
        //connection.setAutoCommit(false);
        //connection.setReadOnly(true);
        //final Statement query = connection.createStatement();
        //if (query != null) {
      final BooleanReference isWithData = new BooleanReference(false);
      final StringBuilder buffer = StreamUtils.sqlStringBuilderPool.getNew();
          try {
            connection.query(request, new EzDBResultSetListener() {

              @Override
              public void init(ResultSet resultSet) throws SQLException {
                super.init(resultSet);
                final ResultSetMetaData meta = resultSet.getMetaData();
                buffer.append("~.~.~.~.~.Metadata Start~.~.~.~.~.\r\n");
                final int columnCount = meta.getColumnCount();
                colCount.setValue(columnCount);
                buffer.append("TYPE")
                .append("\tPRECISION")
                .append("\tSCALE")
                .append("\tNAME")
                .append("\tDISPLAYSIZE")
                .append("\r\n");
                for (int i = 1; i <= columnCount; i++) {
                  final int type = meta.getColumnType(i);
                  buffer.append(type)
                    .append("\t").append(meta.getPrecision(i))
                    .append("\t").append(meta.getScale(i))
                    .append("\t").append(encodeText(meta.getColumnName(i)))
                    .append("\t").append(meta.getColumnDisplaySize(i))
                    .append("\r\n");
                }
                buffer.append("~.~.~.~.~.Metadata End~.~.~.~.~.\r\n");
              }

              @Override
              public void set(int j, ResultSet resultSet) throws SQLException {
                final ResultSetMetaData meta = resultSet.getMetaData();
                
                if (j == 0) {
                  buffer.append("~.~.~.~.~.Data Start~.~.~.~.~.\r\n");
                  isWithData.setValue(true);
                }
                for (int i = 1, n = colCount.getValue(); i <= n; i++) {
                  if (i == 1) {
                    rowCount.setValue(j+1);
                  }
                  if (i > 1) {
                    buffer.append("\t");
                  }
                  final Object object = resultSet.getObject(i);
                  if (object != null && !resultSet.wasNull()) {
                    if (object instanceof Number) {
                      if (meta.getScale(i) > 0 || meta.getPrecision(i) == 0){
                        buffer.append(((Number)object).doubleValue());
                      }
                      else {
                        buffer.append(((Number)object).longValue());
                      }
                    }
                    else if (object instanceof DateAccessor) {
                      buffer.append(dateFormat.format(((DateAccessor)object).toDate()));
                    }
                    else if (object instanceof java.util.Date) {
                      buffer.append(dateFormat.format(object));
                    }
                    else {
                      cdataFormat.format(object.toString(), buffer, null);
                    }
                  }
                  else {
                    buffer.append("�");
                  }                     
                }
              }
            
          });
            if (isWithData.getValue()) {
              buffer.append("~.~.~.~.~.Data End~.~.~.~.~.\r\n");
            }
           return new TSVResponse(buffer.toString(), colCount.getValue(), rowCount.getValue());
          }
          finally {
          	StreamUtils.sqlStringBuilderPool.free(buffer);
          }
      }
      finally {
				//connection.close();
      }
    //throw new IllegalArgumentException(database+" connection return a null value");
  }
  
  @Override
  public String toString() {
    final StringBuilderThreadPool bufferPool = StringBuilderThreadPool.threadPools.get();
    final StringBuilder buffer = bufferPool.get();
    try {
      final String ID = getID();
      if (StringComparator.isNotNull(ID)) { 
        buffer.append("~.~.~.~.~.Request ID~.~.~.~.~.\r\n")
          .append(ID)
          .append("~.~.~.~.~.Request ID~.~.~.~.~.\r\n");
      }
      buffer.append("~.~.~.~.~.Request Start~.~.~.~.~.\r\n")
        .append(request)
      	.append("~.~.~.~.~.Request End~.~.~.~.~.\r\n");
      return buffer.toString();
    }
    finally {
      bufferPool.free(buffer);
    }
  }
    
  private String request;
}
package com.easyrms.db;

import com.easyrms.util.*;

import java.io.*;
import java.sql.*;
import java.util.*;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.*;
import jxl.write.Number;


public class SQLToExcel {
  
  public static EzDBResultSetListener generate(final OutputStream out) throws Throwable {
    final WritableFont arial10ptBoldNotUnderline = new WritableFont(
        WritableFont.ARIAL,
        10,
        WritableFont.BOLD,
        false,
        UnderlineStyle.NO_UNDERLINE);
    final WritableFont arial8ptNotUnderline = new WritableFont(
        WritableFont.ARIAL,
        8,
        WritableFont.NO_BOLD,
        false,
        UnderlineStyle.NO_UNDERLINE);
      
      final WritableCellFormat titleFormat = new WritableCellFormat(arial10ptBoldNotUnderline);
      final WritableCellFormat integerFormat = new WritableCellFormat(arial8ptNotUnderline, new NumberFormat("#"));
      final WritableCellFormat numberFormat = new WritableCellFormat(arial8ptNotUnderline, new NumberFormat("#.##"));
      final WritableCellFormat dateFormat = new WritableCellFormat(arial8ptNotUnderline, new DateFormat ("dd MMM yyyy"));
      final WritableCellFormat stringFormat = new WritableCellFormat(arial8ptNotUnderline);
      titleFormat.setWrap(true);
      titleFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      titleFormat.setBackground(Colour.GRAY_25);
      titleFormat.setAlignment(Alignment.CENTRE);
    
      integerFormat.setWrap(false);
      integerFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      integerFormat.setBackground(Colour.WHITE);
      integerFormat.setAlignment(Alignment.CENTRE);

      numberFormat.setWrap(false);
      numberFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      numberFormat.setBackground(Colour.WHITE);
      numberFormat.setAlignment(Alignment.CENTRE);

      dateFormat.setWrap(false);
      dateFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      dateFormat.setBackground(Colour.WHITE);
      dateFormat.setAlignment(Alignment.CENTRE);

      stringFormat.setWrap(false);
      stringFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      stringFormat.setBackground(Colour.WHITE);
      stringFormat.setAlignment(Alignment.CENTRE);

      return new EzDBResultSetListener() {
      
      private final WritableWorkbook workBook = Workbook.createWorkbook(out);
      private final WritableSheet sheet = workBook.createSheet("SQL Results", 0);
      private final ArrayList<Integer> types = new ArrayList<Integer>();
      private int nbColumns = 0; 
      private int row = 0;

      @Override
      public void init(ResultSet v) throws SQLException {
        try {
          final ResultSetMetaData metaData = v.getMetaData();
          nbColumns = metaData.getColumnCount();
          for (int i = 0 ; i < nbColumns ; i++) {
            final int iAdd1 = i+1;
            final String name = metaData.getColumnName(iAdd1);
            final Label label = new Label(i, 0, name, titleFormat); 
            sheet.addCell(label);
            final Integer type;
            if (SQLUtils.isDate(iAdd1,metaData)) {
              type = DATE_TYPE;
            }
            else if (SQLUtils.isInteger(iAdd1,metaData)) {
              type = INTEGER_TYPE;
            }
            else if (SQLUtils.isNumber(iAdd1,metaData)) {
              type = NUMBER_TYPE;
            }
            else {
              type = STRING_TYPE;
            }
            types.add(type);
          }
        }
        catch (Throwable exception) {
          throw new SQLException(exception);
        }
      }
      
      @Override
      public void close() throws SQLException {
         try {
            workBook.write();
            workBook.close();
          }
          catch (Throwable exception) {
            throw new SQLException(exception);
          }      
        }
      
      @Override
      public void set(int x, ResultSet v) throws SQLException {
        try {
          row++;
          for (int i = 0 ; i < nbColumns ; i++) {
            final int iAdd1 = i+1;
            final Integer type = types.get(i);
            if (type == INTEGER_TYPE) {
              final int value = v.getInt(iAdd1);
              if (!v.wasNull()) {
                final Number number = new Number(i, row, value, integerFormat);
                sheet.addCell(number);
              }
              else {
                sheet.addCell(new Label(i, row, "", stringFormat));
              }
            }
            else if (type == NUMBER_TYPE) {
              final double value = v.getDouble(iAdd1);
              if (!v.wasNull()) {
                final Number number = new Number(i, row, value, numberFormat);
                sheet.addCell(number);
              }
              else {
                sheet.addCell(new Label(i, row, "", stringFormat));
              }
            }
            else if (type == DATE_TYPE) {
              final Timestamp value = v.getTimestamp(iAdd1);
              if (!v.wasNull()) {
                final DateTime dateTime = new DateTime(i, row, value, dateFormat);
                sheet.addCell(dateTime);
              }
              else {
                sheet.addCell(new Label(i, row, "", stringFormat));
              }
            }
            else {
              final String value = v.getString(iAdd1);
              final Label label = new Label(i, row, v.wasNull() ? "" : value, stringFormat); 
              sheet.addCell(label);
            }
          }
        }
        catch (Throwable exception) {
          throw new SQLException(exception);
        }
      }
    };
  }



  public static void generate(final OutputStream out, final ResultSet resultSet) throws Throwable {
    final EzDBResultSetListener listener = generate(out);
    listener.init(resultSet);
    try {
      int i = 0;
      while(resultSet.next()) {
        listener.set(i++, resultSet);
      }
    }
    finally {
      listener.close();
    }
    /*final WritableFont arial10ptBoldNotUnderline = new WritableFont(
        WritableFont.ARIAL,
        10,
        WritableFont.BOLD,
        false,
        UnderlineStyle.NO_UNDERLINE);
    final WritableFont arial8ptNotUnderline = new WritableFont(
        WritableFont.ARIAL,
        8,
        WritableFont.NO_BOLD,
        false,
        UnderlineStyle.NO_UNDERLINE);
     
     
      
      final WritableCellFormat titleFormat = new WritableCellFormat(arial10ptBoldNotUnderline);
      final WritableCellFormat integerFormat = new WritableCellFormat(arial8ptNotUnderline, new NumberFormat("#"));
      final WritableCellFormat numberFormat = new WritableCellFormat(arial8ptNotUnderline, new NumberFormat("#.##"));
      final WritableCellFormat dateFormat = new WritableCellFormat(arial8ptNotUnderline, new DateFormat ("dd MMM yyyy"));
      final WritableCellFormat stringFormat = new WritableCellFormat(arial8ptNotUnderline);
      titleFormat.setWrap(true);
      titleFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      titleFormat.setBackground(Colour.GRAY_25);
      titleFormat.setAlignment(Alignment.CENTRE);
    
      integerFormat.setWrap(false);
      integerFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      integerFormat.setBackground(Colour.WHITE);
      integerFormat.setAlignment(Alignment.CENTRE);

      numberFormat.setWrap(false);
      numberFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      numberFormat.setBackground(Colour.WHITE);
      numberFormat.setAlignment(Alignment.CENTRE);

      dateFormat.setWrap(false);
      dateFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      dateFormat.setBackground(Colour.WHITE);
      dateFormat.setAlignment(Alignment.CENTRE);

      stringFormat.setWrap(false);
      stringFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
      stringFormat.setBackground(Colour.WHITE);
      stringFormat.setAlignment(Alignment.LEFT);
    
    final ResultSetMetaData metaData = sqlValue.getMetaData();
    final int nbColumns = metaData.getColumnCount();
    final WritableWorkbook workBook = Workbook.createWorkbook(out);
    final WritableSheet sheet = workBook.createSheet("SQL Results", 0);
    final ArrayList types = ObjectArrays.getArrayList();
    
    try {
      int row = 0;
      for (int i = 0 ; i < nbColumns ; i++) {
        final int iAdd1 = i+1;
        final String name = metaData.getColumnName(iAdd1);
        final Label label = new Label(i, 0, name, titleFormat); 
        sheet.addCell(label);
        final Integer type;
        if (SQLUtils.isDate(iAdd1,metaData)) {
          type = DATE_TYPE;
        }
        else if (SQLUtils.isInteger(iAdd1,metaData)) {
          type = INTEGER_TYPE;
        }
        else if (SQLUtils.isNumber(iAdd1,metaData)) {
          type = NUMBER_TYPE;
        }
        else {
          final CellView cellView = new CellView();
          cellView.setSize(10000);
          sheet.setColumnView(i, cellView);
          type = STRING_TYPE;
        }
        types.add(type);
      }
      while (sqlValue.next()) {
        row++;
        for (int i = 0 ; i < nbColumns ; i++) {
          final int iAdd1 = i+1;
          final Integer type = (Integer)types.get(i);
          if (type == INTEGER_TYPE) {
            final int value = sqlValue.getInt(iAdd1);
            if (!sqlValue.wasNull()) {
              final Number number = new Number(i, row, value, integerFormat);
              sheet.addCell(number);
            }
            else {
              sheet.addCell(new Label(i, row, "", stringFormat));
            }
          }
          else if (type == NUMBER_TYPE) {
            final double value = sqlValue.getDouble(iAdd1);
            if (!sqlValue.wasNull()) {
              final Number number = new Number(i, row, value, numberFormat);
              sheet.addCell(number);
            }
            else {
              sheet.addCell(new Label(i, row, "", stringFormat));
            }
          }
          else if (type == DATE_TYPE) {
            final Timestamp value = sqlValue.getTimestamp(iAdd1);
            if (!sqlValue.wasNull()) {
              final DateTime dateTime = new DateTime(i, row, value, dateFormat);
              sheet.addCell(dateTime);
            }
            else {
              sheet.addCell(new Label(i, row, "", stringFormat));
            }
          }
          else {
            final String value = sqlValue.getString(iAdd1);
            final Label label = new Label(i, row, sqlValue.wasNull() ? "" : value, stringFormat);
            sheet.addCell(label);
          }
        }
      }
      sheet.addCell(new Label(0, row+1, "Generated By EasyRMS on "+new Date(), stringFormat));
      workBook.write();
      workBook.close();
    }
    finally {
      ObjectArrays.free(types);
    }*/
  }

  private static final Integer INTEGER_TYPE = IntegerCache.zero;
  private static final Integer NUMBER_TYPE = IntegerCache.one;
  private static final Integer DATE_TYPE = IntegerCache.two;
  private static final Integer STRING_TYPE = IntegerCache.three;
}

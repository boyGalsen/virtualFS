package com.easyrms.db;

import java.sql.*;
import java.util.*;

import com.easyrms.util.*;
import com.easyrms.util.array.*;

public abstract class MultiDimensionSQLData extends AbstractSQLData {
  
  public MultiDimensionSQLData(){
  }
  
  public int getDimensionCount() {
    return this.dimensionCount;
  }
  
  @Override
  protected void updateData(int i, ResultSet v, EzArrayList<Object[]> dataArray)  throws SQLException {
    final ResultSetMetaData metaData = v.getMetaData();
    dimensionCount = metaData.getColumnCount() - 1;
    final int keySize = dimensionCount - 1;
    final HashMapThreadPool mapPool = HashMapThreadPool.threadPools.get();
    final HashMap<Tuple, Object> values = mapPool.get();
    
    final EzArrayListThreadPool arrayPool = EzArrayListThreadPool.threadPools.get();
    final EzArrayList<String> header = arrayPool.get();
    final EzArrayList<Object> firstSQLCurrentKey = arrayPool.get();
    final EzArrayList<Object> lineDisplayed = arrayPool.get();
    try {
      dataArray.add(null);
      dataArray.add(null);
      boolean firstLineIsCompleted = false;
      for (int n = 2; n < dimensionCount+1; n++) {
        firstSQLCurrentKey.add(v.getObject(n));
        lineDisplayed.add(v.getObject(n));
      }
      
      do {
        final EzArrayList<Object> currentSQLKey = arrayPool.get();
        try {
          for (int n = 0; n < keySize; n++) {
            currentSQLKey.add(v.getObject(n+2));
          }
          if (!firstSQLCurrentKey.originalEquals(currentSQLKey)) {
            firstLineIsCompleted = true;
            final Object[] line = lineDisplayed.toArray();
            dataArray.add(line);
            lineDisplayed.clear();
            firstSQLCurrentKey.clear();
            for (int n = 2; n <= dimensionCount+1; n++) {
              if (n == dimensionCount+1) {
                lineDisplayed.add(v.getObject(n));
              }
              else {
                lineDisplayed.add(v.getObject(n));
                if (n <= dimensionCount) {
                  firstSQLCurrentKey.add(v.getObject(n));
              }
            }
          }
          }
          else {
            final Object cell = v.getObject(dimensionCount+1);
            lineDisplayed.add(cell);
            if (!firstLineIsCompleted) {
              header.add(v.getObject(1).toString());
          }
        }
        }
        finally {
          arrayPool.free(currentSQLKey);
        }
      } while (v.next());
      dataArray.add(lineDisplayed.toArray());
      
      
      final String[] mainTitles = new String[header.size()+keySize];
      for (int j = 0; j < keySize; j++) {
        mainTitles[j] = metaData.getColumnName(j+2);
      }
      mainTitles[keySize] = metaData.getColumnName(1);
      for (int n = 0; n < keySize; n++) {
        header.add(n, null);
      }
      setMainTitle(mainTitles);
      dataArray.set(0, mainTitles);
      dataArray.set(1, header.toArray());
      setWidth(header.size());
      setHeader(2);
      setTitle(false, header.toArray(new String[getWidth()]));
    }
    finally {
      mapPool.free(values);
      arrayPool.free(header);
      arrayPool.free(firstSQLCurrentKey);
      arrayPool.free(lineDisplayed);
    }
  }
  
  private int dimensionCount;
  
}
package com.easyrms.db;

import com.easyrms.util.array.*;

import java.sql.*;


public abstract class EzDBResultSetListener {
  
  public EzDBResultSetListener() {
    this(null, false, ObjectArrays.emptyObjectArray);
  }
  public EzDBResultSetListener(String request) {
    this(request, false, ObjectArrays.emptyObjectArray);
  }
  public EzDBResultSetListener(String request, Object... parameters) {
    this(request, true, parameters);
  }
  public EzDBResultSetListener(String request, boolean isCopyNeeeded, Object... parameters) {
    this(null, request, isCopyNeeeded, parameters);
  }
  public EzDBResultSetListener(EzDBDatabase database) {
    this(database, null);
  }
  public EzDBResultSetListener(EzDBDatabase database, String request) {
    this(database, request, false, ObjectArrays.emptyObjectArray);
  }
  public EzDBResultSetListener(EzDBDatabase database, String request, Object... parameters) {
    this(database, request, true, parameters);
  }
  public EzDBResultSetListener(EzDBDatabase database, String request, boolean isCopyNeeeded, Object... parameters) {
    this.database = database;
    this.request = request;
    this.parameters = isCopyNeeeded ? parameters.clone() : parameters;
  }

  public boolean query() {
    return query(getDatabase());
  }
  public boolean query(EzDBDatabase database) {
    return query(database, getParameters());
  }
  public boolean query(EzDBDatabase database, Object... parameters) {
    final EzDBAccess access = database.openAccess();
    try {
      return query(access.getConnection(), parameters);
    }
    finally {
      access.close();
    }
  }
  public boolean query(EzDBConnection connection) {
    return query(connection, getParameters());
  }
  public boolean query(EzDBConnection connection, Object... parameters) {
    return query(connection, getRequest(), parameters);
  }
  public boolean query(EzDBConnection connection, String request, Object... parameters) {
    return connection.query(request, this, parameters);
  }
  
  public void init(ResultSet v) throws SQLException {
    updateCount = -1;
  }
  public abstract void set(int i, ResultSet v) throws SQLException;
  public void close() throws SQLException {}

  
  public int process(ResultSet rset) throws SQLException {
    init(rset);
    try {
      int i = 0;
      while (rset.next()) {
        set(i++, rset);
      }
      return i;
    }
    finally {
      close();
    }
  }
  
  public final void setUpdateCount(int updateCount) {
    this.updateCount = updateCount;
  }
  public final int getUpdateCount() {
    return updateCount;
  }
  
  public int getRowPrefetch() { 
    return -1; 
  }
  
  public boolean checkWarning() { 
    return false; 
  }
  
  public void setWarning(SQLWarning warning) { }
  
  /**
   * return -1 to use default value;
   */
  public int getQueryTimeOutInSecond() { 
    return -1; 
  }
  public boolean isWithLog() { 
    return true; 
  }

  public EzDBDatabase getDatabase() {
    return database;
  }
  public String getRequest() { 
    return request; 
  }
  protected Object[] getParameters() { 
    return parameters; 
  }

  final void setException(Throwable exception) { 
    this.exception = exception; 
  }

  public final Throwable getException() { 
    return exception; 
  }
  
  private Throwable exception;
  private int updateCount = -1;
  private final EzDBDatabase database;
  private final String request;
  private final Object[] parameters;
}
package com.easyrms.db;

import com.easyrms.util.*;

import java.io.*;


public class ResponseYyLex {
  
  public ResponseYyLex(Reader reader) {
    this.reader = reader;
  }

  public void setResponse(XMLResponse response) {
    this.response = response;
  }
  
  public Object yylex() {
    final CharThreadPool charPool = CharThreadPool.threadPools.get();
    final char[] buffer = charPool.get();
		try {
			final StringBuilder responseBuffer = StreamUtils.bigStringBuilderPool.getNew();
			try {
        final StringBuilderThreadPool builderThreadPool = StringBuilderThreadPool.threadPools.get();
				final StringBuilder responseBufferId = builderThreadPool.get();
				try {
		      int charCount = 0 ;
			    try {
			      char c;
			      while ((charCount = reader.read(buffer)) > 0) {
			        for (int i= 0 ; i < charCount ; i++) {
			          c = buffer[i];
			          switch (mainState) {
			            case RESPONSE_TAG_STATE: {
			              if (c == '>') {minorState = 0; mainState = RESPONSE_STATE;}
			            } break;
			            case RESPONSE_STATE: {
			              switch (minorState) {
			                case 1 : 
			                  if (c == '/') { minorState = 100; }  
			                  else if (c == 'S') { minorState++; }  
			                  else {minorState = 0;} 
			                  break; 
			                case 2 : if (c == 'Q') { minorState++; } else {minorState = 0;} break; 
			                case 3 : if (c == 'L') { minorState++; } else {minorState = 0;} break; 
			                case 4 : if (c == 'R') { minorState++; } else {minorState = 0;} break; 
			                case 5 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 6 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 7 : if (c == 'P') { minorState++; } else {minorState = 0;} break; 
			                case 8 : if (c == 'O') { minorState++; } else {minorState = 0;} break; 
			                case 9 : if (c == 'N') { minorState++; } else {minorState = 0;} break; 
			                case 10 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 11 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 12 : 
			                  if (c == ' ' || c == '\r' || c == '\t' || c == '\n') { 
			                    minorState = 0; 
			                    mainState = SQLRESPONSE_TAG_STATE;
			                    responseBuffer.setLength(0);
			                    responseBufferId.setLength(0);
			                    responseBuffer.append("<SQLRESPONSE").append(c);
			                  } 
			                  else if (c == '>') { 
			                    minorState = 0; 
			                    mainState = SQLRESPONSE_STATE;
			                    responseBuffer.setLength(0);
			                    responseBufferId.setLength(0);
			                    responseBuffer.append("<SQLRESPONSE>");
			                  } 
			                  else {
			                    minorState = 0;
			                  } break; 
			
			                case 100 : if (c == 'R') { minorState++; } else {minorState = 0;} break; 
			                case 101 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 102 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 103 : if (c == 'P') { minorState++; } else {minorState = 0;} break; 
			                case 104 : if (c == 'O') { minorState++; } else {minorState = 0;} break; 
			                case 105 : if (c == 'N') { minorState++; } else {minorState = 0;} break; 
			                case 106 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 107 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 108 : 
			                  if (c == '>') { 
			                    minorState = 0; 
			                    mainState = YYINITIAL;
			                  } else {
			                    minorState = 0;
			                  } break; 
			
			                default : if (c == '<') minorState++;
			              } 
			              
			            } break;
			            case SQLRESPONSE_TAG_STATE: {
			              responseBuffer.append(c);
			              switch (minorState) {
			                case 1 : 
			                  if (c == 'D') { minorState++; } 
			                  else {
			                    minorState = 0; 
			                    if ( c == '"') {mainState = SQLRESPONSE_TAG_ATTRIB_VALUE_STATE;}
			                    else { mainState = SQLRESPONSE_TAG_ATTRIB_STATE;}
			                  } break; 
			                case 2 : 
			                  if (c == '=') { minorState++; } 
			                  else {
			                    minorState = 0; 
			                    if ( c == '"') {mainState = SQLRESPONSE_TAG_ATTRIB_VALUE_STATE;}
			                    else { mainState = SQLRESPONSE_TAG_ATTRIB_STATE;}
			                  } break; 
			                case 3 : if (c == '"') { minorState = 0; mainState = SQLRESPONSE_TAG_ID_STATE; responseBufferId.setLength(0);} else {minorState = 0; mainState = SQLRESPONSE_TAG_ATTRIB_STATE;} break; 
			                default : {
			                  if (c == '>') {minorState = 0; mainState = SQLRESPONSE_STATE; break;}
			                  else if (c == 'I') {minorState++; break;} 
			                  else if (c == ' ' || c == '\n' || c == '\r' || c == '\t') { break;}
			                  else {minorState = 0; mainState = SQLRESPONSE_TAG_ATTRIB_STATE; break;}
			                }
			              }
			            } break;
			            case SQLRESPONSE_TAG_ATTRIB_STATE: {
			              responseBuffer.append(c);
			              if ( c == '"') { mainState = SQLRESPONSE_TAG_ATTRIB_VALUE_STATE;}
			              else if (c == ' ' || c == '\n' || c == '\r' || c == '\t') { mainState = SQLRESPONSE_TAG_STATE;}
			              else if (c == '>') { mainState = SQLRESPONSE_STATE; }
			            } break;
			            case SQLRESPONSE_TAG_ATTRIB_VALUE_STATE: {
			              responseBuffer.append(c);
			              if ( c == '\\') { mainState = SQLRESPONSE_TAG_ATTRIB_PROTECT_VALUE_STATE;}
			              else if ( c == '"') { mainState = SQLRESPONSE_TAG_ATTRIB_STATE;}
			            } break;
			            case SQLRESPONSE_TAG_ATTRIB_PROTECT_VALUE_STATE: {
			              responseBuffer.append(c);
			              mainState = SQLRESPONSE_TAG_ATTRIB_VALUE_STATE;
			            } break;
			            case SQLRESPONSE_TAG_ID_STATE: {
			              responseBuffer.append(c);
			              if (c == '"') {
			                mainState = SQLRESPONSE_TAG_STATE;
			              }
			              else if (c == '\\') {
			                responseBufferId.append(c);
			                mainState = SQLRESPONSE_TAG_ID_PROTECT_STATE;
			              }
			              else {
			                responseBufferId.append(c);
			              }
			            } break;
			            case SQLRESPONSE_TAG_ID_PROTECT_STATE: {
			              responseBuffer.append(c);
			              responseBufferId.append(c);
			              mainState = SQLRESPONSE_TAG_ID_STATE;
			            } break;
			            case SQLRESPONSE_STATE: {
			              responseBuffer.append(c);
			              switch (minorState) {
			                case 1 : if (c == '/') { minorState++; } else {minorState = 0;} break; 
			                case 2 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 3 : if (c == 'Q') { minorState++; } else {minorState = 0;} break; 
			                case 4 : if (c == 'L') { minorState++; } else {minorState = 0;} break; 
			                case 5 : if (c == 'R') { minorState++; } else {minorState = 0;} break; 
			                case 6 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 7 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 8 : if (c == 'P') { minorState++; } else {minorState = 0;} break; 
			                case 9 : if (c == 'O') { minorState++; } else {minorState = 0;} break; 
			                case 10 : if (c == 'N') { minorState++; } else {minorState = 0;} break; 
			                case 11 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 12 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 13 : 
			                  if (c == '>') { 
			                    minorState = 0; 
			                    mainState = RESPONSE_STATE;
			                    this.response.add(responseBufferId.toString(),responseBuffer.toString());
			                  } else { 
			                    minorState = 0;
			                  } break; 
			                default : if (c == '<') { minorState++; }
			              } 
			            } break;
			            default : {
			              switch (minorState) {
			                case 1 : if (c == 'R') { minorState++; } else {minorState = 0;} break; 
			                case 2 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 3 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 4 : if (c == 'P') { minorState++; } else {minorState = 0;} break; 
			                case 5 : if (c == 'O') { minorState++; } else {minorState = 0;} break; 
			                case 6 : if (c == 'N') { minorState++; } else {minorState = 0;} break; 
			                case 7 : if (c == 'S') { minorState++; } else {minorState = 0;} break; 
			                case 8 : if (c == 'E') { minorState++; } else {minorState = 0;} break; 
			                case 9 : 
			                  if (c == ' ' || c == '\r' || c == '\t' || c == '\n') { 
			                    minorState = 0; 
			                    mainState = RESPONSE_TAG_STATE;
			                  } else if (c == '>') {
			                    minorState = 0; 
			                    mainState = RESPONSE_STATE;
			                  } else {
			                    minorState = 0;
			                  } break; 
			                default : if (c == '<') minorState++;
			              } 
			            }
			          }
			        }
			      }
			    }
			    catch(Exception e) {
			      EasyRMS.trace.log(e);
			      return null;
			    }
					return null;
				}
				finally {
          builderThreadPool.free(responseBufferId);
				}
			}
			finally {
				StreamUtils.bigStringBuilderPool.free(responseBuffer);
			}
    }
    finally {
      charPool.free(buffer);
    }
  }
  
  private int mainState = 0;
  private int minorState = 0;

  private static final int YYINITIAL = 0;
  private static final int RESPONSE_STATE = 1;
  private static final int RESPONSE_TAG_STATE = 2;
  private static final int SQLRESPONSE_TAG_STATE = 3;
  private static final int SQLRESPONSE_TAG_ATTRIB_STATE = 4;
  private static final int SQLRESPONSE_TAG_ATTRIB_VALUE_STATE = 5;
  private static final int SQLRESPONSE_TAG_ATTRIB_PROTECT_VALUE_STATE = 6;
  private static final int SQLRESPONSE_TAG_ID_STATE = 7;
  private static final int SQLRESPONSE_TAG_ID_PROTECT_STATE = 8;
  private static final int SQLRESPONSE_STATE = 9;

  //private String currentID = null;
  //private String currentResponse = null;
  //private StringBuffer responseBuffer = new StringBuffer();
  //private StringBuffer responseBufferId = new StringBuffer();

  private XMLResponse response = null;
  private final Reader reader;
}

package com.easyrms.excel;

import com.easyrms.CSV.*;
import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.array.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.text.*;
import java.util.*;

public class PasteClipboardRecordSet implements ExtendedRecordSet {
  
  public PasteClipboardRecordSet(Reader in) {
    try {
      this.reader = new BoundedBufferedReader(in);
      init();
    }
    catch (Throwable forward) {
      throw ExceptionUtils.newRuntimeException("Error When Parsing Excel File", forward);
    }
  }

  public String getCell(int column) {
    if (!hasMore) throw new IllegalArgumentException("Cannot Access Get Object When Next Is False");  
    return cleanString(rowDataAsString.get(column));
  }
  
  private String cleanString(String string) {
    return string.trim();
  }
  
  public int findColumnIndex(String name) {
    final Integer index = columnByName.get(name);
    if (index == null) return -getWidth();
    return index.intValue();
  }

  public String getColumnName(int column) {
    return columns.get(column);
  }

  public Object getObject(int column) {
    if (!hasMore) throw new IllegalArgumentException("Cannot Access Get Object When Next Is False");  
    return rowData.get(column);
  }

  public int getWidth() {
    return columns.size();
  }

  public boolean next() throws ParseException, IOException {
    if (!hasMore) return false;
    try {
      rowData.clear();
      rowDataAsString.clear();
      currentRow++;
      final String line = reader.readLine();
      if (StringComparator.isNull(line)) {
        hasMore = false;
      }
      else {
        final String[] data = StringArrays.toStringArrayWithEmpty(line, getColumnSeparator());
        final int width = getWidth();
        if (data.length != width) {
          if (data.length < width) throw ExceptionUtils.newRuntimeException("Illegal Datas Not Enougth Values On Row:"+currentRow);
          if (data.length > width) throw ExceptionUtils.newRuntimeException("Illegal Datas Too Many Values On Row:"+currentRow);
        }
        for (int i = 0, n = data.length; i < n; i++) {
          final String dataI = data[i];
          rowData.add(dataI);
          rowDataAsString.add(dataI);
        }
      }
      return hasMore;
    }
    catch (Throwable exception) {
      throw ExceptionUtils.newRuntimeException("Cannot parse reader from paste", exception);
    }
  }
  
  
  private void init() {
    try {
      final String line = reader.readLine();
      if (StringComparator.isNull(line)) {
        hasMore = false;
      }
      else {
        if (line.contains(";")) setColumnSeparator(";");
        final String[] data = StringArrays.toStringArrayWithEmpty(line, getColumnSeparator());
        for (int i = 0, n = data.length; i < n; i++) {
          final String cellContent = data[i];
          //if (StringComparator.isNull(cellContent)) break;
          final Integer index = IntegerCache.get(columns.size());
          columns.add(cellContent);
          columnByName.put(cellContent, index);
        }
      }
    }
    catch (Throwable exception) {
      throw ExceptionUtils.newRuntimeException("Cannot parse reader from paste", exception);
    }
  }
  
  public String getColumnSeparator() {
    return columnSeparator;
  }

  public void setColumnSeparator(String columnSeparator) {
    this.columnSeparator = columnSeparator;
  }
  
  private int currentRow = 0;
  private boolean hasMore = true;
  
  private final EzArrayList<Object> rowData = new EzArrayList<Object>(); 
  private final EzArrayList<String> rowDataAsString = new EzArrayList<String>(); 
  private final EzArrayList<String> columns = new EzArrayList<String>(); 
  private final HashMap<String, Integer> columnByName = new HashMap<String, Integer>(); 

  private final BoundedBufferedReader reader;
  private String columnSeparator = "\t";
}
package com.easyrms.excel;

import com.easyrms.CSV.*;
import com.easyrms.date.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;

import java.io.*;
import java.text.*;
import java.util.*;
import jxl.*;

public class ExcelRecordSet implements ExtendedRecordSet {

  public ExcelRecordSet(InputStream in) {
    try {
      this.workbook = Workbook.getWorkbook(in);
      this.sheet = workbook.getSheet(0);
      init();
    }
    catch (Throwable forward) {
      throw ExceptionUtils.newRuntimeException("Error When Parsing Excel File", forward);
    }
  }

  public String getCell(int column) {
    if (!hasMore) throw new IllegalArgumentException("Cannot Access Get Object When Next Is False");  
    return rowDataAsString.get(column);
  }
  
  public int findColumnIndex(String name) {
    final Integer index = columnByName.get(name);
    return (index == null) ? -getWidth() : index.intValue();
  }

  public String getColumnName(int column) {
    return columns.get(column);
  }

  public Object getObject(int column) {
    if (!hasMore) throw new IllegalArgumentException("Cannot Access Get Object When Next Is False");  
    return rowData.get(column);
  }

  public int getWidth() {
    return columns.size();
  }

  public boolean next() throws ParseException, IOException {
    if (!hasMore) return false;
    rowData.clear();
    rowDataAsString.clear();
    currentRow++;
    if (currentRow >= sheet.getRows()) {
      hasMore = false;
      workbook.close();
      return hasMore;
    }
    Cell refCell = null;
    for (int i = 0, n = getWidth(); i < n; i++) {
      final Cell cell = sheet.getCell(i, currentRow);
      if (cell != null) {
        final String cellContent = cell.getContents();
        if (StringComparator.isNotNull(cellContent)) {
          refCell = cell;
          break;
        }
      }
    }
    
    if (refCell == null) {
      hasMore = false;
      workbook.close();
      return hasMore;
    }
    for (int i = 0, n = getWidth(); i < n; i++) {
      final Cell cell = sheet.getCell(i, currentRow);
      if (cell == null) {
        rowData.add(null);
        rowDataAsString.add(null);
        continue;
      }
      final String dataCell = cell.getContents();
      if (cell.getType() == CellType.DATE) {
        final SimpleDateFormat dateFormat = new SimpleDateFormat(cell.getCellFormat().getFormat().getFormatString().replace(";@", ""));
        final Date date = dateFormat.parse(dataCell);
        final EzDate ezDate = EzDate.getEzDate(date.getYear()+1900, date.getMonth()+1, date.getDate());/*StringComparator.getInt(splitValue[2])+2000, StringComparator.getInt(splitValue[1]), StringComparator.getInt(splitValue[0])*/
        rowData.add(ezDate);
        rowDataAsString.add(IntegerCache.toString(ezDate.getDay()));
      }
      else if (cell.getType() == CellType.NUMBER) {
        final String numberClean = dataCell.replaceAll("[^0-9.]+", "");
        final Double number = StringComparator.getDouble(numberClean);
        rowData.add(number);
        rowDataAsString.add(numberClean);
      }
      else if (cell.getType() == CellType.LABEL) {
        rowData.add(dataCell);
        rowDataAsString.add(dataCell);
      }
      else {
        rowData.add(dataCell);
        rowDataAsString.add(dataCell);
      }
    }      
    return hasMore;
  }
  
  private void init() {
    final int columnsCount = sheet.getColumns();
    for (int columnPosition = 0, n = columnsCount; columnPosition < n; columnPosition++) {
      final Cell cell = sheet.getCell(columnPosition, 0);
      if (cell == null) break;
      final String cellContent = cell.getContents();
      if (StringComparator.isNull(cellContent)) break;
      final Integer index = IntegerCache.get(columns.size());
      columns.add(cellContent);
      columnByName.put(cellContent, index);
    }
  }
  
  private int currentRow = 0;
  private boolean hasMore = true;
  
  private final EzArrayList<Object> rowData = new EzArrayList<Object>(); 
  private final EzArrayList<String> rowDataAsString = new EzArrayList<String>(); 
  private final EzArrayList<String> columns = new EzArrayList<String>(); 
  private final HashMap<String, Integer> columnByName = new HashMap<String, Integer>(); 

  private final Workbook workbook;
  private final Sheet sheet;
}
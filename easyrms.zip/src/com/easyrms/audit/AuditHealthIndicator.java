package com.easyrms.audit;

import com.easyrms.date.*;
import com.easyrms.util.*;

public interface AuditHealthIndicator {

  String getCode();
  String getName();
  String getDescription();
  EzArray<String> getCategory();
  
  EzArray<? extends AuditHealthIndicator> getIndicators();
  
  AuditHealthIndicatorValue getValue();
  
  enum AuditHealthIndicatorSeverity {
    
    IGNORED("Ignored", -2),
    NOTAVAILABLE("Not Available", -1),
    INFORMATION("Information", 0),
    NOTIFICATION("Notification", 1),
    LOW("Low", 2),
    MEDIUMLOW("Medium Low", 3),
    MEDIUM("Medium", 4),
    MEDIUMHIGH("Medium High", 5),
    HIGH("High", 6),
    CRITICAL("Critical", 7),
    FATAL("Fatal", 8);
    
    private AuditHealthIndicatorSeverity(String name, int severity) {
      this.name = name;
      this.severity = severity;
    }
    
    public int getSeverity() {
      return severity;
    }
    
    @Override
    public String toString() {
      return name;
    }
    
    private final String name;
    private final int severity;
    
    public static AuditHealthIndicatorSeverity max(AuditHealthIndicatorSeverity a, AuditHealthIndicatorSeverity b) {
      if (a == null || a == b) return b;
      if (b == null) return a;
      if (a.severity >= b.severity) return a;
      return b;
    }
    
    public static AuditHealthIndicatorSeverity findBySeverity(int severity) {
      switch (severity) {
        case -2:  return IGNORED;
        case -1:  return NOTAVAILABLE;
        case 0:  return INFORMATION;
        case 1:  return NOTIFICATION;
        case 2:  return LOW;
        case 3:  return MEDIUMLOW;
        case 4:  return MEDIUM;
        case 5:  return MEDIUMHIGH;
        case 6:  return HIGH;
        case 7:  return CRITICAL;
        case 8:  return FATAL;
        default : return NOTAVAILABLE;
      }
    }
  }
  
  enum AuditHealthIndicatorStatus {
    
    IGNORED("G", "Ignored", -2),
    NOTAVAILABLE("N", "Not Available", -1),
    INFORMATION("I", "Information", 0),
    OK("O", "OK", 1),
    ANALYSIS("A", "OK", 2),
    WARNING("W", "Warning", 3),
    ERROR("E", "Error", 4);
    
    private AuditHealthIndicatorStatus(String code, String name, int severity) {
      this.code = code;
      this.name = name;
      this.severity = severity;
    }
    
    public int getSeverity() {
      return severity;
    }
    
    public String getCode() {
      return code;
    }
    
    @Override
    public String toString() {
      return name;
    }
    
    private final String name;
    private final String code;
    private final int severity;
    
    public static AuditHealthIndicatorStatus max(AuditHealthIndicatorStatus a, AuditHealthIndicatorStatus b) {
      if (a == null || a == b) return b;
      if (b == null) return a;
      if (a.severity >= b.severity) return a;
      return b;
    }
    
    public static AuditHealthIndicatorStatus findBySeverity(int severity) {
      if (4 == severity) return ERROR;
      if (3 == severity) return WARNING;
      if (2 == severity) return ANALYSIS;
      if (1 == severity) return OK;
      if (0 == severity) return INFORMATION;
      if (-2 == severity) return IGNORED;
      return NOTAVAILABLE;
    }
    
    public static AuditHealthIndicatorStatus findByCode(String code) {
      if ("O".equals(code)) return OK;
      if ("E".equals(code)) return ERROR;
      if ("W".equals(code)) return WARNING;
      if ("A".equals(code)) return ANALYSIS;
      if ("I".equals(code)) return INFORMATION;
      if ("G".equals(code)) return IGNORED;
      return NOTAVAILABLE;
    }
  }
  
  interface AuditHealthIndicatorValue extends AuditHealthIndicatorFigure {
    
    AuditHealthIndicatorSeverity getSeverity();
    AuditHealthIndicatorStatus getStatus();
    
    DateAccessor getCreationDate();
    EzArray<AuditHealthIndicatorReferenceDate> getReferenceDate();
    
    boolean isWithSubValue();
    
    int getSubIndicatorNaCount();
    int getSubIndicatorInformationCount();
    int getSubIndicatorOKCount();
    int getSubIndicatorAnalyseCount();
    int getSubIndicatorWarningCount();
    int getSubIndicatorErrorCount();
    
  }
  
  interface AuditHealthIndicatorUnit {
    boolean isPercentage();
    boolean isInteger();
  }
  
  interface AuditHealthIndicatorReferenceDate {
    
    String getName();
    EzDate getDate();
  }
  
  interface AuditHealthIndicatorFigure {
    
    AuditHealthIndicatorUnit getUnit();

    AuditHealthIndicator getIndicator();
    String getComment();
    
    int getInt();
    double getDouble();
  }
}

package com.easyrms.gui;

import java.util.*;

public class SimpleHTMLListPane extends AbstractHTMLListPane {

  public SimpleHTMLListPane() {
  }
  public SimpleHTMLListPane(String title) {
    this.title = title;
  }
  public SimpleHTMLListPane(String title, Pane[] panes) {
    this.title = title;
    this.panes.addAll(Arrays.asList(panes));
  }
  
  public int getWidth() {
    return panes.size();
  }

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public SimpleHTMLListPane add(Pane pane) {
		panes.add(pane);
		return this;
	}
  
  public void setWidth(int width) {
    this.panes.ensureCapacity(width);
  }
	
  public void setPane(int i, Pane pane) {
    this.panes.set(i, pane);
  }
  public void setPane(Pane[] panes) {
    this.panes.clear();
    this.panes.addAll(Arrays.asList(panes));
  }
	
  @Override
  public Pane getPane(int i) {
		return panes.get(i);
	}

	private final ArrayList<Pane> panes = new ArrayList<Pane>();
	private String title = "";
}

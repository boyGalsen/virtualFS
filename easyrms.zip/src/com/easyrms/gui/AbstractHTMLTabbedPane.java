package com.easyrms.gui;

import com.ezrms.core.www.form.javascript.*;

import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.net.content.*;

import java.io.*;


public abstract class AbstractHTMLTabbedPane implements PaneContainer {

	public int getHeight() { return 1; }
  

  public boolean isAvailable() {
    return true;
  }
  
  public final EzArray<? extends AbstractHtmlAction> getAlternativeTables() { 
    return this.alternativeTables; 
  }
  public void setAlternativeTables(EzArray<? extends AbstractHtmlAction> alternativeTables) { 
    this.alternativeTables = alternativeTables; 
  }

  public final boolean isWithoutCurrency() { 
    return this.isWithoutCurrency; 
  }
  public void setWithoutCurrency(boolean isWithoutCurrency) { 
    this.isWithoutCurrency = isWithoutCurrency; 
  }

	public Pane getPane(int i, int j) {
		if (i <= 0) throw new IllegalStateException();
		return getPane(j);
	}
	
	protected abstract Pane getPane(int i);
	
  public void print(EzContextOutput ezout) throws IOException {
    final EzWriter out = ezout.getOut();
  	final int size = getWidth();
		final String id = IDGenerator.reference.getNewID()+"T";
    final String sizeString = IntegerCache.toString(size);
		out.rawWrite("<script>function change");
		out.write(id);
		out.rawWrite("(pValue) { var i = 0; for (i = 0 ;  i < ");
    out.write(sizeString);
    out.rawWrite(" ; i++) { document.getElementById('");
    out.write(id);
    out.rawWrite("E'+i).className='tabPaneOff'; document.getElementById('");
    out.write(id);
    out.rawWrite("'+i).style.display='none'; } document.getElementById('");
    out.write(id);
    out.rawWrite("E'+pValue).className='tabPaneOn'; document.getElementById('");
    out.write(id);
    out.rawWrite("'+pValue).style.display='';}</script><table border=\"0px\" cellspacing=\"0px\" cellpadding=\"0px\" class=\"tabPaneTable\" width=\"");
    out.write(StringComparator.NVL(getGlobalWidth()));
    out.rawWrite("\" style=\"");
    out.write(StringComparator.NVL(getStyle()));
    out.rawWrite("border-collapse:collapse;\"><tr style=\"border-bottom: 1px solid #B3B3B3;\"><td width=\"100%\">");
		for (int i = 0 ; i < size ; i++) {
      final String iString = IntegerCache.toString(i);
			out.rawWrite("<div class=\"tabPaneDiv\" onclick='change");
      out.write(id);
      out.rawWrite("(");
      out.write(iString);
      out.rawWrite(")'><div id='");
      out.write(id);
      out.rawWrite("E");
      out.write(iString);
      out.rawWrite("' class='");
      out.rawWrite(i == currentTab ? "tabPaneOn" : "tabPaneOff");
      out.rawWrite("'>");
			final Pane pane = getPane(i);
			if (pane != null)	{
			  out.write(StringComparator.NVL(pane.getTitle()));
			}
			out.rawWrite("</div></div>");
		}
		out.rawWrite("</tr>");
		out.rawWrite("<tr><td class=\"tabPaneBody\" width=\"100%\">");
		for (int i = 0 ; i < size ; i++) {
			out.rawWrite("<div id=\"");
      out.write(id);
      out.write(i);
      out.rawWrite("\" style=\"");
      out.write(StringComparator.NVL(getPaneStyle()));
      out.rawWrite(i == currentTab ? "display:'';" : "display:none;");
      out.rawWrite("\" class=\"CalLong\">");
			final Pane pane = getPane(i);
			if (pane != null) pane.print(ezout);
			out.rawWrite("</DIV>");
		}
		out.rawWrite("</td></tr>");
    out.rawWrite("</table>");
  }
  
  public void setCurrentTab(int currentTab) { this.currentTab = currentTab; }  
  
  public void setPaneStyle(String paneStyle) {
    if (StringComparator.isNotNull(paneStyle) && !paneStyle.endsWith(";")) {
      paneStyle = paneStyle+";"; 
    }
    this.paneStyle = paneStyle;
  }
  
  public String getPaneStyle() {
    return paneStyle;
  }
  
  public void setStyle(String style) {
    if (StringComparator.isNotNull(style) && !style.endsWith(";")) {
      style = style+";"; 
    }
    this.style = style;
  }
  
  public String getStyle() {
    return style;
  }
  
  public void setGlobalWidth(String width) {
    this.width = width;
  }
  
  public String getGlobalWidth() {
    return width;
  }
  
  private String width = "99%";
  private String style = "width:99%;";
  private String paneStyle;
  private int currentTab = 0;
  private boolean isWithoutCurrency;
  private EzArray<? extends AbstractHtmlAction> alternativeTables;
}

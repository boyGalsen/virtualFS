package com.easyrms.gui;


public interface PaneContainer extends Pane {

  int getWidth();
  int getHeight();
  
  Pane getPane(int i, int j);
}

package com.easyrms.gui;

import com.easyrms.io.*;

import java.io.*;


public interface FormPane {

  void printForm(EzContextOutput ezout) throws IOException;
  
  /**
   * return true if one field at least;
   */
  boolean printMainForm(EzContextOutput ezout) throws IOException;
}

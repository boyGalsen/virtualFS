package com.easyrms.gui;

import com.ezrms.core.www.form.javascript.*;
import com.ezrms.core.www.form.javascript.SelectJavascriptAction.*;

import com.easyrms.io.*;
import com.easyrms.table.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.format.*;
import com.easyrms.util.net.content.*;

import java.io.*;


public abstract class AbstractHTMLPaneContainer implements PaneContainer {

  public String getTitle() { return null; }
  public boolean isAvailable() { 
    final int height = getHeight();
    final int width = getWidth();
    return (height > 0 && width > 0);
  }
  public boolean isWithPaneTitle() { return isWithPaneTitle; }
  public void setWithPaneTitle(boolean isWithPaneTitle) { this.isWithPaneTitle = isWithPaneTitle; }
  
  protected int getCellSpacing() { 
    return 0; 
  }
  protected int getCellPadding() { 
    return 0; 
  }
  protected int getTopPadding() { 
    return 10; 
  }
  protected int getLeftPadding() { 
    return 20; 
  }
  
  public void setAlternativeTables(EzArray<? extends AbstractHtmlAction> value) { 
    this.alternatives = value; 
  }
  public final EzArray<? extends AbstractHtmlAction> getAlternativeTables() { 
    return alternatives; 
  }

  public void setOnCopyToClipBoard(String value) { 
    this.onCopyToClipBoard = value; 
  }
  public final String getOnCopyToClipBoard() { 
    return this.onCopyToClipBoard; 
  }
  
  public void print(EzContextOutput ezout) throws IOException {
    if (!isAvailable()) return;
    final EzWriter out = ezout.getOut();
    final int height = getHeight();
  	final int width = getWidth();
    if (height > 0 && width > 0) {
  		final int topPadding = getTopPadding();
  		final int leftPadding = getLeftPadding();
      out.rawWrite("<table border=\"0\" style='border:0px;margin:0px;padding:0px;'>"
  		+"<tr>"
      +"<td>"
  		+"<table border=\"0\" style='border:0px;margin:0px;padding:0px;' cellspacing=\"");
      out.write(getCellSpacing());
      out.rawWrite("\" cellpadding=\"");
      out.write(getCellPadding());
      out.rawWrite("\">");
      final String onCopy = getOnCopyToClipBoard();
      final String trValue = "<tr style='padding-top:"+topPadding+"px;'>";
      final String tdValue = "<td style='padding-left:"+leftPadding+"px;border:0px solid gray;'>";
			for (int row = 0; row < height; row++) {
				out.rawWrite((row == 0) ? "<tr>" : trValue);
        for (int column = 0; column < width; column++) {
					out.rawWrite((column == 0) ? "<td>" : tdValue);
					final Pane pane = getPane(row, column);
					if (pane != null) {      
            if (isWithPaneTitle) {
              final String title = pane.getTitle();
              if (StringComparator.isNotNull(title)) {
                out.rawWrite("<div class=\"paneContainerSubPaneTitle\">");
                out.write(title);
                out.rawWrite("</div>");
              }
            }
            pane.print(ezout);
          }
					out.rawWrite("</td>");
				}
				out.rawWrite("</tr>");
			}
      out.rawWrite("</table>"
			+"</td>");
      if (!ezout.isMobileContext()) {
  			out.rawWrite("<td valign='top'><table>");
        if (onCopy != null) {
          out.rawWrite("<tr><td>");
          final SelectJavascriptAction selection = new SelectJavascriptAction();
          selection.setKind(SelectJavascriptActionKind.INFOR_CONTEXT_TABLE);
          selection.add(copyToClipboardLabel, new SimpleJavascriptAction(onCopy), SimpleHTMLTable.getCopyIconURI());
          out.write(new HtmlImgAction("/wsr/ux3/gear_coche.png", selection).setHoverURL("/wsr/ux3/gear_coche_over.png").toString(ezout));
          out.rawWrite("</td></tr>");
        }
        if (alternatives != null && alternatives.getCount() > 0) {
          out.rawWrite("<tr><td>");
          {
            final SelectJavascriptAction selectionRelativeLink = new SelectJavascriptAction();
            selectionRelativeLink.setKind(SelectJavascriptActionKind.INFOR_CONTEXT_TABLE);
            for (int i = 0, n = alternatives.getCount(); i < n ; i++) {
              final AbstractHtmlAction action = alternatives.get(i);
              if (action != null && !(action instanceof HtmlImgAction)) {
                selectionRelativeLink.add(action.getEzTitle(), action.getOnClick(), SimpleHTMLTable.getLinkIconURI());
              }
            }
            if (!selectionRelativeLink.isEmpty()) {
              out.write(new HtmlImgAction("/wsr/ux3/link_coche.png", selectionRelativeLink).setHoverURL("/wsr/ux3/link_coche_over.png").toString(ezout));
            }
          }
          out.rawWrite("</td></tr>");
          {
            final SelectJavascriptAction selectionRelativeLink = new SelectJavascriptAction();
            selectionRelativeLink.setKind(SelectJavascriptActionKind.INFOR_CONTEXT_TABLE);
            for (int i = 0, n = alternatives.getCount(); i < n ; i++) {
              final AbstractHtmlAction action = alternatives.get(i);
              if (action instanceof HtmlImgAction) {
                out.rawWrite("<tr><td>");
                action.print(ezout);
                out.rawWrite("</td></tr>");
              }
            }
          }
        }
        
        out.rawWrite("</table></td>");
      }
      out.rawWrite("</tr></table>");
  	}
  }

  private String onCopyToClipBoard;
  private EzArray<? extends AbstractHtmlAction> alternatives;
  private boolean isWithPaneTitle;
  
  private static final String copyToClipboardLabel = TranslationUtil.getEzRMSContextLabelIntern("Copy data to clipboard");
}

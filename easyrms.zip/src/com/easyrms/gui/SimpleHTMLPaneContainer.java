package com.easyrms.gui;


public class SimpleHTMLPaneContainer extends AbstractHTMLPaneContainer {
	
  public SimpleHTMLPaneContainer(int height, int width) {
    this.height = height;
    this.width = width;
    this.panes = new Pane[height][width];
  }

  public SimpleHTMLPaneContainer(Pane[][] panes, boolean isReverse) {
    if (panes.length == 0) {
      this.width = this.height = 0;
      this.panes = panes;
    }
    else if (isReverse) {
      this.height = panes[0].length;
      this.width = panes.length;
      this.panes = new Pane[height][width];
      for (int j = 0; j < height; j++) {
        this.panes[j] = new Pane[width];
        for (int i = 0; i < width; i++) {
          this.panes[j][i] = panes[i][j];
        }
      }
    }
    else {
      this.width = panes[0].length;
      this.height = panes.length;
      this.panes = new Pane[height][width];
      for (int j = 0; j < height; j++) {
        this.panes[j] = new Pane[width];
        System.arraycopy(panes[j], 0, this.panes[j], 0, width);
      }
    }
  }

  @Override
  public String getTitle() { return title; }
  public void setTitle(String title) { this.title = title; }

  public int getHeight() { return this.height; }
  public int getWidth() { return this.width; }
  
  public void setPane(int row, int column, Pane pane) { this.panes[row][column] = pane; }
  public Pane getPane(int row, int column) { return this.panes[row][column]; }

	private final int height;
	private final int width;
	private final Pane[][] panes; 
	private String title = "";
}

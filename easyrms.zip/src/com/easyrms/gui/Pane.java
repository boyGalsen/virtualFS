package com.easyrms.gui;

import com.easyrms.io.*;
import com.easyrms.util.*;
import com.easyrms.util.net.content.*;

import java.io.*;


public interface Pane {

  String getTitle();
  boolean isAvailable();

	void print(EzContextOutput ezout) throws IOException;
  
  Pane blankPane = new Pane() {

    public String getTitle() {
      return null;
    }

    public void print(EzContextOutput ezout) throws IOException {
      final EzWriter out = ezout.getOut();
      out.write("&nbsp;");
    }
    
    public boolean isAvailable() {
      return true;
    }
    
  };
  
  EzArray<Pane> noPaneArray = new EzArray.NoEzArray<Pane>();
}

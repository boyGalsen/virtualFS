package com.easyrms.gui;

import com.ezrms.core.www.form.javascript.*;

import com.easyrms.io.*;

import java.io.*;


public class SimpleHTMLRefPane implements Pane {
  
  public SimpleHTMLRefPane(String text, String url) {
      this.text = text;
      this.url = url;
  }
  
  public boolean isAvailable() {
    return true;
  }

  public String getTitle() {
    return text;
  }

  public void print(EzContextOutput ezout) throws IOException {
    ezout.getOut().write(new HtmlHRefAction(text, 
      new EzRMSSendJavascriptAction(url)).toString());
  }

  private final String text;
  private final String url;
}

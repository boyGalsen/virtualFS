package com.easyrms.gui;

import com.easyrms.cache.*;
import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.format.*;

import java.awt.*;

public final class EzColor extends Color {
  
  public static String toEzColorName(String colorName) {
    if (StringComparator.isNull(colorName)) {
      return colorName;
    }
    return toEzColorNames.get(colorName);
  }
  
  private static final Cache<String, String> toEzColorNames = Caches.newCacheInstance(new Creator<String, String>() {

    public String create(String colorName) throws Exception {
      if (StringComparator.isNull(colorName)) {
        return colorName;
      }
      final Color color = Color.decode("0X"+colorName);
      final EzColor ezColor = getEzColor(color);
      return HTMLColorBuilder.referenceWithoutSharpFormat(ezColor);
    }  
  });
  
  public static EzColor getEzColor(int rgb) {
    return getEzColor(rgb, true);
  }
  
  /**
   * Get the nearest Soho color
   */
  public static EzColor getEzColor(int red, int green, int blue) {
    return getEzColor(new Color(red, green, blue));
  }
  
  /**
   * Transform the color whith the nearest color of the SOHO Palette
   */
  public static EzColor getEzColor(Color color) {
    return getEzColor(color.getRGB(), true);
  }
  
  /**
   * No modification of the color only transform the object Color to EzColor
   */
  public static EzColor valueOf(Color color) {
    return getEzColor(color.getRGB(), false);
  }
  
  /**
   * No modification of the color only transform the object Color to EzColor
   */
  public static EzColor valueOf(int rgb) {
    return getEzColor(rgb, false);
  }
  
  private static EzColor getEzColor(int rgb, boolean isSohoLike) {
    return ezColors.get(new Tuple2<Integer, Boolean>(IntegerCache.get(rgb), Boolean.valueOf(isSohoLike)));
  }
  
  private static final Cache<Tuple2<Integer, Boolean>, EzColor> ezColors = Caches.newCacheInstance(new Creator<Tuple2<Integer, Boolean>, EzColor>() {

    public EzColor create(Tuple2<Integer, Boolean> key) throws Exception {
      final int rgb = key.get0().intValue();
      if (key.get1().booleanValue()) {
        final int newRGB = getNearRGBSohoColor(rgb);
        final String newhexaColor = Integer.toHexString(newRGB).substring(2);
        final String hexaColor = Integer.toHexString(rgb).substring(2);
        colorConversion.trace("0x"+hexaColor+" -> 0x"+newhexaColor);
        return ezColors.get(Tuple.getTuple(IntegerCache.get(newRGB), Boolean.FALSE));
      }
      return new EzColor(rgb);
    }  
    
    Trace colorConversion = new Trace("Color Conversion", true);
  });

  private EzColor(int rgb) {
    super(rgb);
  }
  private EzColor(Color color) {
    super(color.getRGB());
  }
  
  @Override
  public EzColor darker() {
    return darker.get();
  }
  
  private EzColor getOriginalDarker() {
    return valueOf(super.darker());
  }
  private ObjectReference<EzColor> darker = new AutoCreateReference<EzColor>() {

    @Override
    protected EzColor create() {
      return getOriginalDarker();
    }
    
  };
  
  public EzColor pale() {
    return pale.get();
  }
  
  private ObjectReference<EzColor> pale = new AutoCreateReference<EzColor>() {

    @Override
    protected EzColor create() {
      return pale(EzColor.this);
    }    
  };
  
  public EzColor veryPale() {
    return veryPale.get();
  }
  
  private ObjectReference<EzColor> veryPale = new AutoCreateReference<EzColor>() {

    @Override
    protected EzColor create() {
      return veryPale(EzColor.this);
    }
    
  };
  
  public EzColor veryVeryPale() {
    return veryVeryPale.get();
  }
  
  private ObjectReference<EzColor> veryVeryPale = new AutoCreateReference<EzColor>() {

    @Override
    protected EzColor create() {
      return veryVeryPale(EzColor.this);
    }
    
  };
  
  @Override
  public EzColor brighter() {
    return valueOf(super.brighter());
  }
  
  @Override
  public boolean equals(Object obj) {
    return (obj == this || (obj instanceof EzColor && super.equals(obj)));
  }
  
  private static int getNearRGBSohoColor(int rgb) {
    if (Color.black.getRGB() == rgb || Color.white.getRGB() == rgb) {
      return rgb;
    }
    final Color colorToChange = new Color(rgb);
    final int colorToChangeRed = colorToChange.getRed();
    final int colorToChangeGreen = colorToChange.getGreen();
    final int colorToChangeBlue = colorToChange.getBlue();
    final boolean isGrayColorToChange = (colorToChangeRed == colorToChangeGreen && colorToChangeGreen == colorToChangeBlue);
    final EzArray<EzColor> sohoColors = isGrayColorToChange ? paletteOnlyGray : paletteAllColorsWithoutGray;

    Color nearColor = sohoColors.get(0);
    double lowestDistance = Double.MAX_VALUE;
    for (int i = 0, n = sohoColors.getCount(); i < n; i++) {
      final Color color = sohoColors.get(i);
      final int colorSohoRed = color.getRed();
      final int colorSohoGreen = color.getGreen();
      final int colorSohoBlue = color.getBlue();
      final double distance = Math.pow(colorSohoRed-colorToChangeRed, 2)+Math.pow(colorSohoGreen-colorToChangeGreen, 2)+Math.pow(colorSohoBlue-colorToChangeBlue, 2);
      if (distance < lowestDistance) {
        lowestDistance = distance;
        nearColor = color;
      }
    }
    return nearColor.getRGB();
  }
  
  public static EzColor pale(EzColor color) {
    if (color == null) {
      return null;
    }
    final Color newColor = new Color(
      Math.min((int)((double)color.getRed()/0xFF*(0xFF-0xB8+1)+0xB8), 255),
      Math.min((int)((double)color.getGreen()/0xFF*(0xFF-0xB8+1)+0xB8), 255),
      Math.min((int)((double)color.getBlue()/0xFF*(0xFF-0xB8+1)+0xB8), 255));
    return EzColor.valueOf(newColor);
  }
  
  public static EzColor veryPale(EzColor color) {
    if (color == null) {
      return null;
    }
    if (color.getRed()+color.getGreen()+color.getBlue() > 0x80*3) {
      color = EzColor.valueOf(new Color(
        Math.min((int)((double)color.getRed()  /0xFF*(0xFF-0xA0+1)+0xA0), 0xFF),
        Math.min((int)((double)color.getGreen()/0xFF*(0xFF-0xA0+1)+0xA0), 0xFF),
        Math.min((int)((double)color.getBlue() /0xFF*(0xFF-0xA0+1)+0xA0), 0xFF)));
    }
    else {
      color = EzColor.valueOf(new Color(
        Math.min((int)((double)color.getRed()  /0xFF*(0xFF-0xD8+1)+0xD8), 0xFF),
        Math.min((int)((double)color.getGreen()/0xFF*(0xFF-0xD8+1)+0xD8), 0xFF),
        Math.min((int)((double)color.getBlue() /0xFF*(0xFF-0xD8+1)+0xD8), 0xFF)));
    }
    return color;
  }
  public static EzColor veryVeryPale(EzColor color) {
    if (color == null) {
      return null;
    }
    return EzColor.valueOf(new Color(
      Math.min((int)((double)color.getRed()/0xFF*(0xFF-0xE4+1)+0xE4), 255),
      Math.min((int)((double)color.getGreen()/0xFF*(0xFF-0xE4+1)+0xE4), 255),
      Math.min((int)((double)color.getBlue()/0xFF*(0xFF-0xE4+1)+0xE4), 255)));
  }

  public static EzColor redify(EzColor color) {
    if (color == null) {
      return null;
    }
    return EzColor.valueOf(new Color(
      Math.min((int)(color.getRed()*1.1), 255),
      (int)(color.getGreen()*.95),
      (int)(color.getBlue()*.95)));
  }
  
  public final static EzColor white = new EzColor(new Color(255, 255, 255));
  public final static EzColor lightGray = new EzColor(new Color(192, 192, 192));
  public final static EzColor gray = new EzColor(new Color(128, 128, 128));
  public final static EzColor darkGray = new EzColor(new Color(64, 64, 64));
  public final static EzColor black = new EzColor(new Color(0, 0, 0));
  public final static EzColor red = new EzColor(new Color(255, 0, 0));
  public final static EzColor pink = new EzColor(new Color(255, 175, 175));
  public final static EzColor orange = new EzColor(new Color(255, 200, 0));
  public final static EzColor yellow = new EzColor(new Color(255, 255, 0));
  public final static EzColor green = new EzColor(new Color(0, 255, 0));
  public final static EzColor magenta = new EzColor(new Color(255, 0, 255));
  public final static EzColor cyan = new EzColor(new Color(0, 255, 255));
  public final static EzColor blue = new EzColor(new Color(0, 0, 255));
  
  public static final EzColor azureLight = new EzColor(0x61c5ff);
  public static final EzColor azure = new EzColor(0x13a3f7);
  public static final EzColor azureDeep = new EzColor(0x005ce6);
  
  public static final EzColor emeraldLight = new EzColor(0x9ed927);
  public static final EzColor emerald = new EzColor(0x2db329);
  public static final EzColor emeraldDeep = new EzColor(0x00733a);
  
  public static final EzColor amberLight = new EzColor(0xffd500);
  public static final EzColor amber = new EzColor(0xffaa00);
  public static final EzColor amberDepp = new EzColor(0xff6400);
  
  public static final EzColor rubyLight = new EzColor(0xff574d);
  public static final EzColor ruby = new EzColor(0xd5000e);
  public static final EzColor rubyDeep = new EzColor(0xb3000c);
  
  public static final EzColor tourmalineLigth = new EzColor(0xff80a2);
  public static final EzColor tourmaline = new EzColor(0xe63262);
  public static final EzColor tourmalineDeep = new EzColor(0xbf2951);
  
  public static final EzColor amethystLight = new EzColor(0xc680ff);
  public static final EzColor amethyst = new EzColor(0xa352cc);
  public static final EzColor amethystDeep = new EzColor(0x7533a6);
  
  public static final EzColor graphiteLight = new EzColor(0xb3b3b3);
  public static final EzColor graphite = new EzColor(0x737373);
  public static final EzColor graphiteDeep = new EzColor(0x595959);
  
  public static final EzColor sohoGray = new EzColor(0xEBEBEB);
  
  public static final EzColor turquoiseLight = new EzColor(0x6dd9d1);
  public static final EzColor turquoise = new EzColor(0x00c2b4);
  public static final EzColor turquoiseDeep = new EzColor(0x00898c);
  
  public static final EzArrayList<EzColor> paletteAllColors = new EzArrayList<EzColor>();
  public static final EzArrayList<EzColor> paletteAllColorsWithoutGray = new EzArrayList<EzColor>();
  public static final EzArrayList<EzColor> paletteOnlyGray = new EzArrayList<EzColor>();
  static {
    // Compute simple Soho Color palette 
    final EzArrayList<EzColor> paletteColors = new EzArrayList<EzColor>();
    paletteColors.add(azureLight);
    paletteColors.add(azure);
    paletteColors.add(azureDeep);
    
    paletteColors.add(emeraldLight);
    paletteColors.add(emerald);
    paletteColors.add(emeraldDeep);
    
    paletteColors.add(amberLight);
    paletteColors.add(amber);
    paletteColors.add(amberDepp);
    
    paletteColors.add(rubyLight);
    paletteColors.add(ruby);
    paletteColors.add(rubyDeep);
    
    paletteColors.add(tourmalineLigth);
    paletteColors.add(tourmaline);
    paletteColors.add(tourmalineDeep);
    
    paletteColors.add(amethystLight);
    paletteColors.add(amethyst);
    paletteColors.add(amethystDeep);
    
    paletteColors.add(graphiteLight);
    paletteColors.add(graphite);
    paletteColors.add(graphiteDeep);
    
    paletteColors.add(turquoiseLight);
    paletteColors.add(turquoise);
    paletteColors.add(turquoiseDeep);
    
    final EzArrayList<EzColor> paletteMoreColors = new EzArrayList<EzColor>();
    for (int i = 0, n = paletteColors.getCount(); i < n; i++) {
      final Color c1 = paletteColors.get(i);
      final Color c2 = paletteColors.get((i+3)%n);
      
      if (graphiteLight.equals(c1)
        || graphite.equals(c1)
        || graphiteDeep.equals(c1)
        || graphiteLight.equals(c2)
        || graphite.equals(c2)
        || graphiteDeep.equals(c2)) 
      {
        continue;
      }
      
      paletteMoreColors.add(new EzColor(new Color((c1.getRed()+c2.getRed())/2, (c1.getGreen()+c2.getGreen())/2, (c1.getBlue()+c2.getBlue())/2)));
      paletteMoreColors.add(new EzColor(new Color((3*c1.getRed()+c2.getRed())/4, (3*c1.getGreen()+c2.getGreen())/4, (3*c1.getBlue()+c2.getBlue())/4)));
      paletteMoreColors.add(new EzColor(new Color((c1.getRed()+3*c2.getRed())/4, (c1.getGreen()+3*c2.getGreen())/4, (c1.getBlue()+3*c2.getBlue())/4)));
      paletteMoreColors.add(new EzColor(new Color((c1.getRed()+2*c2.getRed())/3, (c1.getGreen()+2*c2.getGreen())/3, (c1.getBlue()+2*c2.getBlue())/3)));
      paletteMoreColors.add(new EzColor(new Color((2*c1.getRed()+c2.getRed())/3, (2*c1.getGreen()+c2.getGreen())/3, (2*c1.getBlue()+c2.getBlue())/3)));
    }
    
    // Create a big Soho Color palette
    paletteAllColors.addAll((EzArray<EzColor>) paletteColors);
    paletteAllColors.addAll((EzArray<EzColor>) paletteMoreColors);
    
    for (int i = 0, n = paletteAllColors.getCount(); i < n; i++) {
      final EzColor sohoColor = paletteAllColors.get(i); 
      if (graphiteLight.equals(sohoColor)
        || graphite.equals(sohoColor)
        || graphiteDeep.equals(sohoColor)) 
      {
        paletteOnlyGray.add(sohoColor);
      }
      else {
        paletteAllColorsWithoutGray.add(sohoColor);
      }
    }
  }
  
  public static final EzColor[] emptyArray = new EzColor[0];
}

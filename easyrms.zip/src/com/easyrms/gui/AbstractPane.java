package com.easyrms.gui;

public abstract class AbstractPane implements Pane {

  public AbstractPane() {
    this(null);
  }
  
  public AbstractPane(String title) {
    this.title = title;
  }
  
  public String getTitle() {
    return title;
  }
  
  public boolean isAvailable() {
    return true;
  }

  private String title;
}

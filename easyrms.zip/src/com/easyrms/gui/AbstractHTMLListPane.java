package com.easyrms.gui;

import com.easyrms.io.*;
import com.easyrms.util.IDGenerator;
import com.easyrms.util.net.content.*;

import java.io.IOException;


public abstract class AbstractHTMLListPane implements PaneContainer {

	public int getHeight() {
		return 1;
	}

	public Pane getPane(int i, int j) {
		if (i <= 0) throw new IllegalStateException();
		return getPane(j);
	}
  
  public boolean isAvailable() {
    return true;
  }
	
	protected abstract Pane getPane(int i);
	
  public void print(EzContextOutput ezout) throws IOException {
  	final int size = getWidth();
		final String id = IDGenerator.reference.getNewID()+"T";
    final EzWriter out = ezout.getOut();
    out.write("<style>@page { size: landscape; } </style>\r\n");
		for (int i = 0 ; i < size ; i++) {
			final Pane pane = getPane(i);
			if (pane != null) {
        out.write("<div id=\""+(id+i)+"\" style=\""+(i < (size-1) ? "page-break-after:always;" : "")+""+ ((i == currentTab) ? "display:'';" : "display:'';") +"\" class=\"EzBlock\">");
        pane.print(ezout);
        out.write("</DIV>");
      }
		}
  }
  
  public void setCurrentTab(int currentTab) {
    this.currentTab = currentTab;
  }  
  
  private int currentTab = 0;
  
}

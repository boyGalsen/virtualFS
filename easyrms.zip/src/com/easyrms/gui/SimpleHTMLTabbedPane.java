package com.easyrms.gui;

import com.easyrms.util.*;

public class SimpleHTMLTabbedPane extends AbstractHTMLTabbedPane {

  public SimpleHTMLTabbedPane() {
  }
  public SimpleHTMLTabbedPane(String title) {
    this.title = title;
  }
  public SimpleHTMLTabbedPane(String title, Pane... panes) {
    this.title = title;
    this.panes.addAll(panes);
  }
  
  public void setWidth(int width) { this.panes.ensureCapacity(width); }
  public int getWidth() { return panes.size(); }

  public String getTitle() { return title; }
	public void setTitle(String title) { this.title = title; }
	
  @Override
  public Pane getPane(int i) { return panes.get(i); }
  public SimpleHTMLTabbedPane add(Pane pane) { panes.add(pane); return this; }
  public void setPane(int i, Pane pane) { this.panes.set(i, pane); }
  public void setPane(Pane... panes) {
    this.panes.clear();
    this.panes.addAll(panes);
  }
	
	private final EzArrayList<Pane> panes = new EzArrayList<Pane>();
	private String title = "";
}

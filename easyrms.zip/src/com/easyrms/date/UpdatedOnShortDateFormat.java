package com.easyrms.date;

import java.text.*;

import com.easyrms.util.format.AbstractFormat;


public class UpdatedOnShortDateFormat extends AbstractFormat {

  public static String referenceFormat(Object obj) {
    return reference.get().format(obj);
  }
  
  private static final ThreadLocal<UpdatedOnShortDateFormat> reference = new ThreadLocal<UpdatedOnShortDateFormat>() {

    @Override
    protected UpdatedOnShortDateFormat initialValue() {
      return new UpdatedOnShortDateFormat();
    }
    
  };
  
  protected UpdatedOnShortDateFormat() {}

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj != null) {
      if (obj instanceof DateAccessor) {
        obj = ((DateAccessor)obj).toDate();
      }
      EzShortDateTranslationFormat.referenceFormat(obj, toAppendTo, pos);
      toAppendTo.append(" ");
      EzDateTranslationFormat.timeFormatFormat(obj, toAppendTo, pos);
    }
    return toAppendTo;
  }
  
  public static final String updatedOnLabel = UpdatedOnDateFormat.updatedOnLabel;
}
package com.easyrms.date;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;
import com.easyrms.util.format.*;

import java.text.*;


public class EzLongDateTranslationFormat extends EzDateTranslationFormat {
  
  public static String formatDurationTime(long timeDurationInMilliseconds) {
    final long timeDurationInSeconds = timeDurationInMilliseconds/1000;
    final long days = timeDurationInSeconds/(60*60*24);
    final long hours = (timeDurationInSeconds%(60*60*24))/(60*60);
    final long minutes = (timeDurationInSeconds%(60*60))/(60);
    final long seconds = (timeDurationInSeconds%(60));
    return ""
      +(days > 0 
         ? days+" "+(days != 1 ? daysLongLabel : dayLongLabel)+" " 
         : "")
      +(hours > 0 
         ? hours+" "+(hours != 1 ? hoursLongLabel : hourLongLabel)+" " 
         : "")
      +(minutes > 0 
         ? minutes+" "+(minutes != 1 ? minutesLongLabel : minuteLongLabel)+" " 
         : "")
      +(seconds > 0 || timeDurationInSeconds == 0
         ? seconds+" "+(seconds != 1 ? secondsLongLabel : secondLongLabel)+" " 
         : "");
  }
  
  public static String formatElapsedTime(long timeElapsedInMilliseconds) {
    final long inMinutes = timeElapsedInMilliseconds/(60*1000);
    if (inMinutes < 1) {
      return nowLabel;
    }
    if (inMinutes < 60) {
      return inMinutes+" "+(inMinutes == 1 ? minuteLongLabel : minutesLongLabel)+" "+agoLabel;
    }
    final long inHours = timeElapsedInMilliseconds/(60*60*1000);
    if (inHours < 24) {
      return inHours+ " "+ (inHours == 1 ? hourLongLabel : hoursLongLabel)+" "+agoLabel;
    }
    final long inDays = timeElapsedInMilliseconds/(24*60*60*1000);
    if (inDays < 7) {
      return inDays+ " "+(inDays == 1 ? dayLongLabel : daysLongLabel)+" "+agoLabel;
    }
    final int inWeeks = (int)(inDays / 7);
    if (inWeeks <= 5) {
      return inWeeks +" "+(inWeeks == 1 ? weekLongLabel : weeksLongLabel)+" "+agoLabel;
    }
    final int inMonths = (int)(inDays / 30);
    if (inDays <= 365) {
      return inMonths+" "+(inMonths == 1 ? monthLongLabel : monthsLongLabel)+" "+agoLabel;
    }
    final int inYears = (int)(inDays / 365);
    return inYears+" "+(inYears == 1 ? yearLongLabel : yearsLongLabel)+" "+agoLabel;    
  }
  
  
  static String referenceUnBreakFormat(Object obj) {
    return referenceUnBreak.get().format(obj); 
  }
  
  static String referencePeriodAndYearDetailsFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period); 
    }
    return referencePeriodAndYearFormat(period)
      +" ("+EzLongDateTranslationFormat.referenceDOMFormat(period.getFirstDay())+" "+EzLongDateTranslationFormat.referenceMonthFormat(period.getFirstDay())
      +"-"+EzLongDateTranslationFormat.referenceDOMFormat(period.getLastDay())+" "+EzLongDateTranslationFormat.referenceMonthFormat(period.getLastDay())+")";
  }
  
  static String referencePeriodAndYearDetailsFormat(PeriodManager manager, EzDate obj) {
    return referencePeriodAndYearDetailsFormat(ObjectComparator.NVL(manager, EzMonth.manager).getPeriod(obj));
  }
  
  static String referencePeriodAndYearFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(period); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      if (yearManager == null) {
        return reference.get().format(period)+" "+referenceYear.get().format(period.getFirstDay());
      }
      final Period year = yearManager.getPeriod(period.getFirstDay());
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay());
      }
      return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay())+"-"+referenceYear.get().format(year.getLastDay());
    }
  }
  
  static StringBuffer referencePeriodAndYearFormat(Period period, StringBuffer buffer, FieldPosition position) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period, buffer, position); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(period, buffer, position); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      if (yearManager == null) {
        reference.get().format(period, buffer, position).append(" ");
        return referenceYear.get().format(period.getFirstDay(), buffer, position);
      }
      final Period year = yearManager.getPeriod(period.getFirstDay());
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        referenceWithoutYear.get().format(period, buffer, position).append(" ");
        return referenceYear.get().format(year.getFirstDay(), buffer, position);
      }
      referenceWithoutYear.get().format(period, buffer, position).append(" ");
      referenceYear.get().format(year.getFirstDay(), buffer, position).append("-");
      return referenceYear.get().format(year.getLastDay(), buffer, position);
    }
  }
  
  public static String referencePeriodAndYearFormat(PeriodManager manager, EzDate obj) {
    return referencePeriodAndYearFormat(ObjectComparator.NVL(manager, EzMonth.manager).getPeriod(obj));
  }
  
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceUnBreak = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return new EzLongDateTranslationFormat() {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
        
        @Override
        public String formatSeparator() {
          return "&nbsp;";
        }
      };
    }
    
  };

  static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  static StringBuffer referenceFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return reference.get().format(obj, buff, pos); 
  }

  static String referenceFormatDOW(int obj) {
    return reference.get().formatDOW(obj); 
  }
  static String referenceFormatDOM(int obj) {
    return reference.get().formatDOM(obj); 
  }
  static String referenceFormatMOY(int obj) {
    return reference.get().formatMOY(obj); 
  }
  static String referenceFormatYear(int obj) {
    return reference.get().formatYear(obj); 
  }
  static EzLongDateTranslationFormat referenceClone() {
    return new EzLongDateTranslationFormat() {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> reference = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceClone();
    }
    
  };
  
  
  static EzLongDateTranslationFormat referenceWithoutYearClone() {
    return new EzLongDateTranslationFormat(DAY | MONTH) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }

  
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceWithoutYear = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceWithoutYearClone();
    }
    
  };
  
  
  static String referenceWeekFormat(Object obj) {
    return referenceWeek.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceWeek = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return new EzLongDateTranslationFormat() {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };
  
  static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  static EzLongDateTranslationFormat referenceMonthClone() {
    return new EzLongDateTranslationFormat(MONTH) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceMonth = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceMonthClone();
    }
    
  };
  
  static String referenceYearFormat(Object obj) {
    return referenceYear.get().format(obj); 
  }
  
  static StringBuffer referenceYearFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    return referenceYear.get().format(obj, buffer, position); 
  }

  static EzLongDateTranslationFormat referenceYearClone() {
    return new EzLongDateTranslationFormat(YEAR) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceYear = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceYearClone();
    }
    
  };
  
  static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  
  static StringBuffer referenceMonthAndYearFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    return referenceMonthAndYear.get().format(obj, buffer, position); 
  }

  static EzLongDateTranslationFormat referenceMonthAndYearClone() {
    return new EzLongDateTranslationFormat(MONTH+YEAR) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceMonthAndYear = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceMonthAndYearClone();
    }
    
  };
  
  static String referenceWithDOWFormat(Object obj) {
    return referenceWithDOW.get().format(obj); 
  }
  static EzLongDateTranslationFormat referenceWithDOWClone() {
    return new EzLongDateTranslationFormat(DOW+DAY+MONTH+YEAR) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceWithDOW = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceWithDOWClone();
    }
    
  };
  
  static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  static EzLongDateTranslationFormat referenceDOWClone() {
    return new EzLongDateTranslationFormat(DOW) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceDOW = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceDOWClone();
    }
    
  };
  
  static String referenceDOMFormat(Object obj) {
    return referenceDOM.get().format(obj); 
  }
  
  static String referenceMOYFormat(Object obj) {
    if (obj instanceof EzDate) {
      return reference.get().formatMOY(((EzDate)obj).getMOY()); 
    }
    return "";
  }
  static EzLongDateTranslationFormat referenceDOMClone() {
    return new EzLongDateTranslationFormat(DAY) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  private static final ThreadLocal<EzLongDateTranslationFormat> referenceDOM = new ThreadLocal<EzLongDateTranslationFormat>() {

    @Override
    protected EzLongDateTranslationFormat initialValue() {
      return referenceDOMClone();
    }
    
  };

  public EzLongDateTranslationFormat() {
    super();
  }
  public EzLongDateTranslationFormat(int display) {
    super(display);
  }

  @Override
  public String formatSeparator() {
    return " ";
  }

  @Override
  public String formatDOW(int dow) {
    return dowLongTexts[dow];
  }

  @Override
  public String formatMOY(int moy) {
    return moyLongTexts[moy];
  }

  @Override
  public String formatYear(int year) {
    return IntegerCache.toString(year);
  }
  
  private static final String nowLabel = TranslationUtil.getEzRMSContextLabelIntern("Now");  
  private static final String secondsLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Seconds");
  private static final String secondLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Second");
  private static final String minutesLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Minutes");
  private static final String minuteLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Minute");
  private static final String hourLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Hour");
  private static final String hoursLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Hours");
  private static final String dayLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Day");
  private static final String daysLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Days");
  private static final String weekLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Week");
  private static final String weeksLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Weeks");
  private static final String monthLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Month");
  private static final String monthsLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Months");
  private static final String yearLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Year");
  private static final String yearsLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Years");
  private static final String agoLabel = TranslationUtil.getEzRMSContextLabelIntern("Ago");
}

package com.easyrms.date;

import java.text.FieldPosition;

public class EzVeryShortDateTranslationFormat extends EzDateTranslationFormat {

  public static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  public static StringBuffer referenceFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return reference.get().format(obj, buff, pos); 
  }
  public static EzVeryShortDateTranslationFormat referenceClone() {
    return new EzVeryShortDateTranslationFormat() {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzVeryShortDateTranslationFormat> reference = new ThreadLocal<EzVeryShortDateTranslationFormat>() {

    @Override
    protected EzVeryShortDateTranslationFormat initialValue() {
      return referenceClone();
    }
    
  };
  
  public static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  public static EzVeryShortDateTranslationFormat referenceMonthClone() {
    return new EzVeryShortDateTranslationFormat(MONTH) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzVeryShortDateTranslationFormat> referenceMonth = new ThreadLocal<EzVeryShortDateTranslationFormat>() {

    @Override
    protected EzVeryShortDateTranslationFormat initialValue() {
      return referenceMonthClone();
    }
    
  };
  
  public static String referencePeriodAndYearFormat(PeriodManager manager, EzDate obj) {
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(obj); 
    }
    final PeriodManager yearManager = manager.getYearManager();
    final Period period = manager.getPeriod(obj);
    if (yearManager == null) {
      return period.toString()+" "+referenceYear.get().format(period.getFirstDay());
    }
    final Period year = yearManager.getPeriod(obj);
    if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
      return period.toString()+" "+referenceYear.get().format(year.getFirstDay().getEzMonth().getLastDay());
    }
    return period.toString()+" "+referenceYear.get().format(year.getFirstDay())+"-"+referenceYear.get().format(year.getLastDay());
  }
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  
  private static final ThreadLocal<EzVeryShortDateTranslationFormat> referenceMonthAndYear = new ThreadLocal<EzVeryShortDateTranslationFormat>() {

    @Override
    protected EzVeryShortDateTranslationFormat initialValue() {
      return new EzVeryShortDateTranslationFormat(MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };


  private static final ThreadLocal<EzVeryShortDateTranslationFormat> referenceYear = new ThreadLocal<EzVeryShortDateTranslationFormat>() {

    @Override
    protected EzVeryShortDateTranslationFormat initialValue() {
      return new EzVeryShortDateTranslationFormat(YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };


  public static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  public static EzVeryShortDateTranslationFormat referenceDOWClone() {
    return new EzVeryShortDateTranslationFormat(DOW) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzVeryShortDateTranslationFormat> referenceDOW = new ThreadLocal<EzVeryShortDateTranslationFormat>() {

    @Override
    protected EzVeryShortDateTranslationFormat initialValue() {
      return referenceDOWClone();
    }
  };

  public EzVeryShortDateTranslationFormat() {
    super();
  }
  public EzVeryShortDateTranslationFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return "-";
  }
	@Override
  public String formatDOW(int dow) {
    return dowShortTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyShortTexts[moy];
  }
}
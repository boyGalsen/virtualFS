package com.easyrms.date;

import com.easyrms.util.*;

import java.io.*;


public interface Duration extends EzDateCollection, Cloneable, Serializable {

  Period getStart();
  Period getLast();
  int getHorizon();
  
  Bounds getDayBounds();
  Bounds getPeriodBounds();
  
  Duration noDuration = new Duration() {

    public Bounds getDayBounds() {
      return Bounds.noBounds;
    }

    public int getHorizon() {
      return 0;
    }

    public Period getLast() {
      return null;
    }

    public Bounds getPeriodBounds() {
      return getDayBounds();
    }

    public Period getStart() {
      return null;
    }

    public EzDate getDay(int i) {
      throw new ArrayIndexOutOfBoundsException(i);
    }

    public int getDayCount() {
      return 0;
    }

    public EzDate getFirstDay() {
      return null;
    }

    public EzDate getLastDay() {
      return null;
    }    
  };
}
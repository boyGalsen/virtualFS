package com.easyrms.date;

import java.text.*;
import java.util.*;


public class EzDDMMYYYYDateFormat extends EzDateFormat {

  public static final String referenceMonthExcelFormat(Object obj) {
    return referenceMonthExcel.get().format(obj);
  }
  private static final ThreadLocal<EzDDMMYYYYDateFormat> referenceMonthExcel = new ThreadLocal<EzDDMMYYYYDateFormat>() {

    @Override
    protected EzDDMMYYYYDateFormat initialValue() {
      return new EzDDMMYYYYDateFormat(EzDDMMYYYYDateFormat.MONTH+EzDDMMYYYYDateFormat.YEAR,"/");
    }
  };
  
  public static final String referenceExcelFormat(Object obj) {
    return referenceExcel.get().format(obj);
  }
  public static final EzDate parseExcel(String value) {
    try {
      return referenceExcel.get().parse(value);
    }
    catch (Throwable ignored) {
      return null;
    }
  }
  public static final EzDDMMYYYYDateFormat referenceExcelClone() {
    return new EzDDMMYYYYDateFormat(EzDDMMYYYYDateFormat.DAY+EzDDMMYYYYDateFormat.MONTH+EzDDMMYYYYDateFormat.YEAR,"/");
  }
  
  private static final ThreadLocal<EzDDMMYYYYDateFormat> referenceExcel = new ThreadLocal<EzDDMMYYYYDateFormat>() {

    @Override
    protected EzDDMMYYYYDateFormat initialValue() {
      return referenceExcelClone();
    }
  };

  public EzDDMMYYYYDateFormat() {
    this(null);
  }
  public EzDDMMYYYYDateFormat(String separator) {
    super();
    this.separator = separator;
  }
  public EzDDMMYYYYDateFormat(int display) {
    this(display, null);
  }
  public EzDDMMYYYYDateFormat(int display, String separator) {
    super(display);
    this.separator = separator;
  }

  @Override
  public final String formatSeparator() {
    return separator;
  }

  public EzDate parse(int source) {
    final int year;
    if (isYearDisplayed()) {
      year = source % 10000;
      source /= 10000;
    }
    else {
      year = EzDate.valueOf(new Date()).getYear();
    }
    final int month;
    if (isMonthDisplayed()) {
      month = source % 100;
      source /= 100;
    }
    else {
      month = 1;
    }
    final int day;
    if (isDayDisplayed()) {
      day = source;
    }
    else {
      day = 1;
    }
    return EzDate.getEzDate(year, month, day);
  }
  public EzDate parse(Integer source) {
    return (source != null) ? parse(source.intValue()) : null;
  }
  @Override
  protected StringBuffer format(
    EzDate date, StringBuffer toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    if (isDayDisplayed){
      toAppendTo.append(domFigures[date.getDOM()]);
      if((isMonthDisplayed || isYearDisplayed) && separator!=null){
        toAppendTo.append(separator);
      }
    }
    if (isMonthDisplayed) {
      toAppendTo.append(moyFigures[date.getMOY()]);
      if (isYearDisplayed && separator!=null) {
        toAppendTo.append(separator);
      }
    }
    if (isYearDisplayed) {
      toAppendTo.append(date.getYear());
    }
    return toAppendTo;
  }

  @Override
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    final int start = status.getIndex();
    final int separatorLength = (separator == null) ? 0 : separator.length();
    try {
      int length = 0;
      int day = 1;
      int month = 1;
      int year = EzDate.valueOf(new Date()).getYear();
      if (isDayDisplayed()) {
        day = Integer.parseInt(source.substring(start+length, start+length+2));
        length+=2;
        if (separatorLength > 0 && (isMonthDisplayed() || isYearDisplayed())) {
          if (!separator.equals(source.substring(start+length, start+length+separatorLength))) {
            throw new ParseException("Not An Easy Date", start);
          }
          length += separatorLength;
        }
      }
      if (isMonthDisplayed()) {
        month = Integer.parseInt(source.substring(start+length, start+length+2));
        length+=2;
        if (separatorLength > 0 && isYearDisplayed()) {
          if (!separator.equals(source.substring(start+length, start+length+separatorLength))) {
            throw new ParseException("Not An Easy Date", start);
          }
          length += separatorLength;
        }
      }
      if (isYearDisplayed()) {
        year = Integer.parseInt(source.substring(start+length, start+length+4));
        length+=4;
      }
      status.setIndex(start+length);
      return EzDate.getEzDate(year, month, day);
    }
    catch (Throwable ignored) {
    }
    status.setErrorIndex(start);
    throw new ParseException("Not An Easy Date", start);
  }

  private final String separator;
}
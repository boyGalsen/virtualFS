package com.easyrms.date;

import com.easyrms.util.comparator.*;

import java.io.*;

public class StampDate implements Serializable {
  
  public StampDate(EzDate date, String stamp) {
    this.date = date;
    this.stamp = StringComparator.NVL(stamp, defaultStampValue);
  }

  public EzDate getDate() {
    return date;
  }
  
  public String getStamp() {
    return stamp;
  }
  
  @Override
  public int hashCode() {
    final int PRIME = 31;
    int result = 1;
    result = PRIME * result + ((date == null)
      ? 0
      : date.hashCode());
    //TODO: stamp cannot be null
    result = PRIME * result + ((stamp == null)
      ? 0
      : stamp.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final StampDate other = (StampDate)obj;
    if (date == null) {
      //TODO: is it OK like this ? date == null => OK ?
      if (other.date != null) {
        return false;
      }
    }
    else if (!date.equals(other.date)) {
      return false;
    }
    //TODO stamp cannot be null
    if (stamp == null) {
      if (other.stamp != null) {
        return false;
      }
    }
    else if (!stamp.equals(other.stamp)) {
      return false;
    }
    return true;
  }  
  
  private final EzDate date;
  private final String stamp;
  
  public static StampDate valueOf(int day, String stamp) {
    return new StampDate(EzDate.valueOf(day), stamp);
  }
  
  public boolean isStrictlyAfter(StampDate date) {
    final EzDate localDate = getDate();
    final EzDate otherDate = date.getDate();
    if (localDate.isStrictlyAfter(otherDate)) {
      return true;
    }
    if (localDate.isStrictlyBefore(otherDate)) {
      return false;
    }
    return StringComparator.compare(getStamp(), date.getStamp()) > 0;
  }
  
  public boolean isStrictlyBefore(StampDate date) {
    final EzDate localDate = getDate();
    final EzDate otherDate = date.getDate();
    if (localDate.isStrictlyAfter(otherDate)) {
      return false;
    }
    if (localDate.isStrictlyBefore(otherDate)) {
      return true;
    }
    return StringComparator.compare(getStamp(), date.getStamp()) < 0;
  }
  
  public static final String defaultStampValue = "00:00:00";
  
  public static final StampDate ever = new StampDate(EzDate.ever, defaultStampValue);
}

package com.easyrms.date;

import java.text.*;


public class EzNumericDateFormat extends EzDateFormat {
  
  public static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj);
    }
  }
  public static String referenceFormatDOM(int obj) {
    synchronized (reference) {
      return reference.formatDOM(obj);
    }
  }
  public static String referenceFormatMOY(int obj) {
    synchronized (reference) {
      return reference.formatMOY(obj);
    }
  }
  public static EzNumericDateFormat referenceClone() {
    return new EzNumericDateFormat() {

    	@Override
			public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final EzNumericDateFormat reference = referenceClone();
  
  public EzNumericDateFormat() {
    super();
  }
  public EzNumericDateFormat(int display) {
    super(display);
  }

	@Override
  public String formatMOY(int moy) {
    return moyFigures[moy];
  }

	@Override
  public EzDate parse(String source, ParsePosition status) {
    int day = 1;
    int month = 1;
    int year;
    final int n = source.length();
    int i = status.getIndex();
    try {
      if (i < n && Character.isDigit(source.charAt(i))) {
        if (i+1 < n && Character.isDigit(source.charAt(i+1))) {
          day = Integer.parseInt(source.substring(i, i+2));
          i += 2;
        }
        else {
          day = Integer.parseInt(source.substring(i, i+1));
          i += 1;
        }
      }
      while (i < n && !Character.isDigit(source.charAt(i))) i++;
      if (i < n && Character.isDigit(source.charAt(i))) {
        if (i+1 < n && Character.isDigit(source.charAt(i+1))) {
          month = Integer.parseInt(source.substring(i, i+2));
          i += 2;
        }
        else {
          month = Integer.parseInt(source.substring(i, i+1));
          i += 1;
        }
      }
      while (i < n && !Character.isDigit(source.charAt(i))) i++;
      year = Integer.parseInt(source.substring(i));
      if (year < 50) {
        year += 2000;
      }
      status.setIndex(n);
      return EzDate.getEzDate(year, month, day);
    }
    catch (Throwable ignored) {
    }
    status.setErrorIndex(status.getIndex());
    //STRANGE to not throw an exception
    return null;
  }
}
package com.easyrms.date;

import java.util.*;

import com.easyrms.builder.*;


public abstract class EzDateTranslationBuilder extends Builder {

  public static final int DOW = 1;
  public static final int DAY = 2;
  public static final int MONTH = 4;
  public static final int YEAR = 8;
  public static final int QUARTER = 16;

  protected EzDateTranslationBuilder() {
    this.display = DAY | MONTH | YEAR;
  }
  protected EzDateTranslationBuilder(int display) {
    this.display = display;
  }

  public void setDisplay(int display) {
    this.display = display;
  }
  public int getDisplay() {
    return display;
  }
  public boolean isDOWDisplayed() {
    return ((display & DOW) != 0);
  }
  public boolean isDayDisplayed() {
    return ((display & DAY) != 0);
  }
  public boolean isMonthDisplayed() {
    return ((display & MONTH) != 0);
  }
  public boolean isQuarterDisplayed() {
    return ((display & QUARTER) != 0);
  }
  public boolean isYearDisplayed() {
    return ((display & YEAR) != 0);
  }
  private int display;

  public StringBuilder format(EzDate obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuilder format(EzMonth obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj.getFirstDay(), toAppendTo, false, false, isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuilder format(EzQuarter obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    if (isQuarterDisplayed()) toAppendTo.append(formatQOY(obj.getQOY()));
    return toAppendTo;
  }
  
  public StringBuilder format(EzYear obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj.getFirstDay(), toAppendTo, false, false, false, isYearDisplayed());
    return toAppendTo;
  }

  public StringBuilder format(EzDOW obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    if (isDOWDisplayed()) toAppendTo.append(formatDOW(obj.getDOW()));
    return toAppendTo;
  }
  public StringBuilder format(Date obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(EzDate.valueOf(obj), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuilder format(Calendar obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(EzDate.valueOf(obj.getTime()), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuilder format(Number obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    return format(EzDate.valueOf(obj.intValue()),toAppendTo, pos);
  }

  public StringBuilder format(Period obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  @Override
  public StringBuilder format(Object obj, StringBuilder toAppendTo, FieldPosition pos) {
    if (obj == null) {
    }
    else if (obj instanceof EzDate) {
      format((EzDate)obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof Date) {
      format(EzDate.valueOf((Date)obj), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof EzDOW) {
      if (isDOWDisplayed()) toAppendTo.append(formatDOW(((EzDOW)obj).getDOW()));
    }
    else if (obj instanceof Calendar) {
      format(EzDate.valueOf(((Calendar)obj).getTime()), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (getDisplay() == YEAR && obj instanceof Period) {
      toAppendTo.append(formatYear(((Period)obj).getYear()));
    }
    else if (obj instanceof EzWeek) {
      toAppendTo.append(formatWOY(((EzWeek)obj).getWOY()));
      if (isYearDisplayed()) {
        toAppendTo.append(" ");
        toAppendTo.append(formatYear(((EzWeek)obj).getYear()));
      }
    }
    else if (obj instanceof EzMonth) {
      format(((EzMonth)obj).getFirstDay(), toAppendTo, false, false, isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof EzQuarter) {
      toAppendTo.append(formatQOY(((EzQuarter)obj).getQOY()));
      if (isYearDisplayed()) {
        toAppendTo.append(" ");
        toAppendTo.append(formatYear(((EzQuarter)obj).getYear()));
      }
    }
    else if (obj instanceof EzYear) {
      toAppendTo.append(formatYear(((EzYear)obj).getYear()));
      //format(((EzYear)obj).getFirstDay(), toAppendTo, false, false, false, isYearDisplayed());
    }
    else if (obj instanceof Number) {
    	final int value = ((Number)obj).intValue();
    	if (value != -1) format(EzDate.valueOf(value), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof Period) {
      format((Period)obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
      if (isYearDisplayed()) {
        final PeriodManager years = ((Period)obj).getManager().getYearManager();
        if (years != null) {
          toAppendTo.append(" ");
          toAppendTo.append(format(years.getPeriod(((Period)obj).getFirstDay())));
        }
      }
    }
    else if (obj instanceof String) {
      toAppendTo.append(obj);
    }
    else {
    }
    return toAppendTo;
  }

  public String formatDOWSeparator() {
    return " ";
  }
  public String formatSeparator() {
    return "/";
  }
  public String formatDOW(int dow) {
    throw new UnsupportedOperationException();
  }
  public String formatDOM(int dom) {
    return domFigures[dom];
  }
  public String formatWOY(int woy) {
    return woyFigures[woy];
  }
  public String formatQOY(int qoy) {
    return qoyFigures[qoy-EzQuarter.FIRST_QUARTER];
  }
  public String formatMOY(int moy) {
    throw new UnsupportedOperationException();
  }
  public String formatYear(int year) {
    return yyFigures[year % 100];
  }
  public String formatPeriod(Period period) {
    if (period == null) return "";
    return period.toString();
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
  @Override
  public boolean equals(Object object) {
    if (object == null || getClass() != object.getClass()) return false;
    final EzDateTranslationBuilder other = (EzDateTranslationBuilder)object;
    return (isDOWDisplayed() == other.isDOWDisplayed()
      && isDayDisplayed() == other.isDayDisplayed()
      && isMonthDisplayed() == other.isMonthDisplayed()
      && isYearDisplayed() == other.isYearDisplayed());
  }

  protected void format(
    EzDate date,
    StringBuilder toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed)
  {
    if (date != null && date.isStrictlyAfter(EzDate.ever) && date.isStrictlyBefore(EzDate.never)) {
      boolean isSeparatorNeeded = false;
      if (isDOWDisplayed) {
        toAppendTo.append(formatDOW(date.getDOW()));
        isSeparatorNeeded = true;
      }
      if (isDayDisplayed) {
        if (isSeparatorNeeded) toAppendTo.append(formatDOWSeparator());
        toAppendTo.append(formatDOM(date.getDOM()));
        isSeparatorNeeded = true;
      }
      if (isMonthDisplayed) {
        if (isSeparatorNeeded) toAppendTo.append(formatSeparator());
        toAppendTo.append(formatMOY(date.getMOY()));
        isSeparatorNeeded = true;
      }
      if (isYearDisplayed) {
        if (isSeparatorNeeded) toAppendTo.append(formatSeparator());
        toAppendTo.append(formatYear(date.getYear()));
      }
    }
  }
  protected void format(
    Period period,
    StringBuilder toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed)
  {
    toAppendTo.append(formatPeriod(period));
  }

  public final EzDate parse(String source) throws ParseException {
    return parse(source, new ParsePosition(0));
  }
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    int index = status.getIndex();
    if (source != null) {
      try {
        final String separator = formatSeparator();
        String buffer = source.substring(index);
        if (isDOWDisplayed()) {
          index = buffer.indexOf(separator);
          index += separator.length();
          buffer = buffer.substring(index);
        }
        final int dom;
        if (isDayDisplayed()) {
          index = buffer.indexOf(separator);
          dom = Integer.parseInt(buffer.substring(0, index));
          index += separator.length();
          buffer = buffer.substring(index);
        }
        else {
          dom = 1;
        }
        int moy = EzDate.JANUARY;
        if (isMonthDisplayed()) {
          index = buffer.indexOf(separator);
          final String month = buffer.substring(0, index);
          for (; moy < EzDate.DECEMBER; moy++) {
            if (month.equals(formatMOY(moy))) break;
          }
          index += separator.length();
          buffer = buffer.substring(index);
        }
        else {
          moy = 1;
        }
        if (buffer.length() > 4) buffer = buffer.substring(0, 4);
        final int year = Integer.parseInt(buffer);
        status.setIndex(index+4);
        return EzDate.getEzDate(year, moy, dom);
      }
      catch (Throwable ignored) {
      }
    }
    status.setErrorIndex(status.getIndex());
    throw new ParseException("Invalid Date", index);
  }
  @Override
  public final Object parseObject(String source, ParsePosition status) {
    final int start = status.getIndex();
    try {
      return parse(source, status);
    }
    catch (ParseException exception) {
      status.setErrorIndex(start);
    }
    return null;
  }


  public static final String[] domFigures = EzDateTranslationFormat.domFigures;

  public static final String[] woyFigures = EzDateTranslationFormat.woyFigures;

  public static final String[] qoyFigures = EzDateTranslationFormat.qoyFigures;
  public static final String[] moyFigures = EzDateTranslationFormat.moyFigures;

  public static final String[] yyFigures = EzDateTranslationFormat.yyFigures;

  public static final String[] moyShortTexts = EzDateTranslationFormat.moyShortTexts;
  public static final String[] moyTexts = EzDateTranslationFormat.moyTexts;
  public static final String[] threeLetterTexts = EzDateTranslationFormat.threeLetterTexts;
  public static final String[] moyLongTexts = EzDateTranslationFormat.moyLongTexts;

  public static final String[] dowShortTexts = EzDateTranslationFormat.dowShortTexts;
  public static final String[] dowLetterTexts = EzDateTranslationFormat.dowLetterTexts;
  public static final String[] dowTexts = EzDateTranslationFormat.dowTexts;
  public static final String[] dowLongTexts = EzDateTranslationFormat.dowLongTexts;
}
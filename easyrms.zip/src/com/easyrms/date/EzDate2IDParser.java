package com.easyrms.date;

import java.util.*;
import java.text.*;



public class EzDate2IDParser extends Format {

	public EzDate2IDParser(Format format) {
		this.format = format;
	}
  
  public EzDate2IDParser setAlternativeFormat(Format[] format) {
    this.alternativeFormat = format;
    return this;
  }

  @Override
	public StringBuffer format(Object obj, StringBuffer toAppendTo,	FieldPosition pos) {
		if (obj instanceof Number) {
			final Number id = (Number)obj;
			return format.format(EzDate.valueOf(id.intValue()), toAppendTo, pos);
		}
		return format.format(obj, toAppendTo, pos);
	}
	
  @Override
	public Object parseObject(String source, ParsePosition pos) {
		Object object = null;
		try {
      final ParsePosition pos2 = new ParsePosition(pos.getIndex());
			object = format.parseObject(source, pos2);  
      if (pos2.getErrorIndex() >= 0 || pos2.getIndex() < source.length()) object = null;
		}
		catch (Throwable ignored) {
		}
    if (object == null && alternativeFormat != null) {
      for (int i = 0, n = alternativeFormat.length; i < n ; i++) {
				try {
					final ParsePosition pos2 = new ParsePosition(pos.getIndex());
	        object = alternativeFormat[i].parseObject(source, pos2);
	        if (pos2.getErrorIndex() >= 0 || pos2.getIndex() < source.length()) object = null;
				}
				catch (Throwable ignored) {
				}
        if (object != null) break;
      }
    }
    pos.setIndex(source.length());
		if (object instanceof EzDate) return ((EzDate)object).getID();
		if (object instanceof Date) return EzDate.valueOf((Date)object).getID();
		return object;
	}

	private final Format format;
  private Format[] alternativeFormat;
  
}

package com.easyrms.date;

public interface PeriodHorizon {

  int getHorizon();
  String getPeriodName();
}

package com.easyrms.date;

import java.util.*;


public class EzYYYYMMDDDateBuilder extends EzDateBuilder {

  public static String referenceFormat(Object obj) {
    return referenceYYYYMMDDFormat(obj);
  }
  public static StringBuilder referenceFormat(Object obj, StringBuilder buff) {
    return referenceYYYYMMDDFormat(obj, buff);
  }
  
  public static String referenceYYYYMMDDFormat(Object obj) {
    return referenceYYYYMMDD.get().format(obj);
  }
  public static StringBuilder referenceYYYYMMDDFormat(Object obj, StringBuilder buff) {
    return referenceYYYYMMDD.get().format(obj, buff);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateBuilder> referenceYYYYMMDD = new ThreadLocal<EzYYYYMMDDDateBuilder>() {

    @Override
    protected EzYYYYMMDDDateBuilder initialValue() {
      return new EzYYYYMMDDDateBuilder(YEAR+MONTH+DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceYYYYMMFormat(obj);
  }
  
  public static String referenceYYYYMMFormat(Object obj) {
    return referenceYYYYMM.get().format(obj);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateBuilder> referenceYYYYMM = new ThreadLocal<EzYYYYMMDDDateBuilder>() {

    @Override
    protected EzYYYYMMDDDateBuilder initialValue() {
      return new EzYYYYMMDDDateBuilder(YEAR+MONTH) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceDayAndMonthFormat(Object obj) {
    return referenceMMDDFormat(obj);
  }
  
  public static String referenceMMDDFormat(Object obj) {
    return referenceMMDD.get().format(obj);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateBuilder> referenceMMDD = new ThreadLocal<EzYYYYMMDDDateBuilder>() {

    @Override
    protected EzYYYYMMDDDateBuilder initialValue() {
      return new EzYYYYMMDDDateBuilder(MONTH+DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
	
  public static String referenceEbXMLWithoutTimeFormat(Object obj) {
    return referenceEbXMLWithoutTime.get().format(obj);
  }
  public static EzYYYYMMDDDateBuilder referenceEbXMLWithoutTimeClone() {
    return new EzYYYYMMDDDateBuilder("-");
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateBuilder> referenceEbXMLWithoutTime = new ThreadLocal<EzYYYYMMDDDateBuilder>() {

    @Override
    protected EzYYYYMMDDDateBuilder initialValue() {
      return new EzYYYYMMDDDateBuilder("-");
    }
  };
  
  public static String referenceEbXMLYearAndMonthFormat(Object obj) {
    return referenceEbXMLYearAndMonth.get().format(obj);
  }
  private static final ThreadLocal<EzYYYYMMDDDateBuilder> referenceEbXMLYearAndMonth = new ThreadLocal<EzYYYYMMDDDateBuilder>() {

    @Override
    protected EzYYYYMMDDDateBuilder initialValue() {
      return new EzYYYYMMDDDateBuilder(YEAR+MONTH, "-");
    }
  };
  
  public static String referenceWithDotFormat(Object obj) {
    return referenceWithDot.get().format(obj);
  }
  public static EzYYYYMMDDDateBuilder referenceWithDotClone() {
    return new EzYYYYMMDDDateBuilder(".");
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateBuilder> referenceWithDot = new ThreadLocal<EzYYYYMMDDDateBuilder>() {

    @Override
    protected EzYYYYMMDDDateBuilder initialValue() {
      return new EzYYYYMMDDDateBuilder(".");
    }
  };

  public EzYYYYMMDDDateBuilder() {
    super();
  }
  public EzYYYYMMDDDateBuilder(int display) {
    super(display);
  }
  public EzYYYYMMDDDateBuilder(String separator) {
    super();
    this.separator = separator;
  }
  public EzYYYYMMDDDateBuilder(int display, String separator) {
    super(display);
    this.separator = separator;
  }

  @Override
  public final String formatSeparator() {
    return separator;
  }

  public EzDate parse(int source) {
    final int day;
    if (isDayDisplayed()) {
      day = source % 100;
      source /= 100;
    }
    else {
      day = 1;
    }
    final int month;
    if (isMonthDisplayed()) {
      month = source % 100;
      source /= 100;
    }
    else {
      month = 1;
    }
    final int year;
    if (isYearDisplayed()) {
      year = source;
    }
    else {
      year = EzDate.valueOf(new Date()).getYear();
    }
    return EzDate.getEzDate(year, month, day);
  }
  public EzDate parse(Integer source) {
    if (source == null) return null;
    return parse(source.intValue());
  }
  @Override
  protected void format(
    EzDate date, StringBuilder toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    if (isYearDisplayed) toAppendTo.append(date.getYear());
    if (isMonthDisplayed) {
      if (isYearDisplayed && separator != null) toAppendTo.append(separator);
      toAppendTo.append(moyFigures[date.getMOY()]);
    }
    if (isDayDisplayed)   {
      if ((isMonthDisplayed || isYearDisplayed)&& separator != null) toAppendTo.append(separator);
      toAppendTo.append(domFigures[date.getDOM()]);
    }
  }

  private String separator;
}
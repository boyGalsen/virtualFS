package com.easyrms.date;

import com.easyrms.util.format.*;

import java.text.*;

public class EzStandardDateTranslationFormat extends EzDateTranslationFormat {
  
  public static String formatDurationTime(long timeDurationInMilliseconds) {
    return formatDurationTime(timeDurationInMilliseconds,false);
  }
  
  public static String formatDurationTime(long timeDurationInMilliseconds, boolean milliseconds) {
    final long timeDurationInSeconds = timeDurationInMilliseconds/1000;
    final long days = timeDurationInSeconds/(60*60*24);
    final long hours = (timeDurationInSeconds%(60*60*24))/(60*60);
    final long minutes = (timeDurationInSeconds%(60*60))/(60);
    final long seconds = (timeDurationInSeconds%(60));
    final long milliSeconds = timeDurationInMilliseconds%1000;
    String duration= ""
      +(days > 0 
         ? days+" "+(days != 1 ? daysStandardLabel : dayStandardLabel)+" " 
         : "")
      +(hours > 0 
         ? hours+" "+hoursStandardLabel+" " 
         : "")
      +(minutes > 0 
         ? minutes+" "+minutesStandardLabel+" " 
         : "")
      ;
      if(milliseconds){
        return duration+(seconds > 0 
          ? seconds+" "+secondsStandardLabel+" " 
          : "")
        + (milliSeconds >= 0 
          ? milliSeconds+" "+milliSecondsStandardLabel+" "
          : "");
      }
      return duration+(seconds >= 0 
        ? seconds+" "+secondsStandardLabel+" " 
        : "");
  }
  
  public static String referencePeriodAndYearFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(period); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      if (yearManager == null) {
        return reference.get().format(period)+" "+referenceYear.get().format(period.getFirstDay());
      }
      final Period year = yearManager.getPeriod(period.getFirstDay());
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay());
      }
      return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay())+"-"+referenceYear.get().format(year.getLastDay());
    }
  }
  
  public static StringBuffer referencePeriodAndYearFormat(Period period, StringBuffer buffer, FieldPosition position) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period, buffer, position); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(period, buffer, position); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      if (yearManager == null) {
        reference.get().format(period, buffer, position).append(" ");
        return referenceYear.get().format(period.getFirstDay(), buffer, position);
      }
      final Period year = yearManager.getPeriod(period.getFirstDay());
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        referenceWithoutYear.get().format(period, buffer, position).append(" ");
        return referenceYear.get().format(year.getFirstDay(), buffer, position);
      }
      referenceWithoutYear.get().format(period, buffer, position).append(" ");
      referenceYear.get().format(year.getFirstDay(), buffer, position).append("-");
      return referenceYear.get().format(year.getLastDay(), buffer, position);
    }
  }
  
  public static String formatElapsedTime(long timeElapsedInMilliseconds) {
    final long inMinutes = timeElapsedInMilliseconds/(60*1000);
    if (inMinutes < 1) {
      return nowLabel;
    }
    if (inMinutes < 60) {
      return inMinutes+" "+minutesStandardLabel+" "+agoLabel;
    }
    final long inHours = timeElapsedInMilliseconds/(60*60*1000);
    if (inHours < 24) {
      return inHours+" "+(inHours == 1 ? hourLongLabel : hoursLongLabel)+" "+agoLabel;
    }
    final long inDays = timeElapsedInMilliseconds/(24*60*60*1000);
    if (inDays < 7) {
      return inDays+" "+(inDays == 1 ? dayLongLabel : daysLongLabel)+" "+agoLabel;
    }
    final int inWeeks = (int)(inDays / 7);
    if (inWeeks <= 5) {
      return inWeeks+" "+(inWeeks == 1 ? weekLongLabel : weeksLongLabel)+" "+agoLabel;
    }
    final int inMonths = (int)(inDays / 30);
    if (inDays <= 365) {
      return inMonths+" "+(inMonths == 1 ? monthLongLabel : monthsLongLabel)+" "+agoLabel;
    }
    final int inYears = (int)(inDays / 365);
    return inYears+" "+(inYears == 1 ? yearLongLabel : yearsLongLabel)+" "+agoLabel;
  }
  
  
  static String referenceFormatExceptEver(Object obj) {
    if (obj == null || EzDate.ever.equals(obj)) {
      return "";
    }
    return reference.get().format(obj); 
  }
  static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  static String referenceFormatDOM(int obj) {
    return reference.get().formatDOM(obj); 
  }
  static String referenceFormatMOY(int obj) {
    return reference.get().formatMOY(obj); 
  }
  static String referenceFormatYear(int obj) {
    return reference.get().formatYear(obj); 
  }
  static StringBuffer referenceFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return reference.get().format(obj, buff, pos); 
  }
  public static EzStandardDateTranslationFormat referenceClone() {
    return new EzStandardDateTranslationFormat() {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> reference = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return referenceClone();
    }
    
  };
  
  public static String referenceWeekFormat(Object obj) {
    return referenceWeek.get().format(obj); 
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceWeek = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return  new EzStandardDateTranslationFormat() {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };

  
  public static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  static EzStandardDateTranslationFormat referenceMonthClone() {
    return new EzStandardDateTranslationFormat(MONTH) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceMonth = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return referenceMonthClone();
    }
    
  };
  
  public static String referenceYearFormat(Object obj) {
    return referenceYear.get().format(obj); 
  }
  
  public static StringBuffer referenceYearFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    return referenceYear.get().format(obj, buffer, position); 
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceYear = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return new EzStandardDateTranslationFormat(YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };
  
  static String referencePeriodAndYearDetailsFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period); 
    }
    final EzStandardDateTranslationFormat monthFormat = referenceMonth.get();
    final EzStandardDateTranslationFormat domFormat = referenceDOM.get();
    return referencePeriodAndYearFormat(period)
      +" ("+domFormat.format(period.getFirstDay())+" "+monthFormat.format(period.getFirstDay())
      +"-"+domFormat.format(period.getLastDay())+" "+monthFormat.format(period.getLastDay())+")";
  }


  public static String referencePeriodAndYearDetailsFormat(PeriodManager manager, EzDate obj) {
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(obj); 
    }
    final Period period = manager.getPeriod(obj);
    final EzStandardDateTranslationFormat monthFormat = referenceMonth.get();
    final EzStandardDateTranslationFormat domFormat = referenceDOM.get();
    return referencePeriodAndYearFormat(manager, obj)
      +" ("+domFormat.format(period.getFirstDay())+" "+monthFormat.format(period.getFirstDay())
      +"-"+domFormat.format(period.getLastDay())+" "+monthFormat.format(period.getLastDay())+")";
  }

  public static String referencePeriodAndYearFormat(PeriodManager manager, EzDate obj) {
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(obj); 
    }
    final PeriodManager yearManager = manager.getYearManager();
    final Period period = manager.getPeriod(obj);
    if (yearManager == null) {
      return period.toString()+" "+referenceYear.get().format(period.getFirstDay());
    }
    final Period year = yearManager.getPeriod(obj);
    if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
      return period.toString()+" "+referenceYear.get().format(year.getFirstDay().getEzMonth().getLastDay());
    }
    return period.toString()+" "+referenceYear.get().format(year.getFirstDay())+"-"+referenceYear.get().format(year.getLastDay());
  }
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  
  public static StringBuffer referenceMonthAndYearFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    return referenceMonthAndYear.get().format(obj, buffer, position); 
  }

  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceMonthAndYear = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return new EzStandardDateTranslationFormat(MONTH + YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };
  
  public static String referenceWithDOWFormat(Object obj) {
    return referenceWithDOW.get().format(obj); 
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceWithDOW = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return new EzStandardDateTranslationFormat(DOW + DAY + MONTH + YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };
  
  public static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  public static EzStandardDateTranslationFormat referenceDOWClone() {
    return new EzStandardDateTranslationFormat(DOW) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceDOW = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return referenceDOWClone();
    }
    
  };
  
  static String referenceMOYFormat(Object obj) {
    if (obj instanceof EzDate) {
      return reference.get().formatMOY(((EzDate)obj).getMOY()); 
    }
    return "";
  }
  
  public static String referenceDOMFormat(Object obj) {
    return referenceDOM.get().format(obj); 
  }
  public static StringBuffer referenceDOMFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return referenceDOM.get().format(obj, buff, pos); 
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceDOM = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return new EzStandardDateTranslationFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };

  public EzStandardDateTranslationFormat() {
    super();
  }
  public EzStandardDateTranslationFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return " ";
  }
	@Override
  public String formatDOW(int dow) {
    return dowTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyTexts[moy];
  }
  
  private static final ThreadLocal<EzStandardDateTranslationFormat> referenceWithoutYear = new ThreadLocal<EzStandardDateTranslationFormat>() {

    @Override
    protected EzStandardDateTranslationFormat initialValue() {
      return referenceWithoutYearClone();
    }
    
  };
  
  public static EzStandardDateTranslationFormat referenceWithoutYearClone() {
    return new EzStandardDateTranslationFormat(DAY | MONTH) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final String nowLabel = TranslationUtil.getEzRMSContextLabelIntern("Now");
  
  private static final String milliSecondsStandardLabel = TranslationUtil.getEzRMSContextLabelIntern("MilliSeconds_Standard__ms");
  private static final String secondsStandardLabel = TranslationUtil.getEzRMSContextLabelIntern("Seconds_Standard__s");
  private static final String minutesStandardLabel = TranslationUtil.getEzRMSContextLabelIntern("Minutes_Standard__min");
  private static final String hoursStandardLabel = TranslationUtil.getEzRMSContextLabelIntern("Hours_Standard__h");
  private static final String dayStandardLabel = TranslationUtil.getEzRMSContextLabelIntern("Day");
  private static final String daysStandardLabel = TranslationUtil.getEzRMSContextLabelIntern("Days");
  /*private static final String weeksStandardLabel = TranslationUtil.getEzRMSContextLabel("Weeks_Standard__Wk.");
  private static final String monthsStandardLabel = TranslationUtil.getEzRMSContextLabel("Months_Standard__Mth."); 
  private static final String yearsStandardLabel = TranslationUtil.getEzRMSContextLabel("Years_Standard__Yr."); */
  
  private static final String hourLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Hour");
  private static final String hoursLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Hours");
  private static final String dayLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Day");
  private static final String daysLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Days");
  private static final String weekLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Week");
  private static final String weeksLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Weeks");
  private static final String monthLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Month");
  private static final String monthsLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Months");
  private static final String yearLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Year");
  private static final String yearsLongLabel = TranslationUtil.getEzRMSContextLabelIntern("Years"); 
  private static final String agoLabel = TranslationUtil.getEzRMSContextLabelIntern("Ago");
}
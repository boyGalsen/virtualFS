package com.easyrms.date;

import com.easyrms.util.*;

import java.text.*;
import java.util.*;


public class EzYYMMDDDateFormat extends EzDateFormat {

  public static final int YYMMDD = 0;
  public static final int MMDDYY = 1;
  public static final int DDMMYY = 2;

  public static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj); 
    }
  }
  private static final EzYYMMDDDateFormat reference = new EzYYMMDDDateFormat(YEAR+MONTH+DAY, YYMMDD) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };

  public EzYYMMDDDateFormat() {
    super();
  }
  public EzYYMMDDDateFormat(int display, int type) {
    super(display);
    this.type = type;
  }
  public EzYYMMDDDateFormat(String separator, int type) {
    super();
    this.separator = separator;
    this.type = type;
  }
  public EzYYMMDDDateFormat(int display, String separator, int type) {
    super(display);
    this.separator = separator;
    this.type = type;
  }

  @Override
  public final String formatSeparator() {
    return separator;
  }

  public EzDate parse(int source) {
    final int day;
    final int month;
    final int year;
    if (type == YYMMDD) {
      if (isDayDisplayed()) {
        day = source % 100;
        source /= 100;
      }
      else {
        day = 1;
      }
      if (isMonthDisplayed()) {
        month = source % 100;
        source /= 100;
      }
      else {
        month = 1;
      }
      if (isYearDisplayed()) {
        year = (source < 90) ? source+2000 : source+1900;
      }
      else {
        year = EzDate.valueOf(new Date()).getYear();
      }
    }
    else if (type == MMDDYY) {
      if (isYearDisplayed()) {
        final int f = source % 100;
        year = (f < 90) ? f+2000 : f+1900;
        source /= 100;
      }
      else {
        year = EzDate.valueOf(new Date()).getYear();
      }
      if (isDayDisplayed()) {
        day = source % 100;
        source /= 100;
      }
      else {
        day = 1;
      }
      if (isMonthDisplayed()) {
        month = source;
      }
      else {
        month = 1;
      }
    }
    else if (type == DDMMYY) {
      if (isYearDisplayed()) {
        final int f = source % 100;
        year = (f < 90) ? f+2000 : f+1900;
        source /= 100;
      }
      else {
        year = EzDate.valueOf(new Date()).getYear();
      }
      if (isMonthDisplayed()) {
        month = source % 100;
        source /= 100;
      }
      else {
        month = 1;
      }
      if (isDayDisplayed()) {
        day = source;
      }
      else {
        day = 1;
      }
    }
    else {
      throw new IllegalStateException("unknow parse type");
    }
    return EzDate.getEzDate(year, month, day);
  }
  public EzDate parse(Integer source) {
    return (source != null) ? parse(source.intValue()) : null;
  }
  @Override
  protected StringBuffer format(
    EzDate date, StringBuffer toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    if (isYearDisplayed) {
      toAppendTo.append(yyFigures[date.getYear()%100]);
    }
    if (isMonthDisplayed) {
      if (isYearDisplayed && separator != null) {
        toAppendTo.append(separator);
      }
      toAppendTo.append(moyFigures[date.getMOY()]);
    }
    if (isDayDisplayed)   {
      if ((isMonthDisplayed || isYearDisplayed)&& separator != null) {
        toAppendTo.append(separator);
      }
      toAppendTo.append(domFigures[date.getDOM()]);
    }
    return toAppendTo;
  }

  @Override
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    final int separatorLength = (separator == null) ? 0 : separator.length();
    int index = status.getIndex();
    try {
      if (separatorLength == 0) {
        final StringBuilderThreadPool pool = StringBuilderThreadPool.threadPools.get();
        final StringBuilder buffer = pool.get();
        try {
          if (type == YYMMDD) {
            if (isYearDisplayed())  {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
            if (isMonthDisplayed()) {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
            if (isDayDisplayed()) {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
          }
          else if (type == MMDDYY) {
            if (isMonthDisplayed()) {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
            if (isDayDisplayed()) {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
            if (isYearDisplayed())  {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
          }
          else if (type == DDMMYY) {
            if (isDayDisplayed()) {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
            if (isMonthDisplayed()) {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
            if (isYearDisplayed())  {
              buffer.append(source.substring(index, index+2));
              index += 2 + separatorLength;
            }
          }
          else {
            throw new IllegalStateException("Unsupported Type Format");
          }
          final EzDate date = parse(Integer.parseInt(buffer.toString()));
          status.setIndex(index);
          return date;
        }
        finally {
          pool.free(buffer);
        }
      }
      final StringTokenizer tokenizer = new StringTokenizer(source.substring(index), separator);      
      int day = 1;
      int month = 1;
      int year = EzDate.valueOf(new Date()).getYear();
      if (type == YYMMDD) {
        if (isYearDisplayed())  {
          year = Integer.parseInt(tokenizer.nextToken());
        }
        if (isMonthDisplayed()) {
          month = Integer.parseInt(tokenizer.nextToken());
        }
        if (isDayDisplayed()) {
          day = Integer.parseInt(tokenizer.nextToken());
        }
      }
      else if (type == MMDDYY) {
        if (isMonthDisplayed()) {
          month = Integer.parseInt(tokenizer.nextToken());
        }
        if (isDayDisplayed()) {
          day = Integer.parseInt(tokenizer.nextToken());
        }
        if (isYearDisplayed())  {
          year = Integer.parseInt(tokenizer.nextToken());
        }
      }
      else if (type == DDMMYY) {
        if (isDayDisplayed()) {
          day = Integer.parseInt(tokenizer.nextToken());
        }
        if (isMonthDisplayed()) {
          month = Integer.parseInt(tokenizer.nextToken());
        }
        if (isYearDisplayed())  {
          year = Integer.parseInt(tokenizer.nextToken());
        }
      }
      else {
        throw new ParseException("Unsupported Type Format", index);
      }
      if (day > 31) {
        throw new ParseException("Day="+day, index);
      }
      if (month > 12) {
        throw new ParseException("Month="+month, index);
      }
      if (year > 100 && year < 1900) {
        throw new ParseException("Year="+year, index);
      }
      if (year > 2050) {
        throw new ParseException("Year="+year, index);
      }
      if (year < 50) {
        year += 2000;
      }
      if (year < 100) {
        year += 1900;
      }
      status.setIndex(source.length());
      return EzDate.getEzDate(year, month, day);
    }
    catch (Throwable ignored) {
    }
    status.setErrorIndex(status.getIndex());
    throw new ParseException("Not an EzDate", status.getIndex());
  }

  private String separator;
  private int type;  
}
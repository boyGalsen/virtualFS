package com.easyrms.date;


public class SimplePeriod extends AbstractPeriod {

  public SimplePeriod(String name, EzDate firstDay, int dayCount) {
    this(null, firstDay.getDay()*EzDate.SHIFT+dayCount, name, firstDay, dayCount);
  }
  public SimplePeriod(PeriodManager manager, int id, EzDate firstDay, int dayCount) {
    this(manager, id, null, firstDay, dayCount);
  }
  public SimplePeriod(PeriodManager manager, int id, String name, EzDate firstDay, int dayCount) {
		super(id, name);
		this.manager = manager;
		this.firstDay = firstDay;
		this.dayCount = dayCount;
    if (dayCount <= 0 || firstDay.getDay()+dayCount > EzDate.MAX_ID) {
      throw new IllegalArgumentException("DayCount="+dayCount+", FirstDay="+firstDay);
    }
	}
	
  public int getDayCount() {
    return dayCount;
  }

  public EzDate getFirstDay() {
    return firstDay;
  }

  public PeriodManager getManager() {
    return manager;
  }

	PeriodManager manager;
	private final EzDate firstDay;
	private final int dayCount;
  
  private static final long serialVersionUID = -7226227208364506405L;
}

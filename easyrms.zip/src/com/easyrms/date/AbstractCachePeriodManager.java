package com.easyrms.date;

import java.util.concurrent.locks.*;
import java.util.concurrent.locks.ReentrantReadWriteLock.*;


public abstract class AbstractCachePeriodManager extends AbstractPeriodManager {

  public AbstractCachePeriodManager(String name, int referenceID, int cacheSize) {
    this(name, referenceID, cacheSize, null, PeriodManager.noPeriodManagers);
  }
  public AbstractCachePeriodManager(String name, int referenceID, int cacheSize, PeriodManager year, PeriodManager... subPeriods) {
    super(name, year, subPeriods);
    this.cache = new Period[Math.max(32, cacheSize)];
    this.offset = referenceID-3*cache.length/4;
    this.referenceID = referenceID;
  }

  public Period getPeriod(int id) {
    final int i = id - offset;
    final boolean isInCache = (i >= 0 && i < cache.length);
    if (isInCache) {
      final ReadLock rlock = lock.readLock();
      rlock.lock();
      try {
        if (cache[i] != null) {
          return cache[i];
        }    
      }
      finally {
        rlock.unlock();
      }
    }
    final Period lastPeriod = newPeriod(id);
    if (lastPeriod == null) {
      throw new NullPointerException();
    }
    final WriteLock wlock = lock.writeLock();
    wlock.lock();
    try {
      if (isInCache) {
        if (cache[i] != null) {
          return cache[i];
        }    
        cache[i] = lastPeriod;
      }
      this.lastPeriod = lastPeriod;
    }
    finally {
      wlock.unlock();
    }
    return lastPeriod;
  }

  public Period getPeriod(EzDate day) {
    final ReadLock rlock = lock.readLock();
    rlock.lock();
    final Period lastPeriod = this.lastPeriod;
    rlock.unlock();
    return getPeriod((lastPeriod != null) ? lastPeriod : getPeriod(referenceID), null, day.getDay());
  }

  private Period getPeriod(Period periodMin, Period periodMax, int day) {
    final int firstDay = periodMin.getFirstDay().getDay();
    final int dayCount = periodMin.getDayCount();
    if (dayCount <= 0) {
      throw new IllegalArgumentException("dayCount=0");
    }
    int n = day-firstDay;
    if (0 <= n && n < dayCount) {
      return periodMin;
    }
    if (n < 0) {
      n /= dayCount;
      return getPeriod(periodMin.addPeriod((n != 0) ? n : -1), periodMin, day);
    }
    if (periodMax == null) {
      return getPeriod(periodMin.addPeriod(1), periodMin.addPeriod(Math.max(2, n/dayCount)), day);
    }
    if (day > periodMax.getLastDay().getDay()) {
      return getPeriod(periodMax.addPeriod(1), periodMax.addPeriod(Math.max(2, periodMin.getID().intValue()+n/dayCount-periodMax.getID().intValue())), day);
    }
    return getPeriod(periodMin.addPeriod(Math.min(n/dayCount, periodMax.getID().intValue()-periodMin.getID().intValue())), periodMax, day);
  }
  
  @Override
  public int hashCode() {
    return getClass().hashCode();
  }

	@Override
  public boolean equals(Object obj) {
    return (obj != null && obj.getClass() == getClass());
  }
  
  protected abstract Period newPeriod(int id);

  private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
  private Period lastPeriod;
  private final Period[] cache;
  private final int offset;
  protected final int referenceID;
}
package com.easyrms.date.time;

import com.easyrms.cache.*;
import com.easyrms.util.*;


public class EzHourQuarter {

  public static EzHourQuarter get(EzHour hour, int quarter) {
    return valueOf(hour.getID()*4+quarter);
  }

  public static EzHourQuarter valueOf(int id) {
    return hourQuarters.get(IntegerCache.get(id));  
  }
  
  private EzHourQuarter(int id) {
    this.id = id;
    this.hour = EzHour.valueOf(id/4);
  }
  
  public int getID() { return this.id; }
  public int getHourQuarter() { return this.id%4; }
  public EzHour getHour() { return hour; }
  
  private final EzHour hour;
  private final int id;
  
  private static final Cache<Integer, EzHourQuarter> hourQuarters = Caches.newCacheInstance((key) -> { return new EzHourQuarter(key.intValue()); });
}
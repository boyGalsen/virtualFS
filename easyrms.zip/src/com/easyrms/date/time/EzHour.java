package com.easyrms.date.time;

import com.easyrms.cache.*;
import com.easyrms.date.*;
import com.easyrms.util.*;


public class EzHour {
  
  public static EzHour get(EzDate day, int hour) {
    return valueOf(day.getDay()*24+hour);
  }

  public static EzHour valueOf(int id) {
    return hours.get(IntegerCache.get(id));  
  }
  
  private EzHour(int id) {
    this.id = id;
    this.day = EzDate.valueOf(id/24);
  }
  
  public int getID() { return this.id; }
  public int getHour() { return this.id%24; }
  public EzDate getDay() { return day; }
  
  private final EzDate day;
  private final int id;
  
  private static final Cache<Integer, EzHour> hours = Caches.newCacheInstance((key) -> { return new EzHour(key.intValue()); });
}
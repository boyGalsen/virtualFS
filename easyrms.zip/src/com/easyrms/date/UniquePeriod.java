package com.easyrms.date;


public class UniquePeriod extends AbstractPeriod {

  public UniquePeriod(Duration duration) {
    this(null, duration);
  }
  public UniquePeriod(String name, Duration duration) {
    super(
      1,
      (name == null)
        ? duration.toString()
        : name);
    this.duration = duration;
  }
    
  public EzDate getFirstDay() { 
    return duration.getFirstDay();
  }
  public int getDayCount() {
    return duration.getDayCount(); 
  }
  
  public synchronized PeriodManager getManager() {
    if (manager == null) {
      manager = new AbstractPeriodManager(toString()) {

        public Period getPeriod(int id) { return (id == 1) ? UniquePeriod.this : null; }
        public Period getPeriod(EzDate day) { return day.isBetween(duration) ? UniquePeriod.this : null; }
      };
    }
    return manager;
  }
  
  private final Duration duration;
  private PeriodManager manager;
}
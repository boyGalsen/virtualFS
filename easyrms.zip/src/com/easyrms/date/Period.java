package com.easyrms.date;

import com.easyrms.util.comparator.*;

import java.util.*;


public interface Period extends Duration, Comparable<Period> {

  Integer getID();
  int getPeriod();
  int getYear();
  
  Period addPeriod(int periods);
  Period getPreviousYear(int nbOfYears);

  PeriodManager getManager();
  
  default int compareTo(Period other) {
    return comparator.compare(this, other);
  }

	Period[] noPeriods = new Period[0];
  Comparator<Period> comparator = new Comparator<Period>() {
    
    public int compare(Period p1, Period other) {
      if (other == p1) {
        return 0;
      }
      final PeriodManager otherManager = other.getManager();
      final PeriodManager manager = p1.getManager();
      if (manager == otherManager) {
        final int diff = other.getID().intValue() - p1.getID().intValue();
        return (diff == 0) ? 0 : (diff < 0) ? 1 : -1;
      }
      if (p1 == EzDate.ever) {
        return -1;
      }
      if (p1 == EzDate.never) {
        return 1;
      }
      if (other == EzDate.ever) {
        return 1;
      }
      if (other == EzDate.never) {
        return -1;
      }
      return StringComparator.compare(manager.getName(), otherManager.getName());
    }
  };
}
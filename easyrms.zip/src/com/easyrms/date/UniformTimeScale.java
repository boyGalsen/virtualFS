package com.easyrms.date;


public interface UniformTimeScale extends EzTimeScale {

	int getIntraDayPeriodCount();
}

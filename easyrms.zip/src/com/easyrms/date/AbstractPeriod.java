package com.easyrms.date;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;


public abstract class AbstractPeriod implements Period {

  protected AbstractPeriod(int id) {
    this(id, null);
  }
  protected AbstractPeriod(int id, String name) {
    this.id = id;
    this.ID = IntegerCache.get(id);
    this.name = StringComparator.NVL(name, null);
    if (id < 0) {
      throw new IllegalArgumentException("id="+id);
    }
  }

  public final Period getStart() {
    return this;
  }
  public final Period getLast() {
    return getStart().addPeriod(getHorizon()-1);
  }
  public final int getHorizon() {
    return 1;
  }
  public EzDate getLastDay() {
    return getFirstDay().add(getCount()-1);
  }
  public int getYear() {
    return getFirstDay().add((getCount()-1)/2).getYear();
  }
  public EzYear getEzYear() {
    return EzYear.valueOf(getYear());
  }

  public EzDate getFirstDay(int periods) {
    try {
      return addPeriod(periods).getFirstDay();
    }
    catch (Throwable ignored) {
    }
    return null;
  }
  public EzDate getLastDay(int periods) {
    try {
      return addPeriod(periods).getLastDay();
    }
    catch (Throwable ignored) {
    }
    return null;
  }

  public final int getPeriod() {
    return id;
  }
  public final Integer getID() {
    return ID;
  }

  public Period getPreviousYear(int nbOfYears) {
  	int offset = nbOfYears*364;
  	if (nbOfYears > 3) {
      offset += 7;
    }
    return getManager().getPeriod(EzDate.valueOf((getFirstDay().getDay()+getLastDay().getDay())/2-offset));
  }

  public final Period addPeriod(int n) {
    return (n == 0) ? this : getManager().getPeriod(id+n);
  }
  
  public EzDate getDay(int i) {
    if (i >= 0 && i < getCount()) { 
      return getFirstDay().add(i);
    }
    throw new ArrayIndexOutOfBoundsException(i+" Invalid Valid Values [0, "+getCount()+"[");
  }

  @Override
	public String toString() {
    if (name == null) {
    	synchronized (this) {
    		if (computedName == null) {
					final Period firstPeriod = getManager().getPeriod(getFirstDay().getEzYear().getFirstDay());
					computedName = IntegerCache.toString(getPeriod()-firstPeriod.getPeriod()+1);
    		}
    		return computedName;
    	}
    }
    return name;
  }

  @Override
	public final boolean equals(Object object) {
		if (object == this) {
      return true;
    }
    if (object instanceof AbstractPeriod) {
      final AbstractPeriod other = ((AbstractPeriod)object);
      return (other.id == id && getClass() == object.getClass() && getManager() == other.getManager());
    }
    return false;
  }
  
  @Override
  public final int hashCode() {
    return id;
  }

  @Override
  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  public boolean isBetween(Duration duration) {
    return getFirstDay().isAfter(duration.getFirstDay())
      && getLastDay().isBefore(duration.getLastDay());
  }
  
  public Bounds getDayBounds() {
    if (dayBounds != null) {
      return dayBounds;
    }
    synchronized (this) {
      if (dayBounds == null) {
        this.dayBounds = Bounds.getBounds(getFirstDay().getDay(), getLastDay().getDay()+1);
      }
    }
    return dayBounds;
  }
  
  public Bounds getPeriodBounds() {
    if (periodBounds != null) {
      return periodBounds;
    }
    synchronized (this) {
      if (periodBounds == null) {
        this.periodBounds = Bounds.getBounds(getPeriod(), getPeriod()+getHorizon());
      }
    }
    return periodBounds;
  }

  private transient volatile Bounds dayBounds;
  private transient volatile Bounds periodBounds;
  protected final int id;
  protected final Integer ID;
	private final String name;
	private String computedName;
}
package com.easyrms.date;

import java.io.*;
import java.util.*;


public interface DateAccessor extends Serializable {

  long getTime();
  Date toDate();  
}

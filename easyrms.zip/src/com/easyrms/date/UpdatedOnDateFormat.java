package com.easyrms.date;

import com.easyrms.util.format.*;

import java.text.*;


public class UpdatedOnDateFormat extends AbstractFormat {

  public static String referenceFormat(Object obj) {
    if (obj instanceof DateAccessor) {
      return reference.get().format(((DateAccessor)obj).toDate());
    }
    return reference.get().format(obj);
  }
  
  public static StringBuffer referenceFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    if (obj instanceof DateAccessor) {
      return reference.get().format(((DateAccessor)obj).toDate(), buffer, position);
    }
    return reference.get().format(obj, buffer, position);
  }

  public static UpdatedOnDateFormat referenceClone() {
    return new UpdatedOnDateFormat();
  }
  
  
  private static final ThreadLocal<UpdatedOnDateFormat> reference = new ThreadLocal<UpdatedOnDateFormat>() {

    @Override
    protected UpdatedOnDateFormat initialValue() {
      return new UpdatedOnDateFormat();
    }
    
  };
  
  protected UpdatedOnDateFormat() {}

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj != null) {
      if (obj instanceof DateAccessor) {
        obj = ((DateAccessor)obj).toDate();
      }
      EzLongDateTranslationFormat.referenceFormat(
        obj, 
        toAppendTo, 
        pos);
      toAppendTo.append(" ");
      EzDateTranslationFormat.timeFormatFormat(obj, toAppendTo, pos);
    }
    return toAppendTo;
  }
  
  public static final String updatedOnLabel = TranslationUtil.getEzRMSContextLabelIntern("Updated On");
}
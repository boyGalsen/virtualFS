package com.easyrms.date;

import com.easyrms.util.*;

public class SimplePeriodHorizon extends Tuple2<String, Integer> implements PeriodHorizon {

  public SimplePeriodHorizon(String name, int horizon) {
    super(name, IntegerCache.get(horizon));
  }

  public int getHorizon() {
    return get1().intValue();
  }

  public String getPeriodName() {
    return get0();
  }
}

package com.easyrms.date;

import com.easyrms.util.*;

import java.text.*;
import java.util.*;
import java.util.regex.*;


public class EzYYYYMMDDDateFormat extends EzDateFormat {
  
  public static EzDate smartReferenceParse(String obj) throws ParseException {
    if (obj == null) {
      return null;
    }
    if (isEbXMLPattern(obj)) {//ebXMLPattern.matcher(obj).matches()) {
      return referenceEbXMLWithoutTimeParse(obj);
    }
    return referenceYYYYMMDDParse(obj);
  }

  public static String referenceFormat(Object obj) {
    return referenceYYYYMMDDFormat(obj);
  }
  public static StringBuffer referenceFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return referenceYYYYMMDDFormat(obj, buff, pos);
  }
  
  public static EzDate referenceParse(String obj) throws ParseException {
    return referenceYYYYMMDDParse(obj);
  }
  public static EzDate referenceParse(Integer obj) throws ParseException {
    return referenceYYYYMMDDParse(obj);
  }

  public static String referenceYYYYMMDDFormat(Object obj) {
    return referenceYYYYMMDD.get().format(obj);
  }
  public static StringBuffer referenceYYYYMMDDFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return referenceYYYYMMDD.get().format(obj, buff, pos);
  }
  public static EzDate referenceYYYYMMDDParse(String obj) throws ParseException {
    return referenceYYYYMMDD.get().parse(obj);
  }
  public static EzDate referenceYYYYMMDDParseNeverWhenException(String obj) {
    try {
      return referenceYYYYMMDD.get().parse(obj);
    }
    catch (Throwable ignored) {
      EasyRMS.trace.log(ignored);
    }
    return EzDate.never;
  }
  public static EzDate referenceYYYYMMDDParse(Integer obj) throws ParseException {
    return referenceYYYYMMDD.get().parse(obj);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateFormat> referenceYYYYMMDD = new ThreadLocal<EzYYYYMMDDDateFormat>() {

    @Override
    protected EzYYYYMMDDDateFormat initialValue() {
      return new EzYYYYMMDDDateFormat(YEAR+MONTH+DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceYYYYMMFormat(obj);
  }
  
  public static String referenceYYYYMMFormat(Object obj) {
    return referenceYYYYMM.get().format(obj);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateFormat> referenceYYYYMM = new ThreadLocal<EzYYYYMMDDDateFormat>() {

    @Override
    protected EzYYYYMMDDDateFormat initialValue() {
      return new EzYYYYMMDDDateFormat(YEAR+MONTH) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }    
  };
  
  public static String referenceDayAndMonthFormat(Object obj) {
    return referenceMMDDFormat(obj);
  }
  
  public static String referenceMMDDFormat(Object obj) {
    return referenceMMDD.get().format(obj);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateFormat> referenceMMDD = new ThreadLocal<EzYYYYMMDDDateFormat>() {

    @Override
    protected EzYYYYMMDDDateFormat initialValue() {
      return new EzYYYYMMDDDateFormat(MONTH+DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }    
  };

  
  public static String referenceEbXMLWithoutTimeFormat(Object obj) {
    return referenceEbXMLWithoutTime.get().format(obj);
  }
  public static EzDate referenceEbXMLWithoutTimeParse(String obj) throws ParseException {
    return referenceEbXMLWithoutTime.get().parse(obj);
  }
  public static EzDate parseEbXML(String obj) throws ParseException {
    if (obj == null) {
      return null;
    }
    final int index = obj.indexOf("T");
    return referenceEbXMLWithoutTimeParse((index > 0) ? obj.substring(0, index) : obj);
  }
  
  public static EzYYYYMMDDDateFormat referenceEbXMLWithoutTimeClone() {
    return new EzYYYYMMDDDateFormat("-");
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateFormat> referenceEbXMLWithoutTime = new ThreadLocal<EzYYYYMMDDDateFormat>() {

    @Override
    protected EzYYYYMMDDDateFormat initialValue() {
      return new EzYYYYMMDDDateFormat("-");
    }    
  };
  
  public static String referenceEbXMLYearAndMonthFormat(Object obj) {
    return referenceEbXMLYearAndMonth.get().format(obj);
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateFormat> referenceEbXMLYearAndMonth = new ThreadLocal<EzYYYYMMDDDateFormat>() {

    @Override
    protected EzYYYYMMDDDateFormat initialValue() {
      return new EzYYYYMMDDDateFormat(YEAR+MONTH, "-");
    }    
  };
  
  public static String referenceWithDotFormat(Object obj) {
    return referenceWithDot.get().format(obj);
  }
  public static EzYYYYMMDDDateFormat referenceWithDotClone() {
    return new EzYYYYMMDDDateFormat(".");
  }
  
  private static final ThreadLocal<EzYYYYMMDDDateFormat> referenceWithDot = new ThreadLocal<EzYYYYMMDDDateFormat>() {

    @Override
    protected EzYYYYMMDDDateFormat initialValue() {
      return referenceWithDotClone();
    }    
  };

  public EzYYYYMMDDDateFormat() {
    super();
  }
  public EzYYYYMMDDDateFormat(int display) {
    super(display);
  }
  public EzYYYYMMDDDateFormat(String separator) {
    super();
    this.separator = separator;
  }
  public EzYYYYMMDDDateFormat(int display, String separator) {
    super(display);
    this.separator = separator;
  }

  @Override
  public final String formatSeparator() {
    return separator;
  }

  public EzDate parse(int source) {
    final int day;
    if (isDayDisplayed()) {
      day = source % 100;
      source /= 100;
    }
    else {
      day = 1;
    }
    final int month;
    if (isMonthDisplayed()) {
      month = source % 100;
      source /= 100;
    }
    else {
      month = 1;
    }
    final int year;
    if (isYearDisplayed()) {
      year = source;
    }
    else {
      year = EzDate.valueOf(new Date()).getYear();
    }
    return EzDate.getEzDate(year, month, day);
  }
  public EzDate parse(Integer source) {
    return (source != null) ? parse(source.intValue()) : null;
  }
  @Override
  protected StringBuffer format(
    EzDate date, StringBuffer toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    if (isYearDisplayed) {
      toAppendTo.append(date.getYear());
    }
    if (isMonthDisplayed) {
      if (isYearDisplayed && separator != null) {
        toAppendTo.append(separator);
      }
      toAppendTo.append(moyFigures[date.getMOY()]);
    }
    if (isDayDisplayed)   {
      if ((isMonthDisplayed || isYearDisplayed)&& separator != null) {
        toAppendTo.append(separator);
      }
      toAppendTo.append(domFigures[date.getDOM()]);
    }
    return toAppendTo;
  }

  @Override
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    if (source != null) {
      final StringBuilderThreadPool pool = StringBuilderThreadPool.threadPools.get();
      final StringBuilder buffer = pool.get();
      try {
        final int separatorLength = (separator == null) ? 0 : separator.length();
        int start = status.getIndex();
        if (isYearDisplayed())  {
          buffer.append(source.substring(start, start+4));
          start += 4 + separatorLength;
        }
        if (isMonthDisplayed()) {
          buffer.append(source.substring(start, start+2));
          start += 2 + separatorLength;
        }
        if (isDayDisplayed()) {
          buffer.append(source.substring(start, start+2));
          start += 2 + separatorLength;
        }
        final EzDate date = parse(Integer.parseInt(buffer.toString()));
        status.setIndex(start);
        return date;
      }
      catch (Throwable ignored) {
      }
      finally {
        pool.free(buffer);
      }
    }
    status.setErrorIndex(status.getIndex());
    throw new ParseException("Not an EzDate", status.getIndex());
  }

  private String separator;
  
  public static boolean isEbXMLPattern(String value) {
    if (value != null && value.length() == 10) {
      for (int i = 0; i < 10; i++) {
        final char c = value.charAt(i);
        if (i == 4 || i == 7) {
          if (c != '-') {
            return false;
          }
        }
        else if (i == 0) {
          if (c != '1' && c != '2') {
            return false;
          }
        }
        else if (i == 1) {
          if (c != '0' && c != '9') {
            return false;
          }
        }
        else if (i == 5) {
          if (c != '0' && c != '1') {
            return false;
          }
        }
        else if (i == 8) {
          if (c != '0' && c != '1' && c != '2' && c != '3') {
            return false;
          }
        }
        else {
          if (c < '0' || c > '9') {
            return false;
          }
        }
      }
      return true;
    }
    return false;
  }
  
  public static boolean isYYYYMMDDPattern(String value) {
    if (value != null && value.length() == 8) {
      for (int i = 0; i < 8; i++) {
        final char c = value.charAt(i);
        if (i == 0) {
          if (c != '1' && c != '2') {
            return false;
          }
        }
        else if (i == 1) {
          if (c != '0' && c != '9') {
            return false;
          }
        }
        else if (i == 4) {
          if (c != '0' && c != '1') {
            return false;
          }
        }
        else if (i == 6) {
          if (c != '0' && c != '1' && c != '2' && c != '3') {
            return false;
          }
        }
        else {
          if (c < '0' || c > '9') {
            return false;
          }
        }
      }
      return true;
    }
    return false;
  }
  
  public static final Pattern ebXMLPattern = Pattern.compile("[12][09][0-9][0-9]-[01][0-9]-[0123][0-9]");
  public static final Pattern ezYYYYMMDDPattern = Pattern.compile("[12][09][0-9][0-9][01][0-9][0123][0-9]");
}
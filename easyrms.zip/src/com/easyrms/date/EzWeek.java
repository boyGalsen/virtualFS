package com.easyrms.date;

import java.util.*;


public final class EzWeek extends AbstractPeriod {

  public static EzWeek valueOf(int id) {
    return (EzWeek)manager.getPeriod(id);
  }
  public static EzWeek valueOf(Date date) {
    return EzDate.valueOf(date).getEzWeek();
  }

  private EzWeek(int id) {
    super(id);
    if (id > EzDate.MAX_WEEK) {
      throw new IllegalArgumentException("id="+id);
    }
  }

  public EzDate getFirstDay() {
	  return EzDate.valueOf(1+7*(id-1));
  }
  
  public int getWeek() {
    return getPeriod();
  }

  public int getWOY() {
    return getFirstDay().getWOY();
  }

  public final EzWeek add(int weeks) {
    return (EzWeek)addPeriod(weeks);
  }
  
  public int sub(EzWeek other) {
    return this.id-other.id;
  }


	public EzWeek getPreviousYearEzWeek(int nbOfYears) {
		int previousYearID = id-nbOfYears*52;
		if (nbOfYears > 3) previousYearID--;
		return valueOf(previousYearID);
	}
	@Override
	public Period getPreviousYear(int nbOfYears) {
		return getPreviousYearEzWeek(nbOfYears);
	}

  public PeriodManager getManager() {
    return manager;
  }

  @Override
	public String toString() {
    return "["+getWeek()+", week #"+EzStandardDateFormat.referenceFormatWOY(getWOY())+" "+getYear()+"]";
  }

  public static EzWeek max(EzWeek a, EzWeek b) {
    return (a == null || (b != null && a.compareTo(b) < 0)) ? b : a;
  }
  public static EzWeek min(EzWeek a, EzWeek b) {
    return (a == null || (b != null && a.compareTo(b) > 0)) ? b : a;
  }

  public boolean isStrictlyBefore(EzWeek other) {
    return (getWeek() < other.getWeek());
  }
  public boolean isStrictlyBefore(int other) {
    return (getWeek() < other);
  }
  public boolean isBefore(EzWeek other) {
    return (getWeek() <= other.getWeek());
  }
  public boolean isBefore(int other) {
    return (getWeek() <= other);
  }
  public boolean isAfter(EzWeek other) {
    return (getWeek() >= other.getWeek());
  }
  public boolean isAfter(int other) {
    return (getWeek() >= other);
  }
  public boolean isStrictlyAfter(EzWeek other) {
    return (getWeek() > other.getWeek());
  }
  public boolean isStrictlyAfter(int other) {
    return (getWeek() > other);
  }

  public int getDayCount() {
    return 7;
  }
  public int getOffset() {
    return 1;
  }

  public static final PeriodManager manager =
    new AbstractCachePeriodManager("Week", EzDate.today.getWeek(), 1024, EzYear.manager, EzDate.manager) {

      @Override
			protected Period newPeriod(int id) { return new EzWeek(id); }
    };

  static final long serialVersionUID = -6418775106994079972L;
  public Object readResolve() {
    return valueOf(getWeek());
  }
  
	public static final EzWeek[] noEzWeeks = new EzWeek[0];

}
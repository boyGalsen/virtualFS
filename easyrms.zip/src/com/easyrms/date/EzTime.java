package com.easyrms.date;

import com.easyrms.util.*;

import java.io.*;
import java.util.*;


public final class EzTime implements Cloneable, Serializable, Comparable<Object> {

	public EzTime(double id) {
		this.day = EzDate.valueOf((int)id);
		this.ID = MathUtils.getDouble(id);
    this.time = new SimpleDateAccessor(day.getTime().getTime()+1000*((long)((ID.doubleValue()*24*60*60)%(24*60*60))));
	}
	public EzTime(EzDate day) {
		this(day, 0, 0, 0);
	}
	public EzTime(EzDate day, int hours, int minutes, int seconds) {
		final int s = seconds + 60*(minutes + 60* hours);
		if (s == 0) {
			this.day = day;
			this.ID = day.getID();
      this.time = day.getTime();
		}
		else {
			this.day = day.add(s/secondInDayCount);
			this.ID = MathUtils.getDouble(day.getDay() + ((double)(s % secondInDayCount))/(double)secondInDayCount);
      this.time = new SimpleDateAccessor(day.getTime().getTime()+1000*((long)((ID.doubleValue()*24*60*60)%(24*60*60))));
		}
	}
	
  public static EzTime valueOf(double id) { return new EzTime(id); }
  public static EzTime valueOf(DateAccessor date) { return new EzTime(((double)(date.getTime()-EzDate.OFFSET))/EzDate.DAY_IN_MILLISECONDS); }
  public static EzTime valueOf(Date date) { return new EzTime(((double)(date.getTime()-EzDate.OFFSET))/EzDate.DAY_IN_MILLISECONDS); }
  
  public DateAccessor getTime() { return time; }
	public Number getID() { return ID; }
	public EzDate getDay() { return day; }
	public int getHour() { return ((int)(ID.doubleValue()*24))%24; }
	public int getMinute() { return ((int)(ID.doubleValue()*24*60))%60; }
	public int getSecond() { return ((int)(ID.doubleValue()*24*60*60))%60; }

	public int compareTo(Object o) {
		if (o == this) return 0;
		Number id = null;
		if (o instanceof EzTime) id = ((EzTime)o).ID;
		if (o instanceof EzDate) id = ((EzDate)o).ID;
		if (o instanceof Number) id = (Number)o;
		if (id != null) {
			final double d = id.doubleValue() - ID.doubleValue();
			return (d > 0) ? -1 : (d == 0) ? 0 : 1;
		}
		return 1;
	}
	
	@Override
	public String toString() { return EzStandardDateFormat.referenceFormat(day);	}
	
	private EzDate day;
	private final Number ID;
  private final DateAccessor time;
	
	private static final int secondInDayCount = 60*60*24;
}

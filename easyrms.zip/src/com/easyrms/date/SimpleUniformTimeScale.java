package com.easyrms.date;

import com.easyrms.util.Bounds;


public final class SimpleUniformTimeScale implements UniformTimeScale {

	public static final SimpleUniformTimeScale hourScale = new SimpleUniformTimeScale(24);
	public static final SimpleUniformTimeScale quarterScale = new SimpleUniformTimeScale(24*4);
	
	public SimpleUniformTimeScale(int intraDayPeriodCount) {
		this.intraDayPeriodCount = intraDayPeriodCount;
	}
	
	public int getIntraDayPeriodCount() { return intraDayPeriodCount;	}
	public int getIndex(EzTime time) { return (int)(time.getID().doubleValue()*intraDayPeriodCount); }
	public int getIndex(int day, double time, int hh24) { return (int)((day+time/hh24)*intraDayPeriodCount); }
	public EzTime getTime(int i) { return new EzTime(((double)i)/intraDayPeriodCount); }
	
	public Bounds getBounds(Duration duration) {
		final int start = duration.getFirstDay().getDay()*intraDayPeriodCount;
		return Bounds.getBounds(start, start+duration.getCount()*intraDayPeriodCount);
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (o instanceof SimpleUniformTimeScale) return (this.intraDayPeriodCount == ((SimpleUniformTimeScale)o).intraDayPeriodCount);
		return false;
	}
	
	@Override
  public int hashCode() {
    return intraDayPeriodCount;
  }

  private final int intraDayPeriodCount;
}

package com.easyrms.date;

import com.easyrms.cache.*;
import com.easyrms.util.*;


public final class SimpleDuration implements Duration {

  public static Bounds getDayBounds(Duration duration) {
    return duration.getDayBounds();
  }
  public static Bounds getPeriodBounds(Duration duration) {
    return duration.getPeriodBounds();
  }
  
  public static Duration findDayDuration(Duration duration) {
    if (duration.getStart() instanceof EzDate) {
      checkGetDuration();
      return duration;
    }
    return findDuration(duration.getFirstDay(), duration.getLastDay());
  }
  
  public static Duration findLimitedDuration(Duration duration, EzDate minDuration, EzDate maxDuration) {
    if (minDuration == null || minDuration.isBefore(duration.getFirstDay())) {
      if (maxDuration == null || maxDuration.isAfter(duration.getLastDay())) {
        return duration;
      }
    }
    final EzDate min = EzDate.max(minDuration, duration.getFirstDay());
    final EzDate max = EzDate.min(maxDuration, duration.getLastDay());
    if (max.isStrictlyBefore(min)) {
      return Duration.noDuration;
    }
    return SimpleDuration.findDuration(min, max);
  }
  
  public static Duration findDuration(EzDate firstPeriod, EzDate lastPeriod) {
    if (firstPeriod == lastPeriod) {
      checkGetDuration();
      return firstPeriod;
    }
    final int horizon = lastPeriod.getPeriod()-firstPeriod.getPeriod()+1;
    if (lastPeriod.getLastDay().isStrictlyBefore(firstPeriod.getFirstDay())) {
      throw new IllegalArgumentException();
    }
    return findDuration(firstPeriod, horizon);
  }
  
  public static Duration findDuration(EzMonth firstPeriod, EzMonth lastPeriod) {
    if (firstPeriod == lastPeriod) {
      checkGetDuration();
      return firstPeriod;
    }
    final int horizon = lastPeriod.getPeriod()-firstPeriod.getPeriod()+1;
    if (lastPeriod.getLastDay().isStrictlyBefore(firstPeriod.getFirstDay())) {
      throw new IllegalArgumentException();
    }
    return findDuration(firstPeriod, horizon);
  }
  
  public static Duration findDuration(EzWeek firstPeriod, EzWeek lastPeriod) {
    if (firstPeriod == lastPeriod) {
      checkGetDuration();
      return firstPeriod;
    }
    final int horizon = lastPeriod.getPeriod()-firstPeriod.getPeriod()+1;
    if (lastPeriod.getLastDay().isStrictlyBefore(firstPeriod.getFirstDay())) {
      throw new IllegalArgumentException();
    }
    return findDuration(firstPeriod, horizon);
  }
  
  public static Duration findDuration(EzYear firstPeriod, EzYear lastPeriod) {
    if (firstPeriod == lastPeriod) {
      checkGetDuration();
      return firstPeriod;
    }
    final int horizon = lastPeriod.getPeriod()-firstPeriod.getPeriod()+1;
    if (lastPeriod.getLastDay().isStrictlyBefore(firstPeriod.getFirstDay())) {
      throw new IllegalArgumentException();
    }
    return findDuration(firstPeriod, horizon);
  }

  
  public static Duration findDuration(Period firstPeriod, Period lastPeriod) {
    if (firstPeriod.getClass() != lastPeriod.getClass()) {
      lastPeriod = firstPeriod.getManager().getPeriod(lastPeriod.getLastDay());
    }
    if (firstPeriod == lastPeriod) {
      checkGetDuration();
      return firstPeriod;
    }
    final int horizon = lastPeriod.getPeriod()-firstPeriod.getPeriod()+1;
    if (lastPeriod.getLastDay().isStrictlyBefore(firstPeriod.getFirstDay())) {
      throw new IllegalArgumentException();
    }
    return findDuration(firstPeriod, horizon);
  }
  
  private static void checkGetDuration() {
    if (EasyRMS.isDebug) {
      try {
        throw new RuntimeException();
      }
      catch (Throwable ignored) {
        final StackTraceElement[] trace = ignored.getStackTrace();
        for (int i = 0, n = trace.length; i < n; i++) {
          final StackTraceElement traceI = trace[i];
          if (!"com.easyrms.date.SimpleDuration".equals(traceI.getClassName())) {
            EasyRMS.trace.log(traceI.getClassName()+":"+traceI.getMethodName()+":"+traceI.getLineNumber());
            break;
          }
        }
      }
    }
    getPeriod.inc();
  }
  
  public static Duration findDuration(Period start, int horizon) {
    checkGetDuration();
    if (horizon == 1) {
      singlePeriod.inc();
      return start;
    }
    if (start instanceof EzDate) {
      if (horizon < ezDateFixedDuration.length) {
        return ezDateFixedDuration[horizon].get(start);
      }
    }
    else if (start instanceof EzMonth) {
      if (horizon < ezMonthFixedDuration.length) {
        return ezMonthFixedDuration[horizon].get(start);
      }
    }
    else if (start instanceof EzYear) {
      if (horizon < ezYearFixedDuration.length) {
        return ezYearFixedDuration[horizon].get(start);
      }
    }
    else if (start instanceof EzWeek) {
      if (horizon < ezWeekFixedDuration.length) {
        return ezWeekFixedDuration[horizon].get(start);
      }
    }
    return otherDurations.get(IntegerCache.get(horizon)).get(start);
  }
  
  public static Duration findDuration(EzDate start, int horizon) {
    if (horizon < 0) {
      return Duration.noDuration;
    }
    checkGetDuration();
    if (horizon == 1) {
      singlePeriod.inc();
      return start;
    }
    if (horizon < ezDateFixedDuration.length) {
      return ezDateFixedDuration[horizon].get(start);
    }
    return otherDurations.get(IntegerCache.get(horizon)).get(start);
  }

  public static Duration findDuration(EzMonth start, int horizon) {
    if (horizon < 0) {
      return Duration.noDuration;
    }
    checkGetDuration();
    if (horizon == 1) {
      singlePeriod.inc();
      return start;
    }
    if (horizon < ezMonthFixedDuration.length) {
      return ezMonthFixedDuration[horizon].get(start);
    }
    return otherDurations.get(IntegerCache.get(horizon)).get(start);
  }
  
  public static Duration findDuration(EzWeek start, int horizon) {
    if (horizon < 0) {
      return Duration.noDuration;
    }
    checkGetDuration();
    if (horizon == 1) {
      singlePeriod.inc();
      return start;
    }
    if (horizon < ezWeekFixedDuration.length) {
      return ezWeekFixedDuration[horizon].get(start);
    }
    return otherDurations.get(IntegerCache.get(horizon)).get(start);
  }
  
  public static Duration findDuration(EzYear start, int horizon) {
    if (horizon < 0) {
      return Duration.noDuration;
    }
    checkGetDuration();
    if (horizon == 1) {
      singlePeriod.inc();
      return start;
    }
    if (horizon < ezYearFixedDuration.length) {
      return ezYearFixedDuration[horizon].get(start);
    }
    return otherDurations.get(IntegerCache.get(horizon)).get(start);
  }

  private static final Cache<Period, Duration>[] ezDateFixedDuration = new Cache[2048];
  private static final Cache<Period, Duration>[] ezWeekFixedDuration = new Cache[256];
  private static final Cache<Period, Duration>[] ezMonthFixedDuration = new Cache[128];
  private static final Cache<Period, Duration>[] ezYearFixedDuration = new Cache[16];
  static {
    for (int i = 2, n = ezDateFixedDuration.length; i < n; i++) {
      final int duration = i;
      ezDateFixedDuration[i] = Caches.newCacheInstance((period) -> new SimpleDuration(period, duration));
    }
    for (int i = 2, n = ezWeekFixedDuration.length; i < n; i++) {
      final int duration = i;
      ezWeekFixedDuration[i] = Caches.newCacheInstance((period) -> new SimpleDuration(period, duration));
    }
    for (int i = 2, n = ezMonthFixedDuration.length; i < n; i++) {
      final int duration = i;
      ezMonthFixedDuration[i] = Caches.newCacheInstance((period) -> new SimpleDuration(period, duration));
    }
    for (int i = 2, n = ezYearFixedDuration.length; i < n; i++) {
      final int duration = i;
      ezYearFixedDuration[i] = Caches.newCacheInstance((period) -> new SimpleDuration(period, duration));
    }
  }
  private static Cache<Integer, Cache<Period, Duration>> otherDurations = Caches.newCacheInstance(
    (k) -> Caches.newManagerInstance((p) -> new SimpleDuration(p, k.intValue())));

  private SimpleDuration(Period start, int horizon) {
    createPeriod.inc();
    if (horizon <= 0) {
      throw new IllegalArgumentException();
    }
    this.start = start;
    this.horizon = horizon;
    this.firstDate = start.getFirstDay();
    this.lastDate = start.addPeriod(horizon-1).getLastDay();
  }

  public static Duration getPreviousYear(Duration duration, int nbOfPreviousYears) {
    return SimpleDuration.findDuration(duration.getStart().getPreviousYear(nbOfPreviousYears), duration.getHorizon());
  }
  
  public Period getStart() {
    return start;
  }
  public Period getLast() {
    return getStart().addPeriod(getHorizon()-1);
  }
  public int getHorizon() {
    return horizon;
  }
  public EzDate getFirstDay() {
    return firstDate;
  }
  public EzDate getLastDay() {
    return lastDate;
  }
  public int getDayCount() {
    return lastDate.getDay() - firstDate.getDay() + 1;
  }
  public EzDate getDay(int i) {
    final EzDate day = firstDate.add(i);
    if (day.isStrictlyAfter(lastDate)) {
      throw new ArrayIndexOutOfBoundsException(i+" >= Max Value("+getDayCount()+")");
    }
    return day;
  }
  
  public boolean equals(Duration other) {
    return (other != null && this.horizon == other.getHorizon() && this.start.equals(other.getStart()));
  }
  @Override
	public boolean equals(Object object) {
    return (this == object
      || (object instanceof Duration && equals((Duration)object)));
  }
  
  @Override
	public int hashCode() {
    return start.hashCode() + horizon;
  }

  @Override
  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  @Override
	public String toString() {
    return EzStandardDateFormat.referenceFormat(getFirstDay())+"-"+EzStandardDateFormat.referenceFormat(getLastDay().add(1));
  }
  
  public Bounds getDayBounds() {
    if (dayBounds == null) {
      synchronized (this) {
        if (dayBounds == null) {
          this.dayBounds = Bounds.getBounds(getFirstDay().getDay(), getLastDay().getDay()+1);
        }
      }
    }
    return dayBounds;
  }
  
  public Bounds getPeriodBounds() {
    if (periodBounds == null) {
      synchronized (this) {
        if (periodBounds == null) {
          this.periodBounds = Bounds.getBounds(getStart().getPeriod(), getStart().getPeriod()+getHorizon());
        }
      }
    }
    return periodBounds;
  }
  
  private final EzDate firstDate;
  private final EzDate lastDate;
  private final Period start;
  private final int horizon;
  private transient volatile Bounds dayBounds;
  private transient volatile Bounds periodBounds;

  public static final char day = 'D';
  public static final char month = 'M';
  public static final char week = 'W';
  public static final char financialPeriod = 'F';
  public static Duration getStandardDuration(char periodType, EzDate firstDay, EzDate lastDay, PeriodManager financialPeriods) {
    final PeriodManager periods;
    switch (periodType) {
      case day: periods = EzDate.manager; break;
      case week: periods = EzWeek.manager; break;
      case month: periods = EzMonth.manager; break;
      case financialPeriod: periods = financialPeriods; break;
      default: throw new UnsupportedOperationException();
    }
    return SimpleDuration.findDuration(
      periods.getPeriod(firstDay),
      periods.getPeriod(lastDay));
  }
  private static final Counter getPeriod = new Counter("Duration all");
  private static final Counter singlePeriod = new Counter("Duration single");
  private static final Counter createPeriod = new Counter("Duration new");
  private static final long serialVersionUID = 6469921504938033166L;

}
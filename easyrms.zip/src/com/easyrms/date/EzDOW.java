package com.easyrms.date;

import com.easyrms.util.comparator.*;
import com.easyrms.util.*;

import java.io.*;


public final class EzDOW implements Comparable<Object>, Cloneable, Serializable {

  private EzDOW(int id) {
    this.id = id;
    this.ID = IntegerCache.get(id);
  }

  public int getDOW() {
    return id;
  }
  public Integer getID() {
    return ID;
  }

  public EzDOW next() {
    return dows[(id+1)%7];
  }
  public EzDOW prev() {
    return dows[(id+6)%7];
  }

  public static final EzDOW MONDAY    = new EzDOW(EzDate.MONDAY);
  public static final EzDOW TUESDAY   = new EzDOW(EzDate.TUESDAY);
  public static final EzDOW WEDNESDAY = new EzDOW(EzDate.WEDNESDAY);
  public static final EzDOW THURSDAY  = new EzDOW(EzDate.THURSDAY);
  public static final EzDOW FRIDAY    = new EzDOW(EzDate.FRIDAY);
  public static final EzDOW SATURDAY  = new EzDOW(EzDate.SATURDAY);
  public static final EzDOW SUNDAY    = new EzDOW(EzDate.SUNDAY);
  public static final int ALL_DOW = 127;

  public static EzDOW valueOf(int id) {
    if (id >= 0 && id < 7) {
      return dows[id];
    }
    throw new IllegalArgumentException("Bad DOW");
  }
  public static EzDOW findEzDOW(int dow, int index) {
    for (int i = 0, j = 1; i < 7; i++, j *= 2) {
      if ((dow & j) != 0) {
        if (index == 0) {
          return dows[i];
        }
        index--;
      }
    }
    throw new ArrayIndexOutOfBoundsException(index);
  }
  public static EzDOW[] getEzDOW(int dow) {
    final int n = getEzDOWCount(dow);
    final EzDOW[] ezdows = new EzDOW[n];
    for (int i = 0, j = 1, k = 0;  k < n; i++, j *= 2) {
      if ((dow & j) != 0) {
        ezdows[k++] = dows[i];
      }
    }
    return ezdows;
  }
  public static int getEzDOWCount(int dows) {
    if (dows == ALL_DOW) {
      return 7;
    }
    int n = 0;
    for (int i = 0, j = 1;  i < 7; i++, j *= 2) {
      if ((dows & j) != 0) {
        n++;
      }
    }
    return n;
  }

  public int compareTo(Object o) {
    Number otherID = null;
    if (o instanceof EzDOW) {
      otherID = ((EzDOW)o).ID;
    }
    else if (o instanceof Number) {
      otherID = (Number)o;
      final int v = otherID.intValue();
      if (v < 0 || v >= 7) {
        otherID = null;
      }
    }
    if (otherID != null) {
      return NumberComparator.compare(ID.intValue(), otherID.intValue());
    }
    throw new IllegalArgumentException("Bad DOW COmparison");
  }

  @Override
  public boolean equals(Object object) {
    return (this == object || (object instanceof EzDOW && id == ((EzDOW)object).id));
  }

  @Override
  public int hashCode() {
    return id;
  }

  @Override
  public String toString() {
    return EzLongDateFormat.referenceFormatDOW(id);
  }

  public Object readResolve() {
    return valueOf(id);
  }

  private final int id;
  private final Integer ID;

  private static final EzDOW[] dows = new EzDOW[] {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY,
  };
  
	public static final EzDOW[] noEzDOWs = new EzDOW[0];
}
package com.easyrms.date;

import com.easyrms.util.*;


public interface EzTimeScale {

	int getIndex(EzTime time);
	int getIndex(int day, double time, int hh24);
	EzTime getTime(int i);
	
	Bounds getBounds(Duration duration);
}

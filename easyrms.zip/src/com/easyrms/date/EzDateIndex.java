package com.easyrms.date;

import java.io.*;


public final class EzDateIndex implements Comparable<Object>, Serializable {

  private EzDateIndex(EzDate date, int index) {
    this.date = date;
    this.index = index;
  }
  
  public EzDate getEzDate() { 
    return date; 
  }
  public int getIndex() { 
    return index; 
  }
  
  public EzDateIndex add(int dayOffset) {
    return (dayOffset == 0 && index == 0) ? this : getEzDateIndex(date.add(dayOffset));
  }
  public EzDateIndex add(int dayOffset, int indexOffset) {
    return (dayOffset == 0 && indexOffset == 0) ? this : getEzDateIndex(date.add(dayOffset), index+indexOffset);
  }
  
  private static final EzDateIndex nullEzDateIndex = new EzDateIndex(null, 0);
  public static EzDate trunc(EzDateIndex a) {
    return (a == null) ? null : a.getEzDate();
  }
  public static EzDateIndex NVL(EzDateIndex a) {
    return (a == null) ? nullEzDateIndex : a;
  }
  public static EzDateIndex NVL(EzDateIndex a, EzDateIndex b) {
    return (a == null) ? b : a;
  }

  public static EzDateIndex max(EzDateIndex a, EzDateIndex b) {
    if (a == null) {
      return b;
    }
    if (b == null) {
      return a;
    }
    if (a.isStrictlyBefore(b)) {
      return b;
    }
    return a;
  }
  public static EzDateIndex max(EzDateIndex a, EzDate b) {
    if (a == null) {
      return EzDateIndex.getEzDateIndex(b, 0);
    }
    if (b == null) {
      return a;
    }
    final EzDate aDate = a.getEzDate();
    if (aDate.isStrictlyAfter(b)) {
      return a;
    }
    if (aDate.isStrictlyBefore(b)) {
      return EzDateIndex.getEzDateIndex(b, 0);
    }
    return (a.getIndex() == 0) ? EzDateIndex.getEzDateIndex(b, 0) : a;
  }
  public static EzDateIndex max(EzDate a, EzDateIndex b) {
    return max(b, a);
  }
  public static EzDateIndex min(EzDateIndex a, EzDateIndex b) {
    if (b == null) {
      return a;
    }
    if (a == null) {
      return b;
    }
    if (a.isStrictlyBefore(b)) {
      return a;
    }
    return b;
  }
  public static EzDateIndex min(EzDateIndex a, EzDate b) {
    if (b == null) {
      return a;
    }
    if (a == null) {
      return EzDateIndex.getEzDateIndex(b, 0);
    }
    final EzDate aDate = a.getEzDate();
    if (aDate.isStrictlyBefore(b)) {
      return a;
    }
    if (aDate.isStrictlyAfter(b)) {
      return EzDateIndex.getEzDateIndex(b, 0);
    }
    return (a.getIndex() == 0) ? a : EzDateIndex.getEzDateIndex(b, 0);
  }
  public static EzDateIndex min(EzDate a, EzDateIndex b) {
    return min(b, a);
  }

  public boolean isStrictlyBefore(EzDateIndex other) {
    return (compareTo(other) < 0);
  }
  public boolean isStrictlyBefore(EzDate other) {
    return (compareTo(other) < 0);
  }
  public boolean isBefore(EzDateIndex other) {
    return (compareTo(other) <= 0);
  }
  public boolean isBefore(EzDate other) {
    return (compareTo(other) <= 0);
  }
  public boolean isStrictlyAfter(EzDateIndex other) {
    return (compareTo(other) > 0);
  }
  public boolean isStrictlyAfter(EzDate other) {
    return (compareTo(other) > 0);
  }
  public boolean isAfter(EzDateIndex other) {
    return (compareTo(other) >= 0);
  }
  public boolean isAfter(EzDate other) {
    return (compareTo(other) >= 0);
  }
  public boolean isBetween(EzDateIndex first, EzDateIndex last) {
    return isBefore(last) && isAfter(first);
  }
  public boolean isBetween(EzDate first, EzDate last) {
    return isBefore(last) && isAfter(first);
  }

  @Override
  public boolean equals(Object other) {
    if (other instanceof EzDateIndex) {
      final EzDateIndex otherDateIndex = (EzDateIndex)other;
      if (date == null) return (otherDateIndex.date == null);
      return (otherDateIndex.date != null && otherDateIndex.index == index && otherDateIndex.date.equals(date));
    }
    return false;
  }
  @Override
  public int hashCode() {
    return (date == null) ? 0 : index+10*date.hashCode();
  }
  
  public int compareTo(Object other) {
    if (date == null) {
      return (other == null) ? 0 : -1;
    }
    if (other instanceof EzDateIndex) {
      final EzDateIndex otherDateIndex = (EzDateIndex)other;
      if (otherDateIndex.date == null) {
        return 1;
      }
      final int dateComparison = date.compareTo(otherDateIndex.date);
      if (dateComparison != 0) {
        return dateComparison;
      }
      final int indexComparison = index - otherDateIndex.index;
      return (indexComparison == 0) ? 0 : (indexComparison < 0) ? -1 : 1;
    }
    if (other instanceof EzDate) {
      final EzDate otherDate = (EzDate)other;
      final int dateComparison = date.compareTo(otherDate);
      if (dateComparison != 0) {
        return dateComparison;
      }
      return (index > 0) ? 1 : 0;
    }
    throw new IllegalArgumentException(other.toString());
  }

  
  public Object readResolve() {
    return getEzDateIndex(date, index);
  }
  
  @Override
  public String toString() {
    if (date == null) {
      return "null";
    }
    return date.toString()+"#"+index;
  }

  private final EzDate date;
  private final int index;
  
  private static final int maxIndex = 10;
  private static final int maxEzDate = 100;
  private static final EzDate minReferenceDate = EzDate.today.add(-maxEzDate/2);
  private static final EzDate maxReferenceDate = minReferenceDate.add(maxEzDate-1);
  private static final EzDateIndex[][] cache = new EzDateIndex[maxIndex][maxEzDate];
  static {
    for (int i = 0; i < maxIndex; i++) {
      final EzDateIndex[] subCache = cache[i];    
      for (int j = 0; j < maxEzDate; j++) {
        subCache[j] = new EzDateIndex(minReferenceDate.add(j), i);
      }
    }
  }
  public static EzDateIndex getEzDateIndex(EzDate date) {
    return getEzDateIndex(date, 0);
  }
  public static EzDateIndex getEzDateIndex(EzDate date, int index) {
    if (date == null) {
      return nullEzDateIndex;
    }
    if (index < maxIndex && date.isBetween(minReferenceDate, maxReferenceDate)) {
      return cache[index][date.sub(minReferenceDate)]; 
    }
    return new EzDateIndex(date, index);
  }
}
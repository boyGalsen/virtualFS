package com.easyrms.date;

import java.util.*;


public final class EzYear extends AbstractPeriod {

  public static EzYear valueOf(int id) {
    final int ID = id-minID;
    if (ID >= 0 && ID < cache.length) {
      return cache[ID];
    }
    return new EzYear(id);
  }

  public static EzYear valueOf(Date date) {
    return EzDate.valueOf(date).getEzYear();
  }
  
  public static EzYear getEzYear(int year) {
  	return valueOf(year);
  }

  private EzYear(int id) {
    super(id);
    if (id < EzDate.REFERENCE_YEAR || id > EzDate.MAX_YEAR) {
      throw new IllegalArgumentException("id="+id);
    }
  }

  @Override
  public int getYear() {
    return id;
  }
  @Override
  public EzYear getEzYear() {
    return this;
  }

  public EzDate getFirstDay() {
    return EzDate.getEzDate(getYear(), EzDate.JANUARY, 1);
  }
  @Override
  public EzDate getLastDay() {
    return EzDate.getEzDate(getYear(), EzDate.DECEMBER, 31);
  }
  public int getDayCount() {
    return (id % 4 == 0) ? 366 : 365;
  }

  public EzYear add(int years) {
    if (years == 0) return this;
    return valueOf(id+years);
  }

  public int sub(EzYear other) {
    return this.id-other.id;
  }
  
	public EzYear getPreviousEzYear(int nbOfYears) {
		return valueOf(id-nbOfYears);
	}
  @Override
  public Period getPreviousYear(int nbOfYears) {
		return getPreviousEzYear(nbOfYears);
	}

  public PeriodManager getManager() {
    return manager;
  }

  @Override
  public String toString() {
    return "["+id+"]";
  }

  public static EzYear max(EzYear a, EzYear b) {
    return (a == null || (b != null && a.id < b.id)) ? b : a;
  }
  public static EzYear min(EzYear a, EzYear b) {
    return (a == null || (b != null && a.id > b.id)) ? b : a;
  }

  public boolean isStrictlyBefore(EzYear other) {
    return (id < other.id);
  }
  public boolean isStrictlyBefore(int other) {
    return (id < other);
  }
  public boolean isBefore(EzYear other) {
    return (id <= other.id);
  }
  public boolean isBefore(int other) {
    return (id <= other);
  }
  public boolean isAfter(EzYear other) {
    return (id >= other.id);
  }
  public boolean isAfter(int other) {
    return (id >= other);
  }
  public boolean isStrictlyAfter(EzYear other) {
    return (id > other.id);
  }
  public boolean isStrictlyAfter(int other) {
    return (id > other);
  }

  public static final PeriodManager manager = new AbstractPeriodManager("Year") {

    public Period getPeriod(int id) { 
      return EzYear.valueOf(id); 
    }
    public Period getPeriod(EzDate day) { 
      return day.getEzYear(); 
    }
		
    @Override
    public PeriodManager getYearManager() { 
      return this; 
    }
  };

  private static final EzYear[] cache;
  static final int minID;
  static {
    final int cacheSize = EzDate.defaultCacheSize/365;
    cache = new EzYear[cacheSize];
    minID = EzDate.valueOf(EzDate.minID).getYear();
    for (int i = 0; i < cacheSize; i++) {
      cache[i] = new EzYear(minID+i);
    }
  }

  static final long serialVersionUID = 3672973835292197952L;

  public Object readResolve() {
    return valueOf(id);
  }
  
  public static final EzYear[] noEzYears = new EzYear[0];
}
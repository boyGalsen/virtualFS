package com.easyrms.date;

import com.easyrms.util.*;
import com.easyrms.util.comparator.*;


public abstract class AbstractPeriodManager implements PeriodManager {

  public AbstractPeriodManager(String name) {
    this(name, null, PeriodManager.noPeriodManagers);
  }
  public AbstractPeriodManager(String name, PeriodManager year, PeriodManager... subPeriods) {
    this.name = StringComparator.isNull(name) ? "Financial Period" : name;
    this.year = year;
    this.subPeriods = (subPeriods.length == 0) 
      ? PeriodManager.emptyPeriodManagerArray 
      : new EzArray.SimpleEzArray<PeriodManager>(true, subPeriods);
  }

  public final String getName() { 
    return name; 
  }

  public String getStandardPrefix() { 
    return null; 
  }
  
  public final EzArray<? extends PeriodManager> getSubPeriods() {
    return subPeriods;
  }
  
  public PeriodManager getYearManager() { 
    return year; 
  }

  protected final String name;
  private final PeriodManager year;
  private final EzArray<? extends PeriodManager> subPeriods;
}
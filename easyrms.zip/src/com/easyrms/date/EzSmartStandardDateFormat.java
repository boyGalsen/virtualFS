package com.easyrms.date;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;

public class EzSmartStandardDateFormat extends EzDateFormat {

  public static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat reference = new EzSmartStandardDateFormat() {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceWeekFormat(Object obj) {
    synchronized (referenceWeek) {
      return referenceWeek.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceWeek = new EzSmartStandardDateFormat() {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceMonthFormat(Object obj) {
    synchronized (referenceMonth) {
      return referenceMonth.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceMonth = new EzSmartStandardDateFormat(MONTH) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceYearFormat(Object obj) {
    synchronized (referenceYear) {
      return referenceYear.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceYear = new EzSmartStandardDateFormat(YEAR) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceMonthAndYearFormat(Object obj) {
    synchronized (referenceMonthAndYear) {
      return referenceMonthAndYear.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceMonthAndYear = new EzSmartStandardDateFormat(MONTH + YEAR) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceWithDOWFormat(Object obj) {
    synchronized (referenceWithDOW) {
      return referenceWithDOW.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceWithDOW = new EzSmartStandardDateFormat(DOW + DAY + MONTH + YEAR) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceDOWFormat(Object obj) {
    synchronized (referenceDOW) {
      return referenceDOW.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceDOW = new EzSmartStandardDateFormat(DOW) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceDOMFormat(Object obj) {
    synchronized (referenceDOM) {
      return referenceDOM.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceDOM = new EzSmartStandardDateFormat(DAY) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceDOMandMONTHFormat(Object obj) {
    synchronized (referenceDOMandMONTH) {
      return referenceDOMandMONTH.format(obj); 
    }
  }
  private static final EzSmartStandardDateFormat referenceDOMandMONTH = new EzSmartStandardDateFormat(DAY+MONTH) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
	@Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) {
    }
    else if (obj instanceof EzDate) {
      format((EzDate)obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof Date) {
      format(EzDate.valueOf((Date)obj), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof DateAccessor) {
      format(EzDate.valueOf((DateAccessor)obj), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof EzDOW) {
      if (isDOWDisplayed()) toAppendTo.append(formatDOW(((EzDOW)obj).getDOW()));
    }
    else if (obj instanceof Calendar) {
      format(EzDate.valueOf(((Calendar)obj).getTime()), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (getDisplay() == YEAR && obj instanceof Period) {
      toAppendTo.append(formatYear(((Period)obj).getYear()));
    }
    else if (obj instanceof EzMonth) {
      format(((EzMonth)obj).getFirstDay(), toAppendTo, false, false, isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof EzYear) {
      toAppendTo.append(formatYear(((EzYear)obj).getYear()));
      //format(((EzYear)obj).getFirstDay(), toAppendTo, false, false, false, isYearDisplayed());
    }
    else if (obj instanceof Period) {
      final Period period = (Period)obj;      
      if (period.getDayCount() > 1)  {
        if (period.getFirstDay().getEzYear().equals(period.getLastDay().getEzYear())) { 
          referenceDOMandMONTH.format(period.getFirstDay(), toAppendTo, pos);          
        }
        else {
          format(period.getFirstDay(), toAppendTo, pos);
        }
        toAppendTo.append(" - ");
        format(period.getLastDay(), toAppendTo, pos);
      }
      else {
        format(period.getFirstDay(), toAppendTo, pos);
      }
    }
    else if (obj instanceof Number) {
      final int value = ((Number)obj).intValue();
      if (value != -1) format(EzDate.valueOf(value), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof String) {
      toAppendTo.append(obj);
    }
    return toAppendTo;
  }

  public EzSmartStandardDateFormat() {
    super();
  }
  public EzSmartStandardDateFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return " ";
  }
	@Override
  public String formatDOW(int dow) {
    return dowTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyTexts[moy];
  }
}
package com.easyrms.date;

import java.text.*;
import java.util.*;

public abstract class EzDateFormat extends Format {
  
  public static enum DateFormatType {

    SHORT, STANDARD, LONG;

    public static DateFormatType findByName(String name) {
      if (SHORT.toString().equalsIgnoreCase(name)) {
        return SHORT;
      }
      if (STANDARD.toString().equalsIgnoreCase(name)) {
        return STANDARD;
      }
      return LONG;
    }
    
    public static DateFormatType min(DateFormatType a, DateFormatType b) {
      if (a == null) {
        return b;
      }
      if (b == null) {
        return a;
      }
      if (a == LONG) {
        return b;
      }
      if (b == LONG) {
        return a;
      }
      if (a == STANDARD) {
        return b;
      }
      if (b == STANDARD) {
        return a;
      }
      if (a == SHORT) {
        return b;
      }
      return a;
    }
    
    public static DateFormatType max(DateFormatType a, DateFormatType b) {
      if (a == SHORT) {
        return b;
      }
      if (b == SHORT) {
        return a;
      }
      if (a == STANDARD) {
        return b;
      }
      if (b == STANDARD) {
        return a;
      }
      if (a == LONG) {
        return b;
      }
      if (b == LONG) {
        return a;
      }
      if (a == null) {
        return b;
      }
      return a;
    }
  }

  public static final int DOW = 1;
  public static final int DAY = 2;
  public static final int MONTH = 4;
  public static final int YEAR = 8;
  public static final int QUARTER = 16;

  protected EzDateFormat() {
    this.display = DAY | MONTH | YEAR;
  }
  protected EzDateFormat(int display) {
    this.display = display;
  }

  public void setDisplay(int display) {
    this.display = display;
  }
  public int getDisplay() {
    return display;
  }
  public boolean isDOWDisplayed() {
    return ((display & DOW) != 0);
  }
  public boolean isDayDisplayed() {
    return ((display & DAY) != 0);
  }
  public boolean isMonthDisplayed() {
    return ((display & MONTH) != 0);
  }
  public boolean isQuarterDisplayed() {
    return ((display & QUARTER) != 0);
  }
  public boolean isYearDisplayed() {
    return ((display & YEAR) != 0);
  }
  private int display;

  public StringBuffer format(EzDate obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null)
      ? format(obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed())
      : toAppendTo;
  }

  public StringBuffer format(EzWeek obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj != null) { 
      toAppendTo.append(formatWOY(obj.getWOY()));
      if (isYearDisplayed()) {
        toAppendTo.append(" ");
        toAppendTo.append(formatYear(obj.getYear()));
      }
    }
    return toAppendTo;
  }

  public StringBuffer format(EzMonth obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(obj.getFirstDay(), toAppendTo, false, false, true, isYearDisplayed())
      : toAppendTo;
  }

  public StringBuffer format(EzQuarter obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj != null) {
      toAppendTo.append(formatQOY(obj.getQOY()));
      if (isYearDisplayed()) {
        toAppendTo.append(" ");
        toAppendTo.append(formatYear(((EzQuarter)obj).getYear()));
      }
    }
		return toAppendTo;
  }
  
  public StringBuffer format(EzYear obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(obj.getFirstDay(), toAppendTo, false, false, false, isYearDisplayed())
      : toAppendTo;
  }

  public StringBuffer format(EzDOW obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? toAppendTo.append(formatDOW(obj.getDOW()))
      : toAppendTo;
  }
  public StringBuffer format(Date obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(EzDate.valueOf(obj), toAppendTo, pos)
      : toAppendTo;
  }
  public StringBuffer format(DateAccessor obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(obj.toDate(), toAppendTo, pos)
      : toAppendTo;
  }

  public StringBuffer format(Calendar obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(EzDate.valueOf(obj.getTime()), toAppendTo, pos)
      : toAppendTo;
  }

  public StringBuffer format(Number obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(EzDate.valueOf(obj.intValue()), toAppendTo, pos)
      : toAppendTo;
  }

  public StringBuffer format(Period obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj != null) 
      ? format(obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed())
      : toAppendTo;
  }

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj != null) {
      if (obj instanceof EzDate) {
        return format((EzDate)obj, toAppendTo, pos);
      }
      if (obj instanceof DateAccessor) {
        return format((DateAccessor)obj, toAppendTo, pos);
      }
      if (obj instanceof Date) {
        return format((Date)obj, toAppendTo, pos);
      }
      if (obj instanceof EzDOW) {
        return format((EzDOW)obj, toAppendTo, pos);
      }
      if (obj instanceof Calendar) {
        return format((Calendar)obj, toAppendTo, pos);
      }
      if (getDisplay() == YEAR && obj instanceof Period) {
        return toAppendTo.append(formatYear(((Period)obj).getYear()));
      }
      if (obj instanceof EzWeek) {
        return format((EzWeek)obj, toAppendTo, pos);
      }
      if (obj instanceof EzMonth) {
        return format((EzMonth)obj, toAppendTo, pos);
      }
      if (obj instanceof EzQuarter) {
        return format((EzQuarter)obj, toAppendTo, pos);
      }
      if (obj instanceof EzYear) {
        return toAppendTo.append(formatYear(((EzYear)obj).getYear()));
      }
      if (obj instanceof Period) {
        return format((Period)obj, toAppendTo, pos);
      }
      if (obj instanceof String) {
        return toAppendTo.append(obj);
      }
      if (obj instanceof Number) {
        final int value = ((Number)obj).intValue();
        return (value != -1) 
          ? format(EzDate.valueOf(value), toAppendTo, pos)
          : toAppendTo;
      }
    }
    return toAppendTo;
  }

  public String formatDOWSeparator() {
    return " ";
  }
  public String formatSeparator() {
    return "/";
  }
  public String formatDOW(int dow) {
    throw new UnsupportedOperationException();
  }
  public String formatDOM(int dom) {
    return domFigures[dom];
  }
  public String formatWOY(int woy) {
    return woyFigures[woy];
  }
  public String formatQOY(int qoy) {
    return qoyFigures[qoy-EzQuarter.FIRST_QUARTER];
  }
  public String formatMOY(int moy) {
    throw new UnsupportedOperationException();
  }
  public String formatYear(int year) {
    return yyFigures[year % 100];
  }
  public String formatPeriod(Period period) {
    return (period != null) ? period.toString() : "";
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
  @Override
  public boolean equals(Object object) {
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    final EzDateFormat other = (EzDateFormat)object;
    return (isDOWDisplayed() == other.isDOWDisplayed()
      && isDayDisplayed() == other.isDayDisplayed()
      && isMonthDisplayed() == other.isMonthDisplayed()
      && isYearDisplayed() == other.isYearDisplayed());
  }

  protected StringBuffer format(
    EzDate date,
    StringBuffer toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed)
  {
    if (date != null && date.isStrictlyAfter(EzDate.ever) && date.isStrictlyBefore(EzDate.never)) {
      boolean isSeparatorNeeded = false;
      if (isDOWDisplayed) {
        toAppendTo.append(formatDOW(date.getDOW()));
        isSeparatorNeeded = true;
      }
      if (isDayDisplayed) {
        if (isSeparatorNeeded) {
          toAppendTo.append(formatDOWSeparator());
        }
        toAppendTo.append(formatDOM(date.getDOM()));
        isSeparatorNeeded = true;
      }
      if (isMonthDisplayed) {
        if (isSeparatorNeeded) {
          toAppendTo.append(formatSeparator());
        }
        toAppendTo.append(formatMOY(date.getMOY()));
        isSeparatorNeeded = true;
      }
      if (isYearDisplayed) {
        if (isSeparatorNeeded) {
          toAppendTo.append(formatSeparator());
        }
        toAppendTo.append(formatYear(date.getYear()));
      }
    }
    return toAppendTo;
  }
  protected StringBuffer format(
    Period period,
    StringBuffer toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed)
  {
    return toAppendTo.append(formatPeriod(period));
  }

  public EzDate parse(String source) throws ParseException {
    return parse(source, new ParsePosition(0));
  }
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    int index = status.getIndex();
    if (source != null) {
      try {
        final String separator = formatSeparator();
        String buffer = source.substring(index);
        if (isDOWDisplayed()) {
          index = buffer.indexOf(separator);
          index += separator.length();
          buffer = buffer.substring(index);
        }
        final int dom;
        if (isDayDisplayed()) {
          index = buffer.indexOf(separator);
          dom = Integer.parseInt(buffer.substring(0, index));
          index += separator.length();
          buffer = buffer.substring(index);
        }
        else {
          dom = 1;
        }
        int moy = EzDate.JANUARY;
        if (isMonthDisplayed()) {
          index = buffer.indexOf(separator);
          final String month = buffer.substring(0, index);
          for (; moy < EzDate.DECEMBER; moy++) {
            if (month.equals(formatMOY(moy))) {
              break;
            }
          }
          index += separator.length();
          buffer = buffer.substring(index);
        }
        else {
          moy = 1;
        }
        if (buffer.length() > 4) {
          buffer = buffer.substring(0, 4);
        }
        final int year = Integer.parseInt(buffer);
        status.setIndex(index+4);
        return EzDate.getEzDate(year, moy, dom);
      }
      catch (Throwable ignored) {
      }
    }
    status.setErrorIndex(status.getIndex());
    throw new ParseException("Invalid Date", index);
  }
  @Override
  public final Object parseObject(String source, ParsePosition status) {
    final int start = status.getIndex();
    try {
      return parse(source, status);
    }
    catch (ParseException exception) {
      status.setErrorIndex(start);
    }
    return null;
  }

  public static final String[] domFigures = {
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
    "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
    "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
    "30", "31",
  };

  public static final String[] woyFigures = {
    "W00", "W01", "W02", "W03", "W04", "W05", "W06", "W07", "W08", "W09",
    "W10", "W11", "W12", "W13", "W14", "W15", "W16", "W17", "W18", "W19",
    "W20", "W21", "W22", "W23", "W24", "W25", "W26", "W27", "W28", "W29",
    "W30", "W31", "W32", "W33", "W34", "W35", "W36", "W37", "W38", "W39",
    "W40", "W41", "W42", "W43", "W44", "W45", "W46", "W47", "W48", "W49",
    "W50", "W51", "W52", "W53",
   };

  public static final String[] qoyFigures = {
    "Q1", "Q2", "Q3", "Q4",
  }
  ;
  public static final String[] moyFigures = {
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12",
  };

  public static final String[] yyFigures = {
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
    "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
    "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
    "30", "31", "32", "33", "34", "35", "36", "37", "38", "39",
    "40", "41", "42", "43", "44", "45", "46", "47", "48", "49",
    "50", "51", "52", "53", "54", "55", "56", "57", "58", "59",
    "60", "61", "62", "63", "64", "65", "66", "67", "68", "69",
    "70", "71", "72", "73", "74", "75", "76", "77", "78", "79",
    "80", "81", "82", "83", "84", "85", "86", "87", "88","89",
    "90", "91", "92", "93", "94", "95", "96", "97", "98","99",
  };

  public static final String[] moyShortTexts = {
    null, "J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D",
  };
  public static final String[] moyTexts = {
    null, "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec",
  };
  public static final String[] moyThreeLetterTexts = {
    null, "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC",
  };
  public static final String[] moyLongTexts = {
    null, "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",
  };

  public static final String[] dowShortTexts = {
    "M", "T", "W", "T", "F", "S", "S",
  };
  public static final String[] dowTexts = {
    "Mon.", "Tue.", "Wed.", "Thu.", "Fri.", "Sat.", "Sun.",
  };
  public static final String[] dowLetterTexts = {
    "Mo", "Tu", "We", "Th", "Fr", "Sa", "Su",
  };
  public static final String[] dowThreeLetterTexts = {
    "Mo.", "Tu.", "We.", "Th.", "Fr.", "Sa.", "Su.",
  };
  public static final String[] dowLongTexts = {
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
  };
}
package com.easyrms.date;

import com.easyrms.util.*;


public interface PeriodManager {

  String getName();
  String getStandardPrefix();
  
  Period getPeriod(int id);
  Period getPeriod(EzDate day);
  
  PeriodManager getYearManager();

  EzArray<? extends PeriodManager> getSubPeriods();
  
  PeriodManager[] noPeriodManagers = new PeriodManager[0];
  EzArray<? extends PeriodManager> emptyPeriodManagerArray = new EzArray.NoEzArray<PeriodManager>();
}
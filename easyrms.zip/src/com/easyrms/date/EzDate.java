package com.easyrms.date;

import com.easyrms.util.*;

import java.io.*;
import java.time.*;
import java.time.temporal.*;
import java.util.*;
import java.util.function.*;

public final class EzDate extends AbstractPeriod implements Serializable {

  public static EzDate valueOf(int id) {
    if (id >= MAX_ID) {
      if (id == NEVER_ID) {
        return never;
      }
      if (id == MAX_ID) {
        return lastEzDate;
      }
      if (EasyRMS.isDebug) {
        throw new IllegalArgumentException(""+id);
      }
      return lastEzDate;
    }
    if (id <= MIN_ID) {
      if (id == EVER_ID) {
        return ever;
      }
      if (id == MIN_ID) {
        return firstEzDate;
      }
      if (EasyRMS.isDebug) {
        throw new IllegalArgumentException(""+id);
      }
      return firstEzDate;
    }
    final int ID = id-minID;
    if (ID >= 0 && ID < cache.length) {
      return cache[ID];
    }
    return new EzDate(id);
  }

  public static EzDate parseInt(String s) {
    return valueOf(Integer.parseInt(s));
  }

  public static EzDate valueOf(Date date) {
    return valueOf(valueOf(date.getTime()));
  }
  public static EzDate valueOf(DateAccessor date) {
    return valueOf(valueOf(date.getTime()));
  }

  public static EzDate getEzDate(int year, int month, int day) {
    final int yearID = year - minYear;
    if (yearID >= 0 && yearID < conversionCache.length) {
      try {
        return valueOf(conversionCache[yearID][month - 1] + day);
      }
      catch (ArrayIndexOutOfBoundsException e) {
        throw new IllegalArgumentException();
      }
    }
    return valueOf((int)ChronoUnit.DAYS.between(START_DATE, LocalDate.of(year, month, day)));
  }

  private EzDate(int id) {
    super(id);
    if ((id > MAX_ID && id != NEVER_ID) || (id < 0)) {
      throw new IllegalArgumentException("id=" + id);
    }

    final LocalDate currentDate = START_DATE.plus(id, ChronoUnit.DAYS);
    date = new SimpleDateAccessor(Date.from(currentDate.atStartOfDay(GMT).toInstant()));
    dom = currentDate.getDayOfMonth();
    moy = currentDate.getMonth().getValue(); //EzDate.JANUARY == Month.JANUARY.getValue()
    year = currentDate.getYear();
    doy = currentDate.getDayOfYear();
    month = (int)ChronoUnit.MONTHS.between(START_DATE_MONTH, currentDate) + 1;
    woy = currentDate.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);

    if (id != EVER_ID && id != NEVER_ID) {
      if (year < REFERENCE_YEAR || year > MAX_YEAR) {
        throw new IllegalArgumentException("id=" + id + ",Year=" + year);
      }
      if (month <= 0 || month > MAX_MONTH) {
        throw new IllegalArgumentException("id=" + id + ",Year=" + year + ",Month=" + month);
      }
    }
  }

  public static final int MONDAY = 0;
  public static final int TUESDAY = 1;
  public static final int WEDNESDAY = 2;
  public static final int THURSDAY = 3;
  public static final int FRIDAY = 4;
  public static final int SATURDAY = 5;
  public static final int SUNDAY = 6;

  public static final int JANUARY = 1;
  public static final int FEBRUARY = 2;
  public static final int MARCH = 3;
  public static final int APRIL = 4;
  public static final int MAY = 5;
  public static final int JUNE = 6;
  public static final int JULY = 7;
  public static final int AUGUST = 8;
  public static final int SEPTEMBER = 9;
  public static final int OCTOBER = 10;
  public static final int NOVEMBER = 11;
  public static final int DECEMBER = 12;

  public int getDay() {
    return id;
  }
  public static int getDay(EzDate date) {
    return (date != null) ? date.id : 0;
  }
  public int getDOW() {
    return getDOW(id);
  }
  public static int getDOW(int day) {
    return (day-1)%7;
  }
  public int getWeek() {
    return (id-1)/7+1;
  }
  public int getMonth() {
    return month;
  }
  @Override
  public int getYear() {
    return year;
  }
  public int getDIM() {
    return getEzMonth().getDIM();
  }
  public int getDOM() {
    return dom;
  }
  public int getWOY() {
    return woy;
  }
  public int getMOY() {
    return moy;
  }
  public int getDOY() {
    return doy;
  }

  public EzDOW getEzDOW() {
    return EzDOW.valueOf(getDOW());
  }
  public EzWeek getEzWeek() {
    if (ezWeek != null) {
      return ezWeek;
    }
    synchronized (this) {
      if (ezWeek == null) {
        ezWeek = EzWeek.valueOf(getWeek());
      }
    }
    return ezWeek;
  }
  public EzMonth getEzMonth() {
    if (ezMonth != null) {
      return ezMonth;
    }
    synchronized (this) {
      if (ezMonth == null) {
        ezMonth = EzMonth.valueOf(month);
      }
    }
    return ezMonth;
  }
  public EzQuarter getEzQuarter() {
    if (ezQuarter != null) {
      return ezQuarter;
    }
    synchronized (this) {
      if (ezQuarter == null) {
        ezQuarter = EzQuarter.valueOf(this);
      }
    }
    return ezQuarter;
  }
  @Override
  public EzYear getEzYear() {
    if (ezYear != null) {
      return ezYear;
    }
    synchronized (this) {
      if (ezYear == null) {
        ezYear = EzYear.valueOf(year);
      }
    }
    return ezYear;
  }

  public EzDate getFirstDay() {
    return this;
  }
  @Override
  public EzDate getLastDay() {
    return this;
  }
  public int getDayCount() {
    return 1;
  }

  public EzDate add(int days) {
    return (days == 0)
      ? this
      : valueOf(id+days);
  }

  public int sub(EzDate other) {
    return this.id-other.id;
  }

	public EzDate getPreviousYearEzDate(int nbOfYears) {
		int previousYearID = id-364*nbOfYears;
		previousYearID -= ((int)(nbOfYears*1.25+3.5)/7)*7;
		return valueOf(previousYearID);
	}

  public EzDate getNextYearEzDate(int nbOfYears) {
    int nextYearID = id+364*nbOfYears;
    nextYearID += ((int)(nbOfYears*1.25+3.5)/7)*7;
    return valueOf(nextYearID);
  }

  public EzDate getPreviousYearEzDateSameDOM(int nbOfYears) {
    return EzDate.getEzDate(getYear()-nbOfYears, getMOY(), getDOM());
  }

  public EzDate getNextYearEzDateSameDOM(int nbOfYears) {
    return EzDate.getEzDate(getYear()+nbOfYears, getMOY(), getDOM());
  }

  @Override
	public Period getPreviousYear(int nbOfYears) {
		return getPreviousYearEzDate(nbOfYears);
	}

  public static EzDate max(EzDate a, EzDate b) {
    return (a == null || (b != null && a.id < b.id)) ? b : a;
  }
	public static EzDate max(EzDate a, EzDate b, EzDate c) {
		return (a == null)
      ? max(b, c)
      : max(a, max(b, c));
	}
	public static EzDate max(EzDate... dates) {
    EzDate max = null;
    for (int i = 0, n = dates.length; i < n; i++) {
      max = EzDate.max(dates[i], max);
    }
    return max;
  }

  public static EzDate max(EzArray<EzDate> dates) {
    EzDate max = null;
    for (int i = 0, n = dates.getCount(); i < n; i++) {
      max = EzDate.max(dates.get(i), max);
    }
    return max;
  }
  //@Deprecated When EzDateCollection inherits from EzArray
  public static EzDate max(EzDateCollection dates) {
    EzDate max = null;
    for (int i = 0, n = dates.getCount(); i < n; i++) {
      max = EzDate.max(dates.get(i), max);
    }
    return max;
  }
  public static EzDate min(EzArray<EzDate> dates) {
    EzDate min = null;
    for (int i = 0, n = dates.getCount(); i < n; i++) {
      min = EzDate.min(dates.get(i), min);
    }
    return min;
  }
  //@Deprecated When EzDateCollection inherits from EzArray
  public static EzDate min(EzDateCollection dates) {
    EzDate min = null;
    for (int i = 0, n = dates.getCount(); i < n; i++) {
      min = EzDate.min(dates.get(i), min);
    }
    return min;
  }
	public static EzDate min(EzDate a, EzDate b) {
    return (a == null || (b != null && a.id > b.id)) ? b : a;
	}

	public static EzDate min(EzDate... dates) {
	  EzDate min = null;
	  for (int i = 0, n = dates.length; i < n; i++) {
	    min = EzDate.min(dates[i], min);
	  }
    return min;
  }
	public static EzDate min(EzDate a, EzDate b, EzDate c) {
    return (a == null)
      ? min(b, c)
      : min(a, min(b, c));
	}

  public static Integer getNVLID(EzDate a) {
    return (a == null) ? null : a.getID();
  }
	public static EzDate NVL(EzDate a, EzDate b, EzDate c) {
		return (a == null) ? NVL(b, c) : a;
	}
  public static EzDate NVL(EzDate a, EzDate b) {
    return (a == null) ? b : a;
  }

  public boolean equals(EzDate other) {
    return (this == other || (other != null && this.id == other.id));
  }

  public boolean isStrictlyBefore(EzDate other) {
    return (id < other.id);
  }
  public boolean isStrictlyBefore(Period other) {
    return (id < other.getFirstDay().getDay());
  }
  public boolean isStrictlyBeforeDay(int other) {
    return (id < other);
  }
  public boolean isBefore(EzDate other) {
    return (id <= other.id);
  }
  public boolean isBefore(Period other) {
    return (id <= other.getLastDay().getDay());
  }
  public boolean isBeforeDay(int other) {
    return (id <= other);
  }
  public boolean isAfter(EzDate other) {
    return (id >= other.id);
  }
  public boolean isAfter(Period other) {
    return (id >= other.getFirstDay().getDay());
  }
  public boolean isAfterDay(int other) {
    return (id >= other);
  }
  public boolean isBetween(EzDate first, EzDate last) {
    return (id >= first.id && id <= last.id);
  }
  public boolean isBetween(Period first, Period last) {
    return (id >= first.getFirstDay().getDay() && id <= last.getLastDay().getDay());
  }
  public boolean isBetweenDay(int first, int last) {
    return (id >= first && id <= last);
  }
  public boolean isStrictlyAfter(EzDate other) {
    return (id > other.id);
  }
  public boolean isStrictlyAfter(Period other) {
    return (id > other.getLastDay().getDay());
  }
  public boolean isStrictlyAfterDay(int other) {
    return (id > other);
  }

  public static EzDate now() {
    return valueOf(valueOf(StampUtil.getSystemStampValue()));
  }
  public static EzDate ever() {
    return ever;
  }
  public static EzDate never() {
    return never;
  }

  public PeriodManager getManager() {
    return manager;
  }

  public Object readResolve() {
    return valueOf(id);
  }

  @Override
  public String toString() {
    return "["+id+","+EzStandardDateFormat.referenceFormat(this)+"]";
  }

  public int getCount() {
    return 1;
  }

  @Override
  public EzDate get(int i) {
    if (i == 0) {
      return this;
    }
    throw new ArrayIndexOutOfBoundsException(i);
  }

  public void forEach(Consumer<? super EzDate> function) {
    function.accept(this);
  }

  public DateAccessor getTime() {
    return date;
  }
  DateAccessor getLocalTime() {
    return date;
  }

  private final DateAccessor date;
  private final int dom;
  private final int doy;
  private final int woy;
  private final int moy;
  private final int month;
  private final int year;
  private transient volatile EzWeek ezWeek;
  private transient volatile EzMonth ezMonth;
  private transient volatile EzQuarter ezQuarter;
  private transient volatile EzYear ezYear;

  public static final int MAX_ID = 19999;
  public static final int MIN_ID = 1;
  public static final int SHIFT = 100000;
  private static final int NEVER_ID = 99999;
  public static int maxValidityEnd = NEVER_ID;
  public static int indexShift = SHIFT;
  private static final int EVER_ID = 0;
  static final int MINUTE_IN_MILLISECONDS = 1000*60;
  static final int HOUR_IN_MILLISECONDS = MINUTE_IN_MILLISECONDS*60;
  static final int DAY_IN_MILLISECONDS = HOUR_IN_MILLISECONDS*24;
  static final int WEEK_IN_MILLISECONDS = DAY_IN_MILLISECONDS*7;
  public static final int REFERENCE_YEAR = 1990;
  static final int MAX_YEAR = MAX_ID*4/(365+365+365+366)+REFERENCE_YEAR;
  static final int MAX_MONTH = (MAX_YEAR-REFERENCE_YEAR+1)*12;
  static final int MAX_WEEK = MAX_ID/7;

  private static final ZoneId GMT = ZoneId.of("GMT");
  private static final LocalDate START_DATE = LocalDate.of(REFERENCE_YEAR - 1, 12, 31);    //the original calendar started a day earlier
  private static final LocalDate START_DATE_MONTH = LocalDate.of(REFERENCE_YEAR, 01, 01);

  static final long OFFSET = START_DATE.atStartOfDay(GMT).toInstant().toEpochMilli();
  static final EzDate today = new EzDate(valueOf(LocalDate.now().atStartOfDay(GMT).toInstant().toEpochMilli()));

  private static final int valueOf(long time) {
    return (time != 0) ? (int)((time- OFFSET)/DAY_IN_MILLISECONDS) : EVER_ID;
  }

  static final int defaultCacheSize = Integer.getInteger("com.easyrms.date.EzDate.cache.length", 2400).intValue();
  private static final EzDate[] cache;
  static final int minID;
  static {
    final int cacheSize = defaultCacheSize;
    cache = new EzDate[cacheSize];
    minID = Math.max(MIN_ID, Math.min(MAX_ID-((cacheSize/3)+1), today.id) - 2*cacheSize/3);
    for (int i = 0; i < cacheSize && i+minID < MAX_ID; i++) {
      cache[i] = new EzDate(minID+i);
    }
    cache[today.id-minID] = today;
  }

  private static final int[][] conversionCache = new int[8][];
  private static final int minYear;

  static {
    final int n = conversionCache.length;
    minYear = Year.now().getValue() - (n / 2);
    for (int i = 0; i < n; i++) {
      conversionCache[i] = new int[12];
      for (int j = 0; j < 12; j++) {
        conversionCache[i][j] = (int)(ChronoUnit.DAYS.between(START_DATE, LocalDate.of(minYear + i, j + 1, 1)) - 1);
      }
    }
  }

	public static final PeriodManager manager = new AbstractPeriodManager("Date", EzYear.manager) {

		public Period getPeriod(int id) {
      return EzDate.valueOf(id);
    }
		public Period getPeriod(EzDate day) {
      return day;
    }
	};

  public static final EzDate firstEzDate = new EzDate(MIN_ID);
  public static final EzDate lastEzDate = new EzDate(MAX_ID);
  public static final EzDate ever = new EzDate(EVER_ID);
  public static final EzDate never = new EzDate(NEVER_ID);
  public static final EzDate minDisplayedDate = getEzDate(Integer.getInteger("com.easyrms.date.EzDate.minDisplayedDate", 2005).intValue(), 1, 1);
  public static final EzDate maxDisplayedDate = getEzDate(Integer.getInteger("com.easyrms.date.EzDate.maxDisplayedDate", 2024).intValue(), 12, 31);

  public static final EzDate[] noEzDates = new EzDate[0];
  public static final EzArray<EzDate> emptyEzDates = new EzArray.NoEzArray<EzDate>();
  public static DateAccessor noDateAccessor = new SimpleDateAccessor(new Date(0));

  static {
    Singleton.add(EzDate.class);
  }

  static final long serialVersionUID = 1160673766137058769L;
}
package com.easyrms.date.util;


abstract class AbstractDateObject4DBuffer extends InternDateObject4DBuffer{
 
 	abstract protected Object[][][][] loadGetValues(int day, int horizon);
     
	@Override
  final protected Object[][][][] loadValues(int day, int horizon) {
    return loadGetValues(day, horizon);
  }
}

package com.easyrms.date.util;


abstract class InternDateObjectBuffer {

  public synchronized final Object getValue(int day) {
    return getScope(day, true).getValue(day);
  }

  public synchronized final Object[] getValue(int day, int horizon, Object[] result) {
    if (result.length !=horizon) throw new IllegalArgumentException("result length must be equal to horizon");
    internReserve(day, horizon);
    return getScope(day, true).getValue(day, horizon, result);
  }

  final private Scope getScope(int day, boolean isFirstTime) {
    if (firstScope == null) this.internReserve(day, 30);
    Scope current = firstScope;
    while (true) {
      if (current.start <= day && current.end > day) return current;
      if (current.next == null || current.next.start > day) {
        if (!isFirstTime) throw new IllegalStateException();
        this.internReserve(day, 30);
        return this.getScope(day, false);
      }
      current = current.next;
    }
  }

  public synchronized void reserve(int day, int horizon) {
    internReserve(day, horizon);
  }


  private final void internReserve(int workingStart, int workingHorizon) {
      final int workingEnd = workingStart + workingHorizon;
      if (firstScope == null) {
        firstScope = new Scope();
        firstScope.values = internLoadValues(workingStart, workingHorizon);
        firstScope.start = workingStart;
        firstScope.end = workingEnd;
      }
      else {
        firstScope.addWorkingSet(workingStart, workingEnd, workingHorizon);
      }
  }



  private Scope firstScope = null;

  abstract protected Object[] loadValues(int day, int horizon);

  private Object[] internLoadValues(int day, int horizon) {
    return null;//TODO
  }

  private class Scope {

    public Object getValue(int day) {
      return values[day - start];
    }

    public Object[] getValue( int day, int horizon, Object[] result) {
          System.arraycopy(values, day-start, result, 0, horizon);
          return result;
     }

    public void addWorkingSet(int workingStart, int workingEnd, int workingHorizon) {
      if (workingStart > end) {
        if (workingStart - end < 30) {
          extendTo(workingStart, workingEnd);
        }
        else if (next != null) {
          next.addWorkingSet(workingStart, workingEnd, workingHorizon);
        }
        else {
          next = new Scope();
          next.values = internLoadValues(workingStart, workingHorizon);
          next.start = workingStart;
          next.end = workingEnd;
        }
      }
      else {
        extendTo(workingStart, workingEnd);
      }
    }

    private void extendTo(int workingStart, int workingEnd) {
      if (workingStart < start) {
        if (workingEnd <= end) {
          if (workingEnd >= start || start - workingEnd <= 30) {
            final Object[] loadValues = internLoadValues(workingStart, start - workingStart);
            final Object[] newValues = new Object[values.length + loadValues.length];
            System.arraycopy(loadValues, 0, newValues, 0, loadValues.length);
            System.arraycopy(values, 0, newValues, loadValues.length, values.length);
            this.values = newValues;
            this.start = workingStart;
          }
          else {
            final Scope newScope = new Scope();
            newScope.start = workingStart;
            newScope.next = this;
            newScope.values = internLoadValues(workingStart, workingEnd - workingStart);
            newScope.end = workingEnd;
            firstScope = newScope;
          }
        }
        else {
          final Scope limit = getExtendsLimit(workingEnd);
          if (limit == null) {
            final Scope newScope = new Scope();
            newScope.start = workingStart;
            newScope.next = this;
            newScope.values = internLoadValues(workingStart, workingEnd - workingStart);
            newScope.end = workingEnd;
            firstScope = newScope;
          }
          else {
            final Object[] loadValues = internLoadValues(workingStart, limit.start - workingStart);
            final Object[] newValues = new Object[loadValues.length + limit.values.length];
            System.arraycopy(loadValues, 0, newValues, 0, loadValues.length);
            System.arraycopy(limit.values, 0, newValues, loadValues.length, limit.values.length);
            this.values = newValues;
            this.next = limit.next;
            this.end = limit.end;
            this.start = workingStart;
          }
        }
      }
      else if (workingEnd > end) {
        final Scope limit = getExtendsLimit(workingEnd);
        if (limit == null) {
          final Object[] loadValues = internLoadValues(end, workingEnd - end);
          final Object[] newValues = new Object[this.values.length + loadValues.length];
          System.arraycopy(this.values, 0, newValues, 0, this.values.length);
          System.arraycopy(loadValues, 0, newValues, this.values.length, loadValues.length);
          this.values = newValues;
          this.end = workingEnd;
        }
        else {
          final Object[] loadValues = internLoadValues(end, limit.start - end);
          final Object[] newValues = new Object[values.length + loadValues.length + limit.values.length];
          System.arraycopy(this.values, 0, newValues, 0, values.length);
          System.arraycopy(loadValues, 0, newValues, values.length, loadValues.length);
          System.arraycopy(limit.values, 0, newValues, values.length + loadValues.length, limit.values.length);
          this.values = newValues;
          this.next = limit.next;
          this.end = limit.end;
        }
      }
    }

    private Scope getExtendsLimit(int workingEnd) {
      if (start > workingEnd) return  (start - workingEnd <= 30) ? this : null;
      else if (end > workingEnd) return this;
      else return next == null ? null : next.getExtendsLimit(workingEnd);
    }

    private Scope next = null;
    private Object[] values = null;
    private int start = -1;
    private int end = -1;
  }
}

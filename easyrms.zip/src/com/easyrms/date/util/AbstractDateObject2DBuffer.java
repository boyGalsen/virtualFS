package com.easyrms.date.util;

import com.easyrms.util.*;


public abstract class AbstractDateObject2DBuffer extends InternDateObject4DBuffer{
  
  public final Object getValue(int i, int day) {
    return super.getValue(0, 0, i, day);
  }

  public final  <T> T[] getValue(int i, int day, int horizon, T[] result) {
    return super.getValue(0, 0, i, day, horizon, result);
  }
   
  public final <T> EzArray<T> getValueArray(int i, int day, int horizon, T[] result) {
    return new EzArray.SimpleEzArray<T>(false, (T[])super.getValue(0, 0, i, day, horizon, result));
  }

  protected abstract Object[][] loadGetValues(int day, int horizon);
     
	@Override
  final protected Object[][][][] loadValues(int day, int horizon) {
    return new Object[][][][] {
      {
        loadGetValues(day, horizon),
      },
    };
  }
}

package com.easyrms.date.util;


abstract class AbstractDateObject3DBuffer extends InternDateObject4DBuffer{
 
  public final Object getValue(int i, int j, int day) {
	  return super.getValue(0, i, j, day);
  }
  
  public final Object[] getValue(int i, int j, int day, int horizon, Object[] result) {
  	return super.getValue(0, i, j, day, horizon, result);
  }

  abstract protected Object[][][] loadGetValues(int day, int horizon);
     
  @Override
  final protected Object[][][][] loadValues(int day, int horizon) {
    return new Object[][][][] {loadGetValues(day, horizon)};
  }

}

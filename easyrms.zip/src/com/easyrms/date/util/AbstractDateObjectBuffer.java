package com.easyrms.date.util;

import com.easyrms.util.*;


abstract public class AbstractDateObjectBuffer extends InternDateObject4DBuffer{
  
  public final Object getValue(int day) {
      return super.getValue(0,0,0,day);
  }

  public final <T> T[] getValue(int day, int horizon, T[] result) {
    return super.getValue(0, 0, 0, day, horizon, result);
  }
  
  public final <T> EzArray<T> getValueArray(int day, int horizon, T[] result) {
    return new EzArray.SimpleEzArray<T>(false, (T[])super.getValue(0, 0, 0, day, horizon, result));
  }

  abstract protected Object[] loadGetValues(int day, int horizon);
     
	@Override
  final protected Object[][][][] loadValues(int day, int horizon) {
    return new Object[][][][] {{{loadGetValues(day, horizon)}}};
  }

}

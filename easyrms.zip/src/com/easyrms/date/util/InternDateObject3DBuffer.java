package com.easyrms.date.util;


abstract class InternDateObject3DBuffer {

  public synchronized final Object getValue(int i, int j, int day) {
    return getScope(day, true).getValue(i, j, day);
  }

  public synchronized final Object[] getValue(int i, int j, int day, int horizon, Object[] result) {
    if(result.length !=horizon) throw new IllegalArgumentException("result length must be equal to horizon");
    reserve(day, horizon);
    return getScope(day, true).getValue(i, j, day, horizon, result);
  }

  final private Scope getScope(int day, boolean isFirstTime) {
    if (firstScope == null) this.reserve(day, 30);
    Scope current = firstScope;
    while (true) {
      if (current.start <= day && current.end > day) return current;
      if (current.next == null || current.next.start > day) {
        if (!isFirstTime) throw new IllegalStateException();
        this.internReserve(day, 30);
        return this.getScope(day, false);
      }
      current = current.next;
    }
  }

  public synchronized void reserve(int day, int horizon) {
    internReserve(day, horizon);
  }


  private final void internReserve(int workingStart, int workingHorizon) {
      final int workingEnd = workingStart + workingHorizon;
      if (firstScope == null) {
        firstScope = new Scope();
        firstScope.values = internLoadValues(workingStart, workingHorizon);
        firstScope.start = workingStart;
        firstScope.end = workingEnd;
      }
      else {
        firstScope.addWorkingSet(workingStart, workingEnd, workingHorizon);
      }
  }



  private Scope firstScope = null;

  abstract protected Object[][][] loadValues(int day, int horizon);

  private Object[][][] internLoadValues(int day, int horizon) {
    return loadValues(day, horizon);
  }

  private class Scope {

    public Object getValue(int i, int j, int day) {
      return values[i][j][day - start];
    }
    
    public Object[] getValue(int i, int j, int day, int horizon, Object[] result) {
          System.arraycopy(values[i][j], day-start, result, 0, horizon);
          return result;
        }


    public void addWorkingSet(int workingStart, int workingEnd, int workingHorizon) {
      if (workingStart > end) {
        if (workingStart - end < 30) {
          extendTo(workingStart, workingEnd);
        }
        else if (next != null) {
          next.addWorkingSet(workingStart, workingEnd, workingHorizon);
        }
        else {
          next = new Scope();
          next.values = internLoadValues(workingStart, workingHorizon);
          next.start = workingStart;
          next.end = workingEnd;
        }
      }
      else {
        extendTo(workingStart, workingEnd);
      }
    }

    private void extendTo(int workingStart, int workingEnd) {
      if (workingStart < start) {
        if (workingEnd <= end) {
          if (workingEnd >= start || start - workingEnd <= 30) {
            final Object[][][] loadValues = internLoadValues(workingStart, start - workingStart);
            final Object[][][] newValues = new Object[loadValues.length][loadValues[0].length][values[0][0].length + loadValues[0][0].length];
            for (int i = 0; i < newValues.length; i++) {
              for (int j = 0; j < newValues[i].length; j++) {
                System.arraycopy(loadValues[i][j], 0, newValues[i][j], 0, loadValues[i][j].length);
                System.arraycopy(values[i][j], 0, newValues[i][j], loadValues[i][j].length, values[i][j].length);
              }
            }
            this.values = newValues;
            this.start = workingStart;
          }
          else {
            final Scope newScope = new Scope();
            newScope.start = workingStart;
            newScope.next = this;
            newScope.values = internLoadValues(workingStart, workingEnd - workingStart);
            newScope.end = workingEnd;
            firstScope = newScope;
          }
        }
        else {
          final Scope limit = getExtendsLimit(workingEnd);
          if (limit == null) {
            final Scope newScope = new Scope();
            newScope.start = workingStart;
            newScope.next = this;
            newScope.values = internLoadValues(workingStart, workingEnd - workingStart);
            newScope.end = workingEnd;
            firstScope = newScope;
          }
          else {
            final Object[][][] loadValues = internLoadValues(workingStart, limit.start - workingStart);
            final Object[][][] newValues = new Object[loadValues.length][loadValues[0].length][loadValues[0][0].length + limit.values[0][0].length];
            for (int i = 0; i < newValues.length; i++) {
              for (int j = 0; j < newValues[i].length; j++) {
                System.arraycopy(loadValues[i][j], 0, newValues[i][j], 0, loadValues[i][j].length);
                System.arraycopy(limit.values[i][j], 0, newValues[i][j], loadValues[i][j].length, limit.values[i][j].length);
              }
            }
            this.values = newValues;
            this.next = limit.next;
            this.end = limit.end;
            this.start = workingStart;
          }
        }
      }
      else if (workingEnd > end) {
        final Scope limit = getExtendsLimit(workingEnd);
        if (limit == null) {
          final Object[][][] loadValues = internLoadValues(end, workingEnd - end);
          final Object[][][] newValues = new Object[loadValues.length][loadValues[0].length][this.values[0][0].length + loadValues[0][0].length];
          for (int i = 0; i < newValues.length; i++) {
            for (int j = 0; j < newValues[i].length; j++) {
              System.arraycopy(this.values[i][j], 0, newValues[i][j], 0, this.values[i][j].length);
              System.arraycopy(loadValues[i][j], 0, newValues[i][j], this.values[i][j].length, loadValues[i][j].length);
            }
          }
          this.values = newValues;
          this.end = workingEnd;
        }
        else {
          final Object[][][] loadValues = internLoadValues(end, limit.start - end);
          final Object[][][] newValues =
            new Object[loadValues.length][loadValues[0].length][values[0][0].length + loadValues[0][0].length + limit.values[0][0].length];
          for (int i = 0; i < newValues.length; i++) {
            for (int j = 0; j < newValues[i].length; j++) {
              System.arraycopy(this.values[i][j], 0, newValues[i][j], 0, values[i][j].length);
              System.arraycopy(loadValues[i][j], 0, newValues[i][j], values[i][j].length, loadValues[i][j].length);
              System.arraycopy(limit.values[i][j], 0, newValues[i][j], values[i][j].length + loadValues[i][j].length, limit.values[i][j].length);
            }
          }
          this.values = newValues;
          this.next = limit.next;
          this.end = limit.end;
        }
      }
    }

    private Scope getExtendsLimit(int workingEnd) {
      if (start > workingEnd) return  (start - workingEnd <= 30) ? this : null;
      else if (end > workingEnd) return this;
      else return next == null ? null : next.getExtendsLimit(workingEnd);
    }

    private Scope next = null;
    private Object[][][] values = null;
    private int start = -1;
    private int end = -1;
  }
}

package com.easyrms.date;

import java.text.*;
import java.util.*;


public class EzMMDDYYYYDateFormat extends EzDateFormat {

  public EzMMDDYYYYDateFormat() {
    this(null);
  }
  public EzMMDDYYYYDateFormat(String separator) {
    super();
    this.separator = separator;
  }
  public EzMMDDYYYYDateFormat(int display) {
    this(display, null);
  }
  public EzMMDDYYYYDateFormat(int display, String separator) {
    super(display);
    this.separator = separator;
  }

  public static EzDate referenceParse(String obj) throws ParseException {
    synchronized (reference) {
      return reference.parse(obj);
    }
  }
  private static final EzMMDDYYYYDateFormat reference = new EzMMDDYYYYDateFormat() {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };

  @Override
  public final String formatSeparator() {
    return separator;
  }

  public EzDate parse(int source) {
    final int year;
    if (isYearDisplayed()) {
      year = source % 10000;
      source /= 10000;
    }
    else {
      year = EzDate.valueOf(new Date()).getYear();
    }
    final int day;
    if (isDayDisplayed()) {
      day = source % 100;
      source /= 100;
    }
    else {
      day = 1;
    }
    final int month;
    if (isMonthDisplayed()) {
      month = source;
    }
    else {
      month = 1;
    }
    return EzDate.getEzDate(year, month, day);
  }
  public EzDate parse(Integer source) {
    if (source == null) return null;
    return parse(source.intValue());
  }
  
  @Override
  protected StringBuffer format(
    EzDate date, StringBuffer toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    if (isMonthDisplayed) {
      toAppendTo.append(moyFigures[date.getMOY()]);
      if (isYearDisplayed && separator != null) {
        toAppendTo.append(separator);
      }
    }
    if (isDayDisplayed){
      toAppendTo.append(domFigures[date.getDOM()]);
      if ((isMonthDisplayed || isYearDisplayed) && separator != null){
        toAppendTo.append(separator);
      }
    }
    if (isYearDisplayed) {
      toAppendTo.append(date.getYear());
    }
    return toAppendTo;
  }

  @Override
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    final int start = status.getIndex();
    final int separatorLength = (separator == null) ? 0 : separator.length();
    try {
      if (separatorLength == 0) {
        int length = 0;
        int day = 1;
        int month = 1;
        int year = EzDate.valueOf(new Date()).getYear();
        
        if (isMonthDisplayed()) {
          month = Integer.parseInt(source.substring(start+length, start+length+2));
          length += 2;
          if (separatorLength > 0 && isYearDisplayed()) {
            if (!separator.equals(source.substring(start+length, start+length+separatorLength))) {
              status.setErrorIndex(start);
              throw new ParseException("Not An Easy Date", start);
            }
            length += separatorLength;
          }
        }
        if (isDayDisplayed()) {
          day = Integer.parseInt(source.substring(start+length, start+length+2));
          length += 2;
          if (separatorLength > 0 && (isMonthDisplayed() || isYearDisplayed())) {
            if (!separator.equals(source.substring(start+length, start+length+separatorLength))) {
              throw new ParseException("Not An Easy Date", start);
            }
            length += separatorLength;
          }
        }
        if (isYearDisplayed()) {
          year = Integer.parseInt(source.substring(start+length, start+length+4));
          length += 4;
        }
        status.setIndex(start+length);
        return EzDate.getEzDate(year, month, day);
      }
  
      int day = 1;
      int month = 1;
      int year = EzDate.valueOf(new Date()).getYear();
      
      final StringTokenizer tokenizer = new StringTokenizer(source, separator);
      
      if (isMonthDisplayed() && tokenizer.hasMoreTokens()) {
        month = Integer.parseInt(tokenizer.nextToken());
      }
      if (isDayDisplayed() && tokenizer.hasMoreTokens()) {
        day = Integer.parseInt(tokenizer.nextToken());
      }
      if (isYearDisplayed() && tokenizer.hasMoreTokens()) {
        year = Integer.parseInt(tokenizer.nextToken());
        if (year < 50) year = 2000 + year;
        if (year < 100) year = 1900 + year;
      }
      status.setIndex(source.length());
      return EzDate.getEzDate(year, month, day);
    }
    catch (Throwable ignored) {
    }
    status.setErrorIndex(start);
    throw new ParseException("Not An Easy Date", start);
  }

  private final String separator;
}
package com.easyrms.date;

import com.easyrms.util.*;
import com.easyrms.util.format.*;

import java.text.*;
import java.util.*;


public abstract class EzDateTranslationFormat extends Format {
  
  public static StringBuffer referenceFormat(EzDateFormat.DateFormatType dateFormatType, Object value, StringBuffer buff, FieldPosition pos) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceFormat(value, buff, pos);
      case STANDARD : return EzStandardDateTranslationFormat.referenceFormat(value, buff, pos);
      default : return EzLongDateTranslationFormat.referenceFormat(value, buff, pos);
    }
  }

  
  public static String referenceFormatExceptEver(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (value == null || EzDate.ever.equals(value)) {
      return "";
    }
    return referenceFormat(dateFormatType, value);
  }

  public static String referenceFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) {
      dateFormatType = EzDateFormat.DateFormatType.LONG;  
    }
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceFormat(value);
      default : return EzLongDateTranslationFormat.referenceFormat(value);
    }
  }
  
  public static String referenceDOMFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceDOMFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceDOMFormat(value);
      default : return EzLongDateTranslationFormat.referenceDOMFormat(value);
    }
  }
  
  public static String referenceMOYFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceMOYFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceMOYFormat(value);
      default : return EzLongDateTranslationFormat.referenceMOYFormat(value);
    }
  }
  
  public static String referenceYearFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceYearFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceYearFormat(value);
      default : return EzLongDateTranslationFormat.referenceYearFormat(value);
    }
  }
  
  public static StringBuffer referenceYearFormat(EzDateFormat.DateFormatType dateFormatType, Object value, StringBuffer buffer, FieldPosition position) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceYearFormat(value, buffer, position);
      case STANDARD : return EzStandardDateTranslationFormat.referenceYearFormat(value, buffer, position);
      default : return EzLongDateTranslationFormat.referenceYearFormat(value, buffer, position);
    }
  }

  
  public static String referenceMonthAndYearFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceMonthAndYearFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceMonthAndYearFormat(value);
      default : return EzLongDateTranslationFormat.referenceMonthAndYearFormat(value);
    }
  }
  
  public static StringBuffer referenceMonthAndYearFormat(EzDateFormat.DateFormatType dateFormatType, Object value, StringBuffer buffer, FieldPosition position) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceMonthAndYearFormat(value, buffer, position);
      case STANDARD : return EzStandardDateTranslationFormat.referenceMonthAndYearFormat(value, buffer, position);
      default : return EzLongDateTranslationFormat.referenceMonthAndYearFormat(value, buffer, position);
    }
  }
  
  public static String referenceDOWFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceDOWFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceDOWFormat(value);
      default : return EzLongDateTranslationFormat.referenceDOWFormat(value);
    }
  }
  
  public static String referenceWithDOWFormat(EzDateFormat.DateFormatType dateFormatType, Object value) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referenceWithDOWFormat(value);
      case STANDARD : return EzStandardDateTranslationFormat.referenceWithDOWFormat(value);
      default : return EzLongDateTranslationFormat.referenceWithDOWFormat(value);
    }
  }
  
  public static String referencePeriodAndYearDetailsFormat(EzDateFormat.DateFormatType dateFormatType, Period period) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referencePeriodAndYearDetailsFormat(period);
      case STANDARD : return EzStandardDateTranslationFormat.referencePeriodAndYearDetailsFormat(period);
      default : return EzLongDateTranslationFormat.referencePeriodAndYearDetailsFormat(period);
    }
  }
  
  public static String referencePeriodAndYearDetailsFormat(EzDateFormat.DateFormatType dateFormatType, PeriodManager manager, EzDate period) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referencePeriodAndYearDetailsFormat(manager, period);
      case STANDARD : return EzStandardDateTranslationFormat.referencePeriodAndYearDetailsFormat(manager, period);
      default : return EzLongDateTranslationFormat.referencePeriodAndYearDetailsFormat(manager, period);
    }
  }
  
  public static String referencePeriodAndYearFormat(EzDateFormat.DateFormatType dateFormatType, Period period) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referencePeriodAndYearFormat(period);
      case STANDARD : return EzStandardDateTranslationFormat.referencePeriodAndYearFormat(period);
      default : return EzLongDateTranslationFormat.referencePeriodAndYearFormat(period);
    }
  }
  
  public static StringBuffer referencePeriodAndYearFormat(EzDateFormat.DateFormatType dateFormatType, Period period, StringBuffer buffer, FieldPosition position) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return EzShortDateTranslationFormat.referencePeriodAndYearFormat(period, buffer, position);
      case STANDARD : return EzStandardDateTranslationFormat.referencePeriodAndYearFormat(period, buffer, position);
      default : return EzLongDateTranslationFormat.referencePeriodAndYearFormat(period, buffer, position);
    }
  }

  public static EzDateTranslationFormat referenceClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat() {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat() {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat() {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }  
  
  public static EzDateTranslationFormat referenceMonthAndYearClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(MONTH|YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(MONTH|YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(MONTH|YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }
  
  public static EzDateTranslationFormat referenceMonthClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(MONTH) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(MONTH) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(MONTH) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }
  
  public static EzDateTranslationFormat referenceDOMClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }
  
  public static EzDateTranslationFormat referenceWithoutYearClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(DAY | MONTH) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(DAY | MONTH) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(DAY | MONTH) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }
  
  public static EzDateTranslationFormat referenceWithDOWClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(DOW+DAY+MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(DOW+DAY+MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(DOW+DAY+MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }
  
  public static EzDateTranslationFormat referenceYearClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(YEAR) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }
  public static EzDateTranslationFormat referenceDOWClone(EzDateFormat.DateFormatType dateFormatType) {
    if (dateFormatType == null) dateFormatType = EzDateFormat.DateFormatType.LONG;  
    switch (dateFormatType) {
      case SHORT : return new EzShortDateTranslationFormat(DOW) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      case STANDARD : return new EzStandardDateTranslationFormat(DOW) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
      default : return new EzLongDateTranslationFormat(DOW) {
        
        @Override
        public void setDisplay(int display) {
         throw new UnsupportedOperationException();
        }
      };
    }
  }

  public static final int DOW = 1;
  public static final int DAY = 2;
  public static final int MONTH = 4;
  public static final int YEAR = 8;
  public static final int QUARTER = 16;
  
  protected static String formatIndex(EzDateTranslationFormat format, EzDateIndex index) {
    if (index == null) return null;
    if (index.getIndex() < 1) return format.format(index.getEzDate());
    return format.format(index.getEzDate())+" #"+IntegerCache.toString(index.getIndex());
  }
  
  protected static StringBuffer formatIndex(EzDateTranslationFormat format, EzDateIndex index, StringBuffer toAppendTo, FieldPosition pos) {
    if (index == null) return null;
    if (index.getIndex() < 1) return format.format(index.getEzDate(), toAppendTo, pos);
    return format.format(index.getEzDate(), toAppendTo, pos).append(" #").append(IntegerCache.toString(index.getIndex()));
  }
  
  public static StringBuffer timeFormatFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return timeFormat.get().format(obj, buff, pos); 
  }
  //  - h heure (12h) (1~12) (Number) 12
  //  - H hreure (24h) (0~23) (Number) 0
  //  - a marqueur am/pm (Text) PM
  //  - k heure du jour (1~24) (Number) 24
  //  - K heure en am/pm (0~11) (Number) 0
  private static final ThreadLocal<SimpleDateFormat> timeFormat = new ThreadLocal<SimpleDateFormat>() {

    @Override
    protected SimpleDateFormat initialValue() {
      return new SimpleDateFormat("kk:mm:ss");
    }
    
  };
  
  public static StringBuffer timeWithMilliSecondsFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return timeFormatWithMilliSeconds.get().format(obj, buff, pos); 
  }
  //  - h heure (12h) (1~12) (Number) 12
  //  - H hreure (24h) (0~23) (Number) 0
  //  - a marqueur am/pm (Text) PM
  //  - k heure du jour (1~24) (Number) 24
  //  - K heure en am/pm (0~11) (Number) 0
  
  private static final ThreadLocal<SimpleDateFormat> timeFormatWithMilliSeconds = new ThreadLocal<SimpleDateFormat>() {

    @Override
    protected SimpleDateFormat initialValue() {
      return new SimpleDateFormat("kk:mm:ss.SSS");
    }
    
  };


  protected EzDateTranslationFormat() {
    this.display = DAY | MONTH | YEAR;
  }
  protected EzDateTranslationFormat(int display) {
    this.display = display;
  }

  public void setDisplay(int display) {
    this.display = display;
  }
  public int getDisplay() {
    return display;
  }
  public boolean isDOWDisplayed() {
    return ((display & DOW) != 0);
  }
  public boolean isDayDisplayed() {
    return ((display & DAY) != 0);
  }
  public boolean isMonthDisplayed() {
    return ((display & MONTH) != 0);
  }
  public boolean isQuarterDisplayed() {
    return ((display & QUARTER) != 0);
  }
  public boolean isYearDisplayed() {
    return ((display & YEAR) != 0);
  }
  private int display;
  
  public StringBuffer format(Duration obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    if (obj.getHorizon() <= 0) return toAppendTo;
    if (obj.getHorizon() == 1) return format((Object)obj.getStart(), toAppendTo, pos);
    format((Object)obj.getStart(), toAppendTo, pos);
    toAppendTo.append(" - ");
    format((Object)obj.getLast(), toAppendTo, pos);
    return toAppendTo;
  }

  public StringBuffer format(EzDate obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuffer format(EzMonth obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj.getFirstDay(), toAppendTo, false, false, isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuffer format(EzQuarter obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    if (isQuarterDisplayed()) toAppendTo.append(formatQOY(obj.getQOY()));
    return toAppendTo;
  }
  
  public StringBuffer format(EzYear obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj.getFirstDay(), toAppendTo, false, false, false, isYearDisplayed());
    return toAppendTo;
  }

  public StringBuffer format(EzDOW obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    if (isDOWDisplayed()) toAppendTo.append(formatDOW(obj.getDOW()));
    return toAppendTo;
  }
  public StringBuffer format(Date obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(EzDate.valueOf(obj), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuffer format(Calendar obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(EzDate.valueOf(obj.getTime()), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  public StringBuffer format(Number obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    final int value = obj.intValue();
    if (EzDate.MIN_ID <= value && value <= EzDate.MAX_ID) format(EzDate.valueOf(value), toAppendTo, pos);
    return toAppendTo;
  }

  public StringBuffer format(Period obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    format(obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    return toAppendTo;
  }

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) {
    }
    else if (obj instanceof EzDateIndex) {
      formatIndex(this, (EzDateIndex)obj, toAppendTo, pos);
    }
    else if (obj instanceof EzDate) {
      format((EzDate)obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof Date) {
      format(EzDate.valueOf((Date)obj), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof EzDOW) {
      if (isDOWDisplayed()) toAppendTo.append(formatDOW(((EzDOW)obj).getDOW()));
    }
    else if (obj instanceof Calendar) {
      format(EzDate.valueOf(((Calendar)obj).getTime()), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (getDisplay() == YEAR && obj instanceof Period) {
      toAppendTo.append(formatYear(((Period)obj).getYear()));
    }
    else if (obj instanceof EzWeek) {
      toAppendTo.append(formatWOY(((EzWeek)obj).getWOY()));
      if (isYearDisplayed()) {
        toAppendTo.append(" ");
        toAppendTo.append(formatYear(((EzWeek)obj).getYear()));
      }
    }
    else if (obj instanceof EzMonth) {
      format(((EzMonth)obj).getFirstDay(), toAppendTo, false, false, isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof EzQuarter) {
      toAppendTo.append(formatQOY(((EzQuarter)obj).getQOY()));
      if (isYearDisplayed()) {
        toAppendTo.append(" ");
        toAppendTo.append(formatYear(((EzQuarter)obj).getYear()));
      }
    }
    else if (obj instanceof EzYear) {
      toAppendTo.append(formatYear(((EzYear)obj).getYear()));
      //format(((EzYear)obj).getFirstDay(), toAppendTo, false, false, false, isYearDisplayed());
    }
    else if (obj instanceof Number) {
    	final int value = ((Number)obj).intValue();
      if (EzDate.MIN_ID <= value && value <= EzDate.MAX_ID) format(EzDate.valueOf(value), toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
    }
    else if (obj instanceof Period) {
      final Period objAsPeriod = (Period)obj;
      final PeriodManager periodManager = objAsPeriod.getManager();
      if (periodManager == null) {
        final EzDate start = objAsPeriod.getFirstDay();
        final EzDate end = objAsPeriod.getLastDay();
        if (start == end) {
          format((EzDate)obj, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
        }
        else if (start.getEzMonth() == end.getEzMonth()) {
          format(start, toAppendTo, isDOWDisplayed(), isDayDisplayed(), false, false);
          toAppendTo.append("-");
          format(end, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
        }
        else if (start.getYear() == end.getYear()) {
          format(start, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), false);
          toAppendTo.append("-");
          format(end, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
        }
        else {
          format(start, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
          toAppendTo.append("-");
          format(end, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), isYearDisplayed());
        }
      }
      else {
        format(objAsPeriod, toAppendTo, isDOWDisplayed(), isDayDisplayed(), isMonthDisplayed(), false);
        if (isYearDisplayed()) {
          final PeriodManager years = periodManager.getYearManager();
          if (years != null) {
            toAppendTo.append(" ");
            toAppendTo.append(format(years.getPeriod(objAsPeriod.getFirstDay())));
          }
        }
      }
    }
    else if (obj instanceof Duration) {
      format((Duration)obj, toAppendTo, pos);
    }
    else if (obj instanceof String) {
      toAppendTo.append(obj);
    }
    else {
    }
    return toAppendTo;
  }

  public String formatDOWSeparator() {
    return " ";
  }
  public String formatSeparator() {
    return "/";
  }
  public String formatDOW(int dow) {
    throw new UnsupportedOperationException();
  }
  public String formatDOM(int dom) {
    return domFigures[dom];
  }
  public String formatWOY(int woy) {
    return woyFigures[woy];
  }
  public String formatQOY(int qoy) {
    return qoyFigures[qoy-EzQuarter.FIRST_QUARTER];
  }
  public String formatMOY(int moy) {
    throw new UnsupportedOperationException();
  }
  public String formatYear(int year) {
    return yyFigures[year % 100];
  }
  public String formatPeriod(Period period) {
    if (period == null) return "";
    return period.toString();
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
  @Override
  public boolean equals(Object object) {
    if (object == null || getClass() != object.getClass()) return false;
    final EzDateTranslationFormat other = (EzDateTranslationFormat)object;
    return (isDOWDisplayed() == other.isDOWDisplayed()
      && isDayDisplayed() == other.isDayDisplayed()
      && isMonthDisplayed() == other.isMonthDisplayed()
      && isYearDisplayed() == other.isYearDisplayed());
  }

  protected void format(
    EzDate date,
    StringBuffer toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed)
  {
    if (date != null && date.isStrictlyAfter(EzDate.ever) && date.isStrictlyBefore(EzDate.never)) {
      boolean isSeparatorNeeded = false;
      if (isDOWDisplayed) {
        toAppendTo.append(formatDOW(date.getDOW()));
        isSeparatorNeeded = true;
      }
      if (isDayDisplayed) {
        if (isSeparatorNeeded) toAppendTo.append(formatDOWSeparator());
        toAppendTo.append(formatDOM(date.getDOM()));
        isSeparatorNeeded = true;
      }
      if (isMonthDisplayed) {
        if (isSeparatorNeeded) toAppendTo.append(formatSeparator());
        toAppendTo.append(formatMOY(date.getMOY()));
        isSeparatorNeeded = true;
      }
      if (isYearDisplayed) {
        if (isSeparatorNeeded) toAppendTo.append(formatSeparator());
        toAppendTo.append(formatYear(date.getYear()));
      }
    }
  }
  protected void format(
    Period period,
    StringBuffer toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed)
  {
    toAppendTo.append(formatPeriod(period));
  }

  public final EzDate parse(String source) throws ParseException {
    return parse(source, new ParsePosition(0));
  }
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    int index = status.getIndex();
    if (source != null) {
      try {
        final String separator = formatSeparator();
        String buffer = source.substring(index);
        if (isDOWDisplayed()) {
          index = buffer.indexOf(separator);
          index += separator.length();
          buffer = buffer.substring(index);
        }
        final int dom;
        if (isDayDisplayed()) {
          index = buffer.indexOf(separator);
          dom = Integer.parseInt(buffer.substring(0, index));
          index += separator.length();
          buffer = buffer.substring(index);
        }
        else {
          dom = 1;
        }
        int moy = EzDate.JANUARY;
        if (isMonthDisplayed()) {
          index = buffer.indexOf(separator);
          final String month = buffer.substring(0, index);
          for (; moy < EzDate.DECEMBER; moy++) {
            if (month.equals(formatMOY(moy))) break;
          }
          index += separator.length();
          buffer = buffer.substring(index);
        }
        else {
          moy = 1;
        }
        if (buffer.length() > 4) buffer = buffer.substring(0, 4);
        final int year = Integer.parseInt(buffer);
        status.setIndex(index+4);
        return EzDate.getEzDate(year, moy, dom);
      }
      catch (Throwable ignored) {
      }
    }
    status.setErrorIndex(status.getIndex());
    throw new ParseException("Invalid Date", index);
  }
  @Override
  public final Object parseObject(String source, ParsePosition status) {
    final int start = status.getIndex();
    try {
      return parse(source, status);
    }
    catch (ParseException exception) {
      status.setErrorIndex(start);
    }
    return null;
  }

  
  public static String[] getEzRMSContextLabel(String[] values) {
    return getEzRMSContextLabel(values, true);
  }

  public static String[] getEzRMSContextLabel(String[] values, boolean all) {
    final int n = values.length;
    final String[] labels = new String[n];
    for (int i = 0; i < n ; i ++) {
      labels[i] = (all || values[i].startsWith("(") && values[i].endsWith(")")) ? TranslationUtil.getEzRMSContextLabelIntern(values[i]) : values[i]; 
    }
    return labels;
  }

  public static final String[] domFigures = {
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
    "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
    "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
    "30", "31",
  };

  public static final String[] woyFigures = {
    "W00", "W01", "W02", "W03", "W04", "W05", "W06", "W07", "W08", "W09",
    "W10", "W11", "W12", "W13", "W14", "W15", "W16", "W17", "W18", "W19",
    "W20", "W21", "W22", "W23", "W24", "W25", "W26", "W27", "W28", "W29",
    "W30", "W31", "W32", "W33", "W34", "W35", "W36", "W37", "W38", "W39",
    "W40", "W41", "W42", "W43", "W44", "W45", "W46", "W47", "W48", "W49",
    "W50", "W51", "W52", "W53",
   };

  public static final String[] qoyFigures = {
    "Q1", "Q2", "Q3", "Q4",
  }
  ;
  public static final String[] moyFigures = {
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12",
  };

  public static final String[] yyFigures = {
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
    "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
    "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
    "30", "31", "32", "33", "34", "35", "36", "37", "38", "39",
    "40", "41", "42", "43", "44", "45", "46", "47", "48", "49",
    "50", "51", "52", "53", "54", "55", "56", "57", "58", "59",
    "60", "61", "62", "63", "64", "65", "66", "67", "68", "69",
    "70", "71", "72", "73", "74", "75", "76", "77", "78", "79",
    "80", "81", "82", "83", "84", "85", "86", "87", "88","89",
    "90", "91", "92", "93", "94", "95", "96", "97", "98","99",
  };

  public static final String[] moyShortTexts = getEzRMSContextLabel(new String[] {
    null, "MONTH_SHORT_January__J", "MONTH_SHORT_February__F", "MONTH_SHORT_March__M", "MONTH_SHORT_April__A", "MONTH_SHORT_May__M", "MONTH_SHORT_June__J", "MONTH_SHORT_July__J", "MONTH_SHORT_August__A", "MONTH_SHORT_September__S", "MONTH_SHORT_October__O", "MONTH_SHORT_November__N", "MONTH_SHORT_December__D",
  });
  public static final String[] moyTexts = getEzRMSContextLabel(new String[] {
    null, "MONTH_MOY_January__Jan.", "MONTH_MOY_February__Feb.", "MONTH_MOY_March__Mar.", "MONTH_MOY_April__Apr.", "MONTH_MOY_May__May", "MONTH_MOY_June__Jun.", "MONTH_MOY_July__Jul.", "MONTH_MOY_August__Aug.", "MONTH_MOY_September__Sept.", "MONTH_MOY_October__Oct.", "MONTH_MOY_November__Nov.", "MONTH_MOY_December__Dec.",
  });
  public static final String[] threeLetterTexts = getEzRMSContextLabel(new String[] {
    null, "MONTH_THREE_January__Jan.", "MONTH_THREE_February__Feb.", "MONTH_THREE_March__Mar.", "MONTH_THREE_April__Apr.", "MONTH_THREE_May__May", "MONTH_THREE_June__Jun.", "MONTH_THREE_July__Jul.", "MONTH_THREE_August__Aug.", "MONTH_THREE_September__Sep.", "MONTH_THREE_October__Oct.", "MONTH_THREE_November__Nov.", "MONTH_THREE_December__Dec.",
  });
  public static final String[] moyLongTexts = getEzRMSContextLabel(new String[] {
    null, "MONTH_LONG_January__January", "MONTH_LONG_February__February", "MONTH_LONG_March__March", "MONTH_LONG_April__April", "MONTH_LONG_May__May", "MONTH_LONG_June__June", "MONTH_LONG_July__July", "MONTH_LONG_August__August", "MONTH_LONG_September__September", "MONTH_LONG_October__October", "MONTH_LONG_November__November", "MONTH_LONG_December__December",
  });

  public static final String[] dowShortTexts = getEzRMSContextLabel(new String[] {
    "DOW_SHORT_Monday__M", "DOW_SHORT_Tuesday__T", "DOW_SHORT_Wednesday__W", "DOW_SHORT_Thursday__T", "DOW_SHORT_Friday__F", "DOW_SHORT_Saturday__S", "DOW_SHORT_Sunday__S",
  });
  public static final String[] dowLetterTexts = getEzRMSContextLabel(new String[] {
    "DOW_MOY_Monday__Mo", "DOW_MOY_Tuesday__Tu", "DOW_MOY_Wednesday__We", "DOW_MOY_Thursday__Th", "DOW_MOY_Friday__Fr", "DOW_MOY_Saturday__Sa", "DOW_MOY_Sunday__Su",
  });
  public static final String[] dowThreeLetterTexts = getEzRMSContextLabel(new String[] {
    "DOW_MOY_Monday__Mo.", "DOW_MOY_Tuesday__Tu.", "DOW_MOY_Wednesday__We.", "DOW_MOY_Thursday__Th.", "DOW_MOY_Friday__Fr.", "DOW_MOY_Saturday__Sa.", "DOW_MOY_Sunday__Su.",
  });
  public static final String[] dowTexts = getEzRMSContextLabel(new String[] {
    "DOW_MOY_Monday__Mon.", "DOW_MOY_Tuesday__Tue.", "DOW_MOY_Wednesday__Wed.", "DOW_MOY_Thursday__Thu.", "DOW_MOY_Friday__Fri.", "DOW_MOY_Saturday__Sat.", "DOW_MOY_Sunday__Sun.",
  });
  public static final String[] dowLongTexts = getEzRMSContextLabel(new String[] {
    "DOW_LONG_Monday__Monday", "DOW_LONG_Tuesday__Tuesday", "DOW_LONG_Wednesday__Wednesday", "DOW_LONG_Thursday__Thursday", "DOW_LONG_Friday__Friday", "DOW_LONG_Saturday__Saturday", "DOW_LONG_Sunday__Sunday",
  });
}
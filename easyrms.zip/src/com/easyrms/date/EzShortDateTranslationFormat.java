package com.easyrms.date;

import com.easyrms.util.format.*;

import java.text.FieldPosition;

public class EzShortDateTranslationFormat extends EzDateTranslationFormat {
  
  public static String formatDurationTime(long timeDurationInMilliseconds) {
    final long timeDurationInSeconds = timeDurationInMilliseconds/1000;
    final long days = timeDurationInSeconds/(60*60*24);
    final long hours = (timeDurationInSeconds%(60*60*24))/(60*60);
    final long minutes = (timeDurationInSeconds%(60*60))/(60);
    final long seconds = (timeDurationInSeconds%(60));
    return ""
      +(days > 0 
         ? days+" "+daysShortLabel+" " 
         : "")
      +(hours > 0 
         ? hours+" "+hoursShortLabel+" " 
         : "")
      +(minutes > 0 
         ? minutes+" "+minutesShortLabel+" " 
         : "")
      +(seconds >= 0 
         ? seconds+" "+secondsShortLabel+" " 
         : "");
  }
  
  
  public static String formatElapsedTime(long timeElapsedInMilliseconds) {
    final long inMinutes = timeElapsedInMilliseconds/(60*1000);
    if (inMinutes < 1) {
      return nowLabel;
    }
    if (inMinutes < 60) {
      return inMinutes+" "+minutesShortLabel+" "+agoLabel;
    }
    final long inHours = timeElapsedInMilliseconds/(60*60*1000);
    if (inHours < 24) {
      return inHours+" "+hoursShortLabel+" "+agoLabel;
    }
    final long inDays = timeElapsedInMilliseconds/(24*60*60*1000);
    if (inDays < 7) {
      return inDays+" "+daysShortLabel+" "+agoLabel;
    }
    final int inWeeks = (int)(inDays / 7);
    if (inWeeks <= 5) {
      return inWeeks+" "+weeksShortLabel+" "+agoLabel;
    }
    final int inMonths = (int)(inDays / 30);
    if (inDays <= 365) {
      return inMonths+" "+monthsShortLabel+" "+agoLabel;
    }
    final int inYears = (int)(inDays / 365);
    return inYears+" "+yearsShortLabel+" "+agoLabel;  
  }
  
  public static String referenceYearFormat(Object obj) {
    return referenceYear.get().format(obj); 
  }
  
  public static StringBuffer referenceYearFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    return referenceYear.get().format(obj, buffer, position); 
  }


  public static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  public static StringBuffer referenceFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return reference.get().format(obj, buff, pos); 
  }
  public static EzShortDateTranslationFormat referenceClone() {
    return new EzShortDateTranslationFormat() {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  static String referencePeriodAndYearDetailsFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period); 
    }
    final EzShortDateTranslationFormat monthFormat = referenceMonth.get();
    final EzShortDateTranslationFormat domFormat = referenceDOM.get();
    return referencePeriodAndYearFormat(period)
      +" ("+domFormat.format(period.getFirstDay())+" "+monthFormat.format(period.getFirstDay())
      +"-"+domFormat.format(period.getLastDay())+" "+monthFormat.format(period.getLastDay())+")";
  }

  public static String referencePeriodAndYearDetailsFormat(PeriodManager manager, EzDate obj) {
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(obj); 
    }
    final Period period = manager.getPeriod(obj);
    final EzShortDateTranslationFormat monthFormat = referenceMonth.get();
    final EzShortDateTranslationFormat domFormat = referenceDOM.get();
    return referencePeriodAndYearFormat(manager, obj)
      +" ("+domFormat.format(period.getFirstDay())+" "+monthFormat.format(period.getFirstDay())
      +"-"+domFormat.format(period.getLastDay())+" "+monthFormat.format(period.getLastDay())+")";
  }
  
  
  public static String referenceDOMFormat(Object obj) {
    return referenceDOM.get().format(obj); 
  }
  static String referenceMOYFormat(Object obj) {
    if (obj instanceof EzDate) {
      return reference.get().formatMOY(((EzDate)obj).getMOY()); 
    }
    return "";
  }
  
  public static StringBuffer referenceDOMFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return referenceDOM.get().format(obj, buff, pos); 
  }
  
  private static final ThreadLocal<EzShortDateTranslationFormat> referenceDOM = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return new EzShortDateTranslationFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };
  

  
  private static final ThreadLocal<EzShortDateTranslationFormat> reference = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return referenceClone();
    }
    
  };
  
  public static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  static EzShortDateTranslationFormat referenceMonthClone() {
    return new EzShortDateTranslationFormat(MONTH) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzShortDateTranslationFormat> referenceMonth = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return referenceMonthClone();
    }
    
  };
  
  public static String referencePeriodAndYearFormat(PeriodManager manager, EzDate obj) {
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(obj); 
    }
    final PeriodManager yearManager = manager.getYearManager();
    final Period period = manager.getPeriod(obj);
    if (yearManager == null) {
      return period.toString()+" "+referenceYear.get().format(period.getFirstDay());
    }
    final Period year = yearManager.getPeriod(obj);
    if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
      return period.toString()+" "+referenceYear.get().format(year.getFirstDay().getEzMonth().getLastDay());
    }
    final EzShortDateTranslationFormat ref = referenceYear.get();
    return period.toString()+" "+ref.format(year.getFirstDay())+"-"+ref.format(year.getLastDay());
  }
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  
  public static StringBuffer referenceMonthAndYearFormat(Object obj, StringBuffer buffer, FieldPosition position) {
    return referenceMonthAndYear.get().format(obj, buffer, position); 
  }

  
  private static final ThreadLocal<EzShortDateTranslationFormat> referenceMonthAndYear = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return new EzShortDateTranslationFormat(MONTH+YEAR) {
          
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };

  private static final ThreadLocal<EzShortDateTranslationFormat> referenceYear = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return new EzShortDateTranslationFormat(YEAR) {
          
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };

  static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  static EzShortDateTranslationFormat referenceDOWClone() {
    return new EzShortDateTranslationFormat(DOW) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  static String referencePeriodAndYearFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(period); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      if (yearManager == null) {
        return reference.get().format(period)+" "+referenceYear.get().format(period.getFirstDay());
      }
      final Period year = yearManager.getPeriod(period.getFirstDay());
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay());
      }
      return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay())+"-"+referenceYear.get().format(year.getLastDay());
    }
  }
  
  static StringBuffer referencePeriodAndYearFormat(Period period, StringBuffer buffer, FieldPosition position) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(period, buffer, position); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(period, buffer, position); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      if (yearManager == null) {
        reference.get().format(period, buffer, position).append(" ");
        return referenceYear.get().format(period.getFirstDay(), buffer, position);
      }
      final Period year = yearManager.getPeriod(period.getFirstDay());
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        referenceWithoutYear.get().format(period, buffer, position).append(" ");
        return referenceYear.get().format(year.getFirstDay(), buffer, position);
      }
      referenceWithoutYear.get().format(period, buffer, position).append(" ");
      referenceYear.get().format(year.getFirstDay(), buffer, position).append("-");
      return referenceYear.get().format(year.getLastDay(), buffer, position);
    }
  }
  
  public static String referenceWithDOWFormat(Object obj) {
    return referenceWithDOW.get().format(obj); 
  }

  private static final ThreadLocal<EzShortDateTranslationFormat> referenceWithDOW = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return new EzShortDateTranslationFormat(DOW + DAY + MONTH + YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
    
  };
  
  
  private static final ThreadLocal<EzShortDateTranslationFormat> referenceDOW = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return referenceDOWClone();
    }
    
  };


  public EzShortDateTranslationFormat() {
    super();
  }
  public EzShortDateTranslationFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return "-";
  }
	@Override
  public String formatDOW(int dow) {
    return dowLetterTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyShortTexts[moy];
  }
  
  private static final ThreadLocal<EzShortDateTranslationFormat> referenceWithoutYear = new ThreadLocal<EzShortDateTranslationFormat>() {

    @Override
    protected EzShortDateTranslationFormat initialValue() {
      return referenceWithoutYearClone();
    }
    
  };
  
  public static EzShortDateTranslationFormat referenceWithoutYearClone() {
    return new EzShortDateTranslationFormat(DAY | MONTH) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final String nowLabel = TranslationUtil.getEzRMSContextLabelIntern("Now");
  private static final String secondsShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Seconds_Short__s");
  private static final String minutesShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Minutes_Short__m");
  private static final String hoursShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Hours_Short__h");
  private static final String daysShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Days_Short__d.");
  private static final String weeksShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Weeks_Short__w.");
  private static final String monthsShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Months_Short__m.");
  private static final String yearsShortLabel = TranslationUtil.getEzRMSContextLabelIntern("Years_Short__y."); 
  private static final String agoLabel = TranslationUtil.getEzRMSContextLabelIntern("Ago");
}
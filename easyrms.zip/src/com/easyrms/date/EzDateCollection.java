package com.easyrms.date;

import java.util.function.*;


public interface EzDateCollection { //extends EzArray<EzDate> {

  EzDate getFirstDay();
  EzDate getLastDay();
  
  @Deprecated
  int getDayCount();
  default int getCount() {
    return getDayCount();
  }
  @Deprecated
  EzDate getDay(int i);
  default EzDate get(int i) {
    return getDay(i);
  }
  
  default void forEach(Consumer<? super EzDate> function) {
    for (int i = 0, n = getCount(); i < n; i++) {
      function.accept(get(i));
    }
  }
  
  default boolean isEmpty() {
    return (getCount() == 0);
  }
  
  EzDateCollection noEzDates = new EzDateCollection() {
   
    public int getDayCount() { 
      return 0; 
    }
    public int getCount() { 
      return 0; 
    }
    public boolean isEmpty() {
      return true;
    }
    public EzDate getFirstDay() { 
      throw new UnsupportedOperationException(); 
    }
    public EzDate getLastDay() { 
      throw new UnsupportedOperationException(); 
    }
    public EzDate get(int i) { 
      throw new UnsupportedOperationException(); 
    }
    public EzDate getDay(int i) { 
      throw new UnsupportedOperationException(); 
    }
  };
}

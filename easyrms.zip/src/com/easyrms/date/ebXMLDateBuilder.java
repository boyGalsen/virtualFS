package com.easyrms.date;

import java.util.*;

import com.easyrms.builder.SimpleDateBuilder;


public class ebXMLDateBuilder extends SimpleDateBuilder {

  public static ebXMLDateBuilder referenceWithTimeClone() {
    return new ebXMLDateBuilder(true, false);
  }
  public static Date referenceWithTimeParse(String obj) throws com.easyrms.builder.ParseException {
    synchronized (referenceWithTime) {
      return referenceWithTime.parse(obj);
    }
  }
  
  public static String referenceWithTimeFormat(DateAccessor obj) {
    synchronized (referenceWithTime) {
      return referenceWithTime.format(obj == null ? null : obj.toDate()); 
    }
  }
  public static String referenceWithTimeFormat(Object obj) {
    synchronized (referenceWithTime) {
      return referenceWithTime.format(checkObject(obj)); 
    }
  }
  public static StringBuilder referenceWithTimeFormat(Object obj, StringBuilder buff) {
    synchronized (referenceWithTime) {
      return referenceWithTime.format(checkObject(obj), buff); 
    }
  }
  
  public static Object checkObject(Object object) {
    if (object instanceof DateAccessor) {
      return ((DateAccessor)object).toDate();
    }
    return object;
  }

  static final ebXMLDateBuilder referenceWithTime = new ebXMLDateBuilder(true, false);
  static final ebXMLDateBuilder referenceWithoutTime = new ebXMLDateBuilder(false, false);
  
  public static ebXMLDateBuilder referenceClone() {
    return referenceWithTimeClone();
  }
  public static Date referenceParse(String obj) throws com.easyrms.builder.ParseException {
    return referenceWithTimeParse(obj);
  }

  public static String referenceWithTimeInGMTFormat(DateAccessor obj) {
    synchronized (referenceWithTimeInGMT) {
      return referenceWithTimeInGMT.format(obj == null ? null : obj.toDate()); 
    }
  }
  public static String referenceWithTimeInGMTFormat(Object obj) {
    synchronized (referenceWithTimeInGMT) {
      return referenceWithTimeInGMT.format(checkObject(obj)); 
    }
  }
  public static StringBuilder referenceWithTimeInGMTFormat(Object obj, StringBuilder buff) {
    synchronized (referenceWithTimeInGMT) {
      return referenceWithTimeInGMT.format(checkObject(obj), buff); 
    }
  }
  private static final ebXMLDateBuilder referenceWithTimeInGMT = new ebXMLDateBuilder(true, true);
  
  protected ebXMLDateBuilder(boolean withTime, boolean withGMT) {
    super(withTime ? "yyyy-MM-dd'T'HH:mm:ss.SSS" : "yyyy-MM-dd");
    if (withGMT) super.setTimeZone(TimeZone.getTimeZone("GMT"));
  }
  
}
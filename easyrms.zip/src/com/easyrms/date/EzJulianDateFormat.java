package com.easyrms.date;

import java.text.*;


public class EzJulianDateFormat extends EzDateFormat {

  public static EzJulianDateFormat referenceClone() {
    return new EzJulianDateFormat() {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }

  public EzJulianDateFormat() {
    super();
  }
  public EzJulianDateFormat(int display) {
    super(display);
  }

  @Override
  protected StringBuffer format(
    EzDate date, StringBuffer toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    return toAppendTo.append(date.getDay());
  }

  @Override
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    final int start = status.getIndex();
    int end = start+1;
    try {
      while (end < source.length() && Character.isDigit(source.charAt(end))) end++;
      final EzDate date = EzDate.valueOf(Integer.parseInt(source.substring(start, end)));
      status.setIndex(end);
      return date;
    }
    catch (Throwable ignored) {
    }
    status.setErrorIndex(start);
    throw new ParseException("Not An Easy Date", start);
  }
}
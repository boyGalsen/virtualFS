package com.easyrms.date;

import java.text.FieldPosition;

public class EzStandardDateFormat extends EzDateFormat {

  public static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  public static String referenceFormatMOY(int obj) {
    return reference.get().formatMOY(obj); 
  }
  public static String referenceFormatDOW(int obj) {
    return reference.get().formatDOW(obj); 
  }
  public static String referenceFormatQOY(int obj) {
    return reference.get().formatQOY(obj); 
  }
  public static String referenceFormatWOY(int obj) {
    return reference.get().formatWOY(obj); 
  }
  public static EzStandardDateFormat referenceClone() {
    return new EzStandardDateFormat() {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    }; 
  }
  
  private static final ThreadLocal<EzStandardDateFormat> reference = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return referenceClone();
    }
  };
  
  public static String referenceWeekFormat(Object obj) {
    return referenceWeek.get().format(obj); 
  }
  
  private static final ThreadLocal<EzStandardDateFormat> referenceWeek = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return new EzStandardDateFormat() {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  
  private static final ThreadLocal<EzStandardDateFormat> referenceMonth = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return new EzStandardDateFormat(MONTH) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceYearFormat(Object obj) {
    return referenceYear.get().format(obj); 
  }
  public static EzStandardDateFormat referenceYearClone() {
   return new EzStandardDateFormat(YEAR) {
      
    	@Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzStandardDateFormat> referenceYear = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return referenceYearClone();
    }
  };
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  public static EzStandardDateFormat referenceMonthAndYearClone() {
    return new EzStandardDateFormat(MONTH + YEAR) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzStandardDateFormat> referenceMonthAndYear = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return referenceMonthAndYearClone();
    }
  };
  
  
  public static String referenceWithDOWFormat(Object obj) {
    return referenceWithDOW.get().format(obj); 
  }
  private static final ThreadLocal<EzStandardDateFormat> referenceWithDOW = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return new EzStandardDateFormat(DOW + DAY + MONTH + YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };

  public static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  
  private static final ThreadLocal<EzStandardDateFormat> referenceDOW = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return new EzStandardDateFormat(DOW) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceDOMFormat(Object obj) {
    return referenceDOM.get().format(obj);
  }
  public static StringBuffer referenceDOMFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return referenceDOM.get().format(obj, buff, pos); 
  }
  
  private static final ThreadLocal<EzStandardDateFormat> referenceDOM = new ThreadLocal<EzStandardDateFormat>() {

    @Override
    protected EzStandardDateFormat initialValue() {
      return new EzStandardDateFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };

  public EzStandardDateFormat() {
    super();
  }
  public EzStandardDateFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return " ";
  }
	@Override
  public String formatDOW(int dow) {
    return dowTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyTexts[moy];
  }
}
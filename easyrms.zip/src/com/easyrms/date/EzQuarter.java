package com.easyrms.date;

import java.util.*;


public final class EzQuarter extends AbstractPeriod {

  public static EzQuarter valueOf(int id) {
    final int ID = id-minID;
    return (ID >= 0 && ID < cache.length) 
      ? cache[ID]
      : new EzQuarter(id);
  }

  public static EzQuarter valueOf(Date date) {
    return valueOf(EzDate.valueOf(date));
  }
  public static EzQuarter valueOf(EzDate day) {
    return getEzQuarter(day.getYear(), (day.getMOY()-EzDate.JANUARY)/3+FIRST_QUARTER);
  }
  public static EzQuarter getEzQuarter(int year, int quarter) {
    return EzQuarter.valueOf(quarter + 4*(year-EzDate.REFERENCE_YEAR));
  }

  private EzQuarter(int id) {
    super(id);
    if (id <= 0 || id > (EzDate.MAX_YEAR+1-EzDate.REFERENCE_YEAR)*4) {
      throw new IllegalArgumentException("id="+id);
    }
    final int year = getYear();
    final int qoy = getQOY(); 
    firstDay = EzDate.getEzDate(year, EzDate.JANUARY+(qoy-EzQuarter.FIRST_QUARTER)*3, 1);
    lastDay = firstDay.getEzMonth().add(2).getLastDay();
  }

  public int getQuarter() {
    return id;
  }
  public int getQOY() {
    return FIRST_QUARTER + ((id-FIRST_QUARTER)%4);
  }
	@Override
  public int getYear() {
    return EzDate.REFERENCE_YEAR+(id-FIRST_QUARTER)/4;
  }
  public int getDIQ() {
    return lastDay.getDay()-firstDay.getDay()+1;
  }
  
  public EzDate getFirstDay() {
    return firstDay;
  }
	@Override
  public EzDate getLastDay() {
    return lastDay;
  }

  public int getDayCount() {
    return getDIQ();
  }

	public EzQuarter getPreviousYearEzQuarter(int nbOfYears) {
	 return valueOf(id-nbOfYears*4);
  }
	@Override
  public Period getPreviousYear(int nbOfYears) {
	  return getPreviousYearEzQuarter(nbOfYears);
  }

  public EzQuarter add(int quarters) {
    return (quarters == 0) ? this : valueOf(id+quarters);
  }

  public PeriodManager getManager() {
    return manager;
  }

	@Override
  public String toString() {
    return EzStandardDateFormat.referenceFormatQOY(getQOY());
  }

  public static final int FIRST_QUARTER  = 1;
  public static final int SECOND_QUARTER = 2;
  public static final int THIRD_QUARTER =  3;
  public static final int FOURTH_QUARTER = 4;

  public static EzQuarter max(EzQuarter a, EzQuarter b) {
    return (a == null || (b != null && a.id < b.id)) ? b : a;
  }
  public static EzQuarter min(EzQuarter a, EzQuarter b) {
    return (a == null || (b != null && a.id > b.id)) ? b : a;
  }

  public boolean isStrictlyBefore(EzQuarter other) {
    return (id < other.id);
  }
  public boolean isStrictlyBefore(int other) {
    return (id < other);
  }
  public boolean isBefore(EzQuarter other) {
    return (id <= other.id);
  }
  public boolean isBefore(int other) {
    return (id <= other);
  }
  public boolean isAfter(EzQuarter other) {
    return (id >= other.id);
  }
  public boolean isAfter(int other) {
    return (id >= other);
  }
  public boolean isStrictlyAfter(EzQuarter other) {
    return (id > other.id);
  }
  public boolean isStrictlyAfter(int other) {
    return (id > other);
  }

  public static final PeriodManager manager = new AbstractPeriodManager("Quarter", EzYear.manager, EzMonth.manager) {

    public Period getPeriod(int id) { 
      return EzQuarter.valueOf(id); 
    }
    public Period getPeriod(EzDate day) { 
      return EzQuarter.valueOf(day); 
    }
  };

  private final EzDate firstDay;
  private final EzDate lastDay;
  
  private static final EzQuarter[] cache;
  static final int minID;
  static {
    final int cacheSize = 4*(EzDate.defaultCacheSize/365);
    cache = new EzQuarter[cacheSize];
    minID = 4*(EzDate.valueOf(EzDate.minID).getYear()-EzDate.REFERENCE_YEAR);
    for (int i = 0, n = cache.length; i < n; i++) {
      cache[i] = new EzQuarter(minID+i);
    }
  }

  public Object readResolve() {
    return valueOf(id);
  }
  
	public static final EzQuarter[] noEzQuarters = new EzQuarter[0];
}
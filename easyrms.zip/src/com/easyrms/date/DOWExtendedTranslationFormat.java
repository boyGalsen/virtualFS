package com.easyrms.date;

import java.text.FieldPosition;

import com.easyrms.util.IntegerCache;
import com.easyrms.util.format.AbstractFormat;

public class DOWExtendedTranslationFormat extends AbstractFormat {
  
  public static String referenceShortFormat(Object obj) {
    synchronized (referenceShort) {
      return referenceShort.format(obj);
    }
  }
  public static String referenceShortFormat(int obj) {
    synchronized (referenceShort) {
      return referenceShort.format(obj);
    }
  }
  private static final DOWExtendedTranslationFormat referenceShort = new DOWExtendedTranslationFormat(EzDateTranslationFormat.dowShortTexts);

  public static String referenceLongFormat(Object obj) {
    synchronized (referenceLong) {
      return referenceLong.format(obj);
    }
  }
  public static String referenceLongFormat(int obj) {
    synchronized (referenceLong) {
      return referenceLong.format(obj);
    }
  }
  private static final DOWExtendedTranslationFormat referenceLong = new DOWExtendedTranslationFormat(EzDateTranslationFormat.dowLongTexts);
  
  public static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj);
    }
  }
  public static String referenceFormat(int obj) {
    synchronized (reference) {
      return reference.format(obj);
    }
  }
  public static final DOWExtendedTranslationFormat referenceClone()  {
    return new DOWExtendedTranslationFormat(EzDateTranslationFormat.dowTexts); 
  }
  private static final DOWExtendedTranslationFormat reference = referenceClone();
  
  private DOWExtendedTranslationFormat(String[] labels) {
    this.labels = labels;
  }

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj == null) return toAppendTo;
    if (obj instanceof Number) {
      final int i = ((Number)obj).intValue();
      if (i <= 0) return toAppendTo;
      return toAppendTo.append(labels[i-1]);
    }
    return null;
  }
  
  public String format(int i) {
    return format(IntegerCache.get(i));
  }
  
  private final String[] labels;
}

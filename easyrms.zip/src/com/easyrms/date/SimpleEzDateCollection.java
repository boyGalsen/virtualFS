package com.easyrms.date;

import com.easyrms.util.*;

import java.util.*;

public class SimpleEzDateCollection implements EzDateCollection {

  public SimpleEzDateCollection(boolean isSorted) {
    this.isSorted = isSorted;
    this.periods = new ArrayList<EzDate>();
  }
  public SimpleEzDateCollection(EzDateCollection periods, boolean isSorted) {
    this.isSorted = isSorted;
    if (periods != null) {
      final int n = periods.getCount();
      this.periods = new ArrayList<EzDate>(n);
      for (int i = 0; i < n; i++) {
        add(periods.get(i));
      }
    }
    else {
      this.periods = new ArrayList<EzDate>();
    }
  }
  public SimpleEzDateCollection(EzDate[] periods, boolean isSortAllowed) {
    this.isSorted = isSortAllowed;
    if (periods != null) {
      final int n = periods.length;
      this.periods = new ArrayList<EzDate>(n);
      for (int i = 0; i < n; i++) {
        add(periods[i]);
      }
    }
    else {
      this.periods = new ArrayList<EzDate>();
    }
  }
  public SimpleEzDateCollection(boolean isCopyNeed, EzArray<? extends EzDate> periods, boolean isSortAllowed) {
    this.isSorted = isSortAllowed;
    if (periods != null) {
      this.periods = new EzArrayList<EzDate>(periods);
    }
    else {
      this.periods = new ArrayList<EzDate>();
    }
  }
  
  //Why synchronized
  public synchronized void add(EzDate period) {
    this.periods.add(period);
    if (min == null || min.isAfter(period)) {
      min = period;
    }
    else if (isSorted) {
      isSortNeeded = true;
    }
    if (max == null || max.getPeriod() <= period.getPeriod()) {
      max = period;
    }
    else if (isSorted) {
      isSortNeeded = true;
    }
  }
  
  public synchronized EzDate getFirstDay() {
    return min;
  }
  
  public synchronized  EzDate getLastDay() {
    return max;
  }
  
  public synchronized EzDate getDay(int i) {
    if (isSortNeeded) {
      Collections.sort(this.periods);
      isSortNeeded = false;
    }
    return periods.get(i);
  }

  public synchronized int getDayCount() {
    return periods.size();
  }

  public static Duration getDuration(EzDateCollection collection) {
    EzDate start = null;
    EzDate end = null;
    synchronized (collection) {
      for (int i = 0, n = collection.getCount(); i < n; i++) {
        final EzDate period = collection.get(i);
        final int periodID = period.getPeriod();
        if (start == null || start.getPeriod() > periodID) {
          start = period;
        }
        if (end == null || end.getPeriod() < periodID) {
          end = period;
        }
      }
    }
    return SimpleDuration.findDuration(start, end);
  }
  
  public static EzDateCollection filter(EzDateCollection days, Bounds bounds) {
    return filter(days, bounds.getMax(), bounds.getMax());
  }
  public static EzDateCollection filter(EzDateCollection days, EzDate min, EzDate max) {
    final int minID = (min == null) ? EzDate.ever.getDay() : min.getDay();
    final int maxID = (max == null) ? EzDate.never.getDay() : max.getDay();
    return filter(days, minID, maxID);
  }
  public static EzDateCollection filter(EzDateCollection days, int minID, int maxID) {
    SimpleEzDateCollection filtered = null;
    synchronized (days) {
      EzDate end = null;
      for (int i = 0, n = days.getCount(); i < n; i++) {
        final EzDate day = days.get(i);
        final int id = day.getDay();
        if (id < minID || id > maxID) {
          if (filtered == null) {
            filtered = new SimpleEzDateCollection(true);
            for (int j = 0; j < i; j++) {
              filtered.add(days.get(j));
            }
          }
        }
        else {
          //TODO: why ?
          if (end == null || end.getDay() <= day.getDay()) {
            end = day;
          }
          else if (filtered == null) {
            filtered = new SimpleEzDateCollection(true);
            for (int j = 0; j < i; j++) {
              filtered.add(days.get(j));
            }
          }
          if (filtered != null) {
            filtered.add(day);
          }
        }      
      }
    }
    return (filtered == null) ? days : filtered;
  }
  
  private EzDate min = null;
  private EzDate max = null;
  private boolean isSortNeeded;
  private final boolean isSorted;
  private final List<EzDate> periods;
}

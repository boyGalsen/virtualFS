package com.easyrms.date;

import java.text.*;
import java.util.*;


public class ebXMLDateFormat extends Format {

  public static String referenceWithTime0Format(Object obj) {
    synchronized (referenceWithTime0) {
      return referenceWithTime0.format(obj);
    }
  }
  
  public static DateAccessor referenceWithTime0Parse(String obj) throws ParseException {
    synchronized (referenceWithTime0) {
      return new SimpleDateAccessor(referenceWithTime0.parse(obj));
    }
  }
  
  private static final ebXMLDateFormat referenceWithTime0 = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ss", false);
  
  public static String referenceWithTimeFormat(Object obj) {
    synchronized (referenceWithTime) {
      return referenceWithTime.format(obj);
    }
  }
  public static DateAccessor referenceWithTimeParse(String obj) throws ParseException {
    synchronized (referenceWithTime) {
      return new SimpleDateAccessor(referenceWithTime.parse(obj));
    }
  }
  public static DateAccessor referenceWithTimeStampParse(String obj) throws ParseException {
    synchronized (referenceWithTimeStamp) {
      return new SimpleDateAccessor(referenceWithTimeStamp.parse(obj));
    }
  }
  public static ebXMLDateFormat referenceWithTimeClone() {
    return new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", false);
  }

  private static final ebXMLDateFormat referenceWithTime = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", false);
  private static final ebXMLDateFormat referenceWithTimeStamp = new ebXMLDateFormat("yyyy-MM-dd HH:mm:ss", false);
  public static String referenceWithoutTimeFormat(Object obj) {
    synchronized (referenceWithoutTime) {
      return referenceWithoutTime.format(obj);
    }
  }
  private static final ebXMLDateFormat referenceWithoutTime = new ebXMLDateFormat("yyyy-MM-dd", false);
  
  public static String referenceFormat(Object obj) {
    try {
      return referenceWithTimeFormat(obj);
    }
    catch (Throwable t) {
      return "???";
    }
  }
  public static DateAccessor referenceParse(String obj) throws ParseException {
    return referenceWithTimeParse(obj);
  }
  
  public static DateAccessor referenceTimeStampParse(String obj) throws ParseException {
    return referenceWithTimeStampParse(obj);
  }
  
  public static String referenceWithoutTimeInGMTFormat(Object obj) {
    synchronized (referenceWithoutTimeInGMT) {
      return referenceWithoutTimeInGMT.format(obj);
    }
  }
  public static DateAccessor referenceWithoutTimeInGMTParse(String obj) throws ParseException {
    synchronized (referenceWithoutTimeInGMT) {
      return new SimpleDateAccessor(referenceWithoutTimeInGMT.parse(obj));
    }
  }
  public static ebXMLDateFormat referenceWithoutTimeInGMTClone() {
    return new ebXMLDateFormat("yyyy-MM-dd", true);
  }
  private static final ebXMLDateFormat referenceWithoutTimeInGMT = new ebXMLDateFormat("yyyy-MM-dd", true);
  
  public static String referenceWithTimeInGMT0Format(Object obj) {
    synchronized (referenceWithTimeInGMT0) {
      return referenceWithTimeInGMT0.format(obj);
    }
  }
  private static final ebXMLDateFormat referenceWithTimeInGMT0 = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ss", true);
  
  public static String referenceWithTimeInGMTFormat(Object obj) {
    synchronized (referenceWithTimeInGMT) {
      return referenceWithTimeInGMT.format(obj);
    }
  }
  private static final ebXMLDateFormat referenceWithTimeInGMT = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", true);
  
  /**
   * 2011-10-27T11:24:39+0200
   */
  public static String referenceWithTimeAndZoneWithoutSepFormat(Object obj) {
    synchronized (referenceWithTimeZ) {
      return referenceWithTimeZ.format(obj);
    }
  }
  private static final ebXMLDateFormat referenceWithTimeZ = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", false);
  
  /**
   * 2011-10-27T11:24:39+02:00
   */
  public static String referenceWithTimeAndZoneWithSepFormat(Object obj) {
    synchronized (referenceWithTimez) {
      return referenceWithTimez.format(obj);
    }
  }
  private static final ebXMLDateFormat referenceWithTimez = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ssz", false);

  /**
   * 2011-10-27T11:24:39:1234567+02:00
   */
  public static String referenceWithMilliAndWithTimeAndZoneWithSepFormat(Object obj) {
    synchronized (referenceWithMilliAndTimez) {
      return referenceWithMilliAndTimez.format(obj);
    }
  }
  private static final ebXMLDateFormat referenceWithMilliAndTimez = new ebXMLDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSXXX", false);
  
  public ebXMLDateFormat(String format, boolean withGMT) {
    this.format = new SimpleDateFormat(format);
    if (withGMT) {
      this.format.setTimeZone(TimeZone.getTimeZone("GMT"));
    }
  }

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    return (obj instanceof DateAccessor)
      ? format.format(((DateAccessor)obj).toDate(), toAppendTo, pos)
      : format.format(obj, toAppendTo, pos);
  }
  
  public Date parse(String source) throws ParseException {
    return format.parse(source);
  }
  
  @Override
  public Date parseObject(String source, ParsePosition pos) {
    return format.parse(source, pos);
  }


  private final SimpleDateFormat format;
}
package com.easyrms.date;

import com.easyrms.util.IntegerCache;
import com.easyrms.util.comparator.*;

public class EzLongDateTranslationBuilder extends EzDateTranslationBuilder {
  
  
  static String referencePeriodAndYearDetailsFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      synchronized (referenceMonthAndYear) {
        return referenceMonthAndYear.format(period); 
      }
    }
    return referencePeriodAndYearFormat(period)
      +" ("+EzStandardDateTranslationFormat.referenceDOMFormat(period.getFirstDay())+" "+EzStandardDateTranslationFormat.referenceMonthFormat(period.getFirstDay())
      +"-"+EzStandardDateTranslationFormat.referenceDOMFormat(period.getLastDay())+" "+EzStandardDateTranslationFormat.referenceMonthFormat(period.getLastDay())+")";
  }
  
  static String referencePeriodAndYearDetailsFormat(PeriodManager manager, EzDate obj) {
    return referencePeriodAndYearDetailsFormat(ObjectComparator.NVL(manager, EzMonth.manager).getPeriod(obj));
  }
  
  static String referencePeriodAndYearFormat(Period period) {
    final PeriodManager manager = period.getManager();
    if (manager == null || EzMonth.manager.equals(manager)) {
      synchronized (referenceMonthAndYear) {
        return referenceMonthAndYear.format(period); 
      }
    }
    else if (EzYear.manager.equals(manager)) {
      synchronized (referenceMonthAndYear) {
        return referenceYear.format(period); 
      }
    }
    else {
      synchronized (referenceYear) {
        final PeriodManager yearManager = manager.getYearManager();
        if (yearManager == null) {
          return reference.format(period)+" "+referenceYear.format(period.getFirstDay());
        }
        final Period year = yearManager.getPeriod(period.getFirstDay());
        if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
          return referenceWithoutYear.format(period)+" "+referenceYear.format(year.getFirstDay());
        }
        return referenceWithoutYear.format(period)+" "+referenceYear.format(year.getFirstDay())+"-"+referenceYear.format(year.getLastDay());
      }
    }
  }
  
  static EzLongDateTranslationBuilder referenceWithoutYearClone() {
    return new EzLongDateTranslationBuilder(DAY | MONTH) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  private static final EzLongDateTranslationBuilder referenceWithoutYear = referenceWithoutYearClone();
  
  
  static String referencePeriodAndYearFormat(PeriodManager manager, EzDate obj) {
    return referencePeriodAndYearFormat(ObjectComparator.NVL(manager, EzMonth.manager).getPeriod(obj));
  }
	
  static String referenceUnBreakFormat(Object obj) {
    synchronized (referenceUnBreak) {
      return referenceUnBreak.format(obj); 
    }
  }
	private static final EzLongDateTranslationBuilder referenceUnBreak = new EzLongDateTranslationBuilder() {
    
	  @Override
		public void setDisplay(int display) {
			throw new UnsupportedOperationException();
		}
    
	  @Override
		public String formatSeparator() {
			return "&nbsp;";
		}
	};

  static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj); 
    }
  }
  static StringBuilder referenceFormat(Object obj, StringBuilder buff) {
    synchronized (reference) {
      return reference.format(obj, buff); 
    }
  }
  private static final EzLongDateTranslationBuilder reference = new EzLongDateTranslationBuilder() {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceWeekFormat(Object obj) {
    synchronized (referenceWeek) {
      return referenceWeek.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceWeek = new EzLongDateTranslationBuilder() {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceMonthFormat(Object obj) {
    synchronized (referenceMonth) {
      return referenceMonth.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceMonth = new EzLongDateTranslationBuilder(MONTH) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceYearFormat(Object obj) {
    synchronized (referenceYear) {
      return referenceYear.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceYear = new EzLongDateTranslationBuilder(YEAR) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceMonthAndYearFormat(Object obj) {
    synchronized (referenceMonthAndYear) {
      return referenceMonthAndYear.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceMonthAndYear = new EzLongDateTranslationBuilder(MONTH+YEAR) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceWithDOWFormat(Object obj) {
    synchronized (referenceWithDOW) {
      return referenceWithDOW.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceWithDOW = new EzLongDateTranslationBuilder(DOW+DAY+MONTH+YEAR) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceDOWFormat(Object obj) {
    synchronized (referenceDOW) {
      return referenceDOW.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceDOW = new EzLongDateTranslationBuilder(DOW) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  static String referenceDOMFormat(Object obj) {
    synchronized (referenceDOM) {
      return referenceDOM.format(obj); 
    }
  }
  private static final EzLongDateTranslationBuilder referenceDOM = new EzLongDateTranslationBuilder(DAY) {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };

  public EzLongDateTranslationBuilder() {
    super();
  }
  public EzLongDateTranslationBuilder(int display) {
    super(display);
  }

  @Override
  public String formatSeparator() {
    return " ";
  }

  @Override
  public String formatDOW(int dow) {
    return dowLongTexts[dow];
  }

  @Override
  public String formatMOY(int moy) {
    return moyLongTexts[moy];
  }

  @Override
  public String formatYear(int year) {
    return IntegerCache.toString(year);
  }
}

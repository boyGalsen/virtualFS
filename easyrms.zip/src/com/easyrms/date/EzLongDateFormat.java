package com.easyrms.date;

import com.easyrms.util.*;

import java.text.*;


public class EzLongDateFormat extends EzDateFormat {
  
  public static String formatDurationTime(long timeDurationInMilliseconds) {
    final long timeDurationInSeconds = timeDurationInMilliseconds/1000;
    final long days = timeDurationInSeconds/(60*60*24);
    final long hours = (timeDurationInSeconds%(60*60*24))/(60*60);
    final long minutes = (timeDurationInSeconds%(60*60))/(60);
    final long seconds = (timeDurationInSeconds%(60));
    return ""
      +(days > 0 
         ? days+" "+(days != 1 ? "Days" : "Day")+" " 
         : "")
      +(hours > 0 
         ? hours+" "+(hours != 1 ? "Hours" : "Hour")+" " 
         : "")
      +(minutes > 0 
         ? minutes+" "+(minutes != 1 ? "Minutes" : "Minute")+" " 
         : "")
      +(seconds >= 0 
         ? seconds+" "+(seconds != 1 ? "Seconds" : "Second")+" " 
         : "");
  }
  
  public static String formatElapsedTime(long timeElapsedInMilliseconds) {
    final long inMinutes = timeElapsedInMilliseconds/(60*1000);
    if (inMinutes < 1) {
      return nowLabel;
    }
    if (inMinutes < 60) {
      return inMinutes+" "+(inMinutes == 1 ? minuteLongLabel : minutesLongLabel)+" "+agoLabel;
    }
    final long inHours = timeElapsedInMilliseconds/(60*60*1000);
    if (inHours < 24) {
      return inHours+ " "+ (inHours == 1 ? hourLongLabel : hoursLongLabel)+" "+agoLabel;
    }
    final long inDays = timeElapsedInMilliseconds/(24*60*60*1000);
    if (inDays < 7) {
      return inDays+ " "+(inDays == 1 ? dayLongLabel : daysLongLabel)+" "+agoLabel;
    }
    final int inWeeks = (int)(inDays / 7);
    if (inWeeks <= 5) {
      return inWeeks +" "+(inWeeks == 1 ? weekLongLabel : weeksLongLabel)+" "+agoLabel;
    }
    final int inMonths = (int)(inDays / 30);
    if (inDays <= 365) {
      return inMonths+" "+(inMonths == 1 ? monthLongLabel : monthsLongLabel)+" "+agoLabel;
    }
    final int inYears = (int)(inDays / 365);
    return inYears+" "+(inYears == 1 ? yearLongLabel : yearsLongLabel)+" "+agoLabel;    
  }
  
  
  public static String referenceUnBreakFormat(Object obj) {
    synchronized (referenceUnBreak) {
      return referenceUnBreak.format(obj); 
    }
  }

  
  private static final EzLongDateFormat referenceUnBreak = new EzLongDateFormat() {
    
    @Override
		public void setDisplay(int display) {
			throw new UnsupportedOperationException();
		}
    
    @Override
		public String formatSeparator() { return "&nbsp;"; }
	};

  public static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  public static StringBuffer referenceFormat(Object obj, StringBuffer buff, FieldPosition pos) {
    return reference.get().format(obj, buff, pos); 
  }
  public static String referenceFormatDOW(int obj) {
    return reference.get().formatDOW(obj); 
  }
  public static String referenceFormatWOY(int obj) {
    return reference.get().formatWOY(obj); 
  }
  public static EzLongDateFormat referenceClone() {
    return new EzLongDateFormat() {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  private static final ThreadLocal<EzLongDateFormat> reference = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return referenceClone();
    }
  };

  public static String referenceWeekFormat(Object obj) {
    return referenceWeek.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceWeek = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat() {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceMonth = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat(MONTH) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceYearFormat(Object obj) {
    return referenceYear.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceYear = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat(YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceMonthAndYear = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat(MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceWithDOWFormat(Object obj) {
    return referenceWithDOW.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceWithDOW = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat(DOW+DAY+MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceDOW = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat(DOW) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referencePeriodAndYearFormat(PeriodManager manager, EzDate obj) {
    if (manager == null || EzMonth.manager.equals(manager)) {
      return referenceMonthAndYear.get().format(obj); 
    }
    else if (EzYear.manager.equals(manager)) {
      return referenceYear.get().format(obj); 
    }
    else {
      final PeriodManager yearManager = manager.getYearManager();
      final Period period = manager.getPeriod(obj);
      if (yearManager == null) {
        return reference.get().format(period)+" "+referenceYear.get().format(period.getFirstDay());
      }
      final Period year = yearManager.getPeriod(obj);
      if (year.getFirstDay().getEzMonth().getLastDay().getYear() == year.getLastDay().getEzMonth().getFirstDay().getYear()) {
        return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay());
      }
      return referenceWithoutYear.get().format(period)+" "+referenceYear.get().format(year.getFirstDay())+"-"+referenceYear.get().format(year.getLastDay());
    }
  }
  
  public static EzLongDateFormat referenceWithoutYearClone() {
    return new EzLongDateFormat(DAY | MONTH) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  
  private static final ThreadLocal<EzLongDateFormat> referenceWithoutYear = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return referenceWithoutYearClone();
    }
  };
  
  
  public static String referenceDOMFormat(Object obj) {
    return referenceDOM.get().format(obj); 
  }
  
  private static final ThreadLocal<EzLongDateFormat> referenceDOM = new ThreadLocal<EzLongDateFormat>() {

    @Override
    protected EzLongDateFormat initialValue() {
      return new EzLongDateFormat(DAY) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };

  public EzLongDateFormat() {
    super();
  }
  public EzLongDateFormat(int display) {
    super(display);
  }

  @Override
  public String formatSeparator() {
    return " ";
  }

  @Override
  public String formatDOW(int dow) {
    return dowLongTexts[dow];
  }

  @Override
  public String formatMOY(int moy) {
    return moyLongTexts[moy];
  }

  @Override
  public String formatYear(int year) {
    return IntegerCache.toString(year);
  }
  
  private static final String nowLabel = "Now";  
  private static final String minutesLongLabel = "Minutes";
  private static final String minuteLongLabel = "Minute";
  private static final String hourLongLabel = "Hour";
  private static final String hoursLongLabel = "Hours";
  private static final String dayLongLabel = "Day";
  private static final String daysLongLabel = "Days";
  private static final String weekLongLabel = "Week";
  private static final String weeksLongLabel = "Weeks";
  private static final String monthLongLabel = "Month";
  private static final String monthsLongLabel = "Months";
  private static final String yearLongLabel = "Year";
  private static final String yearsLongLabel = "Years";
  private static final String agoLabel = "Ago";
}

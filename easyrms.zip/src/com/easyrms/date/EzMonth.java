package com.easyrms.date;

import java.io.*;
import java.util.*;


public final class EzMonth extends AbstractPeriod implements Serializable {

  public static EzMonth valueOf(int id) {
    final int ID = id-minID;
    if (ID >= 0 && ID < cache.length) {
      return cache[ID];
    }
    return new EzMonth(id);
  }

  public static EzMonth valueOf(Date date) {
    return EzDate.valueOf(date).getEzMonth();
  }
  
  public static EzMonth getEzMonth(int year, int moy) {
  	return EzDate.getEzDate(year, moy, 1).getEzMonth();
  }

  private EzMonth(int id) {
    super(id);
    if (id <= 0 || id > EzDate.MAX_MONTH) {
      throw new IllegalArgumentException("id="+id);
    }
  }

  public int getMonth() {
    return id;
  }
  public int getMOY() {
    return 1 + ((id-1)%12);
  }
  @Override
  public int getYear() {
    return EzDate.REFERENCE_YEAR+(id-1)/12;
  }
  public int getDIM() {
    switch (getMOY()) {
      case EzDate.JANUARY:
      case EzDate.MARCH:
      case EzDate.MAY:
      case EzDate.JULY:
      case EzDate.AUGUST:
      case EzDate.OCTOBER:
      case EzDate.DECEMBER:
        return 31;

      case EzDate.APRIL:
      case EzDate.JUNE:
      case EzDate.SEPTEMBER:
      case EzDate.NOVEMBER:
        return 30;

      case EzDate.FEBRUARY:
        return ((getYear() % 4) == 0) ? 29 : 28;

      default:
        throw new IllegalStateException("MOY="+getMOY());
    }
  }

  public EzDate getFirstDay() {
    if (firstDay != null) {
      return firstDay;
    }
    synchronized (this) {
      if (firstDay == null) {
        firstDay = EzDate.getEzDate(getYear(), getMOY(), 1);
      }
    }
    return firstDay;
  }
  @Override
  public EzDate getLastDay() {
    if (lastDay != null) {
      return lastDay;
    }
    synchronized (this) {
      if (lastDay == null) {
        lastDay = EzDate.getEzDate(getYear(), getMOY(), getDIM());
      }
    }
    return lastDay;
  }

  public int getDayCount() {
    return getDIM();
  }

  public EzMonth add(int months) {
    return (months == 0) 
      ? this
      : valueOf(id+months);
  }

  public int sub(EzMonth other) {
    return this.id-other.id;
  }
  
	public EzMonth getPreviousYearEzMonth(int nbOfYears) {
		return valueOf(id-nbOfYears*12);
	}
  @Override
	public Period getPreviousYear(int nbOfYears) {
		return getPreviousYearEzMonth(nbOfYears);
	}

  public PeriodManager getManager() {
    return manager;
  }

  @Override
  public String toString() {
    return "["+id+","+EzStandardDateFormat.referenceFormatMOY(getMOY())+" "+getYear()+"]";
  }

  public static EzMonth max(EzMonth a, EzMonth b) {
    return (a == null || (b != null && a.id < b.id)) ? b : a;
  }
  public static EzMonth min(EzMonth a, EzMonth b) {
    return (a == null || (b != null && a.id > b.id)) ? b : a;
  }

  public boolean isStrictlyBefore(EzMonth other) {
    return (id < other.id);
  }
  public boolean isStrictlyBefore(int other) {
    return (id < other);
  }
  public boolean isBefore(EzMonth other) {
    return (id <= other.id);
  }
  public boolean isBefore(int other) {
    return (id <= other);
  }
  public boolean isAfter(EzMonth other) {
    return (id >= other.id);
  }
  public boolean isAfter(int other) {
    return (id >= other);
  }
  public boolean isStrictlyAfter(EzMonth other) {
    return (id > other.id);
  }
  public boolean isStrictlyAfter(int other) {
    return (id > other);
  }

  public Object readResolve() {
    return valueOf(id);
  }
  
  private transient volatile EzDate firstDay;
  private transient volatile EzDate lastDay;
  
  public static final PeriodManager manager = new AbstractPeriodManager("Month", EzYear.manager, EzDate.manager) {

    public Period getPeriod(int id) { return EzMonth.valueOf(id); }
    public Period getPeriod(EzDate day) { return day.getEzMonth(); }
  };

  private static final EzMonth[] cache;
  static final int minID;
  static {
    final int cacheSize = 12*(EzDate.defaultCacheSize/365);
    cache = new EzMonth[cacheSize];
    minID = EzDate.valueOf(EzDate.minID).getMonth();
    for (int i = 0; i < cacheSize; i++) {
      cache[i] = new EzMonth(minID+i);
    }
  }

  static final long serialVersionUID = -5763377316518517940L;
  
  public static final EzMonth[] noEzMonths = new EzMonth[0];
}
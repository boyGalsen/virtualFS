package com.easyrms.date;

import java.text.*;

import com.easyrms.util.format.AbstractFormat;

public class UpdatedOnStandardDateFormat extends AbstractFormat {

  public static String referenceFormat(Object obj) {
    return reference.get().format(obj);
  }

  public static UpdatedOnStandardDateFormat referenceClone() {
    return new UpdatedOnStandardDateFormat(false);
  }
  
  private static final ThreadLocal<UpdatedOnStandardDateFormat> reference = new ThreadLocal<UpdatedOnStandardDateFormat>() {

    @Override
    protected UpdatedOnStandardDateFormat initialValue() {
      return referenceClone();
    }
    
  };

  public static String referenceWithMilliSecondsFormat(Object obj) {
    return referenceWithMilliSeconds.get().format(obj);
  }

  public static UpdatedOnStandardDateFormat referenceWithMilliSecondsClone() {
    return new UpdatedOnStandardDateFormat(true);
  }
  
  private static final ThreadLocal<UpdatedOnStandardDateFormat> referenceWithMilliSeconds = new ThreadLocal<UpdatedOnStandardDateFormat>() {

    @Override
    protected UpdatedOnStandardDateFormat initialValue() {
      return referenceWithMilliSecondsClone();
    }
    
  };

  protected UpdatedOnStandardDateFormat(boolean isWithMilliSeconds) {
    this.isWithMilliSeconds = isWithMilliSeconds;
  }

  @Override
  public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
    if (obj != null) {
      if (obj instanceof DateAccessor) {
        obj = ((DateAccessor)obj).toDate();
      }
      EzStandardDateTranslationFormat.referenceFormat(obj, toAppendTo, pos);
      toAppendTo.append(" ");
      if (isWithMilliSeconds) {
        EzDateTranslationFormat.timeWithMilliSecondsFormat(obj, toAppendTo, pos);
      }
      else {
        EzDateTranslationFormat.timeFormatFormat(obj, toAppendTo, pos);
      }
    }
    return toAppendTo;
  }

  private final boolean isWithMilliSeconds;
  
  public static final String updatedOnLabel = UpdatedOnDateFormat.updatedOnLabel;

}
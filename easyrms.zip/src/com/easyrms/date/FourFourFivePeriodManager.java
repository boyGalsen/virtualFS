package com.easyrms.date;

import com.easyrms.cache.*;
import com.easyrms.util.*;


public class FourFourFivePeriodManager extends AbstractCachePeriodManager {

  public FourFourFivePeriodManager(String name, EzDate day1) {
    super(name, EzDate.now().getDay()/30, 50);
    this.day1 = day1;
    this.dow = 1;
    this.is445 = true;
  }
  public FourFourFivePeriodManager(String name, int day1, int dow) {
    super(name, EzDate.now().getDay()/30, 50);
    this.day1 = EzDate.valueOf(Math.abs(day1));
    this.dow = dow;
    this.is445 = (day1 > 0);
  }

  @Override
  protected final Period newPeriod(int id) {
    final int poy = id % 12;
    final int year = id / 12;
    if (poy == 0) {
      final EzDate followingMonday = EzDate.getEzDate(1990+year, day1.getMOY(), day1.getDOM()).getEzWeek().getFirstDay().add(dow-1);
      final String name = EzDateFormat.moyThreeLetterTexts[followingMonday.add(14).getMOY()];
      return new SimplePeriod(this, id, IntegerCache.toString(poy+1)+"-"+name, followingMonday, is445 ? 4*7 : 5*7);
    }
    final Period firstPeriodInYear = getPeriod(year*12);
    int weekOffset = is445 ? 4 : 5;
    int weekCount = 0;
    for (int i = 0; i < poy; i++) {
      weekOffset += weekCount;
      weekCount = ((i % 3) == (is445 ? 1 : 2)) ? 5 : 4;
    }
    if (poy == 11) {
      final Period nextYearPeriod = getPeriod((year+1)*12);
      final int lastPeriodWeekCount = nextYearPeriod.getFirstDay().getWeek()
        - firstPeriodInYear.getFirstDay().getWeek()
        - weekOffset;
      if (lastPeriodWeekCount != weekCount) {
        weekCount++;
        if (lastPeriodWeekCount != weekCount) {
          throw new UnsupportedOperationException();
        }
      }
    }
    final EzDate firstDay = firstPeriodInYear.getFirstDay().add(7*weekOffset);
    final String name = EzDateFormat.moyThreeLetterTexts[firstDay.add(14).getMOY()];
    return new SimplePeriod(this, id, IntegerCache.toString(poy+1)+"-"+name, firstDay, weekCount*7);
  }

  @Override
  public boolean equals(Object object) {
    return (this == object
      || (super.equals(object) && ((FourFourFivePeriodManager)object).day1.equals(this.day1)));
  }

  @Override
  public int hashCode() {
    return day1.getDay();
  }

  private static final Cache<Tuple3<String, Integer, Integer>, PeriodManager> cache = Caches.newManagerInstance(
    (key) -> {
      final String name = key.get0();
      final int period1 = key.get1().intValue();
      final int dow = key.get2().intValue();
      return new FourFourFivePeriodManager(name, period1, dow);              
    });
  public static final PeriodManager getInstance(String name, int period1, int dayCount) {
    return cache.get(Tuple.getTuple(name, IntegerCache.get(period1), IntegerCache.get(dayCount)));
  }

  private final EzDate day1;
  private final int dow;
  private final boolean is445;
}

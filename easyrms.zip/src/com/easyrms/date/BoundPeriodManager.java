package com.easyrms.date;



public class BoundPeriodManager extends AbstractPeriodManager {

  BoundPeriodManager(String name, SimplePeriod[] periods) {
    super(name);
    for (int i = 0, n = periods.length; i < n; i++) {
      periods[i].manager = this;
    }
    this.periods = periods;
  }
  public BoundPeriodManager(String name, EzDate[] starts, String[] names) {
    super(name);
    final int periodCount = names.length;
    this.periods = new Period[periodCount];
    for (int i = 0; i < periodCount; i++) {
      final EzDate startsI = starts[i];
      periods[i] = new SimplePeriod(this, i+1, names[i], startsI, starts[i+1].sub(startsI));
    }
  }
  
  public Duration getBoundDuration() {
    return SimpleDuration.findDuration(
      periods[0],
      periods[periods.length-1]);
  }
  
  public Period getPeriod(int id) {
    return periods[id-periods[0].getID().intValue()];
  }

  public Period getPeriod(EzDate day) {
    final int periodCount = periods.length;
    final Period left = periods[0];
    if (day.isStrictlyBefore(left)) return null;
    final Period right = periods[periodCount-1];
    if (day.isStrictlyAfter(right)) return null;
    return getPeriod(0, left, periodCount-1, right, day);
  }
  public Period getPeriod(int leftIndex, Period left, int rightIndex, Period right, EzDate day) {
    if (leftIndex == rightIndex) return left;
    final float horizon = right.getLastDay().sub(left.getFirstDay())+1;
    final float offset = day.sub(left.getFirstDay());
    int midIndex = Math.round(leftIndex + offset/horizon);
    final Period mid = periods[midIndex];
    if (day.isStrictlyBefore(mid)) return getPeriod(leftIndex, left, midIndex-1, periods[midIndex-1], day);
    if (day.isStrictlyAfter(mid)) return getPeriod(midIndex+1, periods[midIndex+1], rightIndex, right, day);
    return mid;
  }

  private final Period[] periods;
}

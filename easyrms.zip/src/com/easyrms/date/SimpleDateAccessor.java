package com.easyrms.date;

import java.util.*;


public class SimpleDateAccessor implements DateAccessor {
  
  public static SimpleDateAccessor getSimpleDateAccessor(Date date) {
    return (date == null) ? null : new SimpleDateAccessor(date);
  }
  
  public SimpleDateAccessor(Date date) {
    this.time = date.getTime();
    this.date = date;
  }

  public SimpleDateAccessor(long time) {
    this.time = time;
    this.date = new Date(time);
  }

  public long getTime() {
    return time;
  }

  public Date toDate() {
    return date;
  }
  
  private final Date date;
  private final long time;
}

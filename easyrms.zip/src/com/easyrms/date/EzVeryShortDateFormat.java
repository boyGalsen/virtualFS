package com.easyrms.date;

public class EzVeryShortDateFormat extends EzDateFormat {

  public static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj); 
    }
  }
  private static final EzVeryShortDateFormat reference = new EzVeryShortDateFormat() {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceMonthFormat(Object obj) {
    synchronized (referenceMonth) {
      return referenceMonth.format(obj); 
    }
  }
  private static final EzVeryShortDateFormat referenceMonth = new EzVeryShortDateFormat(MONTH) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceMonthAndYearFormat(Object obj) {
    synchronized (referenceMonthAndYear) {
      return referenceMonthAndYear.format(obj); 
    }
  }
  private static final EzVeryShortDateFormat referenceMonthAndYear = new EzVeryShortDateFormat(MONTH+YEAR) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };
  
  public static String referenceDOWFormat(Object obj) {
    synchronized (referenceDOW) {
      return referenceDOW.format(obj); 
    }
  }
  private static final EzVeryShortDateFormat referenceDOW = new EzVeryShortDateFormat(DOW) {
    
  	@Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };

  public EzVeryShortDateFormat() {
    super();
  }
  public EzVeryShortDateFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return "-";
  }
	@Override
  public String formatDOW(int dow) {
    return dowShortTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyShortTexts[moy];
  }
}
package com.easyrms.date;

import com.easyrms.util.*;

import java.text.*;
import java.util.*;


public class EzDDMMYYDateFormat extends EzDateFormat {

  public static EzDDMMYYDateFormat referenceDayClone() {
    return new EzDDMMYYDateFormat(DAY) {
      
      @Override
      public void setDisplay(int display) {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  public EzDDMMYYDateFormat() {
    super();
  }
  public EzDDMMYYDateFormat(int display) {
    super(display);
  }
  public EzDDMMYYDateFormat(String separator) {
    super();
    this.separator = separator;
  }
  public EzDDMMYYDateFormat(int display, String separator) {
    super(display);
    this.separator = separator;
  }

  @Override
  public final String formatSeparator() {
    return separator;
  }

  public EzDate parse(int source) {
    final int year;
    if (isYearDisplayed()) {
      final int y = source % 100;
      source /= 100;
      year = (y < 90) ? y+2000 : y+1900;
    }
    else {
      year = EzDate.valueOf(new Date()).getYear();
    }
    final int month;
    if (isMonthDisplayed()) {
      month = source % 100;
      source /= 100;
    }
    else {
      month = 1;
    }
    final int day;
    if (isDayDisplayed()) {
      day = source;
    }
    else {
      day = 1;
    }
    return EzDate.getEzDate(year, month, day);
  }
  public EzDate parse(Integer source) {
    return (source != null) ? parse(source.intValue()) : null;
  }
  @Override
  protected StringBuffer format(
    EzDate date, StringBuffer toAppendTo,
    boolean isDOWDisplayed, boolean isDayDisplayed, boolean isMonthDisplayed, boolean isYearDisplayed)
  {
    if (isYearDisplayed) {
      toAppendTo.append(yyFigures[date.getYear()%100]);
    }
    if (isMonthDisplayed) {
      if (isYearDisplayed && separator != null) {
        toAppendTo.append(separator);
      }
      toAppendTo.append(moyFigures[date.getMOY()]);
    }
    if (isDayDisplayed)   {
      if ((isMonthDisplayed || isYearDisplayed)&& separator != null) {
        toAppendTo.append(separator);
      }
      toAppendTo.append(domFigures[date.getDOM()]);
    }
    return toAppendTo;
  }

  @Override
  public EzDate parse(String source, ParsePosition status) throws ParseException {
    final int separatorLength = (separator == null) ? 0 : separator.length();
    int index = status.getIndex();
    if (source != null) {
      try {
        final StringBuilderThreadPool pool = StringBuilderThreadPool.threadPools.get();
        final StringBuilder buffer = pool.get();
        try {
          if (isDayDisplayed())  {
            buffer.append(source.substring(index, index+2));
            index += 2 + separatorLength;
          }
          if (isMonthDisplayed()) {
            buffer.append(source.substring(index, index+2));
            index += 2 + separatorLength;
          }
          if (isYearDisplayed()) {
            buffer.append(source.substring(index, index+2));
            index += 2 + separatorLength;
          }
          final EzDate date = parse(Integer.parseInt(buffer.toString()));
          status.setIndex(index);
          return date;
        }
        finally {
          pool.free(buffer);
        }
      }
      catch (Throwable ignored) {
      }
    }
    status.setErrorIndex(status.getIndex());
    throw new ParseException("Not an EzDate", status.getIndex());
  }

  private String separator;
}
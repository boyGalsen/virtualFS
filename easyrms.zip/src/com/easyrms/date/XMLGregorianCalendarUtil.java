package com.easyrms.date;

import com.easyrms.util.*;

import java.util.*;
import javax.xml.datatype.*;

public class XMLGregorianCalendarUtil {

  public static EzDate getEzDate(XMLGregorianCalendar xmlDate) {
    if (xmlDate == null) return null;
    return EzDate.getEzDate(xmlDate.getYear(),xmlDate.getMonth(),xmlDate.getDay());
  }

  public static XMLGregorianCalendar getXMLDate(EzDate ezDate) {
    if (ezDate == null) return null;
    final Calendar g = GregorianCalendar.getInstance();
    g.setTime(ezDate.getTime().toDate());
    try {
      return DatatypeFactory.newInstance().newXMLGregorianCalendar(
      g.get(Calendar.YEAR), 
      g.get(Calendar.MONTH)+1, 
      g.get(Calendar.DAY_OF_MONTH), 
      0, 
      0, 
      0,
      DatatypeConstants.FIELD_UNDEFINED,
      DatatypeConstants.FIELD_UNDEFINED);
    }
    catch (Throwable toForward) {
      throw ExceptionUtils.newRuntimeException(toForward);
    }  
  }

  public static XMLGregorianCalendar getXMLDate(Date time) {
    if (time == null) return null;
    final Calendar g = GregorianCalendar.getInstance();
    g.setTime(time);
    try {
      return DatatypeFactory.newInstance().newXMLGregorianCalendar(
        g.get(Calendar.YEAR), 
        g.get(Calendar.MONTH)+1, 
        g.get(Calendar.DAY_OF_MONTH), 
        g.get(Calendar.HOUR_OF_DAY), 
        g.get(Calendar.MINUTE), 
        g.get(Calendar.SECOND), 
        g.get(Calendar.MILLISECOND), 
        DatatypeConstants.FIELD_UNDEFINED);
    }
    catch (Throwable toForward) {
      throw ExceptionUtils.newRuntimeException(toForward);
    }
  }
  
  public static XMLGregorianCalendar getXMLDate(DateAccessor time) {
    if (time == null) return null;
    final Calendar g = GregorianCalendar.getInstance();
    g.setTime(time.toDate());
    try {
      return DatatypeFactory.newInstance().newXMLGregorianCalendar(
      g.get(Calendar.YEAR), 
      g.get(Calendar.MONTH)+1, 
      g.get(Calendar.DAY_OF_MONTH), 
      g.get(Calendar.HOUR_OF_DAY), 
      g.get(Calendar.MINUTE), 
      g.get(Calendar.SECOND), 
      g.get(Calendar.MILLISECOND), 
      DatatypeConstants.FIELD_UNDEFINED);
    }
    catch (Throwable toForward) {
      throw ExceptionUtils.newRuntimeException(toForward);
    }
  }
}

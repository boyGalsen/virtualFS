package com.easyrms.date;

import com.easyrms.util.*;

public class EzShortDateFormat extends EzDateFormat {

  public static String referenceFormat(Object obj) {
    return reference.get().format(obj); 
  }
  
  private static final ThreadLocal<EzShortDateFormat> reference = new ThreadLocal<EzShortDateFormat>() {

    @Override
    protected EzShortDateFormat initialValue() {
      return new EzShortDateFormat() {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };

  
  public static String referenceMonthFormat(Object obj) {
    return referenceMonth.get().format(obj); 
  }
  
  private static final ThreadLocal<EzShortDateFormat> referenceMonth = new ThreadLocal<EzShortDateFormat>() {

    @Override
    protected EzShortDateFormat initialValue() {
      return new EzShortDateFormat(MONTH) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };

  public static String referenceMonthAndYearFormat(Object obj) {
    return referenceMonthAndYear.get().format(obj); 
  }
  
  public static String formatDurationTime(long timeDurationInMilliseconds) {
    if (timeDurationInMilliseconds < 0) {
      throw new IllegalArgumentException("timeDurationInMilliseconds " + timeDurationInMilliseconds + " < 0 ");
    }
    final long timeDurationInSeconds = timeDurationInMilliseconds/1000;
    final long seconds = (timeDurationInSeconds%(60));
    final long minutes = (timeDurationInSeconds%(60*60))/(60);
    final long hours = (timeDurationInSeconds%(60*60*24))/(60*60);
    final long days = timeDurationInSeconds/(60*60*24);
    return "-"+((days > 0) 
      ? (days < 10) ? domFigures[MathUtils.getLong(days).intValue()]+"d" : days +"d" 
      : (hours > 0) 
        ? (hours < 10) ? domFigures[MathUtils.getLong(hours).intValue()]+"h" : hours+"h" 
        : (minutes > 0) 
          ? (minutes < 10) ? domFigures[MathUtils.getLong(minutes).intValue()]+"m" : minutes+"m" 
          : (seconds >= 0) 
            ? (seconds < 10) ? domFigures[MathUtils.getLong(seconds).intValue()]+"s" : seconds + "s" 
            : "");
  }
  
 
  private static final ThreadLocal<EzShortDateFormat> referenceMonthAndYear = new ThreadLocal<EzShortDateFormat>() {

    @Override
    protected EzShortDateFormat initialValue() {
      return new EzShortDateFormat(MONTH+YEAR) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };
  
  public static String referenceDOWFormat(Object obj) {
    return referenceDOW.get().format(obj); 
  }
  
  private static final ThreadLocal<EzShortDateFormat> referenceDOW = new ThreadLocal<EzShortDateFormat>() {

    @Override
    protected EzShortDateFormat initialValue() {
      return new EzShortDateFormat(DOW) {
        
        @Override
        public void setDisplay(int display) {
          throw new UnsupportedOperationException();
        }
      };
    }
  };

  public EzShortDateFormat() {
    super();
  }
  public EzShortDateFormat(int display) {
    super(display);
  }

	@Override
  public String formatSeparator() {
    return "-";
  }
	@Override
  public String formatDOW(int dow) {
    return dowLetterTexts[dow];
  }

	@Override
  public String formatMOY(int moy) {
    return moyShortTexts[moy];
  }
}
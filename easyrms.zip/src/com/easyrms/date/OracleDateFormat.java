package com.easyrms.date;

import com.easyrms.util.IntegerCache;


public class OracleDateFormat extends EzDateFormat {

  public static String referenceFormat(Object obj) {
    synchronized (reference) {
      return reference.format(obj); 
    }
  }
  private static final OracleDateFormat reference = new OracleDateFormat() {
    
    @Override
    public void setDisplay(int display) {
      throw new UnsupportedOperationException();
    }
  };

  public OracleDateFormat() {
    super(DAY+MONTH+YEAR);
  }

  @Override
  public String formatSeparator() {
    return "-";
  }
  
  @Override
  public String formatMOY(int moy) {
    return moyFigures[moy];
  }

  @Override
  public String formatYear(int year) {
    return IntegerCache.toString(year);
  }
  
  @Override
  protected StringBuffer format(
    EzDate date,
    StringBuffer toAppendTo,
    boolean isDOWDisplayed,
    boolean isDayDisplayed,
    boolean isMonthDisplayed,
    boolean isYearDisplayed) 
  {
    toAppendTo.append("TO_DATE('");
    super.format(date, toAppendTo, isDOWDisplayed, isDayDisplayed, isMonthDisplayed, isYearDisplayed);
    toAppendTo.append("','DD-MM-YYYY')");
    return toAppendTo;
  }
}
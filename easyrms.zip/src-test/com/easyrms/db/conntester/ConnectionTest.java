/*
 * Copyright (c) 2016 Infor.  All rights reserved.
 */
package com.easyrms.db.conntester;

import com.easyrms.db.EzDBResultSetListener;
import com.easyrms.db.EzJDBCConnection;
import com.easyrms.db.EzJDBCDatabase;
import com.easyrms.db.SQLUtils;
import com.easyrms.db.SimpleModify;
import com.easyrms.util.array.ObjectArrays;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

// TODO: investigate JDBC connection for more info
//        2.	https://docs.oracle.com/cd/E18283_01/appdev.112/e13995/oracle/jdbc/pool/OracleDataSource.html
//a.	getConnectionProperties()
//b.	getDatabaseName()
//c.	getDataSourceName()
//d.	getDescription()
//
// Where SimpleRequest is called without closing the connection after each SQL:
//   com.ezrms.load.fastbooking.FastBookingDatabaseLoader.loadSnapshot(EzDBTransaction, String, SnapshotAccessor, EzDate, String, boolean)
// Very probably here, loaded from context:
//   com.ezrms.hotel.deal.db.DBDeal.loadShoulders()
// Where it is always closed:
//   DBSchema.java:141, org.openknows.jdbc.ldd.DBSchema.tables.new AutoCreateReference() {...}.create()
//
/**
 * Tester for EzRMS database connection.
 *
 * @author Petr Aubrecht
 */
public class ConnectionTest {

    private static final String LOGFILE = "connectiontest.log";

    private final String databaseName = "testedDB";
    private String databaseUrl = "jdbc:oracle:thin:yield/yieldboss@nlbavlezrmsdb:1521:DB11G"; // AzatDB
//    private String databaseUrl = "jdbc:oracle:thin:yield/yieldboss@bdd3-easyrms.integra.fr:1525:EZRMS"; // PRODUCTION!!!
    private int poolSize = 1;

    private PrintWriter log;
    private Scanner input;

    public static void main(String[] args) {
        try {
            new ConnectionTest().run(args);
        } catch (IOException ex) {
            Logger.getLogger(ConnectionTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.exit(0);
    }

    public void run(String[] args) throws IOException {
        input = new Scanner(System.in, "utf-8");
        openLog();
        printlnAndLog("Usage: ConnectionTest [<url> [<poolsize>]]");
        printlnAndLog("Example: ConnectionTest jdbc:oracle:thin:yield/yieldboss@bdd3-easyrms.integra.fr:1525:EZRMS 7");
        printlnAndLog("");
        if (args.length > 0) {
            databaseUrl = args[0];
        }
        if (args.length > 1) {
            poolSize = Integer.parseInt(args[1]);
        }

        printHeader("CONNECTING...");
        final EzJDBCDatabase database = new EzJDBCDatabase(databaseName, databaseName, databaseUrl, true, poolSize, -1);
        EzJDBCConnection connection = database.openAccess();
        //System.out.println(database.trace);

        printlnAndLog("Tested URL: " + databaseUrl);

        printHeader("CONNECTED");
        displaySessionInfo(connection);
        printlnAndLog("");

        printlnAndLog("Prepaing test table hotel.test_fo_hotels - dropping old one (ignore, if it fails)...");
        runCommand(database, "DROP TABLE hotel.test_fo_hotels");

        printlnAndLog("Prepaing test table hotel.test_fo_hotels - creating...");
        runCommand(database, "CREATE TABLE hotel.test_fo_hotels NOLOGGING AS SELECT * FROM hotel.hotels");
        printlnAndLog("Prepaing test table hotel.test_fo_hotels - done");

        boolean keepInMenu = true;

        while (keepInMenu) {
            printHeader("MENU");
            displaySessionInfo(connection);
            printlnAndLog("s - test SELECT");
            printlnAndLog("u - test UPDATE");
            printlnAndLog("c - close connection");
            printlnAndLog("n - create new connection");
            printlnAndLog("x - clean up & exit");
            String command = wait4Key("Enter selection");
            try {
                switch (command.toLowerCase()) {
                    case "s":
                        doSelectTest(connection);
                        break;
                    case "u":
                        doUpdateTest(database, connection);
                        break;
                    case "c":
                      connection.close();
                      break;
                    case "n":
                      connection = database.openAccess();
                      break;
                    case "x":
                        keepInMenu = false;
                        break;
                }
            } catch(Exception e) {
                printException(e);
            }
        }

        printlnAndLog("Cleaning up, dropping hotel.test_fo_hotels...");
        runCommand(database, "DROP TABLE hotel.test_fo_hotels");
        printlnAndLog("That's all, folks! Thank you for your attention.");
        closeLog();
    }

    private void displaySessionInfo(final EzJDBCConnection databaseAccess) {
        runQuery(databaseAccess, "SELECT sys_context('USERENV', 'INSTANCE') AS instance#, sys_context('USERENV', 'INSTANCE_NAME') AS instance_name, sys_context('userenv','sessionid') AS session_id FROM dual",
                new EzDBResultSetListener() {
            @Override
            public void set(int i, ResultSet v) throws SQLException {
                printlnAndLog("You are on server '" + SQLUtils.getString(v, 2) + "', #" + SQLUtils.getString(v, 1) + ", session ID " + SQLUtils.getString(v, 3));
            }
        });
        printlnAndLog("Connection Java object: "+databaseAccess.toString());
    }

    private void doSelectTest(final EzJDBCConnection databaseAccess) {
        printlnAndLog("Connection Java object: "+databaseAccess.toString());
        String userInput;
        printHeader("SELECT");
        userInput = wait4Key("Get ready for SELECT from 'test_fo_hotels' (ENTER to continue, 'x' to exit)");
        if (!userInput.equals("x")) {
            runQuery(databaseAccess,
                    "SELECT sys_context('USERENV', 'INSTANCE_NAME') AS instance_name, sys_context('USERENV', 'INSTANCE') AS instance#, sys_context('userenv','sessionid') AS session_id, name FROM hotel.test_fo_hotels",
                    new EzDBResultSetListener() {
                        private boolean wait4User = true;

                        @Override
                        public void set(int i, ResultSet v) throws SQLException {
                            if (wait4User) {
                                printlnAndLog(i
                                        + ". " + SQLUtils.getString(v, 1, "NULL")
                                        + ", " + SQLUtils.getString(v, 2, "NULL")
                                        + ", " + SQLUtils.getString(v, 3, "NULL")
                                        + ", " + SQLUtils.getString(v, 4, "NULL"));
                                if (i % 5 == 4) {
                                    String cmd = wait4Key("Next bunch (ENTER to continue, 'x' to silently scroll to end)");
                                    if ("x".equals(cmd)) {
                                        wait4User = false;
                                    }
                                }
                            }
                        }
            });
        }
        printlnAndLog("Done!");
    }

    private void doUpdateTest(final EzJDBCDatabase databaseLink, final EzJDBCConnection databaseAccess) {
        String userInput;
        printHeader("UPDATE");
        while (true) {
            userInput = wait4Key("Get ready for UPDATE of 'test_fo_hotels' (ENTER to continue, 'x' to exit)");
            if ("x".equalsIgnoreCase(userInput)) {
                break;
            }
            if (!userInput.equals("x")) {
                runCommand(databaseLink,
                        //                    "UPDATE hotel.test_fo_hotels SET display=display+1 RETURNING sys_context('USERENV', 'INSTANCE_NAME') AS instance_name, sys_context('USERENV', 'INSTANCE') AS instance#, sys_context('userenv','sessionid') AS session_id, name, display");
                        "UPDATE hotel.test_fo_hotels SET display=display+1");
            }
            displaySessionInfo(databaseAccess);
        }
        printlnAndLog("Done!");
    }

    private int runCommand(EzJDBCDatabase databaseAccess, String update) {
        printlnAndLog("EXEC: " + update);
        int rows = SimpleModify.commit(databaseAccess, update, ObjectArrays.emptyObjectArray);
        printlnAndLog("EXEC FINISHED: " + rows + " rows affected");
        return rows;
    }

    private boolean runQuery(EzJDBCConnection databaseAccess, String query, EzDBResultSetListener ezDBResultSetListener) {
        return runQuery(databaseAccess, query, ezDBResultSetListener, ObjectArrays.emptyObjectArray);
    }

    private boolean runQuery(EzJDBCConnection databaseAccess, String query, EzDBResultSetListener ezDBResultSetListener, Object[] emptyObjectArray) {
        printlnAndLog("EXEC: " + query);
        boolean success = databaseAccess.query(query, ezDBResultSetListener, emptyObjectArray);
        if (success) {
            printlnAndLog("EXEC SUCCESS");
        } else {
            printlnAndLog("EXEC FAILED:");
            printlnAndLog(ezDBResultSetListener.getException());
        }
        return success;
    }

    private String wait4Key(String message) {
        printlnAndLog(message);
        String userInput = "";
        userInput = input.nextLine();
        log.println(userInput);
        log.flush();
        return userInput;
    }

    private void openLog() throws IOException {
        log = new PrintWriter(new File(LOGFILE), "utf-8");
    }

    private void closeLog() throws IOException {
        log.close();
    }

    private void printlnAndLog(Object msg) {
        msg = new Date() + " " + msg;
        System.out.println(msg);
        log.println(msg);
        log.flush();
    }

    private void printHeader(String msg) {
        printlnAndLog("");
        printlnAndLog("*************************************");
        printlnAndLog("** " + msg);
        printlnAndLog("*************************************");
    }
    
    private void printException(Exception e) {
        e.printStackTrace();
        e.printStackTrace(log);
        log.flush();
    }

}
